package edu.upenn.cis.pdtb.scripts;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.TreeSet;

import edu.upenn.cis.pdtb.PDTBAltLexRelation;
import edu.upenn.cis.pdtb.PDTBEntityRelation;
import edu.upenn.cis.pdtb.PDTBEntityRelationImpl;
import edu.upenn.cis.pdtb.PDTBExplicitRelation;
import edu.upenn.cis.pdtb.PDTBImplicitRelation;
import edu.upenn.cis.pdtb.PDTBNode;
import edu.upenn.cis.pdtb.PDTBRelationImpl;
import edu.upenn.cis.pdtb.PDTBRelationList;
import edu.upenn.cis.pdtb.Span;
import edu.upenn.cis.pdtb.ann.InternalData;
import edu.upenn.cis.pdtb.ann.util.PDTBTask;

public class SortRelations {

	public static void sort(String rawRoot, String ptbRoot, String pdtbRoot,
			String outputRoot, String logFile) throws IOException {

		File logFileFile = new File(logFile);
		final FileWriter logFileHandle = new FileWriter(logFileFile);

		File outputDir = new File(outputRoot);
		outputDir.mkdirs();

		TreeSet relSet = new TreeSet(new Comparator() {
			public int compare(Object o1, Object o2) {
				Span s1 = getSpanForRel(o1);
				Span s2 = getSpanForRel(o2);

				if (s1.getStart() == s2.getStart()) {
					if (s1.getEnd() == s2.getEnd()) {
						try {
							logFileHandle.write(s1.getStart() + ".."
									+ s1.getEnd());
						} catch (IOException ioe) {
							System.err.println("fileerror");
						}
						//return 1;
						return 0;
					}
					return s1.getEnd() - s2.getEnd();
				}

				return s1.getStart() - s2.getStart();
			}

			private Span getSpanForRel(Object rel) {
				if (rel instanceof PDTBExplicitRelation) {
					return (Span) (((PDTBExplicitRelation) rel).getSelection()
							.getSpans().first());
				} else if (rel instanceof PDTBImplicitRelation) {
					int position = ((PDTBImplicitRelation) rel)
							.getInferenceSite().getStringPosition();
					return new Span(position, position);
				} else if (rel instanceof PDTBAltLexRelation) {
					return (Span) (((PDTBAltLexRelation) rel).getSelection()
							.getSpans().first());
				} else if (rel instanceof PDTBEntityRelation) {
					int position = ((PDTBEntityRelation) rel)
							.getInferenceSite().getStringPosition();
					return new Span(position, position);
				} else {
					throw (new IllegalArgumentException("Unexpected type. "
							+ rel.getClass().getName()));
				}
			}

			public boolean equals(Object obj) {
				return false;
			}

		});

		try {

			int badCount = 1;
			for (PDTBTask task = new PDTBTask(rawRoot, ptbRoot, pdtbRoot,
					false, true); task.hasNext();) {
				PDTBRelationList rlist = task.next();

				if(task.getSecNo() == 6 && task.getFileNo() == 8){
					System.out.println("breakpoint after: " + task.getSecNoStr() + task.getFileNoStr());
				}
				
				String secNoStr = task.getSecNoStr();
				String fileNoStr = task.getFileNoStr();

				for (Enumeration iter = rlist.children(); iter
						.hasMoreElements();) {
					PDTBNode node = (PDTBNode) (iter.nextElement());
					if (!relSet.add(node)) {
						logFileHandle.write(": " + secNoStr + fileNoStr + " ("
								+ badCount + ")\n");
						badCount++;
					}
				}
					

				File secDir = new File(outputDir, secNoStr);
				secDir.mkdirs();
				File outputFile = new File(secDir, "wsj_" + secNoStr
						+ fileNoStr + ".pdtb");
				FileWriter fw = new FileWriter(outputFile);
				for (Iterator iter = relSet.iterator(); iter.hasNext();) {
					PDTBNode n = (PDTBNode) (iter.next());
					if (n instanceof PDTBRelationImpl) {
						PDTBRelationImpl rel = (PDTBRelationImpl) n;
						rel.save(fw);
					} else {
						PDTBEntityRelationImpl rel = (PDTBEntityRelationImpl) n;
						rel.save(fw);
					}
					((InternalData) n.getUserObject()).save(fw);
				}				
				
				fw.flush();
				fw.close();
				relSet.clear();

			}
			logFileHandle.flush();
			logFileHandle.close();

		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}

	}

}
