/*
 * SortAndCat.java
 *
 * Created on January 30, 2006, 12:03 PM
 */

package edu.upenn.cis.pdtb.scripts;

import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.ptb.*;
import java.util.*;
import java.io.*;

/**
 *
 * @author  nikhild
 */
public class SortAndCat {
    
    public static final String pdtbRoot = "corpora1-6/alan/pdtb2-0/";
    
    public static final String ptbRoot = "Corpora/PTB/combined/wsj/";
    
    public static final String textRoot = "Corpora/PTB/raw/wsj/";    
    
    /** Creates a new instance of SortAndCat */
    public SortAndCat() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        RelationLoader loader = new RelationLoaderImpl();
        for(int sec = 0; sec < 25; sec++){
            String secNo = (sec < 10)? "0" + sec : "" + sec;
            for(int file = 0; file < 100; file++){
                String fileNo = (file < 10)? "0" + file : "" + file;
                TreeSet relSet = new TreeSet(new Comparator(){
                    public int compare(Object o1, Object o2){
                        Span s1 = getSpanForRel(o1);
                        Span s2 = getSpanForRel(o2);
                        
                        if(s1.getStart() == s2.getStart()){
                            if(s1.getEnd() == s2.getEnd()){
                                throw(new IllegalArgumentException("Duplicate relations " + s1.toString()));
                            }
                            
                            return s1.getEnd() - s2.getEnd();
                        }
                        
                        return s1.getStart() - s2.getStart();
                    }
                    
                    private Span getSpanForRel(Object rel){
                        if(rel instanceof PDTBExplicitRelation){
                            return (Span)(((PDTBExplicitRelation)rel).getSelection().getSpans().first());
                        }
                        else if(rel instanceof PDTBImplicitRelation){
                            int position = ((PDTBImplicitRelation)rel).getInferenceSite().getStringPosition();
                            return new Span(position, position);
                        }
                        else if(rel instanceof PDTBAltLexRelation) { 
                            return (Span)(((PDTBAltLexRelation)rel).getSelection().getSpans().first());
                        }
                        else if(rel instanceof PDTBEntityRelation){
                            int position = ((PDTBEntityRelation)rel).getInferenceSite().getStringPosition();
                            return new Span(position, position);
                        }
                        else{
                            throw(new IllegalArgumentException("Unexpected type. " + rel.getClass().getName()));
                        }
                    }
                    
                    public boolean equals(Object obj){
                        return false;
                    }
                    
                });
                
                try{
                    String rawText = null;
                    PTBTreeNode root = null;
                    
                    for(int set = 1; set < 12; set++){
                        String setNo = "Set" + set;
                        String textFile = args[0] + secNo + "/wsj_" + secNo + fileNo;
                        String ptbFile = args[1] + secNo + "/wsj_" + secNo + fileNo + ".mrg";
                        String pdtbFile = args[2] + setNo + "/" + secNo + "/wsj_" + secNo + fileNo + ".pdtb";
                        File f = new File(pdtbFile);
                        if(f.exists()){
                            System.err.println("Adding: " + setNo + " " + secNo + " " + fileNo);
                            PDTBRelationList relList = loader.loadRelations(textFile, ptbFile, pdtbFile);
                            for(Enumeration e1 = relList.children(); e1.hasMoreElements(); ){
                                relSet.add(e1.nextElement());
                            }
                            
                            for(Enumeration e1 = relList.children(); e1.hasMoreElements(); ){
                                PDTBNode child = (PDTBNode)(e1.nextElement());
                                relList.remove(child);
                            }
                        }
                    }
                    
                    if(relSet.size() > 0){
                        String outputDir = "Corpora/PDTB/PDTB-Flat3/" + secNo;
                        File f = new File(outputDir);
                        f.mkdirs();
                        String outFileName = outputDir + "/" + "wsj_" + secNo + fileNo + ".pdtb";
                        FileWriter writer = new FileWriter(outFileName);
                        
                        PDTBRelationListImpl newRelList = new PDTBRelationListImpl(rawText, root, secNo, fileNo);
                        for(Iterator iter = relSet.iterator(); iter.hasNext();){
                            newRelList.pdtbAddLastChild((PDTBNode)(iter.next()));
                        }
                        newRelList.save(writer);
                        writer.close();
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        }
        
    }
    
}
