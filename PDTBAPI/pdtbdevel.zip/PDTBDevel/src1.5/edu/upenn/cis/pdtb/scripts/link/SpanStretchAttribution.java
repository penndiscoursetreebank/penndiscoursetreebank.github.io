package edu.upenn.cis.pdtb.scripts.link;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

import edu.upenn.cis.pdtb.GornAddressList;
import edu.upenn.cis.pdtb.PDTBAltLexRelationImpl;
import edu.upenn.cis.pdtb.PDTBExplicitRelationImpl;
import edu.upenn.cis.pdtb.PDTBImplicitRelationImpl;
import edu.upenn.cis.pdtb.PDTBNode;
import edu.upenn.cis.pdtb.PDTBRelationList;
import edu.upenn.cis.pdtb.PDTBRelationListImpl;
import edu.upenn.cis.pdtb.SpanList;
import edu.upenn.cis.pdtb.ann.InternalData;
import edu.upenn.cis.pdtb.util.GornAddressUtils;
import edu.upenn.cis.ptb.PTBTreeNode;
import edu.upenn.cis.pdtb.ann.util.PDTBTask;
import edu.upenn.cis.pdtb.xpath.SpanListSizeFunction;

public class SpanStretchAttribution {

	public static void insertGornAddresses(String rawRoot, String ptbRoot,
			String pdtbRoot, String outputRoot, boolean includePunctuation)
			throws IOException {
		File outputDir = new File(outputRoot);
		outputDir.mkdirs();

		for (PDTBTask task = new PDTBTask(rawRoot, ptbRoot, pdtbRoot, true,
				true); task.hasNext();) {
			PDTBRelationList relList = task.next();
			String secNo = task.getSecNoStr();
			String fileNo = task.getFileNoStr();
			File outputSec = new File(outputDir, secNo);
			outputSec.mkdirs();
			File outFile = new File(outputSec, "wsj_" + secNo + fileNo
					+ ".pdtb");
			PTBTreeNode root = relList.getPTBRoot();
			Writer writer = new BufferedWriter(new FileWriter(outFile));
			Vector dummyVect = new Vector();
			for (Enumeration e = relList.children(); e.hasMoreElements();) {
				PDTBNode node = (PDTBNode) (e.nextElement());
				if (node instanceof PDTBExplicitRelationImpl
						|| node instanceof PDTBImplicitRelationImpl
						|| node instanceof PDTBAltLexRelationImpl) {
					InternalData i = (InternalData) (node.getUserObject());
					InternalData temp = new InternalData();
					for (Iterator iter = i.keySet().iterator(); iter.hasNext();) {
						String key = (String) (iter.next());
						temp.putObject(key, i.get(key));
					}

					// Change1
					SpanList sp = SpanListSizeFunction.getSpanListForNode(node,
							true);

					//System.out.println(node.getClass().getName());
					//System.out.println(node instanceof PDTBRelation);

					for (Iterator iter = temp.keySet().iterator(); iter
							.hasNext();) {
						String key = (String) (iter.next());
						if (key.indexOf("AttrSpan") != -1) {
							SpanList value = (SpanList) i.get(key);

							// System.out.println(value);

							GornAddressList gal = SpanStretch
									.getGornAddressList(root, value,
											includePunctuation);
							// Change2
							boolean overlap = sp.isOverlapping(value);

							// Change3
							if (includePunctuation && !overlap) {
								SiblingInclusion.includeSiblings(gal, root,
										dummyVect);
							}
							i.putObject(key.replaceFirst("Span", "Gorn"), gal);
							i.put(key.replaceFirst("Span", "RawText"),
									GornAddressUtils.getText(gal, root));
						}
					}
				}
			}
			((PDTBRelationListImpl) relList).save(writer);
			writer.flush();
			writer.close();
		}
	}

	public static void main(String[] args) {
		if (args.length != 4) {
			System.err
					.println("Usage: java edu.upenn.cis.pdtb.scripts.link.SpanStretchAttribution <rawRoot> <sptbRoot> <pdtbRoot> <outputRoot>");
			System.exit(0);
		}
		try {
			insertGornAddresses(args[0], args[1], args[2], args[3], true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
