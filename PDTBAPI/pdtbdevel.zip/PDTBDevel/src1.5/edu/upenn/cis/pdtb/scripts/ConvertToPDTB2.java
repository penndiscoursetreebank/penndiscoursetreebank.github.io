package edu.upenn.cis.pdtb.scripts;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Iterator;

import edu.upenn.cis.pdtb.PDTBAltLexRelation;
import edu.upenn.cis.pdtb.PDTBAltLexRelationImpl;
import edu.upenn.cis.pdtb.PDTBEntityRelation;
import edu.upenn.cis.pdtb.PDTBEntityRelationImpl;
import edu.upenn.cis.pdtb.PDTBExplicitRelation;
import edu.upenn.cis.pdtb.PDTBExplicitRelationImpl;
import edu.upenn.cis.pdtb.PDTBImplicitRelation;
import edu.upenn.cis.pdtb.PDTBImplicitRelationImpl;
import edu.upenn.cis.pdtb.PDTBInferenceSiteImpl;
import edu.upenn.cis.pdtb.PDTBNoRelation;
import edu.upenn.cis.pdtb.PDTBNoRelationImpl;
import edu.upenn.cis.pdtb.PDTBNode;
import edu.upenn.cis.pdtb.PDTBRelationImpl;
import edu.upenn.cis.pdtb.PDTBRelationListImpl;
import edu.upenn.cis.pdtb.PDTBSelectionImpl;
import edu.upenn.cis.pdtb.PDTBSupImpl;
import edu.upenn.cis.pdtb.Span;
import edu.upenn.cis.pdtb.SpanList;
import edu.upenn.cis.pdtb.ann.InternalData;
import edu.upenn.cis.pdtb.ann.util.PDTBTask;

public class ConvertToPDTB2 {
	
	public static final String[] semanticClasses = new String[] {
	
		"Comparison", "Comparison.Concession",
				"Comparison.Concession.Contra-expectation",
				"Comparison.Concession.Expectation", "Comparison.Contrast",
				"Comparison.Contrast.Juxtaposition",
				"Comparison.Contrast.Opposition",
				"Comparison.Pragmatic concession", "Comparison.Pragmatic contrast",
	
				"Contingency", "Contingency.Cause", "Contingency.Cause.Reason",
				"Contingency.Cause.Result", "Contingency.Condition",
				"Contingency.Condition.Factual past",
				"Contingency.Condition.Factual present",
				"Contingency.Condition.General",
				"Contingency.Condition.Hypothetical",
				"Contingency.Condition.Unreal past",
				"Contingency.Condition.Unreal present",
				"Contingency.Pragmatic cause",
				"Contingency.Pragmatic cause.Justification",
				"Contingency.Pragmatic condition",
				"Contingency.Pragmatic condition.Implicit assertion",
				"Contingency.Pragmatic condition.Relevance",
	
				"Expansion", "Expansion.Alternative",
				"Expansion.Alternative.Chosen alternative",
				"Expansion.Alternative.Conjunctive",
				"Expansion.Alternative.Disjunctive", "Expansion.Conjunction",
				"Expansion.Exception", "Expansion.Instantiation", "Expansion.List",
				"Expansion.Restatement", "Expansion.Restatement.Equivalence",
				"Expansion.Restatement.Generalization",
				"Expansion.Restatement.Specification",
	
				"Temporal", "Temporal.Asynchronous",
				"Temporal.Asynchronous.Precedence",
				"Temporal.Asynchronous.Succession", "Temporal.Synchrony"
	
		};
	
	private static String convertSense(String before) {
		if(before.equalsIgnoreCase("generic")){
			before = "general";
		}
		for(int i = 0; i< semanticClasses.length; i++){
			String[] split = semanticClasses[i].split("\\.");
			if( split[split.length-1].equalsIgnoreCase(before)){
				return semanticClasses[i];
			}
		}
		System.err.println("Error trying to find: " + before);
		return before;
	}
	
	private static void saveFeatureRawText(Writer writer, Object spanString, String rawText) throws IOException{
		writer.write("#### Text ####\n");
		SpanList sl = (SpanList)spanString;
		String saveString = "";
		for(Iterator spanIter = sl.iterator(); spanIter.hasNext();){
			Span s = (Span)spanIter.next();
			saveString += rawText.substring(s.getStart(), s.getEnd());
			if(spanIter.hasNext()){
				saveString += " ";
			}
		}
		writer.write(saveString + "\n");
		writer.write("##############\n");
	}
	
	private static void saveConnFeatures(Writer writer, InternalData i, String rawText) throws IOException{
		writer.write("#### Features ####\n");
		if (i.get("connAttrSource") == null) {
			writer.write("Wr, ");
		} else {
			writer.write(i.get("connAttrSource") + ", ");
		}
		if (i.get("connAttrType") == null) {
			writer.write("Comm, ");
		} else {
			writer.write(i.get("connAttrType") + ", ");
		}
		if (i.get("connAttrPolarity") == null) {
			writer.write("Null, ");
		} else {
			writer.write(i.get("connAttrPolarity") + ", ");
		}
		if (i.get("connAttrSignificance") == null) {
			writer.write("Null\n");
		} else {
			writer.write(i.get("connAttrSignificance") + "\n");
		}
		if (i.get("connAttrSpan") != null) {
			writer.write(i.get("connAttrSpan") + "\n");
			writer.write(i.get("connAttrGorn") + "\n");
			saveFeatureRawText(writer, i.get("connAttrSpan"), rawText);
		}
	}
	
	private static void saveArgFeatures(Writer writer, InternalData i, String rawText, int arg) throws IOException{
		writer.write("#### Features ####\n");
		if (i.get("arg" + arg + "AttrSource") == null) {
			writer.write("Inh, ");
		} else {
			writer.write(i.get("arg" + arg + "AttrSource") + ", ");
		}
		if (i.get("arg" + arg + "AttrType") == null) {
			writer.write("Null, ");
		} else {
			writer.write(i.get("arg" + arg + "AttrType") + ", ");
		}
		if (i.get("arg" + arg + "AttrPolarity") == null) {
			writer.write("Null, ");
		} else {
			writer.write(i.get("arg" + arg + "AttrPolarity") + ", ");
		}
		if (i.get("arg" + arg + "AttrSignificance") == null) {
			writer.write("Null\n");
		} else {
			writer.write(i.get("arg" + arg + "AttrSignificance") + "\n");
		}
		if (i.get("arg" + arg + "AttrSpan") != null) {
			writer.write(i.get("arg" + arg + "AttrSpan") + "\n");
			writer.write(i.get("arg" + arg + "AttrGorn") + "\n");
			saveFeatureRawText(writer, i.get("arg" + arg + "AttrSpan"), rawText);
		}
	}
	
	private static void saveExplicitRelation(PDTBExplicitRelation rel,
			Writer writer, InternalData i, String rawText) throws IOException {
		writer
				.write("________________________________________________________\n");
		writer.write("____Explicit____\n");
		((PDTBSelectionImpl) rel.getSelection()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getSelection().getRawText() + "\n");
		writer.write("##############\n");
		saveConnFeatures(writer, i, rawText);
		if (rel.getFeatures().getConnHead() != null) {
			writer.write(rel.getFeatures().getConnHead());
			if (i.get("new1stConnSClass1") != null) {
				writer.write(", " + convertSense((String)i.get("new1stConnSClass1")));
				if (i.get("new1stConnSClass2") != null) {
					writer.write(", " + convertSense((String)i.get("new1stConnSClass2")));
				}
			}
			writer.write("\n");
		}
		if (rel.getSup1() != null) {
			writer.write("____Sup1____\n");
			((PDTBSupImpl) rel.getSup1()).save(writer);
			writer.write("#### Text ####\n");
			writer.write(rel.getSup1().getSelection().getRawText() + "\n");
			writer.write("##############\n");
		}
		writer.write("____Arg1____\n");
		((PDTBSelectionImpl) rel.getArg1().getSelection()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg1().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		saveArgFeatures(writer, i, rawText, 1);
		writer.write("____Arg2____\n");
		((PDTBSelectionImpl) rel.getArg2().getSelection()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg2().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		saveArgFeatures(writer, i, rawText, 2);
		if (rel.getSup2() != null) {
			writer.write("____Sup2____\n");
			((PDTBSupImpl) rel.getSup2()).save(writer);
			writer.write("#### Text ####\n");
			writer.write(rel.getSup2().getSelection().getRawText() + "\n");
			writer.write("##############\n");
		}
		writer
				.write("________________________________________________________\n");
	}

	private static void saveImplicitRelation(PDTBImplicitRelation rel,
			Writer writer, InternalData i, String rawText) throws IOException {
		writer
				.write("________________________________________________________\n");
		writer.write("____Implicit____\n");
		((PDTBInferenceSiteImpl) rel.getInferenceSite()).save(writer);
		saveConnFeatures(writer, i, rawText);
		if (rel.getFeatures().getConn1() != null) {
			writer.write(rel.getFeatures().getConn1());
			if (i.get("new1stConnSClass1") != null) {
				writer.write(", " + convertSense((String)i.get("new1stConnSClass1")));
				if (i.get("new1stConnSClass2") != null) {
					writer.write(", " + convertSense((String)i.get("new1stConnSClass2")));
				}
			}
			writer.write("\n");
			if (rel.getFeatures().getConn2() != null) {
				writer.write(rel.getFeatures().getConn2());
				if (i.get("new2ndConnSClass1") != null) {
					writer.write(", " + convertSense((String)i.get("new2ndConnSClass1")));
					if (i.get("new2ndConnSClass2") != null) {
						writer.write(", " + convertSense((String)i.get("new2ndConnSClass2")));
					}
				}
				writer.write("\n");
			}
		}
		if (rel.getSup1() != null) {
			writer.write("____Sup1____\n");
			((PDTBSupImpl) rel.getSup1()).save(writer);
			writer.write("#### Text ####\n");
			writer.write(rel.getSup1().getSelection().getRawText() + "\n");
			writer.write("##############\n");
		}
		writer.write("____Arg1____\n");
		((PDTBSelectionImpl) rel.getArg1().getSelection()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg1().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		saveArgFeatures(writer, i, rawText, 1);
		writer.write("____Arg2____\n");
		((PDTBSelectionImpl) rel.getArg2().getSelection()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg2().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		saveArgFeatures(writer, i, rawText, 2);
		if (rel.getSup2() != null) {
			writer.write("____Sup2____\n");
			((PDTBSupImpl) rel.getSup2()).save(writer);
			writer.write("#### Text ####\n");
			writer.write(rel.getSup2().getSelection().getRawText() + "\n");
			writer.write("##############\n");
		}
		writer
				.write("________________________________________________________\n");
	}

	private static void saveAltLexRelation(PDTBAltLexRelation rel,
			Writer writer, InternalData i, String rawText) throws IOException {
		writer
				.write("________________________________________________________\n");
		writer.write("____AltLex____\n");
		((PDTBSelectionImpl) rel.getSelection()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getSelection().getRawText() + "\n");
		writer.write("##############\n");
		saveConnFeatures(writer, i, rawText);
		if (i.get("new1stConnSClass1") != null) {
			writer.write(convertSense((String) i.get("new1stConnSClass1")));
			if (i.get("new1stConnSClass2") != null) {
				writer.write(", " + convertSense((String)i.get("new1stConnSClass2")));
			}
			writer.write("\n");
		}
		if (rel.getSup1() != null) {
			writer.write("____Sup1____\n");
			((PDTBSupImpl) rel.getSup1()).save(writer);
			writer.write("#### Text ####\n");
			writer.write(rel.getSup1().getSelection().getRawText() + "\n");
			writer.write("##############\n");
		}
		writer.write("____Arg1____\n");
		((PDTBSelectionImpl) rel.getArg1().getSelection()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg1().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		saveArgFeatures(writer, i, rawText, 1);
		writer.write("____Arg2____\n");
		((PDTBSelectionImpl) rel.getArg2().getSelection()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg2().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		saveArgFeatures(writer, i, rawText, 2);
		if (rel.getSup2() != null) {
			writer.write("____Sup2____\n");
			((PDTBSupImpl) rel.getSup2()).save(writer);
			writer.write("#### Text ####\n");
			writer.write(rel.getSup2().getSelection().getRawText() + "\n");
			writer.write("##############\n");
		}
		writer
				.write("________________________________________________________\n");
	}

	private static void saveEntityRelation(PDTBEntityRelation rel,
			Writer writer, InternalData i) throws IOException {
		writer
				.write("________________________________________________________\n");
		writer.write("____EntRel____\n");
		((PDTBInferenceSiteImpl) rel.getInferenceSite()).save(writer);
		writer.write("____Arg1____\n");
		((PDTBSupImpl) rel.getArg1()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg1().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		writer.write("____Arg2____\n");
		((PDTBSupImpl) rel.getArg2()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg2().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		writer
				.write("________________________________________________________\n");
	}

	private static void saveNoRelation(PDTBNoRelation rel, Writer writer,
			InternalData i) throws IOException {
		writer
				.write("________________________________________________________\n");
		writer.write("____NoRel____\n");
		((PDTBInferenceSiteImpl) rel.getInferenceSite()).save(writer);
		writer.write("____Arg1____\n");
		((PDTBSupImpl) rel.getArg1()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg1().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		writer.write("____Arg2____\n");
		((PDTBSupImpl) rel.getArg2()).save(writer);
		writer.write("#### Text ####\n");
		writer.write(rel.getArg2().getSelection().getRawText() + "\n");
		writer.write("##############\n");
		writer
				.write("________________________________________________________\n");
	}

	private static void convert(String rawRoot, String ptbRoot,
			String pdtbRoot, String outputRoot) throws IOException {
		File outputDir = new File(outputRoot);
		outputDir.mkdirs();
		for (PDTBTask task = new PDTBTask(rawRoot, ptbRoot, pdtbRoot, false,
				true); task.hasNext();) {
			if(task.getSecNo() == 6 && task.getFileNo() == 8){
				System.out.println("breakpoint");
			}
			PDTBRelationListImpl relList = (PDTBRelationListImpl) task.next();
			String secNo = task.getSecNoStr();
			String fileNo = task.getFileNoStr();
			File outputSec = new File(outputDir, secNo);
			outputSec.mkdirs();

			File outFile = new File(outputSec, "wsj_" + secNo + fileNo
					+ ".pdtb");
			Writer writer = new BufferedWriter(new FileWriter(outFile));
			String rawText = relList.getRawText();
			
			for (Enumeration e = relList.children(); e.hasMoreElements();) {
				PDTBNode node = (PDTBNode) e.nextElement();
				InternalData i = (InternalData) node.getUserObject();
				if (node instanceof PDTBRelationImpl) {					
					if (node instanceof PDTBExplicitRelationImpl) {
						PDTBExplicitRelation rel = (PDTBExplicitRelation) node;
						saveExplicitRelation(rel, writer, i, rawText);
					} else if (node instanceof PDTBImplicitRelationImpl) {
						PDTBImplicitRelationImpl rel = (PDTBImplicitRelationImpl) node;
						saveImplicitRelation(rel, writer, i, rawText);
					} else if (node instanceof PDTBAltLexRelationImpl) {
						PDTBAltLexRelationImpl rel = (PDTBAltLexRelationImpl) node;
						saveAltLexRelation(rel, writer, i, rawText);
					} else {
						System.err.println("Error:  Not a relation.");
					}
				} else {
					if (node instanceof PDTBNoRelationImpl) {
						PDTBNoRelation rel = (PDTBNoRelation) node;
						saveNoRelation(rel, writer, i);
					} else if (node instanceof PDTBEntityRelationImpl) {
						PDTBEntityRelation rel = (PDTBEntityRelation) node;
						saveEntityRelation(rel, writer, i);
					} else {
						System.err.println("Error:  Not a relation.");
					}
				}
			}
			writer.flush();
			writer.close();
		}

	}

	public static void main(String[] args) {
		if (args.length != 4) {
			System.err
					.println("Usage: java edu.upenn.cis.pdtb.scripts.link.ConvertToPDB2 "
							+ "<rawRoot> <ptbRoot> <pdtb1.6Root> <pdtb2.0Root>");
			System.exit(0);
		}
		try {
			convert(args[0], args[1], args[2], args[3]);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
