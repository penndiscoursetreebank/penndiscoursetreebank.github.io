/*
 * FixGornAddresses.java
 *
 * Created on January 17, 2006, 11:38 PM
 */

package edu.upenn.cis.pdtb.scripts;

import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.pdtb.util.*;
import edu.upenn.cis.ptb.*;
import java.util.*;
import java.io.*;
import java.util.regex.*;

/**
 *
 * @author  nikhild
 */
public class FixGornAddresses {
    
    public static final String pdtbRoot = "Corpora/PDTB/PDTB-Flat/";
    
    public static final String ptbRoot = "Corpora/PTB/combined/wsj/";
    
    public static final String textRoot = "Corpora/PTB/raw/wsj/";
    
    public static final String connHeadListFile = "Corpora/PDTB/conn_head_list";
    
    public static PTBTreeNode root = null;
    
    public static HashMap connHeadMap = null;
    
    public static Vector addressesToCheck = new Vector();
    
    private String rawStr = null;
    
    /** Creates a new instance of FixGornAddresses */
    public FixGornAddresses(PDTBRelationList relList, Writer writer) throws IOException{
        if(connHeadMap == null){
            connHeadMap = loadConnHeadMap();
        }
        
        root = relList.getPTBRoot();
        rawStr = relList.getRawText();
        for(Enumeration e = relList.children(); e.hasMoreElements();){
            Object o = e.nextElement();
            if(o instanceof PDTBRelationImpl){
                PDTBRelationImpl rel = (PDTBRelationImpl)o;
                if(rel instanceof PDTBExplicitRelation){
                    PDTBExplicitRelationImpl expRel = (PDTBExplicitRelationImpl)(rel);
                    String rawConnText = expRel.getSelection().getRawText();
                    PDTBExplicitRelationFeatures oldFeats = expRel.getFeatures();
                    
                    PDTBExplicitRelationFeatures newFeats =
                    new PDTBExplicitRelationFeaturesImpl(
                    getSource(oldFeats),
                    getFactuality(oldFeats),
                    getPolarity(oldFeats),
                    getConnHead(rawConnText));
                    
                    PDTBSelection oldSel = expRel.getSelection();
                    PDTBSelection newSel =
                    new PDTBSelectionImpl(
                    oldSel.getSpans(),
                    oldSel.getAddresses(),
                    computeRawStr(oldSel.getSpans(), rawStr),
                    oldSel.getPTBNodes());
                    
                    expRel.setSelection(newSel);
                    expRel.setFeatures(newFeats);
                    
                    addressesToCheck.add(newSel.getAddresses());
                    
                }
                else if(rel instanceof PDTBAltLexRelation){
                    PDTBAltLexRelationImpl expRel = (PDTBAltLexRelationImpl)(rel);
                    String rawConnText = expRel.getSelection().getRawText();
                    PDTBAltLexRelationFeatures oldFeats = expRel.getFeatures();
                    
                    PDTBSelection oldSel = expRel.getSelection();
                    PDTBSelection newSel =
                    new PDTBSelectionImpl(
                    oldSel.getSpans(),
                    oldSel.getAddresses(),
                    computeRawStr(oldSel.getSpans(), rawStr),
                    oldSel.getPTBNodes());
                    
                    expRel.setSelection(newSel);
                    
                    addressesToCheck.add(newSel.getAddresses());
                    
                }
                
                for(Enumeration e1 = rel.children(); e1.hasMoreElements();){
                    addressesToCheck.add(((PDTBSup)(e1.nextElement())).getSelection().getAddresses());
                }
                
                modifySup(rel.getArg1());
                modifySup(rel.getArg2());
                modifySup(rel.getSup1());
                modifySup(rel.getSup2());
                excludeOverlappingPunct();
                
                rel.save(writer);
                addressesToCheck.removeAllElements();
            }
            else{
                PDTBEntityRelationImpl entRel = (PDTBEntityRelationImpl)o;
                PDTBSup arg1 = entRel.getArg1();
                PDTBSup arg2 = entRel.getArg2();
                addressesToCheck.add(arg1.getSelection().getAddresses());
                addressesToCheck.add(arg2.getSelection().getAddresses());
                modifySup(arg1);
                modifySup(arg2);
                entRel.save(writer);
                addressesToCheck.removeAllElements();
            }
        }
    }
    
    private void excludeOverlappingPunct(){
        int i = 0;
        for(Enumeration e = addressesToCheck.elements(); e.hasMoreElements(); i++){
            GornAddressList gal = (GornAddressList)(e.nextElement());
            Vector addressesToRemove = new Vector();
            int j = 0;
            for(Enumeration e1 = addressesToCheck.elements(); e1.hasMoreElements(); j++){
                GornAddressList gal1 = (GornAddressList)(e1.nextElement());
                Vector addressesToRemove1 = new Vector();
                if(i < j){
                    for(Iterator iter = gal.iterator(); iter.hasNext(); ){
                        int[] address = (int[])(iter.next());
                        PTBTreeNode node = (PTBTreeNode)(GornAddressUtils.getNode(address, root));
                        if(punctOrTraceContainer(node)){
                            if(GornAddressUtils.prefixExists(address, gal1)){
                                if(gal1.contains(address)){
                                    addressesToRemove1.add(address);
                                }
                                else{
                                    addressesToRemove.add(address);
                                }
                            }
                            
                        }
                    }
                }
                gal1.removeAll(addressesToRemove1);
            }
            gal.removeAll(addressesToRemove);
        }
    }
    
    private void modifySup(PDTBSup n){
        if(n == null){
            return;
        }
        
        GornAddressList gal = n.getSelection().getAddresses();
        
        modifyAddresses(gal, root);
        
        PDTBSelection oldSel = n.getSelection();
        PDTBSelection newSel =
        new PDTBSelectionImpl(
        oldSel.getSpans(),
        oldSel.getAddresses(),
        computeRawStr(oldSel.getSpans(), rawStr),
        oldSel.getPTBNodes());
        
        n.setSelection(newSel);
    }
    
    private String getSource(PDTBFeatures feats){
        int source = feats.getSource();
        if(source == PDTBFeatures.SourceWriter){
            return PDTBFeatures.SourceWriterVal;
        }
        else if(source == PDTBFeatures.SourceOther){
            return PDTBFeatures.SourceOtherVal;
        }
        else {
            return PDTBFeatures.SourceInheritedVal;
        }
    }
    
    private String getFactuality(PDTBFeatures feats){
        int factuality = feats.getFactuality();
        if(factuality == PDTBFeatures.Factual){
            return PDTBFeatures.FactualVal;
        }
        else if(factuality == PDTBFeatures.NonFactual){
            return PDTBFeatures.NonFactualVal;
        }
        else {
            return PDTBFeatures.NullFactualVal;
        }
    }
    
    private String getPolarity(PDTBFeatures feats){
        int polarity = feats.getPolarity();
        if(polarity == PDTBFeatures.PolarityPositive){
            return PDTBFeatures.PositivePolarityVal;
        }
        else{
            return PDTBFeatures.NegativePolarityVal;
        }
        
    }
    
    
    public String computeRawStr(SpanList spans, String text){
        StringBuffer sb = new StringBuffer(200);
        int i = 0;
        for(Iterator iter = spans.iterator(); iter.hasNext();){
            Span span = (Span)(iter.next());
            if(i > 0){
                sb.append(' ');
            }
            sb.append(text.substring(span.getStart(), span.getEnd()));
            i++;
        }
        
        return sb.toString();
    }
    
    public String getConnHead(String rawStr) throws IOException{
        String head = "";
        rawStr = rawStr.toLowerCase();
        boolean found = false;
        for(Iterator iter = connHeadMap.keySet().iterator(); iter.hasNext() && !found;){
            Pattern regex = (Pattern)(iter.next());
            //System.err.println(regex.pattern());
            if(regex.matcher(rawStr).matches()){
                head = (String)(connHeadMap.get(regex));
                found = true;
            }
        }
        
        if(!found){
            throw(new IOException("Head not found for " + rawStr + rawStr.length()));
        }
        
        return head;
    }
    
    
    public static HashMap loadConnHeadMap() throws IOException{
        HashMap result = new HashMap();
        LineNumberReader lnr = new LineNumberReader(new FileReader(connHeadListFile));
        
        boolean found = false;
        String conn = "because";
        for(String line = lnr.readLine(); line != null; line = lnr.readLine()){
            line = line.trim().toLowerCase();
            int index = line.indexOf(',');
            if(line.length() > 1){
                index = (index == -1)? line.length() : index;
                String head = line.substring(0, index);
                line = line.replaceAll(",",")|(");
                line = line.replaceAll("\\s+", "\\\\s*");
                line = "((\\s*" + line + "))\\s*";
                Pattern regex = Pattern.compile(line);
                result.put(regex, head);
                
            }
        }
        
        lnr.close();
        
        return result;
    }
    
    public static boolean punctOrTraceContainer(PTBTreeNode node){
        if(node.isTracePreterminal() || node.isPunctPreterminal()){
            return true;
        }
        
        
        if(node.isLeaf()){
            return false;
        }
        
        boolean result = true;
        for(Enumeration e = node.children(); e.hasMoreElements(); ){
            PTBTreeNode child = (PTBTreeNode)(e.nextElement());
            result = result && punctOrTraceContainer(child);
        }
        
        return result;
    }
    
    public static boolean isAddressContained(int[] address){
        for(Enumeration e = addressesToCheck.elements(); e.hasMoreElements();){
            GornAddressList gal = (GornAddressList)(e.nextElement());
            if(GornAddressUtils.prefixExists(address, gal)){
                return true;
            }
        }
        
        return false;
    }
    
    public static void modifyAddresses(GornAddressList gal, PTBTreeNode root){
        GornAddressList gal2 = new GornAddressList();
        for(Iterator iter = gal.iterator(); iter.hasNext(); ){
            int[] address = (int[])(iter.next());
            PTBTreeNode node = (PTBTreeNode)(GornAddressUtils.getNode(address, root));
            String type = node.getLabel().getType();
            
            if(!(isClause(node))){
                PTBTreeNode parent = (PTBTreeNode)(node.getParent());
                if(parent.getParent() != null){
                    boolean done = false;
                    
                    for(PTBTreeNode sib = node;
                    sib != null && !done;
                    sib = sib.ptbGetPreviousSibling()){
                        if(punctOrTraceContainer(sib)){
                            int[] address2 = GornAddressUtils.getGornAddress(sib);
                            if(!isAddressContained(address2)){
                                gal2.add(address2);
                            }
                        }
                        
                        if(sib.getLabel().getType().equals("CC")){
                            String leaf = ((PTBTreeNode)sib.getChildAt(0)).getLabel().getType();
                            String leafLower = leaf.toLowerCase();
                            if(leafLower.equals(leaf)){
                                done = true;
                            }
                        }
                        
                    }
                    
                    done = false;
                    for(PTBTreeNode sib = node.ptbGetNextSibling();
                    sib != null && !done;
                    sib = sib.ptbGetNextSibling()){
                        if(punctOrTraceContainer(sib)){
                            int[] address2 = GornAddressUtils.getGornAddress(sib);
                            if(!isAddressContained(address2)){
                                gal2.add(address2);
                            }
                        }
                        
                        if(sib.getLabel().getType().equals("CC")){
                            done = true;
                        }
                        
                    }
                    
                }
            }
        }
        gal.addAll(gal2);
    }
    
    public static boolean isClause(PTBTreeNode node){
        String type = node.getLabel().getType();
        if(type.startsWith("S")){
            return true;
        }
        else{
            if(type.equals("PRN")){
                for(Enumeration e = node.children(); e.hasMoreElements();){
                    PTBTreeNode child = (PTBTreeNode)(e.nextElement());
                    String childType = child.getLabel().getType();
                    if(childType.startsWith("S") || childType.equals("VP")){
                        return true;
                    }
                }
            }
            
            if(type.equals("PP")){
                for(Enumeration e = node.children(); e.hasMoreElements();){
                    PTBTreeNode child = (PTBTreeNode)(e.nextElement());
                    String childType = child.getLabel().getType();
                    if(childType.startsWith("S")){
                        return true;
                    }
                }
            }
            
            return false;
        }        
        
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        AnnotationCorpusFileIterator cfi = new AnnotationCorpusFileIterator(textRoot, ptbRoot, pdtbRoot);
        RelationLoader loader = new RelationLoaderImpl();
        while(cfi.hasMoreFiles()){
            cfi.nextFile();
            String setNo = cfi.getSetNoStr();
            String secNo = cfi.getSecNoStr();
            String fileNo = cfi.getFileNoStr();
            
            File discourseFile = new File(cfi.currentPdtbFile());
            
            
            String outputDir = "Corpora/PDTB/PDTB-Flat2/" +  setNo + "/" + secNo;
            String outFileName = outputDir + "/" + "wsj_" + secNo + fileNo + ".pdtb";
            
            File outputFile = new File(outFileName);
            long modification = outputFile.lastModified() - discourseFile.lastModified();
            
            if(modification <= 0){
                System.err.println(setNo + " " + secNo + " " + fileNo);
            
                try{
                    PDTBRelationList rlist = loader.loadRelations(textRoot, ptbRoot, pdtbRoot + setNo + "/", secNo, fileNo);
                    File f = new File(outputDir);
                    f.mkdirs();
                    FileWriter writer = new FileWriter(outFileName);
                    FixGornAddresses fg = new FixGornAddresses(rlist, writer);
                    writer.close();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        }
    }
    
}
