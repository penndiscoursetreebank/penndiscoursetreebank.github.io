/*
 * InternalData.java
 *
 * Created on March 9, 2006, 9:45 PM
 */

package edu.upenn.cis.pdtb.ann;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.lang.reflect.*;
import java.io.*;
import edu.upenn.cis.pdtb.*;

/**
 *
 * @author  nikhild
 */
public class InternalData {
    
    private HashMap fHashMap = new HashMap();
    private static final HashMap ConstructorMap = createConstructorMap();
    public static final String ConnAttrSpan = "connAttrSpan";
    public static final String Arg1AttrSpan = "arg1AttrSpan";
    public static final String Arg2AttrSpan = "arg2AttrSpan";
    public static final String ConnAttrGorn = "connAttrGorn";
    public static final String Arg1AttrGorn = "arg1AttrGorn";
    public static final String Arg2AttrGorn = "arg2AttrGorn";


    
    /** Creates a new instance of InternalData */
    public InternalData() {
        
    }
    
    private static HashMap createConstructorMap(){
        Class[] constructorArgsClass = {String.class};
        HashMap constructorMap = new HashMap();
            
        try{
	    constructorMap.put(ConnAttrSpan, SpanList.class.getConstructor(constructorArgsClass));
	    constructorMap.put(Arg1AttrSpan, SpanList.class.getConstructor(constructorArgsClass));
	    constructorMap.put(Arg2AttrSpan, SpanList.class.getConstructor(constructorArgsClass));
	    constructorMap.put(ConnAttrGorn, GornAddressList.class.getConstructor(constructorArgsClass));
	    constructorMap.put(Arg1AttrGorn, GornAddressList.class.getConstructor(constructorArgsClass));
	    constructorMap.put(Arg2AttrGorn, GornAddressList.class.getConstructor(constructorArgsClass));

        }catch(Exception e){
            e.printStackTrace();
        }
        
        return constructorMap;
    }
    
    public void put(String key, String value){
        Object val = convertData(key,value);
        fHashMap.put(key, val);
    }
    
    public void putObject(String key, Object value){
        fHashMap.put(key, value);
    }
    
    public Object get(String key){
        return fHashMap.get(key);
    }
    
    public void remove(String key){
        fHashMap.remove(key);
    }
    
    public Set keySet(){
        return fHashMap.keySet();
    }
    
    private Object convertData(String key, String value){
        Constructor c = (Constructor)(ConstructorMap.get(key));
        if(c == null){
            return value;
        }
        else{
            try{
                Object[] args = {value};
                return c.newInstance(args);
            }catch(Exception e){
                e.printStackTrace();
                return value;
            }
        }
    }
    
    public void save(Writer writer) throws IOException{
        writer.write("_____________________ Internal _________________________\n");
        for(Iterator iter = keySet().iterator(); iter.hasNext();){
            String key = (String)(iter.next());
            Object value = get(key);
            writer.write(key);
            writer.write('=');
            writer.write(value.toString());
            writer.write('\n');
        }
        writer.write("________________________________________________________\n");
    }
}
