package edu.upenn.cis.pdtb.scripts;

import edu.upenn.cis.pdtb.scripts.link.RemoveRejects;
import edu.upenn.cis.pdtb.scripts.link.SiblingInclusion;
import edu.upenn.cis.pdtb.scripts.link.SpanStretch;
import edu.upenn.cis.pdtb.scripts.link.SpanStretchAttribution;

public class ConversionScripts {

	static String root = "../../../work/";
		
	static String rawRoot = root + "Corpora/PTB/raw/wsj";
	static String ptbRoot = root + "Corpora/PTB/combined/wsj";
	static String sptbRoot = root + "Corpora/SPTB/combined/wsj";
	
	static String logRoot = root + "corpora1-6/big/";
	static String pdtb1_5Root = logRoot + "pdtb1-5/";
	static String afterRejectRemoval = logRoot + "afterRejectRemoval/";
	static String afterComputeGA = logRoot + "afterComputeGA/";
	static String afterIncludeSiblings = logRoot + "afterIncludeSiblings/";
	static String afterInsertGAs = logRoot + "afterInsertGAs/";
	static String afterTokenSort = logRoot + "afterSort/";
	static String pdtb2_0Root = logRoot + "pdtb2-0/";

	static final boolean includePunctuation = true;
	
	public static void main(String[] args) {
		try {
		
			System.out.println("Doing RemoveRejects on: " + rawRoot + " " + ptbRoot + " " + pdtb1_5Root + " " + afterRejectRemoval);
			RemoveRejects.removeRejects(rawRoot, ptbRoot, pdtb1_5Root, afterRejectRemoval);			
			
			System.out.println("Doing SpanStretch.computeGA on: " + rawRoot + " " + sptbRoot + " " + afterRejectRemoval + " " + afterComputeGA + " " + logRoot + "log1.log");
			SpanStretch.computeGA(rawRoot, sptbRoot, afterRejectRemoval, afterComputeGA, logRoot + "log1.log", true);
			
			System.out.println("Doing SiblingInclusion.includeSiblings on: " + rawRoot + " " + ptbRoot + " " + afterComputeGA + " " + afterIncludeSiblings + " " + logRoot + "log2.log");
			SiblingInclusion.includeSiblings(rawRoot, ptbRoot, afterComputeGA, afterIncludeSiblings, logRoot + "log2.log", true);
			
			System.out.println("Doing SpanStretchAttribution.insertGornAddresses on: " + rawRoot + " " + sptbRoot + " " + afterIncludeSiblings + " " + afterInsertGAs);
			SpanStretchAttribution.insertGornAddresses(rawRoot, sptbRoot, afterIncludeSiblings, afterInsertGAs, includePunctuation);		

			System.out.println("Doing Sort on: " + rawRoot + " " + ptbRoot + " " + afterInsertGAs + " " + afterTokenSort + " " + logRoot + "log3.txt");
			SortRelations.sort(rawRoot,ptbRoot,afterInsertGAs,afterTokenSort,logRoot + "ThisFileContainsErrors.txt");
			
			System.out.println("Doing ConvertToPDTB2 on: " + rawRoot + " " + ptbRoot + " " + afterTokenSort + " " + pdtb2_0Root);
			ConvertToPDTB2.main(new String[]{rawRoot, ptbRoot, afterTokenSort, pdtb2_0Root});
		
			System.out.println("Finished!");
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

}
