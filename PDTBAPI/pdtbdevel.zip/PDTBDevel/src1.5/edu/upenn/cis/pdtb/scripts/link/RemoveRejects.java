package edu.upenn.cis.pdtb.scripts.link;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;

import edu.upenn.cis.pdtb.PDTBEntityRelationImpl;
import edu.upenn.cis.pdtb.PDTBNode;
import edu.upenn.cis.pdtb.PDTBRelationImpl;
import edu.upenn.cis.pdtb.PDTBRelationList;
import edu.upenn.cis.pdtb.ann.InternalData;
import edu.upenn.cis.pdtb.ann.util.PDTBTask;

public class RemoveRejects {

	public static void removeRejects(String rawRoot, String ptbRoot,
			String pdtbRoot, String outputRoot) throws FileNotFoundException,
			IOException {
		File outputDir = new File(outputRoot);
		outputDir.mkdirs();

		for (PDTBTask task = new PDTBTask(rawRoot, ptbRoot, pdtbRoot, false,
				true); task.hasNext();) {
			PDTBRelationList relList = task.next();
			String secNo = task.getSecNoStr();
			String fileNo = task.getFileNoStr();
			if(secNo.equals("09") && fileNo.equals("36")){
				System.out.println("breakpoint");
			}
			File outputSec = new File(outputDir, secNo);
			outputSec.mkdirs();
			File outFile = new File(outputSec, "wsj_" + secNo + fileNo
					+ ".pdtb");
			Writer writer = new BufferedWriter(new FileWriter(outFile));
			for (Enumeration e = relList.children(); e.hasMoreElements();) {
				PDTBNode node = (PDTBNode) (e.nextElement());
				InternalData i = (InternalData) (node.getUserObject());
				if (!i.get("status").equals("Rejected")) {
					if (node instanceof PDTBRelationImpl) {
						PDTBRelationImpl r = (PDTBRelationImpl) node;
						r.save(writer);
					} else {
						PDTBEntityRelationImpl r = (PDTBEntityRelationImpl) node;
						r.save(writer);
					}
					i.save(writer);
				}
				else{
					//System.out.println("removed token in " + secNo + " " + fileNo);	
				}
			}
			writer.flush();
			writer.close();
			//System.out.println("finished " + secNo + " " + fileNo);
		}
	}

	/*
	 * Iterates through the tokens in a file and removes those whose status is
	 * "Rejected" in the "Internal" section
	 */
	public static void main(String[] args) {
		if (args.length != 4) {
			System.err
					.println("Usage: java edu.upenn.cis.pdtb.scripts.link.RemoveRejects <rawRoot> <ptbRoot> <pdtbRoot> <outputRoot>");
			System.exit(0);
		}
		try {
			removeRejects(args[0], args[1], args[2], args[3]);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
