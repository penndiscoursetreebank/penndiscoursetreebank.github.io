/*
 * AnnPDTBRelationList.java
 *
 * Created on March 9, 2006, 10:09 PM
 */

package edu.upenn.cis.pdtb.ann;

import edu.upenn.cis.ptb.PTBTreeNode;
import edu.upenn.cis.pdtb.*;
import java.io.*;
import java.util.Enumeration;

/**
 *
 * @author  nikhild
 */
public class PDTBAnnRelationList extends PDTBRelationListImpl{
    
    /** Creates a new instance of AnnPDTBRelationList */
    public PDTBAnnRelationList(String rawText, PTBTreeNode root, String secNo, String fileNo) {
        super(rawText, root, secNo, fileNo);
    }
    
    public void save(Writer writer) throws IOException{
        for(Enumeration e = children(); e.hasMoreElements();){
            PDTBNode node = (PDTBNode)(e.nextElement());
            if(node instanceof PDTBRelationImpl){
                PDTBRelationImpl r = (PDTBRelationImpl)node;
                r.save(writer);
            }
            else{
                PDTBEntityRelationImpl r = (PDTBEntityRelationImpl)node;
                r.save(writer);
            }
            InternalData i = (InternalData)(node.getUserObject());
            i.save(writer);
        }
    }
    
}
