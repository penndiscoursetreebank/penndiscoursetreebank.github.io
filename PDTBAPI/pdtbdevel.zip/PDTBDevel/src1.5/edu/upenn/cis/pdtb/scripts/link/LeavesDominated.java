/*
 * LeavesDominated.java
 *
 * Created on October 25, 2004, 11:58 AM
 */

package edu.upenn.cis.pdtb.scripts.link;

/**
 *
 * @author  nikhild
 */
public class LeavesDominated {
    
    public int start = 0;
    
    public int end = 0;
    
    public LeavesDominated(int s, int e){
        start = s;
        end = e;
    }

    public String toString(){
	return "(" + start + "," + end + ")";
    }
    
}
