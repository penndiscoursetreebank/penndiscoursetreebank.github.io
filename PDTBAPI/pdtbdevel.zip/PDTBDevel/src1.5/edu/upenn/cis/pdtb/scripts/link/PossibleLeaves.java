/*
 * PossibleLeaves.java
 *
 * Created on October 31, 2004, 12:42 PM
 */

package edu.upenn.cis.pdtb.scripts.link;

/**
 *
 * @author  nikhild
 */
public class PossibleLeaves {
    
    public int rightmostStart;
    
    public int leftmostStart;
    
    public int rightmostEnd;
    
    public int leftmostEnd;
    
    
    /** Creates a new instance of PossibleLeaves */
    public PossibleLeaves() {
    }

    public String toString() {
	return "(" + leftmostStart + ", " + rightmostStart + ", " + leftmostEnd + ", " + rightmostEnd + ")";

    }
    
}
