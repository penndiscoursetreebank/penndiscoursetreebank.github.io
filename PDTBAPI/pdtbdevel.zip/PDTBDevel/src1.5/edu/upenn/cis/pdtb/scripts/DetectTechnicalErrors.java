/*
 * FixGornAddresses.java
 *
 * Created on January 17, 2006, 11:38 PM
 */

package edu.upenn.cis.pdtb.scripts;

import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.pdtb.util.*;
import edu.upenn.cis.ptb.*;
import java.util.*;
import java.io.*;
import java.util.regex.*;

/**
 *
 * @author  nikhild
 */
public class DetectTechnicalErrors {
    
    public static final String pdtbRoot = "Corpora/PDTB/PDTB-Flat2/";
    
    public static final String ptbRoot = "Corpora/PTB/combined/wsj/";
    
    public static final String textRoot = "Corpora/PTB/raw/wsj/";
    
    public static final String connHeadListFile = "Corpora/PDTB/conn_head_list";
    
    public static PTBTreeNode root = null;
    
    public static HashMap connHeadMap = null;
    
    public static Vector addressesToCheck = new Vector();
    
    
    /** Creates a new instance of FixGornAddresses */
    public DetectTechnicalErrors() {
    }
    
    public static boolean  checkAddresses(){
        for(Enumeration e = addressesToCheck.elements(); e.hasMoreElements();){
            GornAddressList gal = (GornAddressList)(e.nextElement());
            for(Enumeration e1 = addressesToCheck.elements(); e1.hasMoreElements();){
                GornAddressList gal1 = (GornAddressList)(e1.nextElement());
                if(gal1 != gal){
                    for(Iterator iter = gal.iterator(); iter.hasNext(); ){
                        int[] address = (int[])(iter.next());
                        PTBTreeNode node = (PTBTreeNode)(GornAddressUtils.getNode(address, root));
                        
                        if(GornAddressUtils.prefixExists(address, gal1)){
                            return false;
                        }
                        
                        
                    }
                }
            }
        }
        
        return true;
    }
    
    public static HashMap loadConnHeadMap() throws IOException{
        HashMap result = new HashMap();
        LineNumberReader lnr = new LineNumberReader(new FileReader(connHeadListFile));
        
        boolean found = false;
        String conn = "because";
        for(String line = lnr.readLine(); line != null; line = lnr.readLine()){
            line = line.trim().toLowerCase();
            int index = line.indexOf(',');
            if(line.length() > 1){
                index = (index == -1)? line.length() : index;
                String head = line.substring(0, index);
                line = line.replaceAll(",",")|(");
                line = line.replaceAll("\\s+", "\\\\s*");
                line = "((\\s*" + line + "))\\s*";
                //line = "\\s*because\\s*";
                Pattern regex = Pattern.compile(line);
                result.put(regex, head);
                //System.err.println(regex.pattern());
                
            }
        }
        
        lnr.close();
        
        return result;
    }
    
    public static boolean punctOrTraceContainer(PTBTreeNode node){
        if(node.isTracePreterminal() || node.isPunctPreterminal()){
            return true;
        }
        
        
        if(node.isLeaf()){
            return false;
        }
        
        boolean result = true;
        for(Enumeration e = node.children(); e.hasMoreElements(); ){
            PTBTreeNode child = (PTBTreeNode)(e.nextElement());
            result = result && punctOrTraceContainer(child);
        }
        
        return result;
    }
    
    public static boolean isAddressContained(int[] address){
        for(Enumeration e = addressesToCheck.elements(); e.hasMoreElements();){
            GornAddressList gal = (GornAddressList)(e.nextElement());
            if(GornAddressUtils.prefixExists(address, gal)){
                return true;
            }
        }
        
        return false;
    }
    
    public static boolean isNodeContained(PTBTreeNode node){
        int[] address = GornAddressUtils.getGornAddress(node);
        
        if(isClause(node)){
            return true;
        }
        
        if(punctOrTraceContainer(node)){
            return true;
        }
        
        if(isAddressContained(address)){
            return true;
        }
        else{
            if(node.isLeaf()){
                return false;
            }
            
            boolean result = true;
            for(Enumeration e = node.children(); e.hasMoreElements();){
                PTBTreeNode child = (PTBTreeNode)(e.nextElement());
                result = result && isNodeContained(child);
            }
            
            return result;
        }
    }
    
    public static boolean checkSiblings(PTBTreeNode node){
        if(punctOrTraceContainer(node)){
            return true;
        }
        
        String type = node.getLabel().getType();
        if(isClause(node) || node.getParent().getParent() == null){
            return true;
        }
        
        boolean done = false;
        for(PTBTreeNode sib = node; sib != null && !done; sib = sib.ptbGetPreviousSibling()){            
            if(!isNodeContained(sib)){
                return false;
            }
            
            String sibType = sib.getLabel().getType();
            if(sibType.equals("CC")){
                done = true;
            }
        }
        
        done = false;
        for(PTBTreeNode sib = node.ptbGetNextSibling(); 
        sib != null && !done; 
        sib = sib.ptbGetNextSibling()){
            if(!isNodeContained(sib)){
                String sibType = sib.getLabel().getType();
                if(!sibType.equals("CC")){
                    return false;
                }
                else{
                    done = true;
                }
            }
        }
        
        return true;
    }
    
    public static boolean isClause(PTBTreeNode node){
        String type = node.getLabel().getType();
        if(type.startsWith("S")){
            return true;
        }
        else{
            if(type.equals("PRN")){
                for(Enumeration e = node.children(); e.hasMoreElements();){
                    PTBTreeNode child = (PTBTreeNode)(e.nextElement());
                    String childType = child.getLabel().getType();
                    if(childType.startsWith("S") || childType.equals("VP")){
                        return true;
                    }
                }
            }
            
            if(type.equals("PP")){
                for(Enumeration e = node.children(); e.hasMoreElements();){
                    PTBTreeNode child = (PTBTreeNode)(e.nextElement());
                    String childType = child.getLabel().getType();
                    if(childType.startsWith("S")){
                        return true;
                    }
                }
            }
            
            return false;
        }        
        
    }
    
    public static boolean checkAncestors(PTBTreeNode node){
        PTBTreeNode parent = (PTBTreeNode)(node.getParent());
        while(node != null && parent != null && !isClause(node)){
            node = parent;
            parent = (PTBTreeNode)(parent.getParent());
        }
        
        if(node != null && parent != null){
            for(Enumeration e = node.children(); e.hasMoreElements();){
                PTBTreeNode child = (PTBTreeNode)(e.nextElement());
                if(!isNodeContained(child)){
                    return true;
                }
            }
            if(isClause(node) && isClause(parent)){
                boolean light = true;
                for(Enumeration e = parent.children(); e.hasMoreElements() && light;){
                    PTBTreeNode child = (PTBTreeNode)(e.nextElement());
                    if(child != node){
                        String type = child.getLabel().getType();
                        if(type.startsWith("NP") || type.startsWith("VP") || type.startsWith("S")){
                            light = false;
                        }
                    }
                    
                }
                
                if(light){
                    for(Enumeration e = parent.children(); e.hasMoreElements();){
                        PTBTreeNode child = (PTBTreeNode)(e.nextElement());
                        if(child != node){
                            if(!isNodeContained(child)){
                                return false;
                            }
                            
                        }
                        
                    }
                    
                }
            }
        }
        
        return true;
    }
    
    public static boolean checkRelation(PDTBRelation rel){
        if(rel instanceof PDTBExplicitRelation){
            PDTBExplicitRelation expRel = (PDTBExplicitRelation)rel;
            PDTBExplicitRelationFeatures feats = expRel.getFeatures();
            
            addressesToCheck.add(expRel.getSelection().getAddresses());
        }
        
        
        addressesToCheck.add(rel.getArg1().getSelection().getAddresses());
        addressesToCheck.add(rel.getArg2().getSelection().getAddresses());
        
        
        GornAddressList gal = new GornAddressList();
        
        gal.addAll(rel.getArg1().getSelection().getAddresses());
        gal.addAll(rel.getArg2().getSelection().getAddresses());
        
        for(Iterator iter = gal.iterator(); iter.hasNext();){
            int[] address = (int[])(iter.next());
            PTBTreeNode node = (PTBTreeNode)(GornAddressUtils.getNode(address, root));
            boolean ancestorCheck = checkAncestors(node);
            boolean siblingCheck = checkSiblings(node);
            if(!ancestorCheck || !siblingCheck){
                addressesToCheck.removeAllElements();
                return false;
            }
        }
        
        if(rel.getSup1() != null){
            addressesToCheck.add(rel.getSup1().getSelection().getAddresses());
        }
        
        if(rel.getSup2() != null){
            addressesToCheck.add(rel.getSup2().getSelection().getAddresses());
        }
        
        if(!checkAddresses()){
            addressesToCheck.removeAllElements();
            return false;
        }
        
        addressesToCheck.removeAllElements();
        return true;
    }
    
    public static void printBadConns(PDTBRelationList rlist, Writer writer) throws IOException{
        root = rlist.getPTBRoot();
        String sec = rlist.getSecNo();
        String file = rlist.getFileNo();
        
        for(Enumeration e = rlist.children(); e.hasMoreElements();){
            Object o = e.nextElement();
            if(o instanceof PDTBExplicitRelation){
                PDTBExplicitRelation expRel = (PDTBExplicitRelation)o;
                if(!checkRelation(expRel)){
                    String raw = expRel.getSelection().getRawText().trim();
                    SpanList spanList = expRel.getSelection().getSpans();
                    Span span = (Span)(spanList.first());
                    
                    writer.write("agreement|rashmi|" + raw + "|" + span.getStart() + "|" + span.getEnd()  + "|wsj_" + sec + file + ".ann" + "|wsj_" + sec + file + "|" + sec + "||||"  + "gold|" );
                    writer.write('\n');
                }
                
            }
        }
    }

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try{
            AnnotationCorpusFileIterator cfi = new AnnotationCorpusFileIterator(textRoot, ptbRoot, pdtbRoot);
            RelationLoader loader = new RelationLoaderImpl();
            FileWriter writer = null;
            String prevSetNo = "";
            while(cfi.hasMoreFiles()){
                cfi.nextFile();
                String setNo = cfi.getSetNoStr();
                String secNo = cfi.getSecNoStr();
                String fileNo = cfi.getFileNoStr();
                System.err.println(setNo + " " + secNo + " " + fileNo);
            
                if(!(setNo.equals(prevSetNo))){
                    prevSetNo = setNo;
                    if(writer != null){
                        writer.close();
                    }
                    writer = new FileWriter(setNo + "TC_Tokens.txt");
                }
                try{
                    PDTBRelationList rlist = loader.loadRelations(textRoot, ptbRoot, pdtbRoot + setNo + "/", secNo, fileNo);
                    
                    DetectTechnicalErrors.printBadConns(rlist, writer);
                    
                    
                }catch(IOException e){
                    e.printStackTrace();
                }
            }
            if(writer != null){
                writer.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
