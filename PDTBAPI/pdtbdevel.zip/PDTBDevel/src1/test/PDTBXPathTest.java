package test;

import junit.framework.*;
import gnu.getopt.*;
import java.io.*;
import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.pdtb.util.*;
import edu.upenn.cis.pdtb.xpath.*;
import org.jaxen.XPath;
import java.util.*;

/*
 * PDTBXPathTest.java
 * JUnit based test
 *
 * Created on March 3, 2007, 8:23 PM
 */

/**
 *
 * @author nikhild
 */
public class PDTBXPathTest extends TestCase {
    
    public static final String RawRoot = "Corpora/PTB/raw/wsj";
    
    public static final String PtbRoot = "Corpora/PTB/combined/wsj";
    
    public static final String PdtbRoot = "Corpora/pdtb/wsj";
    
    private char[] fRawBuffer = new char[8192];
    
    private PDTBStringBuffer fRawStringBuffer = new  PDTBStringBuffer(8192);
    
    private RelationLoader fLoader = new RelationLoaderImpl();
    
    private PDTBNavigator fNavigator = new PDTBNavigator(null);
    
    public PDTBXPathTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }
    
    private int getCount(String xpathExpr) throws Exception{
        XPath xp = fNavigator.parseXPath(xpathExpr);
        
        int count = 0;
        for(CorpusFileIterator cfi = new CorpusFileIterator(RawRoot, PtbRoot, PdtbRoot); cfi.hasMoreFiles();){
            cfi.nextFile();
            FileReader fr = new FileReader(new File(cfi.currentTextFile()));
                int numChars;
                
                while((numChars = fr.read(fRawBuffer)) != -1){
                    fRawStringBuffer.append(fRawBuffer, 0, numChars);
                }
                fr.close();

                int len = fRawStringBuffer.length();
                String rawString = fRawStringBuffer.toString();
                fRawStringBuffer.delete();
                PDTBRelationList rlist = fLoader.loadRelations(new FileReader(cfi.currentPdtbFile()), rawString, null);
                
                
                fNavigator.setRoot(rlist);
                
                count += xp.selectNodes(rlist).size();

        }
        
        return count;
    }
    
    public void testExplicitBecause(){
        try{
            int count = getCount(">::*[@connHead='because']");
            assertTrue(count == 860);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testModifiedConnective(){
        try{
            int count = getCount(">::*[@connHead='if' and contains(@rawText,'even')]");
            assertTrue(count == 52);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testRawText(){
        try{
            int count = getCount(">::*[@connHead='also' and @rawText='Also']");
            assertTrue(count == 118);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testRegexp(){
        try{
            int count = getCount(">::*[@connHead='if' and child::Arg2[regexp(@rawText,'.*\\W*not\\W*.*')]]");
            assertTrue(count == 59);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testRelativePosition(){
        try{
            int count = getCount(
                    ">::*[(@connHead='if' and" +
                    "       ->::*[@connHead='otherwise']) or" +
                    "      (@connHead='otherwise' and" +
                    "        <-::*[@connHead='if'])] ");
            assertTrue(count == 23);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testRelativePosition2(){
        try{
            int count = getCount(
                    ">::*[(@connHead='if' and" +
                    "       $>::*[@connHead='otherwise']) or" +
                    "      (@connHead='otherwise' and" +
                    "        <$::*[@connHead='if'])] ");
            assertTrue(count == 23);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testLoading(){
        try{
            
            int count = getCount(">::*");
            
            for(PDTBTask task = new PDTBTask(RawRoot, PtbRoot, PdtbRoot); task.hasNext();){
                PDTBRelationList rlist = task.next();
                assertTrue(rlist.getPTBRoot() != null);
                count -= rlist.getChildCount();
            }
            
            assertTrue(count == 0);
            
        }catch(Exception e){
            e.printStackTrace();
            fail("Loading failed");
        }
    }
    
    
    public static Test suite(){
        return new TestSuite(PDTBXPathTest.class);
    }
    
    public static void main(String[] args){
        junit.textui.TestRunner.run(suite());
    }
   
}
