/*
 * PTBXPathTest.java
 *
 * Created on March 5, 2007, 12:31 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package test;

import junit.framework.*;
import edu.upenn.cis.ptb.*;
import edu.upenn.cis.ptb.xpath.*;
import edu.upenn.cis.ptb.standoff.util.SPTBTask;
import java.util.*;

/**
 *
 * @author nikhild
 */
public class SPTBXPathTest extends TestCase {
    
    public static final String PtbRoot = "Corpora/SPTB/combined/wsj";
    
    /** Creates a new instance of PTBXPathTest */
    public SPTBXPathTest(String testName) {
        super(testName);
    }
    
    protected int getCount(String xpathExpr) throws Exception{
        PTBNavigator nav = new PTBNavigator(null);
        PTBXPath xp = (PTBXPath)(nav.parseXPath(xpathExpr));
        
        int count = 0;
        for(SPTBTask task = new SPTBTask(PtbRoot);task.hasNext();){
            PTBTreeNode root = task.next();
            for(Enumeration children = root.children(); children.hasMoreElements();){
                nav.setRoot((PTBTreeNode)(children.nextElement()));
                count += ((List)xp.evaluate(nav.getRoot())).size();
            }
            
        }
        return count;
    }
    
    public void testNNCount(){
        try{
            int count = getCount("=>>::NN");
            System.out.print("" + count + "/163935 ");
            assertTrue(count == 163935);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
 
    public void testPPSBAR(){
        try{
            int count = getCount(">>::PP[@raw='PP' and $>::*[position()=1 and @raw='SBAR']]");
            System.out.print(" " + count + "/640 ");
            assertTrue(count == 640);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testSubtree(){
        try{
            int count = getCount("subtree(>>::VP[@raw={VP}], {>>::NP[@raw={NP} and r-edge()]})");
            System.out.print(" " + count + "/215104 ");
            assertTrue(count == 215104);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testIFoll(){
        try{
            int count = getCount("i-foll(>>::VB,{=::NP[@raw={NP}]})");
            System.out.print(" " + count + "/23618 ");
            assertTrue(count == 23618);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testNot(){
        try{
            int count = getCount("=>>::NP[@raw='NP' and not(=>>::JJ)]");
            System.out.print(" " + count + "/211393 ");
            assertTrue(count == 211393);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public void testBigNasty(){
        try{
            int count = getCount(">>::VP[@raw={VP} and subtree(.,{i-foll(=>>::VB[l-edge()],{i-foll(=::NP[@raw={NP}],{=::PP[@raw={PP} and r-edge()]})})})]");
            System.out.print(" " + count + "/2831 ");
            assertTrue(count == 2831);
        }catch(Exception e){
            e.printStackTrace();
            fail("Could not run query");
        }
    }
    
    public static Test suite(){
        return new TestSuite(SPTBXPathTest.class);
    }
    
    public static void main(String[] args){
        junit.textui.TestRunner.run(suite());
    }
    
}
