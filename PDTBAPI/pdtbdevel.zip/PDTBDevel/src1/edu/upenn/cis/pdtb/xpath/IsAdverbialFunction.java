package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import edu.upenn.cis.pdtb.*;
import java.util.regex.*;
import java.util.List;

/**
 * Filter for adverbial connectives. This function has the signature:
 *
 * <pre>
 *  boolean is-adv()
 *  </pre>
 *
 * Returns true iff the context node is an explicit relation and the connHead
 * attribute matches the regex:
 *
 * <pre>
 * .*(instead|otherwise|therefore|as a result|nevertheless|^then|on the other hand|however|in fact|
 * further|furthermore|indeed|for example|though|yet|so$|on the contrary|conversely|consequently|
 * besides|nonetheless|afterwards|finally|by contrast|in sum|simultaneously|in addition|accordingly|
 * thus|overall|in the meantime|meanwhile|in other words|still|previously|as an alternative|specifically|
 * in particular|hence|earlier|later|regardless|for instance|in the end|on the other side|by comparison|
 * alternatively|in short|rather|ultimately|moreover|likewise|next|similarly|in contrast|thereafter|by then|
 * additionally|also|on the whole|plus as well|separately|in turn).*
 * </pre>
 *
 * @since 0.2.8
 * @author nikhild
 */
public class IsAdverbialFunction implements Function {
    
    public static final Pattern AdverbialConnPattern = Pattern.compile(".*(instead|otherwise|therefore|as a result|nevertheless|^then|on the other hand|however|in fact|further|furthermore|indeed|for example|^though|yet|so$|on the contrary|conversely|consequently|besides|nonetheless|afterwards|finally|by contrast|in sum|simultaneously|in addition|accordingly|thus|overall|in the meantime|meanwhile|in other words|still|previously|as an alternative|specifically|in particular|hence|earlier|later|regardless|for instance|in the end|on the other side|by comparison|alternatively|in short|rather|ultimately|moreover|likewise|next|similarly|in contrast|thereafter|by then|additionally|also|on the whole|plus|as well|separately|in turn).*");
    
    public IsAdverbialFunction() {
    }
    
    public Object call(Context context, List args) throws FunctionCallException {
        
        Object contextNode = context.getNodeSet().get(0);
        
        if(contextNode instanceof PDTBExplicitRelation){
            String connHead = ((PDTBExplicitRelation) contextNode).getFeatures().getConnHead();
            if(AdverbialConnPattern.matcher(connHead).matches()){
                return Boolean.TRUE;
            }
        }
        
        return Boolean.FALSE;
    }
    
}
