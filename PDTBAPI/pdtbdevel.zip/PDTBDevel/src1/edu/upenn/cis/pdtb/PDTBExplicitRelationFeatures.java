/*
 * PDTBExplicitRelationFeatures.java
 *
 * Created on November 30, 2005, 7:29 PM
 */

package edu.upenn.cis.pdtb;

/**
 * Features associated with an ExplicitRelation.
 * @author nikhild
 */
public interface PDTBExplicitRelationFeatures extends PDTBFeatures {
    
    //public static final String SenseAttributeQName = "sense";
    
    /**
     * The QName of the attribute whose value is the head of the
     * connective.
     */    
    public static final String ConnHeadAttributeQName = "connHead";
    
    //public String getSense();
    
    /**
     * Get the head of the connective.
     */    
    public String getConnHead();
    
}
