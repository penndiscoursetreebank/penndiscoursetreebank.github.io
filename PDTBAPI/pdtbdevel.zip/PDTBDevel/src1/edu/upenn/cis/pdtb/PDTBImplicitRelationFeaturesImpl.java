/*
 * PDTBImplicitRelationFeaturesImpl.java
 *
 * Created on January 22, 2006, 6:42 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

/**
 * Implementation of the PDTBImplicitRelationFeatures interface.
 * @author nikhild
 */
public class PDTBImplicitRelationFeaturesImpl extends PDTBFeaturesImpl implements PDTBImplicitRelationFeatures{
    
    private String fConn1;
    
    private String fConn2;
    
    private String fSemanticClass1;
    
    private String fSemanticClass2;
    
    /** Creates a new instance of PDTBImplicitRelationFeaturesImpl */
    public PDTBImplicitRelationFeaturesImpl(String source, String factuality, 
               String polarity, String conn1, String semanticClass1,
               String conn2, String semanticClass2) {
                   super(source, factuality, polarity);
                                      
                   fConn1 = conn1;
                   fSemanticClass1 = semanticClass1;
                   fConn2 = conn2;
                   fSemanticClass2 = semanticClass2;
    }
    
    public String getConn1() {
        return fConn1;
    }
    
    public String getSemanticClass1() {
        return fSemanticClass1;
    }
    
    
    public void updateAttributesOnNode(){
        PDTBNode node = getPDTBNode();
        
        node.pdtbSetAttribute("", Conn1AttrQName, Conn1AttrQName, "", fConn1);
        
        
        if(fConn2 != null){
            node.pdtbSetAttribute("", Conn2AttrQName, Conn2AttrQName, "", fConn2);
        }
        
        super.updateAttributesOnNode();
        
        node.pdtbSetAttribute("", SemanticClass1AttrQName, SemanticClass1AttrQName, "", fSemanticClass1);
        
        if(fSemanticClass2 != null){
            node.pdtbSetAttribute("", SemanticClass2AttrQName, SemanticClass2AttrQName, "", fSemanticClass2);
        }
    }
    
    public String getConn2() {
        return fConn2;
    }
    
    public String getSemanticClass2() {
        return fSemanticClass2;
    }
    
    public void save(Writer writer) throws IOException{
        super.save(writer);
        
        writer.write(fConn1);
        writer.write('\n');
        
        writer.write(fSemanticClass1);
        writer.write('\n');
        
        if(fConn2 != null){
            writer.write(fConn2);
            writer.write('\n');
        }
        
        if(fSemanticClass2 != null){
            writer.write(fSemanticClass2);
            writer.write('\n');
        }
        
        
    }
    
}
