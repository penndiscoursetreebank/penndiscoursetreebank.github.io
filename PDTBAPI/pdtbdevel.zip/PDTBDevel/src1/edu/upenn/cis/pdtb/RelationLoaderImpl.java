/*
 * RelationLoaderImpl.java
 *
 * Created on December 1, 2005, 12:29 AM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.pdtb.lexyacc.*;
import edu.upenn.cis.pdtb.util.PDTBStringBuffer;
import edu.upenn.cis.ptb.*;
import edu.upenn.cis.ptb.standoff.SPTBLoaderImpl;
import java.io.*;
import java_cup.runtime.Symbol;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Enumeration;

/**
 *
 * @author  nikhild
 */
public class RelationLoaderImpl implements RelationLoader {
    
    private Yylex fScanner = null;
    
    private Yacc fParser = null;
    
    private PTBLoader fPTBLoader = null;
    
    private char[] fRawBuffer = new char[8192];
    
    private PDTBStringBuffer fRawStringBuffer = new PDTBStringBuffer(8192);
    
    /** Creates a new instance of RelationLoaderImpl */
    public RelationLoaderImpl() {
	this(false);
    }

    public RelationLoaderImpl(boolean useStandoffPTB){
	if(useStandoffPTB){
	    fPTBLoader = new SPTBLoaderImpl();
	}
	else{
	    fPTBLoader = new PTBLoaderImpl();
	}
	
    }
    
    public PDTBRelationList loadRelations(Reader r, String rawString, PTBTreeNode root) throws IOException {
        return load(r, rawString, root, null, null);
    }
    
    private PDTBRelationList load(Reader r, String rawString, PTBTreeNode root, String secNo, String fileNo) throws IOException{
        try{
            if(fScanner == null){
                fScanner = new Yylex(r, rawString, root, new PDTBRelationListImpl(rawString, root, secNo, fileNo));
                fParser = new Yacc(fScanner);
            }
            else{
                fScanner.reset(r, rawString, root, new PDTBRelationListImpl(rawString, root, secNo, fileNo));
            }
            
            Symbol parseTree = fParser.parse();
            PDTBRelationList rList = (PDTBRelationList)parseTree.value;
            
            r.close();
            
            return rList;
            
        }catch(Exception e){
            IOException e1 = new IOException("Read Failed.");
            e1.initCause(e);
            throw(e1);
        }
    }
    
    public PDTBRelationList loadRelations(String textFile, String ptbFile, String pdtbFile) throws IOException {
        FileReader fr = new FileReader(new File(textFile));
        int numChars;
        
        while((numChars = fr.read(fRawBuffer)) != -1){
            fRawStringBuffer.append(fRawBuffer, 0, numChars);
        }
        fr.close();
        
        String rawString = fRawStringBuffer.toString();
        fRawStringBuffer.delete();
        
        
        PTBTreeNode root = fPTBLoader.load(ptbFile);
        
        return load(new FileReader(new File(pdtbFile)), rawString, root, null, null);
    }
    
    public PDTBRelationList loadRelations(String textRoot, String ptbRoot, String pdtbRoot, String secNo, String fileNo) throws IOException {
        File rawFile = new File(new File(textRoot), secNo + File.separator + "wsj_" + secNo + fileNo);
        FileReader fr = new FileReader(rawFile);
        int numChars;
        
        while((numChars = fr.read(fRawBuffer)) != -1){
            fRawStringBuffer.append(fRawBuffer, 0, numChars);    
        }
        fr.close();
        
        int len = fRawStringBuffer.length();
        String rawString = fRawStringBuffer.toString();
        fRawStringBuffer.delete();
        
        PTBTreeNode root = fPTBLoader.load(new FileReader(new File(new File(ptbRoot), secNo + File.separator + "wsj_" + secNo + fileNo + ".mrg")));
        
        
        return load(new FileReader(new File(pdtbRoot, secNo + File.separator + "wsj_" + secNo + fileNo + ".pdtb")), rawString, root, secNo, fileNo);
        
        
    }
    
    
    public static void main(String[] args){
        try{
            if(args.length != 3){
                System.err.println("Usage: java edu.upenn.cis.pdtb.RelationLoaderImpl textFile ptbFile pdtbFile");
                System.exit(0);
            }
            RelationLoader loader = new RelationLoaderImpl();
            loader.loadRelations(args[0], args[1], args[2]);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
