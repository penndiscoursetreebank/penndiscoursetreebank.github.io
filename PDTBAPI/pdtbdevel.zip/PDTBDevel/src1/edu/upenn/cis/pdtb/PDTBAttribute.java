/*
 * pdtbAttribute.java
 *
 * Created on June 10, 2005, 11:03 AM
 */

package edu.upenn.cis.pdtb;

/**
 * An attribute asscoiated with a PDTBNode. Attributes are maintained
 * in addition to features, as a convenience to provide XPath
 * support.
 * @author nikhild
 * @see edu.upenn.cis.pdtb.xpath.PDTBNavigator for a list of attributes that appear on each element
 */
public interface PDTBAttribute {
    
    /**
     * The namespaceURI of the attribute.
     */    
    public String pdtbGetNamespaceURI();
    
    /**
     * The local name of the attribute
     */    
    public String pdtbGetLocalName();
    
    /**
     * The prefix associated with the namespace URI
     */    
    public String pdtbGetPrefix();
    
    /**
     * The qualified name of the attribute
     */    
    public String pdtbGetQName();
    
    /**
     * The value of the attribute
     */    
    public String pdtbGetValue();
    
    /**
     * The pdtbTreeNode with which this attribute is associated
     */    
    public PDTBNode pdtbGetOwnerNode();
    
}
