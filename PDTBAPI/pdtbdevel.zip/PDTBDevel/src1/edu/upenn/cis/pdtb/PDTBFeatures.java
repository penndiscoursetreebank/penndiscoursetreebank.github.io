/*
 * PDTBFeatures.java
 *
 * Created on November 27, 2005, 12:40 PM
 */

package edu.upenn.cis.pdtb;

/**
 * The base class of the features associated with a PDTBNode. In this
 * base form, it is associated with PDTBArg. Subclasses are associated
 * with relations.
 * @author nikhild
 */
public interface PDTBFeatures {
    
    /**
     * Value indicating source is the writer.
     */    
    public static final int SourceWriter = 0;
    
    /**
     * Value indicating that source is an entity other than the writer.
     */    
    public static final int SourceOther = 1;
    
    /**
     * Value indicating factuality.
     */    
    public static final int Factual = 0;
    
    /**
     * Value indicating non-factuality.
     */    
    public static final int NonFactual = 1;
    
    /**
     * Value indicating that factuality considerations don't apply.
     */
    public static final int NullFactual = 2;
    
    /**
     * Value indicating positive polarity.
     */    
    public static final int PolarityPositive = 0;
    
    /**
     * Value indicating negative polarity.
     */    
    public static final int PolarityNegative = 1;
    
    /**
     * Value indicating source inheritance.
     */    
    public static final int SourceInherited = 2;
    
    /**
     * QName of the attribute whose value is the source.
     */    
    public static final String SourceAttributeQName = "source";
    
    /**
     * QName of the attribute whose value determines factuality.
     */    
    public static final String FactualityAttributeQName = "factuality";
    
    /**
     * QName of the attribute whose value determines polarity.
     */    
    public static final String PolarityAttributeQName = "polarity";
    
    /**
     * String value of positive polarity.
     */    
    public static final String PositivePolarityVal = "Pos";
    
    /**
     * String value of negative polarity.
     */    
    public static final String NegativePolarityVal = "Neg";
    
    /**
     * String value of factuality.
     */    
    public static final String FactualVal = "Fact";
    
    /**
     * String value of non-factuality.
     */    
    public static final String NonFactualVal = "NonFact";
    
    /**
     * String value of null factuality
     */
    public static final String NullFactualVal = "Null";
    
    /**
     * String value when the source is the writer.
     */    
    public static final String SourceWriterVal = "Wr";
    
    /**
     * String value when the source is not the writer.
     */    
    public static final String SourceOtherVal = "Ot";
    
    /**
     * String value of source inheritance.
     */    
    public static final String SourceInheritedVal = "Inh";
    
    
    /**
     * Get the source.
     * @return One of PDTBFeatures.SourceWriter, PDTBFeatures.SourceOther,
     * and PDTBFeatures.SourceInherited.
     */    
    public int getSource();
    
    /**
     * Get the factuality.
     * @return One of PDTBFeatures.Factual, PDTBFeatures.NonFactual,
     * and PDTBFeatures.NullFactual.
     */    
    public int getFactuality();
    
    /**
     * Get the polarity.
     * @return One of PDTBFeatures.PolarityPositive,
     * PDTBFeatures.PolarityNegative.
     */    
    public int getPolarity();
    
    /**
     * Get the node on with which these features are associated.
     */    
    public PDTBNode getPDTBNode();
    
    /**
     * Set the node with which these features are associated.
     */    
    public void setPDTBNode(PDTBNode node);
    
    /**
     * Update the attributes on the node to the string values of these features.
     */    
    public void updateAttributesOnNode();
    
}
