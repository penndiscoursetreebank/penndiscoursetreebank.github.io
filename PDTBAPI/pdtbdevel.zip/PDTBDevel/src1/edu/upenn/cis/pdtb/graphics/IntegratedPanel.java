/*
 * IntegratedPanel.java
 *
 * Created on December 7, 2005, 6:28 PM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.*;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.Font;
import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.ptb.*;

/**
 * The panel is first split horizontally. In the top portion the PTBPanel
 * is added. The bottom part is then split vertically. The left side contains
 * the PDTB relations rendered in a JTree, and the right side constains the
 * text in a WSJTextArea.
 *
 * @since 0.1
 * @version 2 Added support for compare mode.
 * @author  nikhild
 * @see WSJTextArea
 * @see PTBPanel
 */
public class IntegratedPanel extends JPanel{
    
    private PDTBRelationList fRelationList;
    
    private boolean fCompareMode;
    
    public IntegratedPanel(PDTBRelationList rlist) {
        this(rlist, false);
    }
    
    public IntegratedPanel(PDTBRelationList rlist, boolean compareMode) {
        super();
        setBackground(ColorConstants.DefaultBackground);
        fCompareMode = compareMode;
        
        if(fCompareMode){
            setLayout(new GridLayout(1,2));
        } else{
            setLayout(new GridLayout(1,1));
        }
        
        fRelationList = rlist;
        add(new IntegratedSplitPane(fRelationList));
        
        if(fCompareMode){
            add(new IntegratedSplitPane(fRelationList));
        }
        
        
    }
    
    
    public PDTBRelationList getRelationList(){
        return fRelationList;
    }
    
    public void setCompareMode(boolean compareMode){
        boolean oldCompareMode = fCompareMode;
        fCompareMode = compareMode;
        
        if(oldCompareMode != fCompareMode){
            IntegratedSplitPane sp = (IntegratedSplitPane) getComponent(0);
            removeAll();
            
            
            if(fCompareMode){
                setLayout(new GridLayout(1,2));
            } else{
                setLayout(new GridLayout(1,1));
            }
            
            add(sp);
            
            if(fCompareMode){
                add(new IntegratedSplitPane(fRelationList));
            }
            
            revalidate();
        }
    }
    
    public boolean getCompareMode(){
        return fCompareMode;
    }
    
    public class IntegratedSplitPane extends JSplitPane implements FontChangeListener{
        
        private JTree fRelationTree;
        
        private PTBPanel fPTBPanel;
        
        private WSJTextArea fTextArea;
        
        public IntegratedSplitPane(PDTBRelationList rlist){
            super(JSplitPane.VERTICAL_SPLIT, true);
            
            //Create the PDTB component
            fRelationTree = new JTree(rlist);
            fRelationTree.setRootVisible(false);
            fRelationTree.setCellRenderer(new PDTBNodeRenderer(ColorConstants.PDTBNodeSelectionColor, ColorConstants.DefaultBackground));
            
            //Create the PTB component which listens to the PDTB component
            fPTBPanel = new PTBPanel(rlist.getPTBRoot(), fRelationTree);
            
            //Create the text component which listens to the PDTB component
            fTextArea = new WSJTextArea(rlist.getRawText(), fRelationTree);
            //textArea.setPreferredSize(new Dimension(100,100));
            
            //The bottom portion of the screen
            JSplitPane horizSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true, new JScrollPane(fRelationTree), new JScrollPane(fTextArea));
            horizSplit.setPreferredSize(new Dimension(100,100));
            horizSplit.setDividerLocation(200);
            
            setTopComponent(new JScrollPane(fPTBPanel));
            setBottomComponent(horizSplit);
            
            setDividerLocation(300);
            FontProvider.PDTBBrowserFontProvider.addListener(this);
            
            
            
        }
        
        public void fontChanged(Font newFont){
            fRelationTree.setCellRenderer(new PDTBNodeRenderer(ColorConstants.PDTBNodeSelectionColor, ColorConstants.DefaultBackground));
            fRelationTree.repaint();
            repaint();
        }
    }

}
