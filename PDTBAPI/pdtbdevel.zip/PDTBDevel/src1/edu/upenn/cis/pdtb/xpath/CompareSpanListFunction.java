/*
 * CompareSpanListFunction.java
 *
 * Created on March 17, 2007, 9:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import edu.upenn.cis.pdtb.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Enumeration;

/**
 * Generic SpanList comparisons.  This function has the signature:
 *
 * <pre>
 *  boolean comp-splist(string comparisonMethod, node-set setOfL2s, string flags?)
 * </pre>
 *
 * The following are valid comparison methods:
 *
 * <ul>
 *  <li> contains </li>
 *  <li> is-contained-by </li>
 *  <li> overlaps </li>
 *  <li> ranges-contains </li>
 *  <li> is-ranged-contained-by </li>
 *  <li> range-identity </li>
 *   <li> range-crosses </li>
 *   <li> range-overlaps</li>
 *  <li> identity </li>
 * </ul>
 *
 * Any subset of the following flags may be used separated by hyphens:
 *
 * <ul>
 *  <li> uc - Union interpretation of context</li>
 *  <li> uns - Union interpretation of node-set </li>
 *  <li> ei - Exclude identity </li>
 *  <li> ec - Exclude containment </li>
 *  <li> eo - Exclude overlap </li>
 *  <li> eri - Exclude range identity </li>
 *  <li> erc - Exclude range containment </li>
 *  <li> ero - Exclude range overlap </li>
 *  <li> erx - Exclude range crosses </li>
 *  <li> esp - Exclude siblings and parents from being compared against each other </li>
 *  <li> emp - Exclude if the parents of the context and the node-set match</li>
 *  <li> emcp - Exclude if the parent of the context matches the node in the node-set </li>
 *  <li> emnsp - Exclude if the context node matches the parent of the node in the node-set</li>
 * </ul>
 *
 * The flags <code>emp, emcp and emnsp</code> exclude cases only if the parent is a relation. While
 * checking if a parent or parents match: the flags <code>ei, ec, eo, eri, ero and erx </code> are
 * negated, i.e., the parent matches if there is identity, overlap, range-identity, ranging-over or range-crossing.
 *
 * <p>
 * The flag <code>uc</code> works as follows: if the context node is a relation, then the corresponding
 * spanlist is the union of the spanlists of the connective(if any) and it's arguments. If the context node is Arg2 of a relation, then
 * the spanlist is the union of the connective(if any) and Arg2.
 *</p>
 *
 * <p>
 * The following query selects relations which
* share an argument exactly with another relation:
*
* <pre>
* Shared Argument:
*
* >::*[>::*[is-arg() and 
*      comp-splist('identity',/>>::*[is-arg()])]]
* </pre>
*
 * A detailed discussion of this and other examples can be found off the
 * <a href="http://www.seas.upenn.edu/~nikhild/PDTBAPI/xpathextensions.html">API Page </a>
 *</p>
 *
 * @version 3 Added several flags, comparison methods and changed range-over to range-contains.
 * @version 2
 * @since 0.2.5
 * @author nikhild
 */
public class CompareSpanListFunction implements Function{
    
    static final int Contains = 1;
    
    static final int IsContainedBy = 2;
    
    static final int Overlaps = 3;
    
    static final int RangeContains = 4;
    
    static final int IsRangeContainedBy = 5;
    
    static final int RangeCrosses = 6;
    
    static final int RangeIdentity = 7;
    
    static final int RangeOverlaps = 8;
    
    static final int Identity = 9;
    
    private Flags fFlags = new Flags();
    
    /** Creates a new instance of CompareSpanListFunction */
    public CompareSpanListFunction() {
    }
    
    static int getComparisonMethod(String methodName) throws FunctionCallException{
        if(methodName.equals("contains")){
            return Contains;
        }
        else if(methodName.equals("is-contained-by")){
            return IsContainedBy;
        }
        else if(methodName.equals("overlaps")){
            return Overlaps;
        }
        else if(methodName.equals("range-contains")){
            return RangeContains;
        }
        else if(methodName.equals("is-range-contained-by")){
            return IsRangeContainedBy;
        }
        else if(methodName.equals("range-crosses")){
            return RangeCrosses;
        }
        else if(methodName.equals("range-overlaps")){
            return RangeOverlaps;
        }
        else if(methodName.equals("range-identity")){
            return RangeIdentity;
        }
        else if(methodName.equals("identity")){
            return Identity;
        }
        
        
        throw(new FunctionCallException("The comparison method is invalid. It should be one of: contains, is-contained-by, overlaps, identiy," +
                "range-ovelaps, range-contains, is-range-contained-by, range-crosses, range-identity."));
    }
    
    static boolean getComparisonResult(int comparisonMethod, SpanList l1, SpanList l2){
        switch(comparisonMethod){
            case Contains: {return l2.isContainedBy(l1);}
            case IsContainedBy: {return l1.isContainedBy(l2);}
            case Overlaps: {return l1.isOverlapping(l2);}
            case RangeContains: {return l1.rangesOver(l2);}
            case IsRangeContainedBy: {return l1.isRangedOverBy(l2);}
            case RangeOverlaps: {return l1.range().isOverlapping(l2.range());}
            case RangeCrosses: {return l1.rangeCrosses(l2);}
            case RangeIdentity: {return l1.range().equals(l2.range());}
            case Identity: {return l1.isIdentical(l2);}
        }
        return false;
    }
    
    static boolean checkExcludeFlags(SpanList l1, SpanList l2, Flags flags){
        
        if(flags.ExcludeOverlap && l1.isOverlapping(l2)){
            return false;
        }
        else if(flags.ExcludeContains && (l1.isContainedBy(l2) || l2.isContainedBy(l1))){
            return false;
        }
        else if(flags.ExcludeIdentity && l1.isIdentical(l2)){
            return false;
        }
        else if(flags.ExcludeRangeIdentity && (l1.range().equals(l2.range()))){
            return false;
        }
        else if(flags.ExcludeRangeContain && (l1.range().contains(l2.range()) || l2.range().contains(l1.range()))){
            return false;
        }
        else if(flags.ExcludeRangeCrosses && (l1.range().crosses(l2.range()))){
            return false;
        }
        else if(flags.ExcludeRangeOverlap && l1.range().isOverlapping(l2.range())){
            return false;
        }
        
        return true;
    }
    
    
    public Object call(Context context, List args) throws FunctionCallException {
        int numArgs = args.size();
        
        
        if(numArgs >= 2){
            Object arg1 = args.get(0);
            Object arg2 = args.get(1);
            
            if(!(arg1 instanceof String) && !(arg2 instanceof List)){
                throw(new FunctionCallException("Usage: comp-splist(string, node-set, string?)"));
            } else{
                if(numArgs ==3){
                    Object o = args.get(2);
                    if(o instanceof String){
                        String str = (String) o;
                        fFlags.parse(str);
                        
                    }
                }
                
                int comparisonMethod = getComparisonMethod((String) arg1);
                List nodes = (List) arg2;
                
                try{
                    PDTBNode contextNode = (PDTBNode) context.getNodeSet().get(0);
                    SpanList l = SpanListSizeFunction.getSpanListForNode(contextNode, fFlags.UnionContext);
                    if(l == null){
                        return Boolean.FALSE;
                    } else{
                        for(Iterator iter = nodes.iterator(); iter.hasNext();){
                            PDTBNode oNode = (PDTBNode) iter.next();
                            if(oNode != contextNode){
                                SpanList l2 = SpanListSizeFunction.getSpanListForNode(oNode, fFlags.UnionNodeSet);
                                boolean excludeONode = ((fFlags.ExcludeSharedParent) &&
                                        (contextNode.getParent() == oNode.getParent() ||
                                        contextNode == oNode.getParent() ||
                                        oNode == contextNode.getParent())) ;
                                
                                if(l2 != null &&
                                        !excludeONode &&
                                        checkExcludeFlags(l,l2,fFlags) &&
                                        getComparisonResult(comparisonMethod,l,l2)){
                                    boolean matchVal = true;
                                    if(fFlags.ExcludeMatchingContextParent && contextNode instanceof PDTBSup){
                                        SpanList l11 = SpanListSizeFunction.getSpanListForNode((PDTBNode) contextNode.getParent(), fFlags.UnionContext);
                                        if(l11 != null &&
                                                ( !checkExcludeFlags(l11,l2,fFlags) ||
                                                getComparisonResult(comparisonMethod,l11,l2))
                                                ){
                                            
                                            matchVal = false;
                                        }
                                    } else if(fFlags.ExcludeMatchingNodeSetParent && oNode instanceof PDTBSup){
                                        SpanList l22 = SpanListSizeFunction.getSpanListForNode((PDTBNode) oNode.getParent(), fFlags.UnionNodeSet);
                                        if(l22 != null &&
                                                (!checkExcludeFlags(l,l22,fFlags) ||
                                                getComparisonResult(comparisonMethod,l,l22))
                                                ){
                                            matchVal = false;
                                        }
                                    } else if(fFlags.ExcludeMatchingParents &&
                                            contextNode instanceof PDTBSup &&
                                            oNode instanceof PDTBSup){
                                        SpanList l13 = SpanListSizeFunction.getSpanListForNode((PDTBNode) contextNode.getParent(), fFlags.UnionContext);
                                        SpanList l23 = SpanListSizeFunction.getSpanListForNode((PDTBNode) oNode.getParent(), fFlags.UnionNodeSet);
                                        
                                        if(l13 != null && l23 != null &&
                                                (!checkExcludeFlags(l13,l23,fFlags) ||
                                                getComparisonResult(comparisonMethod,l13,l23))
                                                
                                                ){
                                            matchVal = false;
                                        }
                                    }
                                    
                                    
                                    if(matchVal){
                                        
                                        return Boolean.TRUE;
                                    }
                                }
                                
                            }
                            
                            
                            
                        }
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
                
                return Boolean.FALSE;
                
            }
        }
        
        throw(new FunctionCallException("Usage: comp-splist(string, node-set, string?)"));
    }

    public class Flags{
        public boolean UnionContext = false;
        public boolean UnionNodeSet = false;
        public boolean ExcludeIdentity = false;
        public boolean ExcludeOverlap = false;
        public boolean ExcludeContains = false;
        public boolean ExcludeSharedParent = false;
        public boolean ExcludeRangeIdentity = false;
        public boolean ExcludeRangeContain = false;
        public boolean ExcludeRangeCrosses = false;
        public boolean ExcludeRangeOverlap = false;
        public boolean ExcludeMatchingContextParent = false;
        public boolean ExcludeMatchingNodeSetParent = false;
        public boolean ExcludeMatchingParents = false;
        
        public Flags(){
            
        }
        
        public void parse(String str){
            int len = str.length();
            for(int i = 0; i < len; i++){
                char c = str.charAt(i);
                switch(c){
                    case 'u': {
                        if(i < len - 1 && str.charAt(i + 1) == 'c'){
                            UnionContext = true;
                        } else if(i < len-2 && str.charAt(i + 1) == 'n' && str.charAt(i + 2) == 's'){
                            UnionNodeSet = true;
                        }
                        break;
                    }
                    
                    case 'e':{
                        if(i < len - 1){
                            char c1 = str.charAt(i + 1);
                            switch(c1){
                                case 'o': {ExcludeOverlap = true; break;}
                                case 'c': {ExcludeContains = true; break;}
                                case 'i': {ExcludeIdentity = true; break;}
                                case 's': {
                                    if(i < len - 2 && str.charAt(i+2) == 'p'){
                                        ExcludeSharedParent = true;
                                    }
                                    break;
                                }
                                case 'm': {
                                    if(i < len - 2 && str.charAt(i+2) == 'p'){
                                        ExcludeMatchingParents = true;
                                    } else if(i < len - 3 && str.charAt(i+2) == 'c' && str.charAt(i+3) == 'p'){
                                        ExcludeMatchingContextParent = true;
                                    } else if(i < len - 4 &&
                                            str.charAt(i+2) == 'n' &&
                                            str.charAt(i+3) == 's' &&
                                            str.charAt(i+4) == 'p'){
                                        ExcludeMatchingNodeSetParent = true;
                                    }
                                    break;
                                }
                                case 'r': {
                                    if(i < len - 2 && str.charAt(i+2) == 'i'){
                                        ExcludeRangeIdentity = true;
                                    } else if(i < len - 2 && str.charAt(i+2) == 'o'){
                                        ExcludeRangeOverlap = true;
                                    } else if(i < len - 2 && str.charAt(i+2) == 'x'){
                                        ExcludeRangeCrosses = true;
                                    } else if(i < len - 2 && str.charAt(i+2) == 'c'){
                                        ExcludeRangeContain = true;
                                    }
                                    
                                    break;
                                }
                            }
                            
                        }
                        break;
                    }
                }
            }
        }
    }
}
