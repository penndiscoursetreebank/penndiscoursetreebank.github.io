/*
 * FileNoComboBoxModel.java
 *
 * Created on December 7, 2005, 7:24 PM
 */

package edu.upenn.cis.pdtb.graphics;

import java.util.LinkedList;
import javax.swing.ComboBoxModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import org.omg.CORBA.StringHolder;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

/**
 * ComboBoxModel representing the files that are present in a given section.
 * The section number is obtained by setting this as a listener on the
 * combo box for section numbers.
 *
 * @author  nikhild
 * @see SecNoComboBoxModel
 */
public class FileNoComboBoxModel implements ComboBoxModel, ItemListener, ChangeListener{
    
    //An array of length 25, such that the ith element contains the files
    //available for section i.
    private LinkedList[] fFileNumbers;
    
    //The files available in the current section
    private LinkedList fCurrentSection;
    
    //The number of the current section
    private int fCurrentSectionNo;
    
    //Listeners who need notification when the section number changes
    private Vector fListeners = new Vector();
    
    //The current file
    private String fCurrentFileNo;
    
    /** Creates a new instance of FileNoComboBoxModel */
    public FileNoComboBoxModel(LinkedList[] fileNumbers) {
        fFileNumbers = fileNumbers;
        int len = fileNumbers.length;
        
        //Track to the first section that has atleast 1 file and
        //make that the current section.
        boolean done = false;
        for(int i = 0; i < len && !done; i++){
           fCurrentSection = fileNumbers[i]; 
           fCurrentSectionNo = i;
           if(fCurrentSection.size() > 0){
               done = true;
           }
        }
        
        //Set the current file.
        if(!(fCurrentSection.isEmpty())){
            fCurrentFileNo = (String)(fCurrentSection.getFirst());
        }
        else{
            fCurrentFileNo = "";
        }
    }
    
    public void addListDataListener(ListDataListener listDataListener) {
        fListeners.add(listDataListener);
    }
    
    public Object getElementAt(int param) {
        return fCurrentSection.get(param);
    }
    
    public Object getSelectedItem() {
        return fCurrentFileNo;
    }
    
    /**
     * Set the section number
     *
     * @param secNo the section number
     */
    protected void setSectionNo(int secNo){
        fCurrentSectionNo = secNo;
        
        if(secNo >= 0 && secNo < fFileNumbers.length){
            fCurrentSection = fFileNumbers[fCurrentSectionNo];
        }
        else{
            fCurrentSection = new LinkedList();
        }
        
        if(!(fCurrentSection.isEmpty())){
            setSelectedItem(fCurrentSection.getFirst());
        }
        else{
            setSelectedItem("");
        }
        
        //Notify the listeners that the contents of this combo box has changed
        //and thus needs repainting.
        for(Enumeration e = fListeners.elements(); e.hasMoreElements();){
            ListDataListener l = (ListDataListener)(e.nextElement());
            l.contentsChanged(new ListDataEvent(this, ListDataEvent.CONTENTS_CHANGED, 0, fCurrentSection.size()));
        }
        
    }
    
    public int getSize() {
        return fCurrentSection.size();
    }
    
    public void removeListDataListener(ListDataListener listDataListener) {
        fListeners.remove(listDataListener);
    }
    
    public void setSelectedItem(Object obj) {
        fCurrentFileNo = (String)obj;
        for(Enumeration e = fListeners.elements(); e.hasMoreElements();){
            ListDataListener l = (ListDataListener)(e.nextElement());
            l.contentsChanged(new ListDataEvent(this, ListDataEvent.CONTENTS_CHANGED, 0, fCurrentSection.size()));
        }
    }
    
    public void itemStateChanged(ItemEvent e) {
        //A new section number has been selected
        if(e.getStateChange() == ItemEvent.SELECTED){
            //Set the section number
            String sec = (String)(e.getItem());            
            setSectionNo((new Integer(sec)).intValue());
        }       
        
    }    
    
    public String getNextFileNo(){
        int len = getSize();
        String selectedItem = (String) getSelectedItem();
        if(selectedItem == null || selectedItem.equals("")){
            return null;
        }
        
        for(int i = 0; i < len; i++){
            String item = (String) getElementAt(i);
            if(item.equals(selectedItem)){
                if(i == len - 1){
                    return null;
                } else{
                    return (String) getElementAt(i+1);
                }
            }
        }
        return null;
        
    }
    
    public String getPrevFileNo(){
        int len = getSize();
        String selectedItem = (String) getSelectedItem();
        if(selectedItem == null || selectedItem.equals("")){
            return null;
        }
        
        for(int i = 0; i < len; i++){
            String item = (String) getElementAt(i);
            if(item.equals(selectedItem)){
                if(i == 0){
                    return null;
                } else{
                    return (String) getElementAt(i -1);
                }
            }
        }
        return null;
        
    }
    
    public String getFirstFileNo(){
        int len = getSize();
        if(len == 0){
            return null;
        }
        
        return (String) getElementAt(0);
        
    }
    
    public String getLastFileNo(){
        int len = getSize();
        if(len == 0){
            return null;
        }
        
        return (String) getElementAt(len -1);
        
    }
    
    public void stateChanged(ChangeEvent e) {
        Object source = e.getSource();
        if(source instanceof PDTBBrowserTab){
            PDTBBrowserTab tab = (PDTBBrowserTab) source;
            int index = tab.getSelectedIndex();
            if(index >= 0){
                String title = tab.getTitleAt(index);
                if(title != null && title.length() == 4){
                    String fileNo = title.substring(2, 4);
                    if(!fileNo.equals(getSelectedItem())){
                        setSelectedItem(fileNo);
                    }
                    
                }
            }
        }
    }
    
    
}
