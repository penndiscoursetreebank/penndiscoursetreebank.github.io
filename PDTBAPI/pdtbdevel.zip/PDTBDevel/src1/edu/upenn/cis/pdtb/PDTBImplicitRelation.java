/*
 * PDTBImplicitRelation.java
 *
 * Created on January 22, 2006, 6:28 PM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.ptb.PTBTreeNode;

/**
 * An ImplicitRelation.
 * @author nikhild
 */
public interface PDTBImplicitRelation extends PDTBRelation {
    
    /**
     * Get the site of inference of the implicit relation.
     */    
    public PDTBInferenceSite getInferenceSite();
    
    /**
     * Set the site of inference of the implicit relation.
     */    
    public void setInferenceSite(PDTBInferenceSite infSite);
    
    /**
     * Get the features.
     */    
    public PDTBImplicitRelationFeatures getFeatures();
    
    /**
     * Set the features.
     */    
    public void setFeatures(PDTBImplicitRelationFeatures feats);
}
