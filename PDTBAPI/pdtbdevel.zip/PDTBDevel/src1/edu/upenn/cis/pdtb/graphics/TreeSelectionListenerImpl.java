/*
 * TreeSelectionListenerImpl.java
 *
 * Created on December 5, 2005, 10:41 PM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import edu.upenn.cis.pdtb.*;
import java.util.Vector;
import java.util.Enumeration;
import javax.swing.tree.*;

/**
 * Synthesizes selection events on a JTree and messages PDTBNodeSelectionListeners.
 *
 * @author  nikhild
 * @see PDTBNodeSelectionListener
 */
public class TreeSelectionListenerImpl implements TreeSelectionListener{
    private Vector fListeners = new Vector();
    
    /** Creates a new instance of TreeSelectionListenerImpl */
    public TreeSelectionListenerImpl() {
    }
    
    public void add(PDTBNodeSelectionListener l){
        fListeners.add(l);
    }
    
    public void remove(PDTBNodeSelectionListener l){
        fListeners.remove(l);
    }
    
    public void valueChanged(TreeSelectionEvent e1) {
        TreePath p = e1.getNewLeadSelectionPath();
        PDTBNode n = (PDTBNode)(p.getLastPathComponent());
        
        for(Enumeration e = fListeners.elements(); e.hasMoreElements();){
            PDTBNodeSelectionListener l = (PDTBNodeSelectionListener)(e.nextElement());
            
            if(n instanceof PDTBRelation){
                if(n instanceof PDTBExplicitRelation){
                l.explicitRelationSelected((PDTBExplicitRelation)n);
                }
                else if(n instanceof PDTBAltLexRelation){
                    l.altLexRelationSelected((PDTBAltLexRelation)n);
                }
                else if(n instanceof PDTBImplicitRelation){
                    l.implicitRelationSelected((PDTBImplicitRelation)n);
                }
            }
            else{
                if(n instanceof PDTBEntityRelation){
                    if(n instanceof PDTBNoRelation){
                        l.noRelationSelected((PDTBNoRelation)n);
                    }
                    else{
                        l.entityRelationSelected((PDTBEntityRelation)n);
                    }
                }
                else if(n instanceof PDTBArg){
                    
                    if(n == ((PDTBRelation) n.getParent()).getArg1()){
                        l.arg1Selected((PDTBArg)n);
                    }
                    else{
                        l.arg2Selected((PDTBArg)n);
                    }
                    
                }
                else{
                    PDTBNode parent = (PDTBNode)(n.getParent());
                    if(parent instanceof PDTBRelation){
                        if(n == ((PDTBRelation) parent).getSup1()){
                            l.sup1Selected((PDTBSup)n);
                        }
                        else{
                            l.sup2Selected((PDTBSup)n);
                        }
                    }
                    else{
                        if(n == ((PDTBEntityRelation)parent).getArg1()){
                            l.arg1Selected((PDTBSup)n);
                        }
                        else{
                            l.arg2Selected((PDTBSup)n);
                        }
                    }
                }
            }
        }
        
    }
    
}
