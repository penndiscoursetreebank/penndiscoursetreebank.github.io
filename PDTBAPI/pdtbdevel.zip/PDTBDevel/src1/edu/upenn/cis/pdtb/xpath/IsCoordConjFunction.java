package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import edu.upenn.cis.pdtb.*;
import java.util.regex.*;
import java.util.List;

/**
 * Filter for subordinating conjunctions. This function has the signature:
 *
 * <pre>
 *  boolean is-sc()
 *  </pre>
 *
 * Returns true iff the context node is an explicit relation and the connHead
 * attribute matches the regex:
 *
 * <pre>
 * .*(and|or|but|nor)
 * </pre>
 *
 * @since 0.2.8
 * @author nikhild
 */
public class IsCoordConjFunction implements Function{
    
    public static final Pattern CoordConjConnPattern = Pattern.compile(".*(and|or|but|nor)");
    
    public IsCoordConjFunction() {
    }
    
    public Object call(Context context, List args) throws FunctionCallException {
        
        Object contextNode = context.getNodeSet().get(0);
        
        if(contextNode instanceof PDTBExplicitRelation){
            String connHead = ((PDTBExplicitRelation) contextNode).getFeatures().getConnHead();
            if(CoordConjConnPattern.matcher(connHead).matches()){
                return Boolean.TRUE;
            }
        }
        
        return Boolean.FALSE;
    }
    
}
