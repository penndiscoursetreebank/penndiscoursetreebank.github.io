/*
 * FontChangeListener.java
 *
 * Created on February 17, 2006, 11:10 PM
 */

package edu.upenn.cis.pdtb.graphics;

import java.awt.Font;

/**
 *
 * @author  nikhild
 */
public interface FontChangeListener {
    
    public void fontChanged(Font newFont);
}
