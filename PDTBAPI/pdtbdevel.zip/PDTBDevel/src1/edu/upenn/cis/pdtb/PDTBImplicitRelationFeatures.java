/*
 * PDTBImplicitRelationFeatures.java
 *
 * Created on January 22, 2006, 6:33 PM
 */

package edu.upenn.cis.pdtb;

/**
 * Features associated with an implicit relation.
 * @author nikhild
 */
public interface PDTBImplicitRelationFeatures extends PDTBFeatures {
    /**
     * QName of the attribute whose value gives a connective expressing the
     * relation. Used iff the type is PDTBImplicitRelationFeatures.EConn.
     */    
    public static final String Conn1AttrQName = "conn1";
    
    /**
     * QName of the attribute whose value gives the semantic class of the value
     * of PDTBImplicitRelationFeatures.Conn1.
     */    
    public static final String SemanticClass1AttrQName = "semanticClass1";
    
    /**
     * QName of the attribute whose value gives a connective expressing the
     * relation. Used only if the type is PDTBImplicitRelationFeatures.EConn.
     */    
    public static final String Conn2AttrQName = "conn2";
    
    /**
     * QName of the attribute whose value gives the semantic class of the value
     * of PDTBImplicitRelationFeatures.Conn2
     */    
    public static final String SemanticClass2AttrQName = "semanticClass2";
    
    
    /**
     * Get a connective that expresses the relation
     * @return The connective iff getType() == EConn. null otherwise.
     */    
    public String getConn1();
    
    /**
     * Get the semantic class of Conn1.
     * @return Semantic class if Conn1 is not null. null otherwise.
     */    
    public String getSemanticClass1();
    
    /**
     * Get a second connective that expresses the relation.
     * @return non null only if getType()==EConn.
     */    
    public String getConn2();
    
    /**
     * Get the semantic class of the second connective if present.
     * @return non null only if Conn2 is not null. null otherwise.
     */    
    public String getSemanticClass2();
}
