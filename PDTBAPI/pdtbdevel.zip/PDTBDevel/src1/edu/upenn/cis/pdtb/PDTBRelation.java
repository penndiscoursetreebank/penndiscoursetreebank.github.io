/*
 * PDTBRel.java
 *
 * Created on November 27, 2005, 12:46 PM
 */

package edu.upenn.cis.pdtb;

import javax.swing.tree.*;

/**
 * Base class of relations. Arg1 and Arg2 are required, while Sup1 and
 * Sup2 are optional.
 * @author nikhild
 */
public interface PDTBRelation extends PDTBNode {
    
    public PDTBArg getArg1();
    
    public void setArg1(PDTBArg arg1);
    
    public PDTBArg getArg2();
    
    public void setArg2(PDTBArg arg2);
    
    public PDTBSup getSup1();
    
    public void setSup1(PDTBSup sup1);
    
    public PDTBSup getSup2();
    
    public void setSup2(PDTBSup sup2);
    
    public PDTBRelationList getRelationList();
    
    public void setRelationList(PDTBRelationList rel);
  
}


