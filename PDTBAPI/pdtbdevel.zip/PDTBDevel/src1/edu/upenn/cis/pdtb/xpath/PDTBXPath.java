/*
 * PDTBXPath.java
 *
 * Created on February 16, 2006, 8:01 PM
 */

package edu.upenn.cis.pdtb.xpath;

import gnu.getopt.*;
import java.io.*;
import edu.upenn.cis.pdtb.graphics.PDTBBrowser;
import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.pdtb.util.*;
import org.jaxen.XPath;
import java.util.*;

/**
 * A simple top level query interface to the PDTB. Usage is as follows:
 *
 * <pre>
 *  java -Xmx100M -Xms100M -server edu.upenn.cis.pdtb.xpath.PDTBXPath args
 * </pre>
 *
 * The arguments are as follows:
 *
 * <pre>
 *  --rawRoot RawRoot (or -r RawRoot)
 *  --ptbRoot PtbRoot (or -p PtbRoot)
 *  --pdtbRoot PdtbRoot (or -d PdtbRoot)
 *  --outputRoot OutputRoot (or -o OutputRoot. This will serve as the result PdtbRoot. 
 *                           OutputRoot should not exist when this is run)
 *  --xpath XPathExpression (or -x XPathExpression)
 *  -c (generates total counts in addition to the files)
 *  -b (opens results in the browser. The saved results can always be opened in the browser
 *      at a later time, by specifying OutputRoot as the PdtbRoot argument to the browser.)
 * </pre>
 *
 * The XPath expression should select Element nodes listed below. If any other kind of node or object
 * is returned by the query, the program exits. The full XPath functionality can be accessed via the
 * API. The following is the list of Elements, their children, and attributes (the suffix * 
 * indicates optionality of an attribute, and 0 or more potential occurences of a child
 * element):
 *
 * <TABLE border="1">
 * <COLGROUP>
 *    <COL width="1*" />
 *    <COL width="2*" />
 *    <COL width="2*" />
 * </COLGROUP>
 *  <TR>
 * <TD>Element QName</TD><TD>Children QNames</TD><TD> Attribute QNames</TD>
 *  </TR>
 *
 * <TR>
 * <TD>RelationList</TD>
 * <TD>ExplicitRelation*, ImplicitRelation*, AltLexRelation*, EntityRelation*, NoRelation*</TD>
 * <TD></TD>
 * </TR>
 *  
 * <TR>
 * <TD>ExplicitRelation</TD>
 * <TD>Sup1*, Arg1, Arg2, Sup2*</TD>
 * <TD>source, factuality, polarity, connHead, rawText</TD>
 * </TR>
 *
 * <TR>
 * <TD>ImplicitRelation</TD>
 * <TD>Sup1*, Arg1, Arg2, Sup2*</TD>
 * <TD>source, factuality, polarity, conn1, semanticClass1, conn2*, semanticClass2*</TD>
 * </TR>
 *
 * <TR>
 * <TD>AltLexRelation</TD>
 * <TD>Sup1*, Arg1, Arg2, Sup2*</TD>
 * <TD>source, factuality, polarity, semanticClass, rawText</TD>
 * </TR>
 *
 * <TR>
 * <TD>EntityRelation</TD>
 * <TD>Arg1, Arg2</TD>
 * <TD></TD>
 * </TR>
 *
 *<TR>
 * <TD>NoRelation</TD>
 * <TD>Arg1, Arg2</TD>
 * <TD></TD>
 * </TR>
 *
 * <TR>
 * <TD>Arg1</TD>
 * <TD></TD>
 * <TD>source, factuality, polarity, rawText</TD>
 * </TR>
 *
 * <TR>
 * <TD>Arg2</TD>
 * <TD></TD>
 * <TD>source, factuality, polarity, rawText</TD>
 * </TR>
 *
 * <TR>
 * <TD>Sup1</TD>
 * <TD></TD>
 * <TD>rawText</TD>
 * </TR>
 *
 * <TR>
 * <TD>Sup2</TD>
 * <TD></TD>
 * <TD>rawText</TD>
 * </TR>
 *
 *  </TABLE>
 *
 * <br/>
 * <br/>
 *
 * <p>
 * The expression <code>"//PDTBExplicitRelation[@connHead='because']"</code> selects
 * all occurences of the explicit connective "because". The expression 
 * <code>"//ImplicitRelation[@conn1='instead']"</code> selects all implicit relations
 * where "instead" is chosen as conn1. Note that the enclosing quotes are necessary on
 * the command line. 
 * </p>
 *
 * <p>
 * If an Element is selected by an expression, the closest ancestor (or the node 
 *  itself) which is a child of PDTBRelationList will be output. This is so that the
 * results can be loaded in the browser. If the -c option is specified total counts of
 * the number of objects selected is produced. This will usually be greater than or equal to the number
 * of relations saved in the OutputRoot.
 * </p>
 *
 * <p>
 *  Here is a sample command line invocation:
 * 
 *  <pre>
 *    java -Xmx100M -Xms100M -server edu.upenn.cis.pdtb.xpath.PDTBXPath\\  
 *            -r Corpora/PTB/raw/wsj \\ 
 *            -p Corpora/PTB/combined/wsj \\ 
 *            -d Corpora/PDTB/PDTB-Flat3 \\
 *            -o Corpora/PDTB/PDTB-Flat4 \\ 
 *            -x "//ImplicitRelation[@conn1 = 'because']" -c -b
 *   </pre>
 *
 * Note that the output directory specified by -o, should not exist prior to
 * invocation.
 *
 * </p>
 *
 * <p>
 *
 * See the <a href="http://www.w3.org/TR/xpath">XPath</a> recommendation for further 
 * info on XPath. For querying the syntax as well, use the API.
 * </p>
 *
 * <p>
 * The following syntactic shortenings are supported, since v0.2.3:
 *
 * <table border="1">
 *   <tr><td>Standard XPath</td><td>Short Form</td></tr>
 *   <tr><td><code>self::*</code></td><td><code>=::*</code></td></tr>
 *   <tr><td><code>child::*</code></td><td><code> >::*</code></td></tr>
 *   <tr><td><code>parent::* </code></td><td><code> <::*</code></td></tr>
 *   <tr><td><code>descendant::* </code></td><td><code> >>::*</code></td></tr>
 *   <tr><td><code>descendant-or-self::*</code></td><td><code> =>>::*</code></td></tr>
 *   <tr><td><code>ancestor-or-self::*</code></td><td><code> <<=::*</code></td></tr>
 *   <tr><td><code>following::*</code></td><td><code> ->::*</code></td></tr>
 *   <tr><td><code>preceding::*</code></td><td><code> <-::*</code></td></tr>
 *   <tr><td><code>following-sibling::*</code></td><td><code>$>::*</code></td></tr>
 *   <tr><td><code>preceding-sibling::* </code></td><td><code><$::*</code></td></tr>
 * </table>
 * </p>
 *
 * @since 0.1
 * @version 2 
 * @author  nikhild
 */
public class PDTBXPath {
    
    public static final String Usage =
            "------------------------------------------------------------\n\n" +
            "java edu.upenn.cis.pdtb.xpath.PDTBXPath args\n" +
            "--rawRoot or -r <rawRoot>\n" +
            "--ptbRoot or -p <ptbRoot>\n" +
            "--pdtbRoot or -d <pdtbRoot>\n" +
            "--outputRoot or -o <outputRoot>\n" +
            "--xpath or -x <xpathExpression>\n" +
            "------------------------------------\n" +
            "--help or -h prints this message\n" +
            "-c generates counts\n" +
            "-b opens results in browser\n" +
            "--shutUp or -s suppresses all overfriendly error messages\n" +
            "--exceptions or -e dumps the stack trace on an exception\n" +
            "------------------------------------\n" +
            "------------------------------------------------------------\n\n";
    
    public static final String NoFilesMessage = 
            "------------------------------------------------------------\n\n" +
            "No files were examined. Please ensure that the directories\n" +
            "are valid. For example, PtbRoot" + File.separatorChar + "00" + File.separatorChar + "wsj_0001.mrg should exist.\n\n" +
            "\n-------------------------------------------------------------\n";
    
    /** Creates a new instance of PDTBXPath */
    public PDTBXPath() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        LongOpt[] opts = new LongOpt[7];
        
        
        opts[0] = new LongOpt("rawRoot", LongOpt.REQUIRED_ARGUMENT, null, 'r');
        opts[1] = new LongOpt("ptbRoot", LongOpt.REQUIRED_ARGUMENT, null, 'p');
        opts[2] = new LongOpt("pdtbRoot", LongOpt.REQUIRED_ARGUMENT, null, 'd');
        opts[3] = new LongOpt("outputRoot", LongOpt.REQUIRED_ARGUMENT, null, 'o');
        opts[4] = new LongOpt("xpath", LongOpt.REQUIRED_ARGUMENT, null, 'x');
        opts[5] = new LongOpt("shutUp", LongOpt.NO_ARGUMENT, null, 's');
        opts[6] = new LongOpt("exceptions", LongOpt.NO_ARGUMENT, null, 'e');
        
        Getopt g = new Getopt("PDTBXPath", args, "sebcr:p:d:o:x:", opts);
        g.setOpterr(false);
        
        String rawRoot = null;
        String ptbRoot = null;
        String pdtbRoot = null;
        String outputRoot = null;
        String xpathStr = null;
        
        boolean browser = false;
        boolean produceCount = false;
        boolean shutUp = false;
        boolean dumpExceptions = false;
        
        int c;
        while((c = g.getopt()) != -1){
            switch(c){
                case 'r':
                    rawRoot = g.getOptarg();
                    break;
                case 'p':
                    ptbRoot = g.getOptarg();
                    break;
                case 'd':
                    pdtbRoot = g.getOptarg();
                    break;
                case 'o':
                    outputRoot = g.getOptarg();
                    break;
                case 'x':
                    xpathStr = g.getOptarg();
                    break;
                case 'c':
                    produceCount = true;
                    break;
                case 'b':
                    browser = true;
                    break;
                 case 's':
                    shutUp = true;
                    break;
                 case 'e':
                    dumpExceptions = true;
                    break;
                case 'h':
                    System.err.println(Usage);
                    System.exit(0);
                    break;
                default :
                    System.err.println("Invalid option: " + (char)c);
                    break;
            }
        }
        
        if(rawRoot == null || pdtbRoot == null || ptbRoot == null || outputRoot == null || xpathStr == null){
            System.err.println(Usage);
            System.exit(0);
        }
        
        
        File outputDir = new File(outputRoot);
        if(outputDir.exists()){
            System.err.print(outputRoot + " exists already. It shouldn't.");
            if(shutUp){
                System.err.println();
            }
            else{
                System.err.println("Chickening out.");
            }
            System.exit(0);
        }
        else{
            try{
                if(!outputDir.mkdirs()){
                    System.err.println(Usage);
                    System.err.println(outputRoot + " could not be created");
                    System.exit(0);
                }
            }
            catch(Exception e){
                System.err.println(Usage);
                System.err.println(outputRoot + " could not be created");
                e.printStackTrace();
                System.exit(0);
            }
        }
        
        XPath xp = null;
        PDTBNavigator nav = new PDTBNavigator(null);
        try{
            xp = nav.parseXPath(xpathStr);
        }
        catch(Exception e){
            if(dumpExceptions){
                e.printStackTrace();
            }
            
            if(shutUp){
                System.err.println(xpathStr + " is not a valid XPath expression");
                System.exit(0);
            }
            
            System.err.println(Usage);
            System.err.println(xpathStr + " is not a valid XPath expression");
            String str = edu.upenn.cis.ptb.xpath.PTBXPath.desugarExpr(xpathStr);
            System.err.println("Desugared Form         " +  str + "\n");
            if(str.equals(xpathStr)){
                System.err.println("You are either not using the syntactic sugar or using it incorrectly.");
            }
            else{
                System.err.println("If you are having trouble reading the desugared form, welcome to my life.");
                System.err.println("You may want to look for places where the desugared monstrosity is");
                System.err.println("similar to your original expression.");
            }
            
            System.err.println("Here are some common errors:");
            System.err.println("       (a) Use >::* and _not_ >* or >:*");
            System.err.println("       (b) The @ symbol should appear before attribute names");
            System.err.println("       (c) Unbalanced paratheses");
            System.err.println("       (d) Misspelling function names");

            System.err.println("Goodbye");
            System.err.println("\n-------------------------------------------------------------\n");
            System.exit(0);
        }
        
        char[] fRawBuffer = new char[8192];
        PDTBStringBuffer fRawStringBuffer = new PDTBStringBuffer(8192);
        RelationLoader loader = new RelationLoaderImpl();
	TreeSet relSet = new TreeSet(new Comparator(){
		public int compare(Object o1, Object o2){
		    Span s1 = getSpanForRel(o1);
		    Span s2 = getSpanForRel(o2);

		    if(s1.getStart() == s2.getStart()){
			return s1.getEnd() - s2.getEnd();
		    }

		    return s1.getStart() - s2.getStart();
		}

		private Span getSpanForRel(Object rel){
		    if(rel instanceof PDTBExplicitRelation){
			return (Span)(((PDTBExplicitRelation)rel).getSelection().getSpans().first());
		    }
		    else if(rel instanceof PDTBImplicitRelation){
			int position = ((PDTBImplicitRelation)rel).getInferenceSite().getStringPosition();
			return new Span(position, position);
		    }
		    else if(rel instanceof PDTBAltLexRelation) {
			return (Span)(((PDTBAltLexRelation)rel).getSelection().getSpans().first());
		    }
		    else if(rel instanceof PDTBEntityRelation){
			int position = ((PDTBEntityRelation)rel).getInferenceSite().getStringPosition();
			return new Span(position, position);
		    }
		    else{
			throw(new IllegalArgumentException("Unexpected type. " + rel.getClass().getName()));
		    }
		}

		public boolean equals(Object obj){
		    return false;
		}

	    });
                
        try{
            int count = 0;
            boolean filesSeen = false;
            for(CorpusFileIterator cfi = new CorpusFileIterator(rawRoot, ptbRoot, pdtbRoot); cfi.hasMoreFiles();){
                cfi.nextFile();
                String secNoStr = cfi.getSecNoStr();
                String fileNoStr = cfi.getFileNoStr();
                
                FileReader fr = new FileReader(new File(cfi.currentTextFile()));
                int numChars;
                
                while((numChars = fr.read(fRawBuffer)) != -1){
                    fRawStringBuffer.append(fRawBuffer, 0, numChars);
                }
                fr.close();

                int len = fRawStringBuffer.length();
                String rawString = fRawStringBuffer.toString();
                fRawStringBuffer.delete();
                PDTBRelationList rlist = loader.loadRelations(new FileReader(cfi.currentPdtbFile()), rawString, null);
                
                
                nav.setRoot(rlist);
                List nodes = xp.selectNodes(rlist);


                if(nodes.size() > 0){
                    boolean relationListSelected = false;
                    for(Iterator iter = nodes.iterator(); iter.hasNext();){
                        Object o = iter.next();
                        count++;
                        if(!(o instanceof PDTBNode)){
                            System.err.println(Usage);
                            System.err.println("XPath expression should select an Element. See docs for Element names.");
                            System.exit(0);
                        }
                        PDTBNode n = (PDTBNode)o;
                        PDTBNode parent = (PDTBNode)(n.getParent());
                        for(; (parent != null && parent.getParent() != null);){
                            n = parent;
                            parent = (PDTBNode)(parent.getParent());
                        }
                        
                        
			if(!(n instanceof PDTBRelationList)){
			    relSet.add(n);
			}
			else{
			    relSet.clear();
			    relationListSelected = true;
			}
                        
                        
                        
                    }
                    
                    File secDir = new File(outputDir, secNoStr);
                    secDir.mkdirs();
                    
                    File outputFile = new File(secDir, "wsj_" + secNoStr + fileNoStr + ".pdtb");
                    FileWriter fw = new FileWriter(outputFile);
                    
                    if(relationListSelected){
                        ((PDTBRelationListImpl)rlist).save(fw);
                    }
                    else{
                        for(Iterator iter = relSet.iterator(); iter.hasNext();){
                            PDTBNodeImpl n = (PDTBNodeImpl)(iter.next());
                            n.save(fw);
                        }
                    }
                    
                    fw.close();
                    relSet.clear();
                }
                filesSeen = true;
            }
            
            if(produceCount){
                System.err.println("Total number of objects selected = " + count);
            }
            
            if(browser && count > 0){
                String[] browserArgs = {rawRoot, ptbRoot, outputRoot};
                PDTBBrowser.main(browserArgs);
            }
            else if(!filesSeen && !shutUp){
                System.err.println(NoFilesMessage);
                System.err.println("The directories given were as follows:\n");
                System.err.println("RawRoot       " + rawRoot);
                System.err.println("PtbRoot       " + ptbRoot);
                System.err.println("PdtbRoot      " + pdtbRoot);
                System.err.println("\n\nGoodbye.");
                System.err.println("\n-------------------------------------------------------------\n");
            }
            else if(count == 0 && !shutUp){
                System.err.println("\n-------------------------------------------------------------\n");
                System.err.println("Nothing was selected. The parameters were as follows:\n");
                System.err.println("RawRoot       " + rawRoot);
                System.err.println("PtbRoot       " + ptbRoot);
                System.err.println("PdtbRoot      " + pdtbRoot);
                System.err.println("OutputRoot    " + outputRoot );
                System.err.println("\n########## Query ##############\n");
                System.err.println(xpathStr);
                System.err.println("\n###############################");
                System.err.println("\n\nGoodbye.");
                System.err.println("\n-------------------------------------------------------------\n");
            }
        }
        catch(Exception e){
            System.err.println(Usage);
            System.err.println("Perhaps one of the directories supplied is invalid.");
            if(dumpExceptions){
                e.printStackTrace();
            }
            else{
                System.err.println("Running with option -e will dump the exception, which");
                System.err.println("may help diagnose the problem.");
            }
            System.exit(0);
        }
    }
    
}
