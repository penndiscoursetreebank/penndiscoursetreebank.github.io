/*
 * IsSupFunction.java
 *
 * Created on March 18, 2007, 10:25 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import edu.upenn.cis.pdtb.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;


/**
 * Checks if the context node is supplementary information. This function has the
 * signature:
 *
 * <pre>
 *  boolean is-sup()
 *  </pre>
 *
 * @since 0.2.5
 * @author nikhild
 */
public class IsSupFunction implements Function {
    
    public IsSupFunction() {
    }
    
    public Object call(Context context, List args) throws FunctionCallException {
        Object contextNode = context.getNodeSet().get(0);
        
        try{
            PDTBNode n = (PDTBNode) contextNode;
            String qName = n.pdtbGetQName();
            if(qName.charAt(0) == 'S'){
                return Boolean.TRUE;
            }
        }catch(Exception e){
            return Boolean.FALSE;
        }
        
        
        return Boolean.FALSE;
    }
}
