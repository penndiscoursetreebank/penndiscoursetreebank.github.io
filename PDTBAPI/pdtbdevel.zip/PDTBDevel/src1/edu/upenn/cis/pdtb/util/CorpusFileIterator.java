/*
 * CorpusFileIterator.java
 *
 * Created on December 10, 2004, 11:03 AM
 */

package edu.upenn.cis.pdtb.util;

import java.io.*;

/**
 * Utility class for iterating over files in the corpus. For example:
 *
 *  <pre>
 *   ....
 *   RelationLoader loader = new RelationLoaderImpl();
 *   for(CorpusFileIterator cfi = new CorpusFileIterator(textRoot, ptbRoot, pdtbRoot);
 *       cfi.hasMoreFiles();
 *       ){
 *      cfi.nextFile();
 *      String textFile = cfi.currentTextFile();
 *      String ptbFile = cfi.currentPtbFile();
 *      String pdtbFile = cfi.currentPdtbFile();
 *      loader.load(textFile, ptbFile, pdtbFile);
 *      ....
 *  }
 *  </pre>
 *
 * @author  nikhild
 * @see edu.upenn.cis.pdtb.RelationLoader
 */
public class CorpusFileIterator implements FilenameFilter{
    
    private File pdtbRoot;
    
    private File ptbRoot;
    
    private File textRoot;
    
    private int secNo = 0;
   
    private int nextSecNo = 0;
    
    private int maxSec = 25;
    
    private int minSec = 0;
    
    private int fileNo = -1;
    
    private int nextFileNo = 0;
    
    private int maxFile = 100;
    
    private int minFile = 0;
    
    private String currentPdtbFile = null;
    
    private String nextPdtbFile = null;
    
    private String currentTextFile = null;
    
    private String nextTextFile = null;
    
    private String currentPtbFile = null;
    
    private String nextPtbFile = null;

    private int[][] fileDatabase = null;
    
    
    /** Creates a new instance of CorpusFileIterator */
    public CorpusFileIterator(String textRoot, String ptbRoot, String pdtbRoot) {
        this.pdtbRoot = new File(pdtbRoot);
        if(!(this.pdtbRoot.isDirectory())){
            throw(new IllegalArgumentException(pdtbRoot + " is not a directory"));
        }
        
        this.ptbRoot = new File(ptbRoot);
        if(!(this.ptbRoot.isDirectory())){
            throw(new IllegalArgumentException(ptbRoot + " is not a directory"));
        }
        
        this.textRoot = new File(textRoot);
        if(!(this.textRoot.isDirectory())){
            throw(new IllegalArgumentException(textRoot + " is not a directory"));
        }

	initDatabase();        
        setNext();
    }
    
    public CorpusFileIterator(String textRoot, String ptbRoot, String pdtbRoot, int minSec, int maxSec, int minFile, int maxFile) {
        this.pdtbRoot = new File(pdtbRoot);
        if(!(this.pdtbRoot.isDirectory())){
            throw(new IllegalArgumentException(pdtbRoot + " is not a directory"));
        }
        
        this.ptbRoot = new File(ptbRoot);
        if(!(this.ptbRoot.isDirectory())){
            throw(new IllegalArgumentException(ptbRoot + " is not a directory"));
        }
        
        this.textRoot = new File(textRoot);
        if(!(this.textRoot.isDirectory())){
            throw(new IllegalArgumentException(textRoot + " is not a directory"));
        }
        
        this.minSec = minSec;
        this.nextSecNo = minSec;
        this.maxSec = maxSec;
        this.minFile = minFile;
        this.nextFileNo = minFile - 1;
        this.maxFile = maxFile;

	initDatabase();
        setNext();
    }

    private void initDatabase(){
	fileDatabase = new int[maxSec][maxFile];
	for(int i = 0; i < maxSec; i++){
	    File secFile = new File(ptbRoot, (i < 10)? "0" + i : "" + i);
	    secFile.list(this);
	    secFile = new File(pdtbRoot, (i < 10)? "0" + i : "" + i);
            secFile.list(this);
	    secFile = new File(textRoot, (i < 10)? "0" + i : "" + i);
            secFile.list(this);
	}

    }

    public boolean accept(File dir, String name){
	try{
	    char i1 = name.charAt(4);
	    char i2 = name.charAt(5);
	    char i3 = name.charAt(6);
	    char i4 = name.charAt(7);
	    int sn = Character.digit(i1,10) * 10 + Character.digit(i2,10);
	    int fn = Character.digit(i3,10) * 10 + Character.digit(i4,10);
	    fileDatabase[sn][fn] += 1;
	}
	catch(Exception e){
	}
	return false;
    }
    
    
    
    public boolean hasMoreFiles(){
        return nextPdtbFile != null;
    }
    
    public void nextFile(){
        currentPdtbFile = nextPdtbFile;
        currentPtbFile = nextPtbFile;
        currentTextFile = nextTextFile;
        secNo = nextSecNo;
        fileNo = nextFileNo;
        
        setNext();
        
    }
    
    public String currentPdtbFile(){
        return currentPdtbFile;
    }
    
    public String currentPtbFile(){
        return currentPtbFile;
    }
    
    public String currentTextFile(){
        return currentTextFile;
    }
    
    
    public String getSecNoStr(){
        return (secNo < 10)? "0" + secNo : "" + secNo;
    }
    
    public int getSecNo(){
        return secNo;
    }
    
    public String getFileNoStr(){
        return (fileNo < 10)? "0" + fileNo : "" + fileNo;
    }
    
    public int getFileNo(){
        return fileNo;
    }
    
    private void setNext(){
        nextFileNo++;
        
        if(nextFileNo == maxFile){
            nextFileNo = minFile;
            nextSecNo++;
        }
        
        while(nextSecNo < maxSec){
            String sec = (nextSecNo < 10)? "0" + nextSecNo : "" + nextSecNo;
            while(nextFileNo < maxFile){
		if(fileDatabase[nextSecNo][nextFileNo] == 3){
		    String file = (nextFileNo < 10)? "0" + nextFileNo : "" + nextFileNo;
                
		    nextPdtbFile = pdtbRoot.getAbsolutePath() +  File.separatorChar +
                        sec + File.separatorChar +
			"wsj_" + sec + file + ".pdtb";
                
                    nextPtbFile = ptbRoot.getAbsolutePath() + File.separatorChar +
                        sec + File.separatorChar +
                        "wsj_" + sec + file + ".mrg";

		    nextTextFile = textRoot.getAbsolutePath() + File.separatorChar +
                        sec + File.separatorChar +
                        "wsj_" + sec + file;
		    return;
                }
                
                nextFileNo++;
            }
            
            nextSecNo++;
            nextFileNo = 0;
        }
        
        
        
        
        nextPdtbFile = null;
        nextPtbFile = null;
	nextTextFile = null;
    }
    
}
