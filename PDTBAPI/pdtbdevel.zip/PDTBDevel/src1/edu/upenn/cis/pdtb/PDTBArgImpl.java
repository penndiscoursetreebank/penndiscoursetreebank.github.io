/*
 * PDTBArgImpl.java
 *
 * Created on November 27, 2005, 1:57 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;
import edu.upenn.cis.pdtb.util.ArraySet;

/**
 * Implementation of the PDTBArg interface
 * @author nikhild
 */
public class PDTBArgImpl extends PDTBSupImpl implements PDTBArg{
    
    
    
    private PDTBFeatures fFeats = null;
    
    /** Creates a new instance of PDTBArgImpl */
    public PDTBArgImpl(PDTBSelection sel, PDTBFeatures feats) {
        super(sel);
        feats.setPDTBNode(this);
        fFeats = feats;
    }
    
    protected void initAttributes(){
        fAttributes = new ArraySet(fAttributesComparator,4);
        fFeats.updateAttributesOnNode();
        fSel.updateAttributesOnNode();
    }
    
    
    public PDTBFeatures getFeatures() {
        return fFeats;
    }
    
    public void setFeatures(PDTBFeatures feats) {
        if(fFeats != null){
            fFeats.setPDTBNode(null);
        }
        
        feats.setPDTBNode(this);
        
        fFeats = feats;
        fFeats.updateAttributesOnNode();
    }
    
    public void save(Writer writer) throws IOException{
        super.save(writer);
        
        writer.write("#### Features ####\n");
        ((PDTBFeaturesImpl)fFeats).save(writer);
        
        writer.write("##################\n");
    }
    
}
