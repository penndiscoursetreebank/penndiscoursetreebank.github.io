/*
 * PDTBSup.java
 *
 * Created on November 27, 2005, 12:43 PM
 */

package edu.upenn.cis.pdtb;

import javax.swing.tree.*;

/**
 * Corresponds to supplementary information.
 * @author nikhild
 */
public interface PDTBSup extends PDTBNode {
    
    /**
     * Get the selection.
     */    
    public PDTBSelection getSelection();
    
    /**
     * Set the selection.
     */    
    public void setSelection(PDTBSelection sel);
    
    /**
     * Get the relation to which this belongs.
     */    
    public PDTBRelation getRelation();
    
    /**
     * Set the relation to which this belongs.
     */    
    public void setRelation(PDTBRelation rel);
    
}
