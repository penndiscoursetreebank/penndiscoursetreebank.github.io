/*
 * PDTBNoRelationImpl.java
 *
 * Created on February 13, 2006, 5:04 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

/**
 *
 * @author  nikhild
 */
public class PDTBNoRelationImpl extends PDTBEntityRelationImpl implements PDTBNoRelation {
    
    /** Creates a new instance of PDTBNoRelationImpl */
    public PDTBNoRelationImpl(PDTBInferenceSite infSite, PDTBSup arg1, PDTBSup arg2) {
        super(infSite, arg1, arg2);
        
        pdtbSetName("", NoRelationQName, NoRelationQName);
    }
    
    public void save(Writer writer) throws IOException {
        writer.write("________________________________________________________\n");
        writer.write("____NoRel____\n");
        
        ((PDTBInferenceSiteImpl)getInferenceSite()).save(writer);
        
        writer.write("____Arg1____\n");
        ((PDTBSupImpl)getArg1()).save(writer);
        
        writer.write("____Arg2____\n");
        ((PDTBSupImpl)getArg2()).save(writer);
        
        
        writer.write("________________________________________________________\n");
    }
}
