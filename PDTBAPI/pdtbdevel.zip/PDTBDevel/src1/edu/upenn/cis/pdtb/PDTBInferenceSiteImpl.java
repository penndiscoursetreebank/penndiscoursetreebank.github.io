/*
 * PDTBInferenceSiteImpl.java
 *
 * Created on January 22, 2006, 7:52 PM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.ptb.PTBTreeNode;
import java.io.Writer;
import java.io.IOException;

/**
 * Implementation of the PDTBInferenceSite interface.
 * @author nikhild
 */
public class PDTBInferenceSiteImpl implements PDTBInferenceSite{
    
    private int fStringPosition;
    
    private int fSentenceNo;
    
    private PTBTreeNode fSentence;
    
    private PDTBNode fNode;
    
    
    /** Creates a new instance of PDTBInferenceSiteImpl */
    public PDTBInferenceSiteImpl(int stringPosition, int sentenceNo, PTBTreeNode sentence) {
        fStringPosition = stringPosition;
        fSentenceNo = sentenceNo;
        fSentence = sentence;
    }
    
    public PDTBNode getPDTBNode() {
        return fNode;
    }
    
    public int getStringPosition() {
        return fStringPosition;
    }
    
    public PTBTreeNode getSentence() {
        return fSentence;
    }
    
    public int getSentenceNo() {
        return fSentenceNo;
    }
    
    public void setPDTBNode(PDTBNode node) {
        fNode = node;
    }
    
    public void updateAttributesOnNode() {
    }
    
    public void save(Writer writer) throws IOException{
        writer.write("" + fStringPosition); writer.write('\n');
        writer.write("" + fSentenceNo); writer.write('\n');
    }
}
