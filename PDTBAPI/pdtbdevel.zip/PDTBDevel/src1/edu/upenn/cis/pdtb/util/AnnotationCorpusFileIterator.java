/*
 * CorpusFileIterator.java
 *
 * Created on December 10, 2004, 11:03 AM
 */

package edu.upenn.cis.pdtb.util;

import java.io.File;

/**
 * For internal use.
 *
 * @author  nikhild
 */
public class AnnotationCorpusFileIterator {
    
    private File pdtbRoot;
    
    private File ptbRoot;
    
    private File textRoot;
    
    private int setNo = 1;
    
    private int nextSetNo = 1;
    
    private int minSet = 1;
    
    private int maxSet = 12;
    
    private int secNo = 0;
   
    private int nextSecNo = 0;
    
    private int minSec = 0;
    
    private int maxSec = 25;
    
    private int fileNo = -1;
    
    private int nextFileNo = 0;
    
    private int minFile = 0;
    
    private int maxFile = 100;
    
    private File currentPdtbFile = null;
    
    private File nextPdtbFile = null;
    
    private File currentPtbFile = null;
    
    private File nextPtbFile = null;
    
    private File currentTextFile = null;
    
    private File nextTextFile = null;
    
    
    
    /** Creates a new instance of CorpusFileIterator */
    public AnnotationCorpusFileIterator(String textRoot, String ptbRoot, String pdtbRoot) {
        this.pdtbRoot = new File(pdtbRoot);
        if(!(this.pdtbRoot.isDirectory())){
            throw(new IllegalArgumentException(pdtbRoot + " is not a directory"));
        }
        
        this.ptbRoot = new File(ptbRoot);
        if(!(this.ptbRoot.isDirectory())){
            throw(new IllegalArgumentException(ptbRoot + " is not a directory"));
        }
        
        this.textRoot = new File(textRoot);
        if(!(this.textRoot.isDirectory())){
            throw(new IllegalArgumentException(textRoot + " is not a directory"));
        }
        
        setNext();
    }
    
    public AnnotationCorpusFileIterator(String textRoot, String ptbRoot, String pdtbRoot,  int minSet, int maxSet, int minSec, int maxSec, int minFile, int maxFile){
        this.minSet = minSet;
        this.nextSetNo = minSet;
        this.maxSet = maxSet;
        
        this.minSec = minSec;
        this.nextSecNo = minSec;
        this.maxSec = maxSec;
        
        this.minFile = minFile;
        this.nextFileNo = minFile - 1;
        this.maxFile = maxFile;
        
        this.pdtbRoot = new File(pdtbRoot);
        if(!(this.pdtbRoot.isDirectory())){
            throw(new IllegalArgumentException(pdtbRoot + " is not a directory"));
        }
        
        this.ptbRoot = new File(ptbRoot);
        if(!(this.ptbRoot.isDirectory())){
            throw(new IllegalArgumentException(ptbRoot + " is not a directory"));
        }
        
        this.textRoot = new File(textRoot);
        if(!(this.textRoot.isDirectory())){
            throw(new IllegalArgumentException(textRoot + " is not a directory"));
        }
        
        setNext();
        
    }
    
    
    public boolean hasMoreFiles(){
        return nextPdtbFile != null;
    }
    
    public void nextFile(){
        currentPdtbFile = nextPdtbFile;
        currentPtbFile = nextPtbFile;
        currentTextFile = nextTextFile;
        
        setNo = nextSetNo;
        secNo = nextSecNo;
        fileNo = nextFileNo;
        
        setNext();
        
    }
    
    public String currentPdtbFile(){
        return currentPdtbFile.getAbsolutePath();
    }
    
    public String currentPtbFile(){
        return currentPtbFile.getAbsolutePath();
    }
    
    public String currentTextFile(){
        return currentTextFile.getAbsolutePath();
    }
    
    public String getSetNoStr(){
        return "Set" + setNo;
    }
    
    public int getSetNo(){
        return setNo;
    }
    
    public String getSecNoStr(){
        return (secNo < 10)? "0" + secNo : "" + secNo;
    }
    
    public int getSecNo(){
        return secNo;
    }
    
    public String getFileNoStr(){
        return (fileNo < 10)? "0" + fileNo : "" + fileNo;
    }
    
    public int getFileNo(){
        return fileNo;
    }
    
    private void setNext(){
        nextFileNo++;
        
        if(nextFileNo == maxFile){
            nextFileNo = minFile;
            nextSecNo++;
            if(nextSecNo == maxSec){
                nextSecNo = minSec;
                nextSetNo++;
            }
        }
        
        while(nextSetNo < maxSet){
            String set = "Set" + nextSetNo;
            while(nextSecNo < maxSec){
                String sec = (nextSecNo < 10)? "0" + nextSecNo : "" + nextSecNo;
                while(nextFileNo < maxFile){
                    String file = (nextFileNo < 10)? "0" + nextFileNo : "" + nextFileNo;
                    
                    
                    nextPdtbFile = new File(pdtbRoot,  set +
                    File.separatorChar + sec + File.separatorChar +
                    "wsj_" + sec + file + ".pdtb");
                    
                    
                    if(nextPdtbFile.exists()){
                        
                        nextPtbFile = new File(ptbRoot,  sec +
                        File.separatorChar + "wsj_" + sec + file + ".mrg");
                        
                        
                        nextTextFile = new File(textRoot, sec +
                        File.separatorChar + "wsj_" + sec + file);
                        
                        
                        if(nextPtbFile.exists() && nextTextFile.exists()){
                            return;
                        }
                        
                        
                    }
                    
                    nextFileNo++;
                }
                
                nextSecNo++;
                nextFileNo = 0;
            }
            
            nextSetNo++;
            nextSecNo = 0;
            nextFileNo = 0;
        }
        
        nextPdtbFile = null;
        nextPtbFile = null;
    }
    
}
