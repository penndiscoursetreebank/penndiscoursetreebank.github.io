/*
 * PDTBExplicitRelationFeaturesImpl.java
 *
 * Created on November 30, 2005, 7:30 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

/**
 * Implementation of the PDTBExplicitRelationFeatures interface.
 * @author nikhild
 */
public class PDTBExplicitRelationFeaturesImpl extends PDTBFeaturesImpl implements PDTBExplicitRelationFeatures {
    
    private String fHead;
    
    //private String fSense;
    
    /** Creates a new instance of PDTBExplicitRelationFeaturesImpl */
    public PDTBExplicitRelationFeaturesImpl(String source, String factuality, 
               String polarity, String connHead) {
                   super(source, factuality, polarity);
                   //fSense = sense;
                   fHead = connHead;
                   
    }
    
    //public String getSense() {
      //  return "null";
    //}
    
    /**
     * Sets the connHead attribute on the ownerNode.
     */    
    public void updateAttributesOnNode(){
        getPDTBNode().pdtbSetAttribute("", ConnHeadAttributeQName, ConnHeadAttributeQName, "", fHead);
        //getPDTBNode().pdtbSetAttribute("", SenseAttributeQName, SenseAttributeQName, "", fSense);
        super.updateAttributesOnNode();
    }
    
    public String getConnHead() {
        return fHead;
    }
    
    public void save(Writer writer) throws IOException{
        super.save(writer);
        writer.write(fHead);
        writer.write('\n');
    }
    
}
