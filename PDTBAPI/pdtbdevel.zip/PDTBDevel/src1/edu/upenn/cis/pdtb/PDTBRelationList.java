/*
 * PDTBRelationList.java
 *
 * Created on November 27, 2005, 8:19 PM
 */

package edu.upenn.cis.pdtb;

import javax.swing.tree.*;
import edu.upenn.cis.ptb.*;

/**
 * Container for a list of relations. Typically represents an annotation
 * file in its entirety.
 * @author nikhild
 */
public interface PDTBRelationList extends PDTBNode{
    
    /**
     * Get the section number is one is associated.
     */    
    public String getSecNo();
    
    /**
     * Get the file number, if associated.
     */    
    public String getFileNo();
    
    /**
     * Get the raw text associated with this relation list
     * (the entire discourse).
     */    
    public String getRawText();
    
    /**
     * The children of this root node correspond to parse trees for each sentence.
     */    
    public PTBTreeNode getPTBRoot();
    
}
