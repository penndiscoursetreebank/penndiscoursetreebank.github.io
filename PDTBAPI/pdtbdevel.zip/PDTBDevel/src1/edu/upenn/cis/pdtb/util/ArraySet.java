/*
 * BaseArraySet.java
 *
 * Created on March 15, 2007, 5:00 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package edu.upenn.cis.pdtb.util;

import java.util.ArrayList;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.SortedSet;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.List;

/**
 *
 * @author nikhild
 */
public class ArraySet extends AbstractSet implements SortedSet{
    
    protected List fStore = null;
    
    protected Comparator fComparator = null;
    
    protected boolean fCheckLowerBound = false;
    
    protected Object fLowerBound = null;
    
    protected boolean fCheckUpperBound = false;
    
    protected Object fUpperBound = null;
   
    /** Creates a new instance of BaseArraySet */
    public ArraySet(Comparator comparator, int initialCapacity) {
        fComparator = comparator;
        fStore = new ArrayList(initialCapacity);
    }
    
    public ArraySet(Comparator comparator){
        this(comparator,1);
    }
    
    protected ArraySet(Comparator comparator, List store, 
            boolean checkLowerBound, Object lowerBound, 
            boolean checkUpperBound, Object upperBound){
        fComparator = comparator;
        fStore = store;
        fCheckLowerBound = checkLowerBound;
        fLowerBound = lowerBound;
        fCheckUpperBound = checkUpperBound;
        fUpperBound = upperBound;
        
    }
    
    public boolean add(Object o){
        if(fCheckLowerBound && fComparator.compare(fLowerBound, o) < 0){
            throw(new IllegalArgumentException("Cannot add an element less than the lower bound to the view"));
        }
        
        if(fCheckUpperBound && fComparator.compare(fUpperBound, o) >= 0){
            throw(new IllegalArgumentException("Cannot add an element >= the lower bound to the view"));
        }
        
        int size = fStore.size();
        if(size == 0 || fComparator.compare(fStore.get(size - 1),o) < 0){
            fStore.add(o);
            return true;
        }
        else{
            return search(o, true, fComparator) != -1;
            
        }
    }
    
    protected int search(Object o, boolean addIfNotFound, Comparator c){
        int size = fStore.size();
            
        int startIndex = 0;
        int endIndex = size;
        int comparison = 0;
        int mid = 0;
            
        while(startIndex <= endIndex -1){
            mid = (startIndex + endIndex)/2;
        
            Object inSet = fStore.get(mid);
            comparison = c.compare(inSet, o);
            
            if(comparison == 0){
                return mid;
            }
            else if(comparison > 0){
                endIndex = mid;
            }
            else{
                startIndex = mid + 1;
            }    
        }
        
        mid = (startIndex + endIndex)/2;
        
        if(addIfNotFound){
            if(mid == size){
                fStore.add(o);
            } else{
                fStore.add(mid, o);
            }
        }
        
        
        return -1;
    }
    
    protected int findLeastUpperBound(Object o, Comparator c){
        int startIndex = 0;
        int endIndex = fStore.size();
        int comparison = 0;
        int mid = 0;
         
        while(startIndex <= endIndex -1){
            mid = (startIndex + endIndex)/2;
        
            Object inSet = fStore.get(mid);
            comparison = c.compare(inSet, o);
            
            if(comparison == 0){
                return mid;
            }
            else if(comparison > 0){
                endIndex = mid;
            }
            else{
                startIndex = mid + 1;
            }    
        }
        mid = (startIndex + endIndex)/2;
        
        return mid;
        
    }
    
    
    public boolean contains(Object o){
        return (search(o, false, fComparator) != -1);
    }
    
    public Object get(int index){
        return fStore.get(index);
    }
    
    public Iterator iterator(){
        return fStore.iterator();
    }
    
    public boolean remove(Object o){
        int index = search(o, false, fComparator);
        if(index != -1){
            fStore.remove(index);
            return true;
        }
        
        return false;
    }
    
    public int size(){
        return fStore.size();
    }
    
    public Comparator comparator(){
        return fComparator;
    }
    
    public Object first(){
        return fStore.get(0);
    }
    
    public SortedSet headSet(Object toElement){
        if(fCheckLowerBound || fCheckUpperBound){
            throw(new IllegalArgumentException("Cannot create a subview of a view"));
        }
        
        int index = findLeastUpperBound(toElement, fComparator);
        
        return new ArraySet(fComparator, fStore.subList(0, index), false, null, true, toElement);
    }
    
    public Object last(){
        return fStore.get(fStore.size() - 1);
    }
    
    public SortedSet subSet(Object fromElement, Object toElement){
        if(fCheckLowerBound || fCheckUpperBound){
            throw(new IllegalArgumentException("Cannot create a subview of a view"));
        }
        
        int startIndex = findLeastUpperBound(fromElement, fComparator) ;
        int endIndex = findLeastUpperBound(toElement, fComparator) ;
        
        
        return new ArraySet(fComparator, fStore.subList(startIndex, endIndex), true, fromElement, true, toElement);
    }
    
    
    public SortedSet tailSet(Object fromElement){
        if(fCheckLowerBound || fCheckUpperBound){
            throw(new IllegalArgumentException("Cannot create a subview of a view"));
        }
        
        int index = findLeastUpperBound(fromElement, fComparator);
        
        return new ArraySet(fComparator, fStore.subList(index, fStore.size()), true, fromElement, false, null);
    }
    
    public void clear(){
        fStore.clear();
    }

    
    public String toString(){
        return fStore.toString();
    }
    
    public static void main(String[] args){
        Comparator c = (new Comparator(){
            public int compare(Object o1, Object o2){
                Integer i1 = (Integer) o1;
                Integer i2 = (Integer) o2;
                
                return i1.intValue() - i2.intValue();
            }
            
            public boolean equals(Object o){
                return o == this;
            }
        });
        
        {
            ArraySet set = new ArraySet(c,10000);
            
            long startTime = System.currentTimeMillis();
            for(int i = 0; i < 10000; i++){
                //Integer elem = new Integer((int) (Math.random() * 10000));
                Integer elem = new Integer(i);
                double d = Math.random();
                if(d >= 0.8){
                    elem = new Integer((int)(d * 10000));
                }
                set.add(elem);
            }
            long endTime = System.currentTimeMillis();
            System.err.println("Base Set timing = " + (endTime - startTime));
        }
        
        {
            TreeSet set = new TreeSet(c);
            
            long startTime = System.currentTimeMillis();
            for(int i = 0; i < 100000; i++){
                //Integer elem = new Integer((int) (Math.random() * 10000));
                Integer elem = new Integer(i);
                
                double d = Math.random();
                if(d >= 0.8){
                    elem = new Integer((int)(d * 10000));
                }
                 
                set.add(elem);
            }
            long endTime = System.currentTimeMillis();
            System.err.println("TreeSet timing = " + (endTime - startTime));
        }
        
        {
            ArraySet set = new ArraySet(c,10000);
            TreeSet set2 = new TreeSet(c);
            
            for(int i = 0; i < 100000; i++){
                //Integer elem = new Integer((int) (Math.random() * 10000));
                Integer elem = new Integer(100000-i);
                
                double d = Math.random();
                if(d >= 0.8){
                    elem = new Integer((int)(d * 10000));
                }
                 
                set.add(elem);
                set2.add(elem);
            }
            
            {
                SortedSet ss = set.headSet(new Integer(100));
                SortedSet ss2 = set2.headSet(new Integer(100));
                
                System.err.println(ss.toString());
                System.err.println(ss2.toString());
                
                
            }
            
            {
                SortedSet ss = set.tailSet(new Integer(100));
                SortedSet ss2 = set2.tailSet(new Integer(100));
                
                System.err.println(ss.toString());
                System.err.println(ss2.toString());
                
                
            }
            
            {
                SortedSet ss = set.subSet(new Integer(100), new Integer(200));
                SortedSet ss2 = set2.subSet(new Integer(100), new Integer(200));
                
                
                System.err.println(ss.toString());
                System.err.println(ss2.toString());
                
            }
            
        }
    }
}
