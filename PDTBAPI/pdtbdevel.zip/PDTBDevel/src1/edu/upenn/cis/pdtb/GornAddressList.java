/*
 * GornAddressList.java
 *
 * Created on December 3, 2004, 5:21 PM
 */

package edu.upenn.cis.pdtb;

import java.util.Iterator;
import java.util.TreeSet;
import java.util.Comparator;
import java.util.regex.*;
import edu.upenn.cis.pdtb.util.ArraySet;

/**
 * <p>
 * A list of Gorn addresses.
 * A Gorn address a<SUB>1</SUB>, a<SUB>2</SUB>,...a<SUB>n-1</SUB>, a<SUB>n</SUB> denotes the
 * a_nth child of the a<SUB>n-1</SUB>th child of .... the a<SUB>2</SUB>th child of the
 * sentence number a<SUB>1</SUB> in the associated PTB file. Given a PTB file with
 * two sentences:
 * </p>
 *
 * <pre>
 * ((S1 (A a) (B b)))
 * ((S2 (C c) (D d)))
 * </pre>
 *
 * <p>
 * The Gorn address <EM>0,0</EM> refers to the node A. The Gorn address <EM>1,1,0</EM>
 * refers to the node <EM>d</EM>. Note that <EM>0</EM> refers to <EM>S1</EM>, and <EM>1</EM> refers to <EM>S2</EM>
 * and  not to the <EM>TOP</EM> node inserted by several APIs. Let G<SUB>1</SUB>,
 * G<SUB>2</SUB>...G<SUB>n</SUB> be Gorn addresses, then a <EM> Gorn address list</EM> is given
 * by G<SUB>1</SUB>; G<SUB>2</SUB>...;G<SUB>n</SUB>. A Gorn address list of length n denotes n
 * nodes. In most cases, G<SUB>i</SUB> is not a prefix (denoting an ancestor) of
 * G<SUB>j</SUB> for all 1 <= i,j <= n.
 *
 * </p>
 *
 * <p>
 * The implementation here sorts Gorn addresses according to an inorder
 * traversal of the tree.
 * </p>
 * @author nikhild
 */
public class GornAddressList extends ArraySet {
    
    private static final Pattern SemiColonPattern = Pattern.compile(";");
    
    private static final Pattern CommaPattern = Pattern.compile(",");


    /**
     * Instantiation from string representation.
     * @param gal A string representation of a GornAddressList
     */
    public GornAddressList(String gal) {
        super((new Comparator(){
            
            public int compare(Object o1, Object o2){
                int[] a1 = (int[])o1;
                int[] a2 = (int[])o2;
                
                int l1 = a1.length;
                int l2 = a2.length;
                
                int min = (l1 <= l2)? l1 : l2;
                for(int i = 0; i < min; i++){
                    if(a1[i] < a2[i]){
                        return -1;
                    }
                    
                    if(a1[i] > a2[i]){
                        return 1;
                    }
                }
                
                if(l1 < l2){
                    return -1;
                }
                else if(l1 > l2){
                    return 1;
                }
                
                return 0;
            }
            public boolean equals(Object o){
                return false;
            }
            
        }    ), 3);
        
        if(!(gal.equals(""))){
            String[] addresses = SemiColonPattern.split(gal);
            
            int len = addresses.length;
            for(int i = 0; i < len; i++){
                String[] comps = CommaPattern.split(addresses[i]);
                
                int numComps = comps.length;
                int[] add = new int[numComps];
                for(int j = 0; j < numComps; j++){
                    add[j] = (new Integer(comps[j])).intValue();
                }
                
                super.add(add);
            }
        }
    }
    
    /**
     * Creates an empty GornAddressList
     */    
    public GornAddressList(){
        super((new Comparator(){
            
            public int compare(Object o1, Object o2){
                int[] a1 = (int[])o1;
                int[] a2 = (int[])o2;
                
                int l1 = a1.length;
                int l2 = a2.length;
                
                int min = (l1 <= l2)? l1 : l2;
                for(int i = 0; i < min; i++){
                    if(a1[i] < a2[i]){
                        return -1;
                    }
                    
                    if(a1[i] > a2[i]){
                        return 1;
                    }
                }
                
                if(l1 < l2){
                    return -1;
                }
                else if(l1 > l2){
                    return 1;
                }
                
                return 0;
            }
            public boolean equals(Object o){
                return false;
            }
            
        }    ), 3);
    }
    
    /**
     * Converts back to string form for serialization
     */    
    public String toString(){
        String s = "";
        Iterator iter = iterator();
        int j = 0;
        while(iter.hasNext()){
            s = (j > 0)? s + ";" : s;
            int[] add = (int[])(iter.next());
            int len = add.length;
            for(int i = 0; i < len ; i++){
                s = (i > 0)? s + "," + add[i] : s + add[i];
            }
            
            j++;
        }
        
        return s;
    }
    
}
