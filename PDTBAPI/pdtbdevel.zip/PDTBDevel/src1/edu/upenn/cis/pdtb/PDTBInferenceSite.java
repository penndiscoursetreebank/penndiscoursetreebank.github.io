/*
 * PDTBInferenceSite.java
 *
 * Created on January 22, 2006, 7:48 PM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.ptb.PTBTreeNode;

/**
 * The site of inference of an implicit relation.
 * @author nikhild
 */
public interface PDTBInferenceSite {
    
    /**
     * The character offset where the relation was inferred. Usually points to
     * the first character of the sentence containing Arg2.
     */    
    public int getStringPosition();
    
    /**
     * Sentence, at the start of which, the implicit relation was inferred.
     * Usually the sentence containing Arg2.
     */    
    public int getSentenceNo();
    
    /**
     * The sentence corresponding to getSentenceNo().
     */    
    public PTBTreeNode getSentence();
    
    /**
     * Get the associated PDTBImplicitRelation.
     */    
    public PDTBNode getPDTBNode();
    
    /**
     * Set the associated implicit relation.
     */    
    public void setPDTBNode(PDTBNode node);
    
    public void updateAttributesOnNode();
}
