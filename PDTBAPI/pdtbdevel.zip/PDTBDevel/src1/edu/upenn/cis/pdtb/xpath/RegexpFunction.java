/*
 * RegexpFunction.java
 *
 * Created on February 11, 2006, 7:20 PM
 */

package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import org.jaxen.XPath;
import org.jaxen.function.StringFunction;
import java.util.List;
import java.util.WeakHashMap;
import java.util.Iterator;
import java.util.LinkedList;
import edu.upenn.cis.ptb.*;
import java.util.regex.*;

/**
 * Regular Expressions. This function has the signature:
 *
 * <pre>
 *  boolean regexp(string, string)
 * </pre>
 *
 * The first argument is a string and the second argument is a regular expression.
 * Returns true if the first argument matches the second. Used by PDTBXPath.
 * For example:
 *
 * <pre>
 *  //*[@connHead='if' and child::Arg2[regexp(@rawText,".*\\W*not\\W*.*")]]
 * </pre>
 *
 *
 * @author  nikhild
 * @see PDTBXPath
 *
 */
public class RegexpFunction implements Function {
    
    private WeakHashMap fExpressionMap = new WeakHashMap();

    private StringFunction sf = new StringFunction();
   
    
    public RegexpFunction() {
    }
    
    public Object call(Context context, List list) throws org.jaxen.FunctionCallException {
        if(list.size() != 2){
            throw(new FunctionCallException("Number of arguments expected is 2." + list.size() + "supplied"));
        }

	Object arg = list.get(0);
        if(!(arg instanceof String)){
	    if(arg instanceof List){
		arg = sf.call(context, (List) arg);
	    }
	    else{
		throw(new FunctionCallException("Argument at index 0 should be a string"));
	    }
        }

        String toBeMatched = (String) arg;
        
        arg = list.get(1);
        if(!(arg instanceof String)){
            throw(new FunctionCallException("Argument at index 1 should be a regular expression"));
        }
        String regexStr = (String) arg;

        Pattern pat = (Pattern) fExpressionMap.get(regexStr);
        if(pat == null){
	    pat = Pattern.compile(regexStr,Pattern.DOTALL);
            fExpressionMap.put(regexStr,pat);
        }

        if(pat.matcher(toBeMatched).matches()){
	    return Boolean.TRUE;
	}
        
        return Boolean.FALSE;
    }
    
}
