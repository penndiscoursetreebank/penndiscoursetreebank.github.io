package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import edu.upenn.cis.pdtb.*;
import java.util.regex.*;
import java.util.List;

/**
 * Filter for subordinating conjunctions. This function has the signature:
 *
 * <pre>
 *  boolean is-sc()
 *  </pre>
 *
 * Returns true iff the context node is an explicit relation and the connHead
 * attribute matches the regex:
 *
 * <pre>
 * .*(because|although|even though|when|so that|(^|\s)while|(^|\s)if|since|unless|after|until|
 * whereas|as$|as though|^till|once|for$|before|lest|except|else|now that).*
 * </pre>
 *
 * @since 0.2.8
 * @author nikhild
 */
public class IsSubConjFunction implements Function{
    
    public static final Pattern SubConjConnPattern = Pattern.compile(".*(because|although|even though|when|so that|(^|\\s)while|(^|\\s)if|since|unless|after|until|whereas|as$|as though|^till|once|for$|before|lest|except|else|now that).*");
    
    public IsSubConjFunction() {
    }
    
    public Object call(Context context, List args) throws FunctionCallException {
        
        Object contextNode = context.getNodeSet().get(0);
        
        if(contextNode instanceof PDTBExplicitRelation){
            String connHead = ((PDTBExplicitRelation) contextNode).getFeatures().getConnHead();
            if(SubConjConnPattern.matcher(connHead).matches()){
                return Boolean.TRUE;
            }
        }
        
        return Boolean.FALSE;
    }
    
}
