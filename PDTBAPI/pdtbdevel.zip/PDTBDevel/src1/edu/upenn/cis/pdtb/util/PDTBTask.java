/*
 * PDTBTask.java
 *
 * Created on March 4, 2007, 11:52 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package edu.upenn.cis.pdtb.util;

import edu.upenn.cis.pdtb.*;
import java.io.IOException;


/**
 * Utility class for iterating over the corpus. Note that this will load
 * the syntax, so it's not the most efficient if you only care about the
 * PDTB. Use the RelationLoader directly to load just the PDTB and
 * raw text.
 *
 *  <pre>
 *   ....
 *   for(PDTBTask task = new PDTBTask(textRoot, ptbRoot, pdtbRoot);
 *       task.hasNext(); ){
 *      PDTBRelationList rlist = task.next();
 *      ....
 *  }
 *  </pre>
 *
 * @author nikhild
 */
public class PDTBTask {
    
    private CorpusFileIterator fCfi;
    
    private RelationLoader fLoader = new RelationLoaderImpl();
    
    
    /** Creates a new instance of PDTBTask */
    public PDTBTask(String textRoot, String ptbRoot, String pdtbRoot) {
        this(textRoot,ptbRoot, pdtbRoot, false);
    }

    public PDTBTask(String textRoot, String ptbRoot, String pdtbRoot, boolean useStandoffPTB){
	fCfi = new CorpusFileIterator(textRoot,ptbRoot, pdtbRoot);
	    fLoader = new RelationLoaderImpl(useStandoffPTB);
    }
    
    public boolean hasNext(){
        return fCfi.hasMoreFiles();
    }
    
    public PDTBRelationList next() throws IOException{
        if(fCfi.hasMoreFiles()){
            fCfi.nextFile();
            return fLoader.loadRelations(fCfi.currentTextFile(), fCfi.currentPtbFile(), fCfi.currentPdtbFile());
        }
        return null;
    }
    
    public int getSecNo(){
        return fCfi.getSecNo();
    }
    
    public String getSecNoStr(){
        return fCfi.getSecNoStr();
    }
    
    public int getFileNo(){
        return fCfi.getFileNo();
    }
    
    public String getFileNoStr(){
        return fCfi.getFileNoStr();
    }


}
