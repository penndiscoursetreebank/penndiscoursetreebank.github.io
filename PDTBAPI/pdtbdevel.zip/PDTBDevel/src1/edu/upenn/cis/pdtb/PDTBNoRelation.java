/*
 * PDTBNoRelation.java
 *
 * Created on February 13, 2006, 5:03 PM
 */

package edu.upenn.cis.pdtb;

/**
 *
 * @author  nikhild
 */
public interface PDTBNoRelation extends PDTBEntityRelation{
    
}
