/*
 * PDTBSupImpl.java
 *
 * Created on November 27, 2005, 12:51 PM
 */

package edu.upenn.cis.pdtb;

import java.util.Enumeration;
import java.util.Iterator;
import java.io.Writer;
import java.io.IOException;
import edu.upenn.cis.pdtb.util.ArraySet;

/**
 *
 * @author  nikhild
 */
public class PDTBSupImpl extends PDTBNodeImpl implements PDTBSup{
    
    
    protected PDTBSelection fSel = null;
    
    /** Creates a new instance of PDTBSupImpl */
    public PDTBSupImpl(PDTBSelection sel) {
        sel.setPDTBNode(this);
        fSel = sel;
    }
    
    protected void initAttributes(){
        fAttributes = new ArraySet(fAttributesComparator);
        fSel.updateAttributesOnNode();
    }
    
    
    public boolean getAllowsChildren() {
        return false;
    }
    
    
    public PDTBSelection getSelection() {
        return fSel;
    }
    
    
    public void setSelection(PDTBSelection sel) {
        if(fSel != null){
            fSel.setPDTBNode(null);
        }
        
        fSel = sel;
        fSel.setPDTBNode(this);
        fSel.updateAttributesOnNode();
    }
    
    
    public PDTBRelation getRelation() {
        return (PDTBRelation)(getParent());
    }
    
    public void setRelation(PDTBRelation rel) {
        setParent(rel);        
    }
    
    public void save(Writer writer) throws IOException{
        ((PDTBSelectionImpl)fSel).save(writer);
    }
    
}
