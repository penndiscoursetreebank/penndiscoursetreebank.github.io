/*
 * PDTBExplicitRelationFeatures.java
 *
 * Created on November 30, 2005, 7:29 PM
 */

package edu.upenn.cis.pdtb;

/**
 * Features of an AltLexRelation
 * @author nikhild
 * @see edu.upenn.cis.pdtb.PDTBAltLexRelation
 */
public interface PDTBAltLexRelationFeatures extends PDTBFeatures {
    
    //public static final String SenseAttributeQName = "sense";
    
    /**
     * QName of the feature corresponding to the semantic class.
     */    
    public static final String SemanticClassAttributeQName = "semanticClass";
    
    //public String getSense();
    
    /**
     * Returns the value of the semantic class
     */    
    public String getSemanticClass();
    
}
