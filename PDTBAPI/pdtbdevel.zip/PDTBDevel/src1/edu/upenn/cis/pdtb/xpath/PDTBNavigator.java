/*
 * PTBMRGNavigator.java
 *
 * Created on June 4, 2005, 12:17 PM
 */

package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Navigator;
import org.jaxen.XPath;
import org.jaxen.UnsupportedAxisException;
import org.jaxen.FunctionCallException;
import org.jaxen.BaseXPath;
import org.jaxen.SimpleFunctionContext;
import org.jaxen.XPathFunctionContext;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Enumeration;
import java.util.Stack;
import java.util.List;

import org.w3c.dom.Node;

import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.pdtb.util.*;

/**
 * This interfaces with the <a href="http://jaxen.sourceforge.net">Jaxen</a> XPath API.
 * For example the following selects all the explicit relations with connective instead:
 * 
 * <pre>
 *   ...           
 *   CorpusFileIterator cfi = new CorpusFileIterator(textRoot, ptbRoot, pdtbRoot);
 *   RelationLoader loader = new RelationLoaderImpl();
 *   PDTBNavigator nav = new PDTBNavigator(null);
 *   XPath xp = nav.parseXPath("//ExplicitRelation[@connHead='instead']");
 *   int totalCount = 0;
 *   while(cfi.hasMoreFiles()){
 *       cfi.nextFile();                
 *       String secNo = cfi.getSecNoStr();
 *       String fileNo = cfi.getFileNoStr(); 
 *       PDTBRelationList rlist = loader.loadRelations(textRoot, ptbRoot, pdtbRoot, secNo, fileNo);
 *       nav.setRoot(rlist);                
 *               
 *       List selectedNodes = xp.selectNodes(nav.getDocument());
 *               
 *       for(Iterator iter = selectedNodes.iterator(); iter.hasNext(); iter.next()){
 *           totalCount++;
 *       }
 *   }            
 *   System.err.println(totalCount);            
 *           
 *   ...
 * </pre>
 * <p>
 * The PDTBTask class can be used to simplify the code above.
 * The following is the list of Elements, their children, and attributes (the suffix * 
 * indicates optionality):
 *
 * <TABLE border="1">
 * <COLGROUP>
 *    <COL width="1*" />
 *    <COL width="2*" />
 *    <COL width="2*" />
 * </COLGROUP>
 *  <TR>
 * <TD>Element QName</TD><TD>Children QNames</TD><TD> Attribute QNames</TD>
 *  </TR>
 *
 * <TR>
 * <TD>RelationList</TD>
 * <TD>ExplicitRelation*, ImplicitRelation*, AltLexRelation*, EntityRelation*, NoRelation*</TD>
 * <TD></TD>
 * </TR>
 *  
 * <TR>
 * <TD>ExplicitRelation</TD>
 * <TD>Sup1*, Arg1, Arg2, Sup2*</TD>
 * <TD>source, factuality, polarity, connHead</TD>
 * </TR>
 *
 * <TR>
 * <TD>ImplicitRelation</TD>
 * <TD>Sup1*, Arg1, Arg2, Sup2*</TD>
 * <TD>source, factuality, polarity, type, eConn1*, semanticClass1*, eConn2*, semanticClass2*</TD>
 * </TR>
 *
 * <TR>
 * <TD>AltLexRelation</TD>
 * <TD>Sup1*, Arg1, Arg2, Sup2*</TD>
 * <TD>source, factuality, polarity, semanticClass</TD>
 * </TR>
 *
 * <TR>
 * <TD>EntityRelation</TD>
 * <TD>Arg1, Arg2</TD>
 * <TD></TD>
 * </TR>
 *
 *<TR>
 * <TD>NoRelation</TD>
 * <TD>Arg1, Arg2</TD>
 * <TD></TD>
 * </TR>
 *
 * <TR>
 * <TD>Arg1</TD>
 * <TD></TD>
 * <TD>source, factuality, polarity, rawText</TD>
 * </TR>
 *
 * <TR>
 * <TD>Arg2</TD>
 * <TD></TD>
 * <TD>source, factuality, polarity, rawText</TD>
 * </TR>
 *
 * <TR>
 * <TD>Sup1</TD>
 * <TD></TD>
 * <TD>rawText</TD>
 * </TR>
 *
 * <TR>
 * <TD>Sup2</TD>
 * <TD></TD>
 * <TD>rawText</TD>
 * </TR>
 *
 *  </TABLE>
 * </p>
 *
 * <p>
 * See the <a href="http://www.w3.org/TR/xpath">XPath</a> recommendation for further 
 * info on XPath.
 * </p>
 *
 * The second version fixes bugs in the parent axis and preceding axis.
 *
 * @author  nikhild
 * @since 0.1
 * @version 2
 * @see  edu.upenn.cis.pdtb.util.PDTBTask
 */
public class PDTBNavigator implements Navigator{
    
    protected PDTBRelationList root;
    
    protected PDTBDocument doc;
    
    
    public static final Iterator EmptyIterator = (
    new Iterator() {
        public boolean hasNext(){
            return false;
        }
        
        public Object next(){
            return null;
        }
        
        public void remove(){
            
        }
    }
    );
    
    public static final String EmptyString = "";
    
    /** Creates a new instance of PTBMRGNavigator */
    public PDTBNavigator(PDTBRelationList root) {
        setRoot(root);
    }
    
    public void setRoot(PDTBRelationList root){
        this.root = root;
        doc = new PDTBDocument(root);
    }
    
    public PDTBRelationList getRoot(){
        return root;
    }
    
    public PDTBDocument getDocument(){
        return doc;
    }
    
    protected Iterator getConcatenatedIterator(final Object obj, final Iterator iter){
        return (new Iterator(){
           private boolean retFirst = false;
           
           public boolean hasNext(){
               return (retFirst)? iter.hasNext() : true;
           }
           
           public Object next(){
               if(!retFirst){
                   retFirst = true;
                   return obj;
               }
               else{
                   return iter.next();
               }
           }
           
           public void remove(){
               
           }
           
        });
    }
    
    protected Iterator getConcatenatedIterator(final Stack iterators){
        return (new Iterator(){
           private Iterator iteratorSet = iterators.iterator();
           private Iterator currentIter = (iteratorSet.hasNext())? (Iterator)(iteratorSet.next()) : null;
           
           public boolean hasNext(){
               if(currentIter == null){
                   return false;
               }
               else{
                   if(currentIter.hasNext()){
                       return true;
                   }
                   else{
                       while(iteratorSet.hasNext() && !(currentIter.hasNext())){
                           currentIter = (Iterator)(iteratorSet.next());
                       }
                       
                       if(currentIter.hasNext()){
                           return true;
                       }
                       else{
                           currentIter = null;
                           return false;
                       }
                   }
               }
           }
           
           public Object next(){
               return currentIter.next();
           }
           
           public void remove(){
           }
           
        });
    }
    
    
    public Iterator getAncestorAxisIterator(Object obj) throws UnsupportedAxisException {
        if(isDocument(obj)){
            return EmptyIterator;
        }
        
        if(isAttribute(obj)){
            return getAncestorAxisIterator((((PDTBAttribute)obj)).pdtbGetOwnerNode());
        }
        
        
        final PDTBNode r = root;
        final PDTBDocument d = doc;
        final PDTBNode node = (PDTBNode)obj;
        
        return (new Iterator(){
            private PDTBNode currentNode = (node == root)? node : (PDTBNode)(node.getParent());
            private boolean rootReturned = false;
            
            public boolean hasNext(){
                return (currentNode != null);
            }
            
            public Object next(){
                if(currentNode == root && rootReturned){
                    currentNode = null;
                    return d;
                }
                else{
                    PDTBNode retVal = currentNode;
                    if(retVal == root){
                        rootReturned = true;
                    }
                    else{
                        currentNode = (PDTBNode)(currentNode.getParent());
                    }
                    return retVal;
                }
            }
            
            public void remove(){
            }
        });
        
    }
    
    public Iterator getAncestorOrSelfAxisIterator(Object obj) throws UnsupportedAxisException {
        return getConcatenatedIterator(obj, getAncestorAxisIterator(obj));
    }
    
    public Iterator getAttributeAxisIterator(Object obj) throws UnsupportedAxisException {
        final Enumeration e = ((PDTBNode) obj).pdtbGetAttributes();
        return (new Iterator(){
           public boolean hasNext(){
               return e.hasMoreElements();
           }
           
           public Object next(){
               return e.nextElement();
           }
           
           public void remove(){
               
           }
           
        });
    }
    
    public String getAttributeName(Object obj) {
        return ((PDTBAttribute)obj).pdtbGetLocalName();
        
    }
    
    public String getAttributeNamespaceUri(Object obj) {
        return ((PDTBAttribute)obj).pdtbGetNamespaceURI();
    }
    
    public String getAttributeQName(Object obj) {
        return ((PDTBAttribute)obj).pdtbGetQName();
        
    }
    
    public String getAttributeStringValue(Object obj) {
        return ((PDTBAttribute)obj).pdtbGetValue();
    }
    
    public java.util.Iterator getChildAxisIterator(Object obj) throws org.jaxen.UnsupportedAxisException {
        if(isDocument(obj)){
            return getConcatenatedIterator(root, EmptyIterator);
        }
        
        if(isAttribute(obj)){
            return EmptyIterator;
        }
        
        final PDTBNode node = (PDTBNode)obj;
        return (new Iterator(){
            private PDTBNode currentChild = node.pdtbGetFirstChild();
            
            public boolean hasNext(){
                return (currentChild != null);
            }
            
            public Object next(){
                PDTBNode retVal = currentChild;
                currentChild = (PDTBNode)(currentChild.pdtbGetNextSibling());
                
                return retVal;
            }
            
            public void remove(){
                
            }
            
            
        });
    }
    
    public String getCommentStringValue(Object obj) {
        return null;
    }
    
    public Iterator getDescendantAxisIterator(Object obj) throws UnsupportedAxisException {
        if(isDocument(obj)){
            return getDescendantOrSelfAxisIterator(root);
        }
        
        if(isAttribute(obj)){
            return EmptyIterator;
        }
	
        final PDTBNode node = (PDTBNode)obj;
        
        return (new Iterator(){
            private PDTBNode currentNode = node.pdtbGetFirstChild();
            public boolean hasNext(){
                return currentNode != null;
            }
            
            public Object next(){
                PDTBNode retVal = currentNode;
                
                currentNode = retVal.pdtbGetFirstChild();
                if(currentNode != null){
                    return retVal;
                }
                
                currentNode = retVal.pdtbGetNextSibling();
                if(currentNode != null){
                    return retVal;
                }
                
                for(currentNode =  (PDTBNode) retVal.getParent();
                currentNode.pdtbGetNextSibling() == null && currentNode != node;
                currentNode = (PDTBNode) currentNode.getParent()){
                }
                currentNode = (currentNode == node)? null: currentNode.pdtbGetNextSibling();
                
                
                return retVal;
            }
            
            public void remove(){
            }
            
        });

    }
    
    public Iterator getDescendantOrSelfAxisIterator(Object obj) throws UnsupportedAxisException {
        return getConcatenatedIterator(obj, getDescendantAxisIterator(obj));
    }
    
    public Object getDocument(String str) throws FunctionCallException {
        throw(new FunctionCallException("Load Document Failed"));
    }
    
    public Object getDocumentNode(Object obj) {
        return doc;
    }
    
    public Object getElementById(Object obj, String str) {
        return null;
    }
    
    public String getElementName(Object obj) {
        return ((PDTBNode) obj).pdtbGetLocalName();
    }
    
    public String getElementNamespaceUri(Object obj) {
        return EmptyString;
    }
    
    public String getElementQName(Object obj) {
        return ((PDTBNode) obj).pdtbGetQName();
    }
    
    public String getElementStringValue(Object obj) {
        return EmptyString;
    }
    
    public Iterator getFollowingAxisIterator(Object obj) throws UnsupportedAxisException {
        if(obj instanceof PDTBDocument){
            return getDescendantAxisIterator(obj);
        }
        
        if(obj instanceof PDTBAttribute){
            PDTBAttribute attr = (PDTBAttribute)obj;
            getConcatenatedIterator(attr.pdtbGetOwnerNode(), getFollowingAxisIterator(attr.pdtbGetOwnerNode()));
        }
        
	
        PDTBNode node = (PDTBNode)obj;
	for(;node.pdtbGetNextSibling()==null && node != root; node = (PDTBNode) node.getParent()){
	}
	node = (node == root)? null: node.pdtbGetNextSibling();
        
	final PDTBNode n = node;
        return (new Iterator(){
	   private PDTBNode currentNode = n;
           public boolean hasNext(){
               return currentNode != null;
           }
           
           public Object next(){
               PDTBNode retVal = currentNode;
               
               currentNode = retVal.pdtbGetFirstChild();
	       if(currentNode != null){
		   return retVal;
	       }
               
               currentNode = retVal.pdtbGetNextSibling();
               if(currentNode != null){
                   return retVal;
               }
               
               for(currentNode =  (PDTBNode) retVal.getParent();
               currentNode.pdtbGetNextSibling() == null && currentNode != root;
               currentNode = (PDTBNode) currentNode.getParent()){
               }
               currentNode = (currentNode == root)? null: currentNode.pdtbGetNextSibling();

 
               return retVal;
           }
           
           public void remove(){
           }
           
        });	
        
    }
    
    public java.util.Iterator getFollowingSiblingAxisIterator(Object obj) throws org.jaxen.UnsupportedAxisException {
        if(isDocument(obj) || isAttribute(obj) || obj == root){
            return EmptyIterator;
        }
        
        final PDTBNode n = (PDTBNode)obj;
        
        return (new Iterator(){
           PDTBNode currNode = (PDTBNode)(n.pdtbGetNextSibling());
           
           public boolean hasNext(){
               return (currNode != null);
           }
           
           public Object next(){
               PDTBNode retVal = currNode;
               currNode = (PDTBNode)(currNode.pdtbGetNextSibling());
               return retVal;
           }
           
           public void remove(){
               
           }
           
        });

    }
    
    public Iterator getNamespaceAxisIterator(Object obj) throws org.jaxen.UnsupportedAxisException {
        return EmptyIterator;
    }
    
    public String getNamespacePrefix(Object obj) {
        return EmptyString;
    }
    
    public String getNamespaceStringValue(Object obj) {
        return EmptyString;
    }
    
    public short getNodeType(Object obj) {
        if(obj instanceof PDTBNode){
            return Node.ELEMENT_NODE;
        }
        else if(obj instanceof PDTBAttribute){
            return Node.ATTRIBUTE_NODE;
        }else if(obj instanceof PDTBDocument){
            return Node.DOCUMENT_NODE;
        }
        
        throw(new IllegalArgumentException("Wrong object."));
    }
    
    public Iterator getParentAxisIterator(Object obj) throws UnsupportedAxisException {
        return getConcatenatedIterator(getParentNode(obj), EmptyIterator);
        
    }
    
    public Object getParentNode(Object obj) throws UnsupportedAxisException {
        if(obj instanceof PDTBDocument){
            return null;
        }
        
        if(obj instanceof PDTBAttribute){
            return ((PDTBAttribute)obj).pdtbGetOwnerNode();
        }
        
        PDTBNode parent = (PDTBNode)(((PDTBNode) obj).getParent());
        if(parent == null){return doc;}else {return parent;}
    }
    
    public Iterator getPrecedingAxisIterator(Object obj) throws UnsupportedAxisException {
        if(obj instanceof PDTBDocument){
            return EmptyIterator;
        }
        
        if(obj instanceof PDTBAttribute){
            PDTBAttribute attr = (PDTBAttribute)obj;
            getConcatenatedIterator(attr.pdtbGetOwnerNode(), getPrecedingAxisIterator(attr.pdtbGetOwnerNode()));
        }
	
        
        PDTBNode node = (PDTBNode)obj;
	for(;node.pdtbGetPreviousSibling()==null && node != root; node = (PDTBNode) node.getParent()){
	}
	node = (node == root)? null: node.pdtbGetPreviousSibling();

	final PDTBNode n = node;
        
        return (new Iterator(){
	   private PDTBNode currentNode = n;
           public boolean hasNext(){
               return currentNode != null;
           }
           
           public Object next(){
               PDTBNode retVal = currentNode;
               
               currentNode = retVal.pdtbGetLastChild();
	       if(currentNode != null){
		   return retVal;
	       }
               
               currentNode = retVal.pdtbGetPreviousSibling();
               if(currentNode != null){
                   return retVal;
               }
               
               for(currentNode =  (PDTBNode) retVal.getParent();
               currentNode.pdtbGetPreviousSibling() == null && currentNode != root;
               currentNode = (PDTBNode) currentNode.getParent()){
               }
               currentNode = (currentNode == root)? null: currentNode.pdtbGetPreviousSibling();

 
               return retVal;
           }
           
           public void remove(){
           }
           
        });
        
    }
    
    public Iterator getPrecedingSiblingAxisIterator(Object obj) throws UnsupportedAxisException {
        if(isAttribute(obj) || isDocument(obj) || obj == root){
            return EmptyIterator;
        }
        
        final PDTBNode n = (PDTBNode)obj;
        
        return (new Iterator(){
           PDTBNode currNode = (PDTBNode)(n.pdtbGetPreviousSibling());
           
           public boolean hasNext(){
               return (currNode != null);
           }
           
           public Object next(){
               PDTBNode retVal = currNode;
               currNode = (PDTBNode)(currNode.pdtbGetPreviousSibling());
               return retVal;
           }
           
           public void remove(){
               
           }
           
        });

    }
    
    public String getProcessingInstructionData(Object obj) {
        return EmptyString;
    }
    
    public String getProcessingInstructionTarget(Object obj) {
        return EmptyString;
    }
    
    public Iterator getSelfAxisIterator(Object obj) throws UnsupportedAxisException {
        return getConcatenatedIterator(obj, EmptyIterator);
    }
    
    public String getTextStringValue(Object obj) {
        return EmptyString;
    }
    
    public boolean isAttribute(Object obj) {
        return (obj instanceof PDTBAttribute);
    }
    
    public boolean isComment(Object obj) {
        return false;
    }
    
    public boolean isDocument(Object obj) {
        return (obj instanceof PDTBDocument);
    }
    
    public boolean isElement(Object obj) {
        return (obj instanceof PDTBNode);
    }
    
    public boolean isNamespace(Object obj) {
        return false;
    }
    
    public boolean isProcessingInstruction(Object obj) {
        return false;
    }
    
    public boolean isText(Object obj) {
        return false;
    }
    
    public org.jaxen.XPath parseXPath(String str) throws org.jaxen.saxpath.SAXPathException {
	SimpleFunctionContext fc = new XPathFunctionContext();
	fc.registerFunction("","regexp", new RegexpFunction());
        fc.registerFunction("","comp-splist", new CompareSpanListFunction() );
        fc.registerFunction("","splist-size", new SpanListSizeFunction() );
        fc.registerFunction("","is-arg", new IsArgFunction() );
        fc.registerFunction("","is-rel", new IsRelationFunction() );
        fc.registerFunction("","is-sup", new IsSupFunction() );
        fc.registerFunction("","delim-text", new DelimTextFunction() );
        fc.registerFunction("","cache", new CachedAbsolutePathFunction() );
        fc.registerFunction("","is-adv", new IsAdverbialFunction());
        fc.registerFunction("","is-sc", new IsSubConjFunction() );
        fc.registerFunction("","is-cc", new IsCoordConjFunction() );
	BaseXPath xp = new BaseXPath(edu.upenn.cis.ptb.xpath.PTBXPath.desugarExpr(str), this);
	xp.setFunctionContext(fc);
	return xp;
    }
    
    public String translateNamespacePrefixToUri(String str, Object obj) {
        return EmptyString;
    }
    
    public static void main(String[] args){
        try{
            if(args.length != 4){
                System.err.println("Usage: java edu.upenn.cis.pdtb.PDTBNavigator <textRoot> <ptbRoot> <pdtbRoot> <xpath>");
                System.exit(0);
            }
            String textRoot = args[0];
            String ptbRoot = args[1];
            String pdtbRoot = args[2];
            
            CorpusFileIterator cfi = new CorpusFileIterator(textRoot, ptbRoot, pdtbRoot);
            RelationLoader loader = new RelationLoaderImpl();
            PDTBNavigator nav = new PDTBNavigator(null);
            XPath xp = nav.parseXPath(args[3]);
            int totalCount = 0;
            long selectStartTime = System.currentTimeMillis();
            while(cfi.hasMoreFiles()){
                cfi.nextFile();
                String secNo = cfi.getSecNoStr();
                String fileNo = cfi.getFileNoStr();
                
                PDTBRelationList rlist = loader.loadRelations(textRoot, ptbRoot, pdtbRoot, secNo, fileNo);
                nav.setRoot(rlist);                
                
                List selectedNodes = xp.selectNodes(nav.getDocument());
                
                for(Iterator iter = selectedNodes.iterator(); iter.hasNext(); iter.next()){
                    totalCount++;
                }
                
                
            }
            long selectEndTime = System.currentTimeMillis();
            
            System.err.println("Time taken = " + ((selectEndTime - selectStartTime)/1000) + "secs");
            System.err.println("No of nodes = " + totalCount);
            
            
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
 
    public class PDTBDocument{
        private PDTBRelationList root;
        
        public PDTBDocument(PDTBRelationList root){
            this.root = root;
        }
        
        public PDTBRelationList getDocumentElement(){
            return root;
        }
        
        public void setDocumentElement(PDTBRelationList root){
            this.root = root;   
         }
    }
    
}
