/*
 * PDTBFeaturesImpl.java
 *
 * Created on November 28, 2005, 11:57 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

/**
 * Implementation of the PDTBFeatures interface.
 * @author nikhild
 */
public class PDTBFeaturesImpl implements PDTBFeatures{
    
    private PDTBNode fNode;
    
    private int fFactuality;
    
    private int fPolarity;
    
    private int fSource;
    
    private String fFeatString;
    
    
    
    /** Creates a new instance of PDTBFeaturesImpl */
    public PDTBFeaturesImpl(String source, String factuality, String polarity) {
        fSource = (!(source.equals(SourceWriterVal)))? ((!(source.equals(SourceInheritedVal)))? SourceOther : SourceInherited) : SourceWriter; 
        fFactuality = (!factuality.equals(NonFactualVal))? ((!factuality.equals(NullFactualVal))? Factual : NullFactual) : NonFactual;
        fPolarity = (!polarity.equals(NegativePolarityVal))? PolarityPositive : PolarityNegative; 
        
    }
    
    public PDTBNode getPDTBNode() {
        return fNode;
    }
    
    public int getFactuality() {
        return fFactuality;
    }
    
    public int getPolarity() {
        return fPolarity;
    }
    
    public int getSource() {
        return fSource;
    }
    
    public void setPDTBNode(PDTBNode node) {
        fNode = node;
    }
    
    public void updateAttributesOnNode() {
        fNode.pdtbSetAttribute("", FactualityAttributeQName, FactualityAttributeQName, "",
              (fFactuality == Factual)? FactualVal : ((fFactuality == NonFactual)? NonFactualVal : NullFactualVal));
              
        fNode.pdtbSetAttribute("", PolarityAttributeQName, PolarityAttributeQName, "", 
              (fPolarity == PolarityPositive)? PositivePolarityVal : NegativePolarityVal);
        
        fNode.pdtbSetAttribute("", SourceAttributeQName, SourceAttributeQName, "", 
              (fSource == SourceWriter)? SourceWriterVal : ((fSource == SourceOther)? SourceOtherVal : SourceInheritedVal));
        
    }
    
    public void save(Writer writer) throws IOException{
        int source = fSource;
        
        if(source == PDTBFeatures.SourceWriter){
            writer.write(SourceWriterVal);
            writer.write('\n');
        }
        else if(source == PDTBFeatures.SourceOther){
            writer.write(SourceOtherVal);
            writer.write('\n');
        }
        else{
            writer.write(SourceInheritedVal);
            writer.write('\n');
        }
        
        int fact = fFactuality;
        
        if(fact == PDTBFeatures.Factual){
            writer.write(FactualVal);
            writer.write('\n');
        }
        else if(fact == PDTBFeatures.NonFactual){
            writer.write(NonFactualVal);
            writer.write('\n');
        }
        else{
            writer.write(NullFactualVal);
            writer.write('\n');
        }
        
        int pol = fPolarity;
        
        if(pol == PDTBFeatures.PolarityPositive){
            writer.write(PositivePolarityVal);
            writer.write('\n');
        }
        else{
            writer.write(NegativePolarityVal);
            writer.write('\n');
        }
        
    }
    
}
