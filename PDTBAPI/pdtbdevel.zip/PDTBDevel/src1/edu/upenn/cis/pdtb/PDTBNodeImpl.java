/*
 * PDTBNodeImpl.java
 *
 * Created on November 29, 2005, 7:28 PM
 */

package edu.upenn.cis.pdtb;

import javax.swing.tree.*;
import java.util.Vector;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Iterator;
import java.io.Writer;
import java.io.IOException;
import edu.upenn.cis.pdtb.util.ArraySet;
import java.util.Comparator;

/**
 *
 * @author  nikhild
 */
public abstract class PDTBNodeImpl implements PDTBNode{
    
    private PDTBNode fFirstChild;
    
    private PDTBNode fLastChild;
    
    private PDTBNode fPreviousSibling;
    
    private PDTBNode fNextSibling;
    
    private PDTBNode fParent;
    
    private Object fUserObject;
    
    private String fNamespaceUri;
    
    private String fLocalName;
    
    private String fQName;
    
    protected ArraySet fAttributes = null;
    
    protected static final Comparator fAttributesComparator = (new Comparator(){
        public int compare(Object o1, Object o2){
            PDTBAttribute att1 = (PDTBAttribute) o1;
            PDTBAttribute att2 = (PDTBAttribute) o2;
            return att1.pdtbGetQName().compareTo(att2.pdtbGetQName());
        }
        
        public boolean equals(Object o){
            return o == this;
        }
    });
    
    /** Creates a new instance of PDTBNodeImpl */
    public PDTBNodeImpl() {
    }
    
    protected abstract void initAttributes();
    
    public Enumeration children() {
        final PDTBNode currChild = fFirstChild;
        return(new Enumeration(){
           private PDTBNode child = currChild;
           
           public boolean hasMoreElements(){
               return (child != null);
           }
           
           public Object nextElement(){
               PDTBNode saveChild = child;
               child = child.pdtbGetNextSibling();
               return saveChild;
           }
        });
    }
    
    public TreeNode getChildAt(int childIndex) {
        if(childIndex < 0){
            throw(new RuntimeException("Child Index should be > 0. Value supplied = " + childIndex));
        }
        
        PDTBNode child = fFirstChild;
        for(int i = childIndex; (i > 0) && (child != null); i--){
            child = child.pdtbGetNextSibling();
        }
        return child;
    }
    
    public int getChildCount() {
        PDTBNode child = fFirstChild;
        int i = 0;
        for(; (child != null); i++){
            child = child.pdtbGetNextSibling();
        }
        return i;
    }
    
    public int getIndex(TreeNode node) {
        PDTBNode child = fFirstChild;
        for(int i = 0; (child != null); i++){
            if(child == node){
                return i;
            }
            child = child.pdtbGetNextSibling();
        }
        
        return -1;
    }
    
    public TreeNode getParent() {
        return fParent;
    }
    
    public void insert(MutableTreeNode child, int index) {
        if(getAllowsChildren()){
            PDTBNode nextSib = (PDTBNode)(getChildAt(index));
            PDTBNode prevSib = (nextSib == null)? null : nextSib.pdtbGetPreviousSibling();
            
            if(nextSib == null && prevSib == null && fFirstChild != null){
                throw(new RuntimeException("Illegal position to insert"));
            }
            
            PDTBNode newChild = (PDTBNode) child;
            
            if(newChild.getParent() != null){
                throw(new RuntimeException("Child is already attached to some node"));
            }
            
            newChild.pdtbSetPreviousSibling(prevSib);
            newChild.pdtbSetNextSibling(nextSib);
            newChild.setParent(this);
            if(prevSib != null){
                prevSib.pdtbSetNextSibling(newChild);
            }
            else{
                fFirstChild = newChild;
            }
            
            if(nextSib != null){
                nextSib.pdtbSetPreviousSibling(newChild);
            }
            else{
                fLastChild = newChild;
            }
        }
    }

    
    public boolean isLeaf() {
        return (fFirstChild == null);
    }
    
    public PDTBNode pdtbGetFirstChild() {
        return fFirstChild;
    }
    
    public PDTBNode pdtbGetLastChild() {
        return fLastChild;
    }
    
    public PDTBNode pdtbGetNextSibling() {
        return fNextSibling;
    }
    
    public PDTBNode pdtbGetPreviousSibling() {
        return fPreviousSibling;
    }
    
    public void pdtbAddFirstChild(PDTBNode firstChild) {
        if(getAllowsChildren()){
            firstChild.setParent(this);
            if(fFirstChild != null){
                fFirstChild.pdtbSetPreviousSibling(firstChild);
            }
            
            firstChild.pdtbSetNextSibling(fFirstChild);
            firstChild.pdtbSetPreviousSibling(null);
            fFirstChild = firstChild;
            
            if(fLastChild == null){
                fLastChild = fFirstChild;
            }
        }
        else{
            throw(new RuntimeException("This node does not allow children"));
        }
    }
    
    public void pdtbAddLastChild(PDTBNode lastChild) {
        if(getAllowsChildren()){
            lastChild.setParent(this);
            if(fLastChild != null){
                fLastChild.pdtbSetNextSibling(lastChild);
            }
            
            lastChild.pdtbSetPreviousSibling(fLastChild);
            lastChild.pdtbSetNextSibling(null);
            fLastChild = lastChild;
            
            if(fFirstChild == null){
                fFirstChild = fLastChild;
            }
        }
        else{
            throw(new RuntimeException("This node does not allow children"));
        }
    }

    public void pdtbSetNextSibling(PDTBNode node) {
        fNextSibling = node;
    }
    
    public void pdtbSetPreviousSibling(PDTBNode node) {
        fPreviousSibling = node;
    }
    
    public void remove(MutableTreeNode aChild) {
        if(aChild.getParent() == this){
            PDTBNode child = (PDTBNode)(aChild);
            PDTBNode prevSib = child.pdtbGetPreviousSibling();
            PDTBNode nextSib = child.pdtbGetNextSibling();
            
            if(prevSib != null){
                prevSib.pdtbSetNextSibling(nextSib);
            }
            else{
                fFirstChild = nextSib;
            }
            
            if(nextSib != null){
                nextSib.pdtbSetPreviousSibling(prevSib);
            }
            else{
                fLastChild = prevSib;
            }
            
            child.pdtbSetNextSibling(null);
            child.pdtbSetPreviousSibling(null);
            child.setParent(null);
        }
    }
    
    public void remove(int index) {
        remove((MutableTreeNode)(getChildAt(index)));
    }
    
    public void removeFromParent() {
        if(fParent != null){
            fParent.remove(this);
        }
    }
    
    public void setParent(MutableTreeNode newParent) {
        fParent = (PDTBNode)(newParent);
    }
    
    public void setUserObject(Object object) {
        fUserObject = object;
    }
    
    public Object getUserObject(){
        return fUserObject;
    }
    
    public void pdtbSetAttribute(String namespaceURI, String localName, String qName, String prefix, String value){
        if(fAttributes == null){
            initAttributes();
        }
        PDTBAttributeImpl attrib = new PDTBAttributeImpl(namespaceURI, localName, qName, prefix, value, this);
        //fAttributes.add(attrib);
        
        if(!fAttributes.add(attrib)){
            fAttributes.remove(attrib);
            fAttributes.add(attrib);
        }
         
    }
    
    public void pdtbRemoveAttribute(String namespaceURI, String localName, String qName){
        if(fAttributes == null){
            initAttributes();
        }
        
        PDTBAttributeImpl attrib = new PDTBAttributeImpl(namespaceURI, localName, qName, null, null, null);
        fAttributes.remove(attrib);
    }
    
    public Enumeration pdtbGetAttributes(){
        if(fAttributes == null){
            initAttributes();
        }
        
        final Iterator iter = fAttributes.iterator();
        return (new Enumeration(){
           public boolean hasMoreElements(){
               return iter.hasNext();
           }
           
           public Object nextElement(){
               return iter.next();
           }
        });
    }
    
    public String pdtbGetNamespaceUri(){
        return fNamespaceUri;
    }
    
    public String pdtbGetLocalName(){
        return fLocalName;
    }
    
    public String pdtbGetQName(){
        return fQName;
    }
    
    public void pdtbSetName(String namespaceUri, String localName, String qName){
        fNamespaceUri = namespaceUri;
        fLocalName = localName;
        fQName = qName;
    }
    
    public abstract void save(Writer writer) throws IOException;
    
    
    public class PDTBAttributeImpl implements PDTBAttribute, java.lang.Comparable{
        
        private String fNamespaceURI;
        
        private String fLocalName;
        
        private String fQName;
        
        private String fPrefix;
        
        private String fValue;
        
        private PDTBNode fOwner = null;
        
        public PDTBAttributeImpl(String namespaceURI, String localName, 
               String qName, String prefix, String value, PDTBNode owner){
            fNamespaceURI = namespaceURI;
            fLocalName = localName;
            fQName = qName;
            fPrefix = prefix;
            fValue = value;
            fOwner = owner;
        }
      
        
        public String pdtbGetLocalName() {
            return fLocalName;
        }
        
        public String pdtbGetNamespaceURI() {
            return fNamespaceURI;
        }
        
        public PDTBNode pdtbGetOwnerNode() {
           return fOwner; 
        }
        
        public String pdtbGetPrefix() {
            return fPrefix;
        }
        
        public String pdtbGetQName() {
            return fQName;
        }
        
        public String pdtbGetValue() {
            return fValue;
        }
        
        public int hashCode(){
            return fQName.hashCode();
        }
        
        public boolean equals(Object o){
            PDTBAttribute other = (PDTBAttribute)o;
            return fQName.equals(other.pdtbGetQName());
        }
        
        public int compareTo(Object o){
            PDTBAttribute other = (PDTBAttribute)o;
            return fQName.compareTo(other.pdtbGetQName());
        }
        
    }
    
}
