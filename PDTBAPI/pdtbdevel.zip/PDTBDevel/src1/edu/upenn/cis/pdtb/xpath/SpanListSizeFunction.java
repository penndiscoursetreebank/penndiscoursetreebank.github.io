/*
 * SpanListSizeFunction.java
 *
 * Created on March 17, 2007, 9:11 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import edu.upenn.cis.pdtb.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Returns the size of the SpanList associated with the context node. This function has the
 * signature:
 *
 * <pre>
 *  number splist-size()
 *  </pre>
 *
 * If the node doesn't have an associated span list, -1 is returned.
 *
 * @since 0.2.5
 * @author nikhild
 */
public class SpanListSizeFunction implements Function{
    
    /** Creates a new instance of SpanListSizeFunction */
    public SpanListSizeFunction() {
    }
    
    public Object call(Context context, List args) throws FunctionCallException {
        Object contextNode = context.getNodeSet().get(0);
        if(contextNode instanceof PDTBNode){
            SpanList l = getSpanListForNode((PDTBNode) contextNode, false);
            if(l != null){
                return new Double(l.size());
            }
        }
        return new Integer(-1);
    }
    
    public static SpanList getSpanListForNode(PDTBNode node, boolean unionForRelations){
        if(node instanceof PDTBArg && 
                node.pdtbGetPreviousSibling() != null &&
                node.pdtbGetPreviousSibling() instanceof PDTBArg &&
                node.getParent() instanceof PDTBExplicitRelation && 
                unionForRelations){
            SpanList sp = new SpanList();
            PDTBArg arg2 = (PDTBArg) node;
            PDTBExplicitRelation rel  = (PDTBExplicitRelation) node.getParent();
            sp.addAll(rel.getSelection().getSpans());
            sp.addAll(arg2.getSelection().getSpans());
            return sp;
        }
        
        if(node instanceof PDTBSup){
            return ((PDTBSup) node).getSelection().getSpans();
        }
        else if(node instanceof PDTBExplicitRelation && !unionForRelations){
            return ((PDTBExplicitRelation) node).getSelection().getSpans();
        }
        else if(node instanceof PDTBAltLexRelation && !unionForRelations){
            return ((PDTBAltLexRelation) node).getSelection().getSpans();
        }
        
        if(unionForRelations && node instanceof PDTBRelation){
            SpanList sp = new SpanList();
            PDTBRelation rel = (PDTBRelation) node;
            sp.addAll(rel.getArg1().getSelection().getSpans());
            if(rel instanceof PDTBExplicitRelation){
                sp.addAll(((PDTBExplicitRelation) node).getSelection().getSpans());
            }
            else if(rel instanceof PDTBAltLexRelation){
                sp.addAll(((PDTBAltLexRelation) node).getSelection().getSpans());
            }
            sp.addAll(rel.getArg2().getSelection().getSpans());
            
            
            return sp;
            
        }
        
        return null;
    }
}
