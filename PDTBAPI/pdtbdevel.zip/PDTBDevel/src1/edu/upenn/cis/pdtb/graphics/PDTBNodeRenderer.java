/*
 * PDTBNodeRenderer.java
 *
 * Created on December 3, 2005, 10:34 PM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.tree.*;
import javax.swing.table.*;
import javax.swing.*;
import java.awt.*;
import edu.upenn.cis.pdtb.*;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.event.TableModelListener;
import javax.swing.event.TableModelEvent;
import java.awt.event.*;
import java.awt.Color;
import edu.upenn.cis.pdtb.lexyacc.*;
import javax.swing.CellRendererPane;

/**
 * Renders a PDTBNode in a JTree. Each node has a label depending on the node, and
 * a table placed below the node containing the features. The table is displayed
 * only when the node is selected.
 *
 * @author  nikhild
 */
public class PDTBNodeRenderer extends JPanel implements TreeCellRenderer{
    //The label
    private JLabel fLabel = new JLabel();
    
    //The data for the table containing the features
    private FeatureData fTableData = new FeatureData();
    
    //The table
    private JTable fTable = new JTable(fTableData);
    
    //The selection background
    private Color fSelectionBG;
    
    //The default background
    private Color fNonSelectionBG;
    
    private DefaultTreeCellRenderer fDefaultRenderer = new DefaultTreeCellRenderer();
    
    //The selection icon
    private Icon fSelectionIcon = fDefaultRenderer.getLeafIcon();;
    
    //The non selection icon
    private Icon fNonSelectionIcon = fDefaultRenderer.getOpenIcon();
    
    //The current icon
    private Icon fCurrentIcon = fNonSelectionIcon;
    
    
    /** Creates a new instance of PDTBNodeRenderer */
    public PDTBNodeRenderer(Color selectionColor, Color nonSelectionColor) {
        super();
        
        
        Font currentFont = FontProvider.PDTBBrowserFontProvider.getCurrentFont();
        fLabel.setFont(currentFont);
        fTable.getTableHeader().setFont(currentFont);
        fTable.setFont(currentFont);
        fTable.setRowHeight(fTable.getFontMetrics(currentFont).getHeight() + fTable.getRowMargin());
        //need 3 rows for label, table header and table
        setLayout(new GridLayout(3,1));
        add(fLabel);
        //fTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        add(fTable.getTableHeader());
        add(fTable);
        
        fSelectionBG = selectionColor;
        fNonSelectionBG = nonSelectionColor;
    }
    
    
    public java.awt.Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        PDTBNode node = (PDTBNode)(value);
        fTableData.setData(node);
        
        //Ensure that columns other than raw text are completely visible
        TableCellRenderer headerRenderer = fTable.getTableHeader().getDefaultRenderer();
        int numColumns = fTableData.getColumnCount();
        for(int i = 0; i < numColumns; i++){
            String columnName = fTableData.getColumnName(i);
            Component comp = headerRenderer.getTableCellRendererComponent(fTable, columnName, false, false, 0, 0);
            int headerWidth = comp.getPreferredSize().width;
            if(!(columnName.equals(PDTBSelection.RawTextAttributeQName))){
                String columnVal = (String)(fTableData.getValueAt(0, i));
                comp = fTable.getDefaultRenderer(String.class).getTableCellRendererComponent(fTable, columnVal, false, false, 0, i);
                int colWidth = comp.getPreferredSize().width;
                TableColumn tc = fTable.getColumnModel().getColumn(i);
                tc.setMinWidth(Math.max(headerWidth, colWidth) + 20);
                tc.setPreferredWidth(Math.max(headerWidth, colWidth) + 20);
            }
            
        }
        
        fCurrentIcon = (selected)? ((!leaf && expanded)? fSelectionIcon : (leaf)? fSelectionIcon : fNonSelectionIcon) : fNonSelectionIcon;
        
        fLabel.setIcon(fCurrentIcon);
        fLabel.setIconTextGap(10);
        
        //if selected then table should be visible otherwise not
        //Background should be set appropriately
        if(selected){
            setBackground(fSelectionBG);
            
            fLabel.setBackground(fSelectionBG);
            fTable.getTableHeader().setVisible(true);
            fTable.setVisible(true);
        }
        else{
            setBackground(fNonSelectionBG);
            fTable.getTableHeader().setVisible(false);
            fTable.setVisible(false);
        }
        
        //Get the label
        StringBuffer sb = new StringBuffer(50);
        
        if(node instanceof PDTBRelation){
            if(node instanceof PDTBExplicitRelation){
                sb.append("Conn: ");
            }
            else if(node instanceof PDTBImplicitRelation){
                sb.append("Implicit: ");
                PDTBImplicitRelationFeatures feats = ((PDTBImplicitRelation)node).getFeatures();
                sb.append(feats.getConn1());
            }
            else if(node instanceof PDTBAltLexRelation){
                sb.append("AltLex: ");
            }
        }
        else{
            if(node instanceof PDTBEntityRelation){
                if(node instanceof PDTBNoRelation){
                    sb.append("NoRel");
                }
                else{
                    sb.append("EntRel");
                }
            }
            else if(node instanceof PDTBArg){
                
                if(node == ((PDTBRelation) node.getParent()).getArg1()){
                    sb.append("Arg1: ");
                }
                else{
                    sb.append("Arg2: ");
                }
                
            }
            else{
                PDTBNode parent = (PDTBNode)(node.getParent());
                if(parent instanceof PDTBRelation){
                    if(node == ((PDTBRelation)parent).getSup1()){
                        sb.append("Sup1: ");
                    }
                    else{
                        sb.append("Sup2: ");
                    }
                }
                else{
                    PDTBEntityRelation entRelParent = (PDTBEntityRelation)parent;
                    if(node == entRelParent.getArg1()){
                        sb.append("Arg1: ");
                    }
                    else{
                        sb.append("Arg2: ");
                    }
                }                
            }
        }
        
        if(node instanceof PDTBSup){
            String raw = ((PDTBSup)node).getSelection().getRawText();
            if(raw.length() > 30){
                raw = raw.substring(0, 30) + "...";
            }
            sb.append(raw);
        }
        else{
            if(node instanceof PDTBExplicitRelation){
                sb.append(((PDTBExplicitRelation)node).getSelection().getRawText());
            }
            else if(node instanceof PDTBAltLexRelation){
                sb.append(((PDTBAltLexRelation)node).getSelection().getRawText());
            }
        }
        
        fLabel.setText(sb.toString());
        
        return this;
    }
    
    public boolean isShowing(){
        return true;
    }
        
    
    /**
     * Table data for features associated with a PDTBNode.
     */
    public class FeatureData extends AbstractTableModel implements TableModel{
        private Vector fTableColumns = new Vector();
        
        private Vector fValues = new Vector();
        
        
        public FeatureData(){
            
        }
        
        public void setData(PDTBNode node){
            fTableColumns.removeAllElements();
            fValues.removeAllElements();
            
            for(Enumeration e = node.pdtbGetAttributes(); e.hasMoreElements();){
                PDTBAttribute attr = (PDTBAttribute)(e.nextElement());
                fTableColumns.add(attr.pdtbGetQName());
                fValues.add(attr.pdtbGetValue());
            }
            
            
            super.fireTableStructureChanged();
        }
        
        
        
        public int getColumnCount() {
            return fTableColumns.size();
        }
        
        public String getColumnName(int columnIndex) {
            return (String)(fTableColumns.elementAt(columnIndex));
        }
        
        public int getRowCount() {
            return (fTableColumns.size() > 0)? 1 : 0;
        }
        
        public Object getValueAt(int rowIndex, int columnIndex) {
            return fValues.elementAt(columnIndex);
        }
        
        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return false;
        }
        
        
        public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        }
        
    }
        
}
