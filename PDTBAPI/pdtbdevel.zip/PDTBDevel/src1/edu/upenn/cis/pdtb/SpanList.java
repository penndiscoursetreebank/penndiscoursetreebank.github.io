/*
 * GornAddressList.java
 *
 * Created on December 3, 2004, 5:21 PM
 */

package edu.upenn.cis.pdtb;

import java.util.Iterator;
import java.util.TreeSet;
import java.util.Comparator;
import edu.upenn.cis.pdtb.util.ArraySet;

/**
 * Spans ordered by getStart() and getEnd(). This has
 * been changed to derive from ArraySet rather than
 * TreeSet for performance reasons. Since the SortedSet
 * interface is still respected, hopefully this won't cause
 * any problems.
 *
 * @since 0.1
 * @version 3 Added a method for crossing comparison.
 * @version 2 Added several comparison methods. Derives from ArraySet rather than TreeSet.
 * @author nikhild
 */
public class SpanList extends ArraySet {
    
    /** Creates a new instance of SpanList */
    public SpanList(String spans) {
        super((new Comparator(){
            
            public int compare(Object o1, Object o2){
                Span s1 = (Span)o1;
                Span s2 = (Span)o2;
                
                int startComp = s1.getStart() - s2.getStart();
                
                return (startComp == 0)? s1.getEnd() - s2.getEnd() : startComp;
                
            }
            
            public boolean equals(Object o){
                return false;
            }
            
        }    ));
        
        if(!(spans.equals(""))){
            String[] comps = spans.split(";");
            
            int len = comps.length;
            for(int i = 0; i < len; i++){
                super.add(new Span(comps[i]));
            }
        }
    }
    
    public SpanList(){
        super((new Comparator(){
            
            public int compare(Object o1, Object o2){
                Span s1 = (Span)o1;
                Span s2 = (Span)o2;
                
                int startComp = s1.getStart() - s2.getStart();
                
                return (startComp == 0)? s1.getEnd() - s2.getEnd() : startComp;
                
            }
            
            public boolean equals(Object o){
                return false;
            }
            
        }    ));
    }
    
    public String toString(){
        String s = "";
        int i = 0;
        for(Iterator iter = iterator(); iter.hasNext();){
            Span sp = (Span)(iter.next());
            s = s + ((i == 0)? sp.toString() : ";" + sp.toString());
            i++;
        }
        
        return s;
    }
    
    /**
     * Checks if some span in this set overlaps with some span in l.
     */
    public boolean isOverlapping(SpanList l){
        int size = size();
        int lSize = l.size();
        
        
        for(int i = 0; i < size; i++){
            Span s = (Span) fStore.get(i);
            Span s2 = null;
            Span s3 = null;
            
            if(lSize == 1){
                s2 = (Span) l.get(0);
            }
            else{
                int index = l.findLeastUpperBound(s, fComparator);
                
                if(index == lSize){
                    index--;
                    s2 = (Span) l.get(index);
                }
                else {
                    s2 = (Span) l.get(index);
                    if(index > 0){
                        s3 = (Span) l.get(index - 1);
                    }
                    
                     
                }
                 
            }
            
            if(s.isOverlapping(s2) || (s3 != null && s.isOverlapping(s3))){
                return true;
            }
        }
        
        
               
        return false;
        
    }
    
    /**
     * Checks if some span in this set overlaps with s2.
     */
    public boolean isOverlapping(Span s2){
        int size = size();
        
        
        for(int i = 0; i < size; i++){
            Span s = (Span) fStore.get(i);
            
            if(s.isOverlapping(s2)){
                return true;
            }
        }
        
        
               
        return false;
        
    }
    
    /**
     * Checks if every span in this set is contained by some span in l.
     */
    public boolean isContainedBy(SpanList l){
        int size = size();
        int lSize = l.size();
        
        
        for(int i = 0; i < size; i++){
            Span s = (Span) fStore.get(i);
            Span s2 = null;
            
            if(lSize == 1){
                s2 = (Span) l.get(0);
            }
            else{
                int index = l.findLeastUpperBound(s, fComparator);
                
                if(index == lSize){
                    index--;
                    s2 = (Span) l.get(index);
                }
                else {
                    s2 = (Span) l.get(index);
                    
                    if(s2.getStart() > s.getStart()){
                        if(index == 0){
                            return false;
                        }
                        s2 = (Span) l.get(index - 1);
                        
                    }
                     
                }
                 
            }
            
            if(!s.isContainedBy(s2)){
                return false;
            }
        }
        
        
               
        return true;
    }
    
    /**
     * Checks if every span in this set is contained by s2.
     */
    public boolean isContainedBy(Span s2){
        int size = size();
        
        for(int i = 0; i < size; i++){
            Span s = (Span) fStore.get(i);
            
            if(!s.isContainedBy(s2)){
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Checks if every span in this set is identical to some span in l and conversely.
     */
    public boolean isIdentical(SpanList l){
       int size = size();
       int lSize = l.size();
       if(size != lSize){
           return false;
       }
       
       if(size == 0){
           return true;
       }
       
       for(int i = 0; i < size; i++){
           if(!fStore.get(i).equals(l.get(i))){
               return false;
           }
       }
   
       return true;
    }
    
    /**
     * Checks if every span in this set is identical to s2.
     */
    public boolean isIdentical(Span s2){
        return size() == 1 && s2.equals(first());
    }
    
    
    /**
     * Checks if the range of this set is contains the range of l.
     */
    public boolean rangesOver(SpanList l){
        return l.range().isContainedBy(range());
    }
    
    /**
     * Checks if the range of this set is contains s.
     */
    public boolean rangesOver(Span s){
        Span range = range();
        return range.contains(s);
    }
    
    /**
     * Checks if the range of this set is contained by the range of l.
     */
    public boolean isRangedOverBy(SpanList l){
        return range().isContainedBy(l.range());
    }
    
    /**
     * Checks if the range of this set is contained by s.
     */
    public boolean isRangedOverBy(Span s){
        Span range = range();
        return s.contains(range);
    }
    
    /**
     * Checks if the range of this set crosses the range of l.
     */
    public boolean rangeCrosses(SpanList l){
        return range().crosses(l.range());
    }
    
    /**
     * Checks if the range of this set crosses s.
     */
    public boolean rangeCrosses(Span s){
        return range().crosses(s);
    }
    
    public boolean rangeOverlaps(SpanList l){
        int start = getRangeStart();
        int end = getRangeEnd();
        
        int start2 = l.getRangeStart();
        int end2 = l.getRangeEnd();
        
         return (start >= start2 && start < end2) || (start2 >= start && start2 < end);
    }
    
    public boolean rangeOverlaps(Span s){
        int start = getRangeStart();
        int end = getRangeEnd();
        
        int start2 = s.getStart();
        int end2 = s.getEnd();
        
         return (start >= start2 && start < end2) || (start2 >= start && start2 < end);
    }
    
    /**
     * The range of this set. This is a span starting at the
     * start of the first element and ending at the end of the
     * last element.
     */
    public Span range(){
        int size = size();
        
        if(size == 0){
            return null;
        }
        else{
            Span first = (Span) first();
            Span last = (Span) last();
            return new Span(first.getStart(), last.getEnd());
        }
    }
    
    public int getRangeStart(){
        return ((Span) first()).getStart();
    }
    
    public int getRangeEnd(){
        return ((Span) last()).getEnd();
    }
    
    
}
