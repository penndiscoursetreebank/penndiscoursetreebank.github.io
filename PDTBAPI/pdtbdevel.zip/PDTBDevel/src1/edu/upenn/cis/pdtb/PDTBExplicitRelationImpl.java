/*
 * PDTBRelationImpl.java
 *
 * Created on November 27, 2005, 2:06 PM
 */

package edu.upenn.cis.pdtb;

import java.util.Vector;
import java.io.Writer;
import java.io.IOException;
import edu.upenn.cis.pdtb.util.ArraySet;

/**
 * Implementation of the PDTBExplicitRelation interface.
 * @author nikhild
 */
public class PDTBExplicitRelationImpl extends PDTBRelationImpl implements PDTBExplicitRelation {
    
    private PDTBSelection fSel;
    
    private PDTBExplicitRelationFeatures fFeats;
    
    /** Creates a new instance of PDTBRelationImpl */
    public PDTBExplicitRelationImpl(PDTBSelection sel, PDTBExplicitRelationFeatures feats, 
    PDTBSup sup1, PDTBArg arg1, PDTBArg arg2, PDTBSup sup2) {
               super(sup1, arg1, arg2, sup2);
               
               fSel = sel;
               fSel.setPDTBNode(this);
               fFeats = feats;
               fFeats.setPDTBNode(this);
               
               pdtbSetName("", ExplicitRelationQName, ExplicitRelationQName);
               
    }
     
    protected void initAttributes(){
        fAttributes = new ArraySet(fAttributesComparator, 5);
        fFeats.updateAttributesOnNode();
        fSel.updateAttributesOnNode();
    }
    
    
    public PDTBExplicitRelationFeatures getFeatures() {
        return fFeats;
    }
    
    public void setFeatures(PDTBExplicitRelationFeatures feats) {
        if(fFeats != null){
            fFeats.setPDTBNode(null);
        }
        
        feats.setPDTBNode(this);
        
        fFeats = feats;
        fFeats.updateAttributesOnNode();
    }
    
    public void setSelection(PDTBSelection sel) {
        if(fSel != null){
            fSel.setPDTBNode(null);
        }
        
        fSel = sel;
        fSel.setPDTBNode(this);
        fSel.updateAttributesOnNode();
    }
    
    
    public PDTBSelection getSelection(){
        return fSel;
    }
    
    public void save(Writer writer) throws IOException{
        writer.write("________________________________________________________\n");
        writer.write("____Explicit____\n");
        
        ((PDTBSelectionImpl)fSel).save(writer);
        
        writer.write("#### Features ####\n");
        ((PDTBExplicitRelationFeaturesImpl)fFeats).save(writer);
        
        writer.write("##################\n");
        super.save(writer);
        writer.write("________________________________________________________\n");
        
    }
    
}
