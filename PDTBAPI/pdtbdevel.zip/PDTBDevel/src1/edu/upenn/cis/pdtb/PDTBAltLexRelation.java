/*
 * PDTBAltLexRelation.java
 *
 * Created on January 22, 2006, 8:13 PM
 */

package edu.upenn.cis.pdtb;

/**
 * An AltLexRelation represents a relation between adjacent sentences
 * predicated by something which is not a connective.
 * @author nikhild
 */
public interface PDTBAltLexRelation extends PDTBRelation{
    
    /**
     * Get the features
     */    
    public PDTBAltLexRelationFeatures getFeatures();
    
    /**
     * Set the features.
     */    
    public void setFeatures(PDTBAltLexRelationFeatures attribs);
    
    /**
     * Get the selection associated with the phrase establishing the relation.
     */    
    public PDTBSelection getSelection();
    
    /**
     * Set the selection correponding to the phrase establishing the relation.
     */    
    public void setSelection(PDTBSelection sel);
    
}
