/*
 * FileNoComboBoxModel.java
 *
 * Created on December 7, 2005, 7:24 PM
 */

package edu.upenn.cis.pdtb.graphics;

import java.util.LinkedList;
import javax.swing.ComboBoxModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import org.omg.CORBA.StringHolder;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.Font;

/**
 * ComboBoxModel representing the files that are present in a given section.
 * The section number is obtained by setting this as a listener on the
 * combo box for section numbers.
 *
 * @author  nikhild
 * @see SecNoComboBoxModel
 */
public class FontSizeComboBoxModel implements ComboBoxModel{
    private Vector fListeners = new Vector();
    
    private int[] fData = new int[30];
    
    private int fSelectedItem = 15;
    
    /** Creates a new instance of FileNoComboBoxModel */
    public FontSizeComboBoxModel() {
        for(int i = 0; i < 30; i++){
            fData[i] = i + 8;
        }
    }
    
    public void addListDataListener(ListDataListener listDataListener) {
        fListeners.add(listDataListener);
    }
    
    public Object getElementAt(int param) {
        return "" + fData[param];
    }
    
    public Object getSelectedItem() {
        return "" + fSelectedItem;
    }
    
    
    public int getSize() {
        return 30;
    }
    
    public void removeListDataListener(ListDataListener listDataListener) {
        fListeners.remove(listDataListener);
    }
    
    public void setSelectedItem(Object obj) {
        fSelectedItem = (new Integer((String)obj)).intValue();
        FontProvider fp  = FontProvider.PDTBBrowserFontProvider;
        fp.setCurrentFont(fp.getCurrentFont().deriveFont((float)fSelectedItem));
    }
    
        
    
}
