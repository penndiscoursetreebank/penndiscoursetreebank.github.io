/*
 * PDTBNodeSelectionListener.java
 *
 * Created on December 5, 2005, 10:38 PM
 */

package edu.upenn.cis.pdtb.graphics;

import edu.upenn.cis.pdtb.*;

/**
 * Listener which receives callbacks if a PDTBNode is selected. This is
 * implemented by the PTBPanel and WSJTextArea to paint the highlights when
 * a PDTBNode is selected. The callbacks are obtained from the 
 * TreeSelectionListenerImpl which listens on the JTree for selection events, 
 * synthesizes it into a high level event and notifies the PTBPanel and
 * WSJTextArea. The PTBPanel and WSJTextArea register separate TreeSelectionListenerImpls
 * on the JTree for the relations.
 *
 * @author  nikhild
 * @see TreeSelectionListenerImpl
 * 
 */
public interface PDTBNodeSelectionListener {
    
    public void implicitRelationSelected(PDTBImplicitRelation rel);
    
    public void explicitRelationSelected(PDTBExplicitRelation rel);
    
    public void altLexRelationSelected(PDTBAltLexRelation rel);
    
    public void entityRelationSelected(PDTBEntityRelation rel);
    
    public void noRelationSelected(PDTBNoRelation rel);
    
    public void arg1Selected(PDTBSup arg1);
    
    public void arg2Selected(PDTBSup arg2);
    
    public void sup1Selected(PDTBSup sup1);
    
    public void sup2Selected(PDTBSup sup2);
}
