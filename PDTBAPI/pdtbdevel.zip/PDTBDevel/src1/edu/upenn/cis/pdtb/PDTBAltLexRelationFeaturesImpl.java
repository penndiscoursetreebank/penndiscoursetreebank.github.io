/*
 * PDTBExplicitRelationFeaturesImpl.java
 *
 * Created on November 30, 2005, 7:30 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

/**
 * Implementation of the PDTBAltLexRelationFeatures interface.
 * @author nikhild
 */
public class PDTBAltLexRelationFeaturesImpl extends PDTBFeaturesImpl implements PDTBAltLexRelationFeatures {
    
    private String fSemanticClass;
    
    //private String fSense;
    
    /** Creates a new instance of PDTBExplicitRelationFeaturesImpl */
    public PDTBAltLexRelationFeaturesImpl(String source, String factuality, String polarity, String semanticClass) {
                   super(source, factuality, polarity);
                   //fSense = sense;
                   fSemanticClass = semanticClass;
                   
    }
    
    //public String getSense() {
      //  return "null";
    //}
    
    /**
     * Adds the semantic class attribute to the ownerNode
     */    
    public void updateAttributesOnNode(){
        getPDTBNode().pdtbSetAttribute("", SemanticClassAttributeQName, SemanticClassAttributeQName, "", fSemanticClass);
        //getPDTBNode().pdtbSetAttribute("", SenseAttributeQName, SenseAttributeQName, "", fSense);
        super.updateAttributesOnNode();
    }
    
    public String getSemanticClass() {
        return fSemanticClass;
    }
    
    public void save(Writer writer) throws IOException{
        super.save(writer);
        writer.write(fSemanticClass);
        writer.write('\n');
    }
    
}
