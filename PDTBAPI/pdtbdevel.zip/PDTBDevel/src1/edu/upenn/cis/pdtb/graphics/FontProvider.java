/*
 * FontProvider.java
 *
 * Created on February 17, 2006, 11:13 PM
 */

package edu.upenn.cis.pdtb.graphics;

import java.awt.Font;
import java.util.HashSet;
import java.util.Vector;
import java.util.Iterator;
import java.lang.ref.*;

/**
 * Provides the global font. Maintains only WeakReferences to the listeners
 * so that they can be garbage collected without an explicit remove notification.
 *
 * @author  nikhild
 */
public class FontProvider {
    
    private Font fCurrentFont = new Font(null, Font.PLAIN, 15);
        
    public HashSet fListeners = new HashSet();
    
    public static final FontProvider PDTBBrowserFontProvider = new FontProvider();
    
    private ReferenceQueue fQueue = new ReferenceQueue();
    
    /** Creates a new instance of FontProvider */
    public FontProvider() {
    }
    
    public void addListener(FontChangeListener l){
        cleanUp();
        fListeners.add(new WeakReference(l, fQueue));
    }
    
    private void cleanUp(){
        for(Reference r = fQueue.poll(); r != null; r = fQueue.poll()){
            fListeners.remove(r);
        }
    }
    
    public void removeListener(FontChangeListener l){
        cleanUp();
        Reference r = getReference(l);
        if(r != null){
            fListeners.remove(r);
        }
    }
    
    private Reference getReference(FontChangeListener l){
        for(Iterator iter = fListeners.iterator(); iter.hasNext();){
            Reference r = (Reference) iter.next();
            if(r.get() == l){
                return r;
            }
        }
        return null;
    }
    public Font getCurrentFont(){
        return fCurrentFont;
    }
    
    public void setCurrentFont(Font newFont){
        cleanUp();
        fCurrentFont = newFont;
        for(Iterator iter = fListeners.iterator(); iter.hasNext();){
            FontChangeListener l = (FontChangeListener)((Reference)iter.next()).get();
            if(l != null){
                l.fontChanged(newFont);
            }
        }
    }
    
    
}
