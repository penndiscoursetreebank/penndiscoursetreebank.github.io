/*
 * PDTBRelationImpl.java
 *
 * Created on November 27, 2005, 2:06 PM
 */

package edu.upenn.cis.pdtb;

import java.util.Vector;
import java.util.LinkedList;
import java.util.Enumeration;
import java.util.Iterator;
import javax.swing.tree.*;
import java.io.Writer;
import java.io.IOException;

/**
 *
 * @author  nikhild
 */
public abstract class PDTBRelationImpl extends PDTBNodeImpl implements PDTBRelation {
    
    
    /** Creates a new instance of PDTBRelationImpl */
    public PDTBRelationImpl(PDTBSup sup1, PDTBArg arg1, PDTBArg arg2, PDTBSup sup2) {
        pdtbAddFirstChild(arg1);
        pdtbAddLastChild(arg2);
        
        arg1.pdtbSetName("", Arg1QName, Arg1QName);
        arg2.pdtbSetName("", Arg2QName, Arg2QName);       
        
        if(sup1 != null){
            sup1.pdtbSetName("", Sup1QName, Sup1QName);
            pdtbAddFirstChild(sup1);
        }
        if(sup2 != null) {
            sup2.pdtbSetName("", Sup2QName, Sup2QName);
            pdtbAddLastChild(sup2); 
        }
        
    }
    
    
    
    public boolean getAllowsChildren() {
        return true;
    }
    
    public PDTBArg getArg1() {
        for(PDTBNode child = pdtbGetFirstChild(); child != null; child = child.pdtbGetNextSibling()){
            if(child instanceof PDTBArg){
                return (PDTBArg)child;
            }
        }
        
        return null;
    }
    
    public PDTBArg getArg2() {
        for(PDTBNode child = pdtbGetLastChild(); child != null; child = child.pdtbGetPreviousSibling()){
            if(child instanceof PDTBArg){
                return (PDTBArg)child;
            }
        }
       
       return null;
    }
    
    
    
    public void setArg1(PDTBArg arg1) {
        PDTBArg oldArg1 = getArg1();
        int index = getIndex(oldArg1);
        insert(arg1, index);
        oldArg1.removeFromParent();
        arg1.pdtbSetName("", Arg1QName, Arg1QName);
    }
    
    public void setArg2(PDTBArg arg2) {
        PDTBArg oldArg2 = getArg2();
        int index = getIndex(oldArg2);
        insert(arg2, index);
        oldArg2.removeFromParent();
        arg2.pdtbSetName("", Arg2QName, Arg2QName);
    }
    
    public PDTBSup getSup1() {
        PDTBNode child = pdtbGetFirstChild();
        if(!(child instanceof PDTBArg)){
           return (PDTBSup)(child);
        }
        else{
            return null;
        }
    }
    
    public PDTBSup getSup2() {
        PDTBNode child = pdtbGetLastChild();
        if(!(child instanceof PDTBArg)){
           return (PDTBSup)(child);
        }
        else{
            return null;
        }
    }
    
    
    
    public void setSup1(PDTBSup sup1) {
        PDTBSup oldSup1 = getSup1();
        if(oldSup1 != null){
            oldSup1.removeFromParent();
        }
        pdtbAddFirstChild(sup1);
        sup1.pdtbSetName("", Sup1QName, Sup1QName);
    }
    
    public void setSup2(PDTBSup sup2) {
        PDTBSup oldSup2 = getSup2();
        if(oldSup2 != null){
            oldSup2.removeFromParent();
        }
        
        pdtbAddLastChild(sup2);
        sup2.pdtbSetName("", Sup2QName, Sup2QName);
    }
    
    
    
    public void setRelationList(PDTBRelationList parent){
        setParent(parent);
    }
    
    public PDTBRelationList getRelationList(){
        return (PDTBRelationList)(getParent());
    }
    
    public void save(Writer writer) throws IOException {
        if(getSup1() != null){
            writer.write("____Sup1____\n");
            ((PDTBSupImpl)getSup1()).save(writer);
        }
        
        writer.write("____Arg1____\n");
        ((PDTBArgImpl)getArg1()).save(writer);
        
        writer.write("____Arg2____\n");
        ((PDTBArgImpl)getArg2()).save(writer);
        
        if(getSup2() != null){
            writer.write("____Sup2____\n");
            ((PDTBSupImpl)getSup2()).save(writer);
        }
        
        
    }    
    
}
