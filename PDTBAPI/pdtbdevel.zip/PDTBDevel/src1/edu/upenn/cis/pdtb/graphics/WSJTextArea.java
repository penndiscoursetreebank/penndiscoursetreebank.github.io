/*
 * WSJTextArea.java
 *
 * Created on December 7, 2005, 4:14 PM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import javax.swing.plaf.TextUI;
import edu.upenn.cis.pdtb.*;
import java.util.Iterator;

/**
 * The raw text corresponding to the discourse. Highlights the appropriate spans
 * when a PDTB node is selected, and scrolls to move the selection into the
 * center of the screen.
 *
 * @author  nikhild
 */
public class WSJTextArea extends JTextArea implements PDTBNodeSelectionListener, FontChangeListener{
    
    protected final WSJHighlightPainter ExplicitConnHighlightPainter = new WSJHighlightPainter(ColorConstants.ExplicitConnColor);
    
    protected final WSJHighlightPainter Arg1HighlightPainter = new WSJHighlightPainter(ColorConstants.Arg1Color);
    
    protected final WSJHighlightPainter Arg2HighlightPainter = new WSJHighlightPainter(ColorConstants.Arg2Color);
    
    protected final WSJHighlightPainter Sup1HighlightPainter = new WSJHighlightPainter(ColorConstants.Sup1Color);
    
    protected final WSJHighlightPainter Sup2HighlightPainter = new WSJHighlightPainter(ColorConstants.Sup2Color);
    
    
    /** Creates a new instance of WSJTextArea */
    public WSJTextArea(String text, JTree pdtbTree) {
        super(text);
        
        setFont(FontProvider.PDTBBrowserFontProvider.getCurrentFont());    
        FontProvider.PDTBBrowserFontProvider.addListener(this);
        
        setLineWrap(true);
        setWrapStyleWord(true);
        setMargin(new Insets(10,10,10,10));
        setEditable(false);
        TreeSelectionListenerImpl listener = new TreeSelectionListenerImpl();
        listener.add(this);
        pdtbTree.getSelectionModel().addTreeSelectionListener(listener);
    }
    
    protected void clearHighlights(){
        getHighlighter().removeAllHighlights();
    }
    
    protected void highlight(SpanList spans, Highlighter.HighlightPainter painter){
        for(Iterator iter = spans.iterator(); iter.hasNext();){
            Span s = (Span)(iter.next());
            try{
                getHighlighter().addHighlight(s.getStart(), s.getEnd(), painter);
            }catch(Exception e){
                
            }
        }
    }
    
    protected void highlight(PDTBNode node){
        if(node instanceof PDTBRelation){
            if(node instanceof PDTBExplicitRelation){
                PDTBExplicitRelation rel = (PDTBExplicitRelation)node;
                highlight(rel.getSelection().getSpans(), ExplicitConnHighlightPainter);
                
                PDTBSup arg1 = rel.getArg1();
                highlight(arg1.getSelection().getSpans(), Arg1HighlightPainter);
                
                PDTBSup arg2 = rel.getArg2();
                highlight(arg2.getSelection().getSpans(), Arg2HighlightPainter);
                
                PDTBSup sup1 = rel.getSup1();
                if(sup1 != null){
                    highlight(sup1.getSelection().getSpans(), Sup1HighlightPainter);
                }
                
                PDTBSup sup2 = rel.getSup2();
                if(sup2 != null){
                    highlight(sup2.getSelection().getSpans(), Sup2HighlightPainter);
                }
            }
            else if(node instanceof PDTBAltLexRelation){
                PDTBAltLexRelation rel = (PDTBAltLexRelation)node;
                highlight(rel.getSelection().getSpans(), ExplicitConnHighlightPainter);
                
                PDTBSup arg1 = rel.getArg1();
                highlight(arg1.getSelection().getSpans(), Arg1HighlightPainter);
                
                PDTBSup arg2 = rel.getArg2();
                highlight(arg2.getSelection().getSpans(), Arg2HighlightPainter);
                
                PDTBSup sup1 = rel.getSup1();
                if(sup1 != null){
                    highlight(sup1.getSelection().getSpans(), Sup1HighlightPainter);
                }
                
                PDTBSup sup2 = rel.getSup2();
                if(sup2 != null){
                    highlight(sup2.getSelection().getSpans(), Sup2HighlightPainter);
                }
            }
            else if(node instanceof PDTBImplicitRelation){
                PDTBImplicitRelation rel = (PDTBImplicitRelation)node;
                
                PDTBSup arg1 = rel.getArg1();
                highlight(arg1.getSelection().getSpans(), Arg1HighlightPainter);
                
                PDTBSup arg2 = rel.getArg2();
                highlight(arg2.getSelection().getSpans(), Arg2HighlightPainter);
                
                PDTBSup sup1 = rel.getSup1();
                if(sup1 != null){
                    highlight(sup1.getSelection().getSpans(), Sup1HighlightPainter);
                }
                
                PDTBSup sup2 = rel.getSup2();
                if(sup2 != null){
                    highlight(sup2.getSelection().getSpans(), Sup2HighlightPainter);
                }
            }
            
            
        }
        else{
            if(node instanceof PDTBEntityRelation){
                PDTBEntityRelation rel = (PDTBEntityRelation)node;
                
                PDTBSup arg1 = rel.getArg1();
                highlight(arg1.getSelection().getSpans(), Arg1HighlightPainter);
                
                PDTBSup arg2 = rel.getArg2();
                highlight(arg2.getSelection().getSpans(), Arg2HighlightPainter);
                
            }
            else if(node instanceof PDTBArg){
                
                if(node == ((PDTBRelation) node.getParent()).getArg1()){
                    highlight(((PDTBSup)node).getSelection().getSpans(), Arg1HighlightPainter);
                }
                else{
                    highlight(((PDTBSup)node).getSelection().getSpans(), Arg2HighlightPainter);
                }
                
            }
            else{
                PDTBNode parent = (PDTBNode)(node.getParent());
                if(parent instanceof PDTBRelation){
                    if(node == ((PDTBRelation) parent).getSup1()){
                        highlight(((PDTBSup)node).getSelection().getSpans(), Sup1HighlightPainter);
                    }
                    else{
                        highlight(((PDTBSup)node).getSelection().getSpans(), Sup2HighlightPainter);
                    }
                }
                else{
                    if(node == ((PDTBEntityRelation) parent).getArg1()){
                        highlight(((PDTBSup)node).getSelection().getSpans(), Arg1HighlightPainter);
                    }
                    else{
                        highlight(((PDTBSup)node).getSelection().getSpans(), Arg2HighlightPainter);
                    }
                }
            }
        }
    }
    
    protected void makeVisible(PDTBNode node){
        Span s = null;
        if(node instanceof PDTBSup){
            s = (Span)(((PDTBSup)node).getSelection().getSpans().first());
        }
        else{
            if(node instanceof PDTBExplicitRelation){
                s = (Span)(((PDTBExplicitRelation)node).getSelection().getSpans().first());
            }
            else if(node instanceof PDTBAltLexRelation){
                s = (Span)(((PDTBAltLexRelation)node).getSelection().getSpans().first());
            }
            else if(node instanceof PDTBImplicitRelation){
                s = (Span)(((PDTBImplicitRelation)node).getArg2().getSelection().getSpans().first());
            }
            else if (node instanceof PDTBEntityRelation){
                s = (Span)(((PDTBEntityRelation)node).getArg2().getSelection().getSpans().first());
            }
        }
        
        TextUI ui = getUI();
        try{
            Rectangle r = ui.modelToView(this, s.getStart());
            Rectangle v = getVisibleRect();
            
            
            r.height = (v.height/2);
            r.width = (v.width/2);
            
            int centerY = v.y + v.height/2;
            int diffY = r.y - centerY;
            r.y = ((diffY) > 0)? r.y : r.y - v.height/2;
            
            
            int centerX = v.x + v.width/2;
            int diffX = r.x - centerX;
            r.x = (diffX <= 0)? r.x - v.width/2 : r.x;
            
            if(r.x < 0){
                r.x = 0;
            }
            
            scrollRectToVisible(r);
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
    }

    protected void select(PDTBNode node){
        clearHighlights();
        highlight(node);
        makeVisible(node);
    }
    
    public void arg1Selected(PDTBSup arg1) {
        select(arg1);
    }
    
    public void arg2Selected(PDTBSup arg2) {
        select(arg2);
    }
    
    public void explicitRelationSelected(PDTBExplicitRelation rel) {
        select(rel);
    }
    
    public void sup1Selected(PDTBSup sup1) {
        select(sup1);
    }
    
    public void sup2Selected(PDTBSup sup2) {
        select(sup2);
    }
    
    public Dimension getPreferredScrollableViewportSize() {
        Dimension d = getPreferredSize();
        //return getPreferredSize();
        
        return new Dimension(((d.getWidth() > 100)? 100 : (int) (d.getWidth())),
        ((d.getHeight() > 100)? 100 : (int) (d.getHeight())));
    }
    
    public void altLexRelationSelected(PDTBAltLexRelation rel) {
        select(rel);
    }    
    
    public void implicitRelationSelected(PDTBImplicitRelation rel) {
        select(rel);
    }    
    
    public void entityRelationSelected(PDTBEntityRelation rel) {
        select(rel);
    }
    
    public void noRelationSelected(PDTBNoRelation rel) {
        select(rel);
    }
    
    public void fontChanged(Font newFont){
        setFont(newFont);
    }
    
    public class WSJHighlightPainter extends DefaultHighlighter.DefaultHighlightPainter{
        
        public WSJHighlightPainter(Color c){
            super(c);
        }
    }
    
}
