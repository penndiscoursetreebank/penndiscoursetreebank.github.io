/*
 * VTreeExpansionState.java
 *
 * Created on September 8, 2004, 1:08 PM
 */

package org.annotation.agschema.graphics.vtree;

import javax.swing.tree.TreeNode;
import java.beans.PropertyChangeListener;

/**
 * Maintains the state of expansion/collapse of the nodes in
 * a tree from the perspective of viewing.
 *
 * @author  nikhild
 */
public interface VTreeExpansionState extends PropertyChangeListener{
    
    /**
     * Add a listener to receive notification of events
     *
     * @param l the listener to add
     */
    public void addListener(VTreeExpansionListener l);
    
    /**
     * Remove the listener
     *
     * @param l the listener to remove
     */
    public void removeListener(VTreeExpansionListener l);
    
    /**
     * Get the root of the tree
     */
    public TreeNode getRoot();
    
    /**
     * Returns true iff the node is expanded
     */
    public boolean isExpanded(TreeNode node);
    
    /**
     * Returns true iff the node is collapsed
     */
    public boolean isCollapsed(TreeNode node);
    
    /**
     * Returns true iff an ancestor of the node is
     * collapsed. 
     */
    public boolean isHidden(TreeNode node);
    
    /**
     * Expands a node
     */
    public void expand(TreeNode node);
    
    /**
     * Collapses a node.
     */
    public void collapse(TreeNode node);
}
