/*
 * VTreeCanvasTest.java
 *
 * Created on September 23, 2004, 10:19 PM
 */

package org.annotation.agschema.graphics.vtree;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.border.*;

import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.Point;

import java.awt.event.*;

import java.util.Enumeration;
import edu.upenn.cis.ptb.*;

/**
 *
 * @author  nikhild
 */
public class VTreeCanvasTest {
    
    /** Creates a new instance of VTreeCanvasTest */
    public VTreeCanvasTest() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if(args.length != 1){
            System.err.println(
            "Usage: java org.annotation.agschema.graphics.vtree.VTreeCanvasTest <fileName>");
            System.exit(0);
        }
        
        try{
            PTBLoader loader = new PTBLoaderImpl();
            
            
            PTBTreeNode root = loader.load(args[0]);
            
            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(root.getChildCount(),1));
            
            MouseListener ms = (new MouseAdapter() {
                public void mouseClicked(MouseEvent e){
                    VTreeCanvas can = (VTreeCanvas)(e.getComponent());
                        Point p = e.getPoint();
                        PTBTreeNode node = (PTBTreeNode)(can.getNode((int)p.getX(), (int)p.getY()));
                        
                    if(e.getButton() == MouseEvent.BUTTON1){
                        if(node != null){
                            VTreeSelectionModel m = can.getSelectionModel();
                            m.clear();
                            m.add(node);
                        }
                    }
                    else{
                        if(node != null){
                            VTreeExpansionState es = can.getExpansionState();
                            if(es.isCollapsed(node)){
                                es.expand(node);
                            }
                            else{
                                es.collapse(node);
                            }
                        }
                    }
                }
            });
            
            for(Enumeration children = root.children();children.hasMoreElements();){
                PTBTreeNode child = (PTBTreeNode)(children.nextElement());
                VTreeCanvas c = new VTreeCanvas();
                c.setBorder(new EtchedBorder());
                c.setRoot(child);
                c.setCellRenderer(new VTreeCellRendererImpl());
                VTreeSelectionModel sm = new VTreeSelectionModelImpl(child);
                sm.setSelectionInterpretation(VTreeSelectionModel.SubtreeInterpretation);
                VTreeExpansionState es = new VTreeExpansionStateImpl(child);
                c.setSelectionModel(sm);
                c.setExpansionState(es);
                c.addMouseListener(ms);
                
                panel.add(c);
            }
            
            JViewport vp = new JViewport();
            vp.setView(panel);
            //vp.setPreferredSize(new Dimension(300,300));
            
            final JFrame frame = new JFrame();
            
            WindowListener wl = (new WindowAdapter() {
               public void windowClosing(WindowEvent e){
                   System.exit(0);
               }
               
               public void windowGainedFocus(WindowEvent e){
                   e.getWindow().repaint();
                   
               }
            });
            
            frame.getContentPane().setLayout(new GridLayout(1,1));
            frame.getContentPane().add(new JScrollPane(vp));
            frame.addWindowListener(wl);
            frame.setSize(300, 300);
            frame.pack();
            frame.show();
            
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    public class NodeSelector extends MouseAdapter{
        public NodeSelector(){
            
        }
        
        public void mouseClicked(MouseEvent e){
            
        }
    }
    
}
