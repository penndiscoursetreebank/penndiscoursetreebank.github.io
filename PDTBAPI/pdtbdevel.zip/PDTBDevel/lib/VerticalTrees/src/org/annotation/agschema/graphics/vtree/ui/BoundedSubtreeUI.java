/*
 * BoundedSubtreeUI.java
 *
 * Created on September 11, 2004, 12:16 AM
 */

package org.annotation.agschema.graphics.vtree.ui;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Component;
import java.awt.Insets;
import java.awt.geom.GeneralPath;
import java.awt.Graphics;
import java.awt.Graphics2D;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.util.Enumeration;
import java.util.Stack;
import java.util.Vector;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;

import javax.swing.JComponent;
import javax.swing.CellRendererPane;
import javax.swing.plaf.ComponentUI;

import org.omg.CORBA.IntHolder;
import org.annotation.agschema.graphics.vtree.*;

/**
 * <p>
 * This UI draws each subtree in its own rectangle. The size of the
 * rectangle is proportional to the number of leaves in the subtree, so the 
 * leaves appear evenly spaced. This implementation is optimized for speed, and
 * uses memory proportional to the size of the tree being drawn. 
 * </p>
 *
 * <p>
 *
 * TODO - Make a memory efficient counterpart to this.
 *
 * </p>
 *
 * @author  nikhild
 */
public class BoundedSubtreeUI extends VTreeUI 
implements PropertyChangeListener, TreeMutationListener, VTreeExpansionListener, VTreeSelectionListener{
    
    private VTreeCanvas canvas = null;
    
    private TreeNode root = null;
    
    private TreeMutationSupport mutationSupport = null;
    
    private VTreeExpansionState expansionState = null;
    
    private VTreeSelectionModel selectionModel = null;
    
    private VTreeCellRenderer cellRenderer = null;
    
    private BoundsTreeNode nodeDimensionRoot = null;
    
    private CellRendererPane rendererPane = new CellRendererPane();
    
    private final PaintingInfoPool pInfoPool = new PaintingInfoPool();
    
    
    /** Creates a new instance of BoundedSubtreeUI */
    public BoundedSubtreeUI() {
        super();
    }
    
    public static ComponentUI createUI(JComponent c){
        BoundedSubtreeUI ui = new BoundedSubtreeUI();
        ui.installUI(c);
        return ui;
    }
    
    /*
     * Get the coordinates for the node
     *
     * @param node the node
     * @return the rectangle representing the space in which the node is 
     * drawn.
     *
     */
    public Rectangle getNodeLocation(TreeNode node){
        if(!(canvas.isShowing())){
            return null;
        }
        //The canvas is showing
        
        Stack address = getAddress(node);
        double x = 0;
        double y = 0;
        
        //Attempt to get the bounds node corresponding to this node
        //and adjust the x and y coordinates to point to the rectangle
        //bounding the subtree dominated by the node
        BoundsTreeNode currentNode = nodeDimensionRoot;
        while(!(address.isEmpty()) && !(currentNode.isPaintingLeaf())){
            //Address is not empty, so the currentNode is an ancestor
            
            NodeBoundsInfo cBounds = currentNode.getBounds();
            
            //Nodes at depth d all have the same y coordinate i.e.,
            //the difference between the y coord of a parent and a child
            //is height req to draw a node plus the height again which is
            //the space left between them.
            
            y += (2 * cBounds.getNodePreferredSize().getHeight());
            
            // x coordinate where the children start.
            x += ((cBounds.getSubtreeSize().getWidth() - cBounds.getChildrenWidth())/2);
            
            //Adjust the x coord to the start of the appropriate child
            //and currentNode is the appropriate child
            int childIndex = ((IntHolder)(address.pop())).value;
            
            Enumeration children = currentNode.children();
            for(int i = 0; i < childIndex; i++){
                currentNode = (BoundsTreeNode)(children.nextElement());
                NodeBoundsInfo iBounds = currentNode.getBounds();
                x += iBounds.getSubtreeSize().getWidth();
            }
            currentNode = (BoundsTreeNode)(children.nextElement());
        }
        
        //Move the x coordinate to the left of the node rectangle
        //y coordinate is fine.
        NodeBoundsInfo bounds = currentNode.getBounds();
        Dimension subtreeDim = bounds.getSubtreeSize();
        double subtreeWidth = subtreeDim.getWidth();
        double subtreeHeight = subtreeDim.getHeight();
        
        Dimension nodeDim = bounds.getNodePreferredSize();
        double nodeWidth = nodeDim.getWidth();
        double nodeHeight = nodeDim.getHeight();
        
        x += ((bounds.getSubtreeSize().getWidth() - nodeWidth)/2);
        
        //Adjust the coordinates to absolute coordinates
        Insets insets = (canvas.getBorder() != null) ? canvas.getBorder().getBorderInsets(canvas) : new Insets(0,0,0,0);
        
        x += insets.left;
        y += insets.top;
        
        return new Rectangle((int)x, (int)y, (int)(subtreeWidth), (int)(subtreeHeight));
    }
    
    /*
     * Get the coordinates for the subtree dominated by the node
     *
     * @param node the node
     * @return the rectangle representing the space in which the subtree is 
     * drawn.
     *
     */
    public Rectangle getSubtreeLocation(TreeNode node){
        if(!(canvas.isShowing())){
            return null;
        }
        
        //The canvas is showing
        
        Stack address = getAddress(node);
        double x = 0;
        double y = 0;
        
        
        //Attempt to get the bounds node corresponding to this node
        //and adjust the x and y coordinates to point to the rectangle
        //bounding the subtree dominated by the node
        BoundsTreeNode currentNode = nodeDimensionRoot;
        while(!(address.isEmpty())){
            //Address is not empty, so the currentNode is an ancestor
            
            //If the ancestor is collapsed, then it has no location
            
            if(currentNode.isPaintingLeaf()){
                return null;
            }
            
            //Ancestor is expanded
            
            NodeBoundsInfo cBounds = currentNode.getBounds();
            
            //Nodes at depth d all have the same y coordinate i.e.,
            //the difference between the y coord of a parent and a child
            //is height req to draw a node plus the height again which is
            //the space left between them.
            y += (2 * cBounds.getNodePreferredSize().getHeight());
            
            //x coordinate where the children start
            x += (cBounds.getSubtreeSize().getWidth() - cBounds.getChildrenWidth())/2;
            
            //Adjust the x coord to the start of the appropriate child
            //and currentNode is the appropriate child
            
            int childIndex = ((IntHolder)(address.pop())).value;
            Enumeration children = currentNode.children();
            for(int i = 0; i < childIndex; i++){
                currentNode = (BoundsTreeNode)(children.nextElement());
                NodeBoundsInfo iBounds = currentNode.getBounds();
                x += iBounds.getSubtreeSize().getWidth();
            }
        }
        
        //Move the x coordinate to the left of the node rectangle
        //y coordinate is fine.
        
        NodeBoundsInfo bounds = currentNode.getBounds();
        Dimension subtreeDim = bounds.getSubtreeSize();
        double subtreeWidth = subtreeDim.getWidth();
        double subtreeHeight = subtreeDim.getHeight();
        
        x += ((subtreeWidth - bounds.getNodePreferredSize().getWidth())/2);
        
        //Move the coordinates to absolute coordinates
        Insets insets = (canvas.getBorder() != null) ? canvas.getBorder().getBorderInsets(canvas) : new Insets(0,0,0,0);
        
        x += insets.left;
        y += insets.top;
        
        return new Rectangle((int)x, (int)y, (int)(subtreeWidth), (int)(subtreeHeight));
    }
    
    public TreeNode getNode(int x, int y){
        if(!(canvas.isShowing())){
            return null;
        }
        
        Insets insets = (canvas.getBorder() != null) ? canvas.getBorder().getBorderInsets(canvas) : new Insets(0,0,0,0);
        
        x -= insets.left;
        y -= insets.top;
        
        NodeBoundsInfo bInfo = (NodeBoundsInfo)(nodeDimensionRoot.getUserObject());
        Dimension subtreeBounds = bInfo.getSubtreeSize();
        Dimension nodeBounds = bInfo.getSubtreeSize();
        
        if(x - subtreeBounds.getWidth() <= 0){
            return getNode(root, nodeDimensionRoot, (double)x, (double)y, true);
        }
        
        
        return null;
    }
    
    /*
     * Get the node corresponding to the location.
     *
     * @param node the node
     *
     * @param dimensionsNode the node in the bounds tree corresponding to this node
     *
     * @param x the relative x coordinate
     *
     * @param y the relative y coordinate
     *
     * @param exact if true returns a node only if the component corresponding to
     * that node covers (x,y). Otherwise it returns the node closest to (x,y)
     *
     * @return the node if one exists null otherwise
     */
    private TreeNode getNode(TreeNode node, BoundsTreeNode dimensionsNode, double x, double y, boolean exact){
        NodeBoundsInfo bInfo = dimensionsNode.getBounds();
        Dimension subtreeBounds = bInfo.getSubtreeSize();
        Dimension nodeBounds = bInfo.getNodePreferredSize();
        
        double subtreeWidth = subtreeBounds.getWidth();
        double subtreeHeight = subtreeBounds.getHeight();
        
        double nodeWidth = nodeBounds.getWidth();
        double nodeHeight = nodeBounds.getHeight();
        
        double childrenWidth = bInfo.getChildrenWidth();
        
        boolean xOk = ((x - (subtreeWidth-nodeWidth)/2) >= 0 
        && ((x - (subtreeWidth-nodeWidth)/2 - nodeWidth) <= 0 || !exact));
        
        boolean yOk = ((y - nodeHeight) <= 0 && (y >=0 || !exact));
        
        if(xOk && yOk){
            return node;
        }
        
        if(node.isLeaf()){
            return (exact)? null : node;
        }
       
        x -= ((subtreeWidth - childrenWidth)/2);
        y -= (nodeHeight * 2);
        
        if(!(dimensionsNode.isPaintingLeaf()) && x > 0 && y > 0){
            Enumeration children = node.children();
            Enumeration boundsChildren = dimensionsNode.children();
            
            while(children.hasMoreElements()){
                TreeNode child = (TreeNode)(children.nextElement());
                BoundsTreeNode boundsChild = (BoundsTreeNode)(boundsChildren.nextElement());
                NodeBoundsInfo cInfo = boundsChild.getBounds();
                Dimension childSubtreeBounds = cInfo.getSubtreeSize();
                Dimension childNodeBounds = cInfo.getNodePreferredSize();
                
                if(x - childSubtreeBounds.getWidth() <= 0){
                    return getNode(child, boundsChild, x, y, exact);
                }

                x -= childSubtreeBounds.getWidth();
            }
        }
        
        return (exact)? null : node;
    }
    
    private void computeLocalBounds(BoundsTreeNode dimensionsNode, TreeNode node){
        NodeBoundsInfo bInfo = dimensionsNode.getBounds();
        boolean isSelected = (selectionModel == null)? false : selectionModel.isNodeSelected(node);
        boolean isExpanded = (expansionState == null)? true : expansionState.isExpanded(node);
        boolean hasFocus = false;
        boolean isLeaf = node.isLeaf();
        
        Dimension nodeBounds = cellRenderer.getTreeCellRendererComponent(canvas, node, isSelected, hasFocus, isLeaf, isExpanded).getPreferredSize();
        bInfo.setNodePreferredSize(nodeBounds.getWidth(), nodeBounds.getHeight());
        
        double subtreeWidth = 0.;
        double subtreeHeight = 0.;
        
        if(!(dimensionsNode.isPaintingLeaf())){
            Enumeration boundsChildren = dimensionsNode.children();
            while(boundsChildren.hasMoreElements()){
                BoundsTreeNode childBounds = (BoundsTreeNode)(boundsChildren.nextElement());
                NodeBoundsInfo childBInfo = childBounds.getBounds();
                
                Dimension childSubtreeBounds = childBInfo.getSubtreeSize();
                subtreeWidth += childSubtreeBounds.getWidth();
                subtreeHeight = Math.max(subtreeHeight,childSubtreeBounds.getHeight());
            }
        }
        
        bInfo.setChildrenWidth(subtreeWidth);
        
        double nodeWidth = nodeBounds.getWidth();
        double nodeHeight = nodeBounds.getHeight();
        
        
        subtreeWidth += (subtreeWidth > nodeWidth)? 0. : nodeWidth + 10.;
        subtreeHeight += (dimensionsNode.isPaintingLeaf())? nodeHeight : 2 * nodeHeight;
        bInfo.setSubtreeSize(subtreeWidth, subtreeHeight);
    }
    
    private void computeBounds(TreeNode node, BoundsTreeNode dimensionsNode){
        boolean isExpanded = (expansionState == null)? true : expansionState.isExpanded(node);
        dimensionsNode.setIsPaintingLeaf(!(isExpanded));
        
        if(dimensionsNode.isPaintingLeaf()){
            computeLocalBounds(dimensionsNode, node);
        }
        else{
            Enumeration children = node.children();
            Enumeration boundsChildren = dimensionsNode.children();
            while(children.hasMoreElements()){
                TreeNode child = (TreeNode)(children.nextElement());
                BoundsTreeNode bChild = (BoundsTreeNode)(boundsChildren.nextElement());
                computeBounds(child, bChild);
            }
            
            computeLocalBounds(dimensionsNode, node);
        }
        
    }
    
    private void fixBoundsToRoot(TreeNode node, BoundsTreeNode nodeBounds){
        computeLocalBounds(nodeBounds, node);
        if(node == root){
            return;
        }
        else{
            fixBoundsToRoot(node.getParent(), (BoundsTreeNode)(nodeBounds.getParent()));
        }
    }
    
    private BoundsTreeNode allocateBoundsTreeNode(TreeNode node){
        BoundsTreeNode bNode = new BoundsTreeNode(new NodeBoundsInfo());
        Enumeration children = node.children();
        while(children.hasMoreElements()){
            TreeNode child = (TreeNode)(children.nextElement());
            bNode.add(allocateBoundsTreeNode(child));
        }
        return bNode;
    }
    
    private TreeNode getNodeForAddress(TreeNode root, Stack address){
        TreeNode currentNode = root;
        while(!(address.isEmpty())){
            int index = ((IntHolder)(address.pop())).value;
            currentNode = currentNode.getChildAt(index);
        }
        return currentNode;
    }
    
    private Stack getAddress(TreeNode node){
        Stack result = new Stack();
        while(node != root){
            TreeNode parent = node.getParent();
            IntHolder index = new IntHolder(parent.getIndex(node));
            result.push(index);
            node = parent;  
        }
        return result;
    }
    
    public void paint(Graphics g, JComponent component){
        if(canvas != component) throw(new IllegalArgumentException("Wrong component"));
        Graphics2D g2d = (Graphics2D)g;
        Rectangle clip = g2d.getClipBounds();
        
        if(canvas.isOpaque()){
            g2d.setColor(canvas.getBackground());
            g2d.fillRect((int)(clip.getX()), (int)(clip.getY()), (int)(clip.getWidth()), (int)(clip.getHeight()));
        }
        
        g2d.setColor(canvas.getForeground());
        
        Insets insets = (canvas.getBorder() != null) ? canvas.getBorder().getBorderInsets(canvas) : new Insets(0,0,0,0);
        Point topLeft = new Point(insets.left, insets.top);
        
        if(nodeDimensionRoot != null){
            paintTree(g2d, clip, root, nodeDimensionRoot, topLeft);
        }
    }
    
    private void paintTree(Graphics2D g, Rectangle clip, TreeNode node, BoundsTreeNode dimensionsNode, Point topLeft){
        PaintingInfo pInfo = pInfoPool.newPaintingInfo(node, dimensionsNode, topLeft);
        
        Rectangle nodeRect = pInfo.getNodeRectangle();
        if(nodeRect.intersects(clip)){
            //paint the node
            boolean isSelected = (selectionModel == null)? false : selectionModel.isNodeSelected(node);
            boolean isExpanded = (expansionState == null)? true : expansionState.isExpanded(node);
            boolean hasFocus = false;
            boolean isLeaf = node.isLeaf();
            
            Component nodeComponent = cellRenderer.getTreeCellRendererComponent(canvas, node, isSelected, hasFocus, isLeaf, isExpanded);
            
            rendererPane.paintComponent(g, nodeComponent, canvas, (int)(nodeRect.getX()), (int)(nodeRect.getY()), (int)(nodeRect.getWidth()), (int)(nodeRect.getHeight()));
        }
        
        if(!(dimensionsNode.isPaintingLeaf())){
            GeneralPath linesToChildren = pInfo.getLinesToChildren();
            if(linesToChildren.intersects(clip)){
                //paint the path
                g.draw(linesToChildren);
            }
        }
        
        Rectangle subtreeRect = pInfo.getSubtreeRectangle();
        if(!(dimensionsNode.isPaintingLeaf()) && subtreeRect.intersects(clip)){
            Enumeration children = node.children();
            Enumeration dChildren = dimensionsNode.children();
            double childX = subtreeRect.getX();
            double childY = subtreeRect.getY();
            pInfoPool.returnPaintingInfo(pInfo);
            
            while(dChildren.hasMoreElements()){
                TreeNode child = (TreeNode)(children.nextElement());
                BoundsTreeNode dimensionsChild = (BoundsTreeNode)(dChildren.nextElement());
                NodeBoundsInfo cInfo = (NodeBoundsInfo)(dimensionsChild.getUserObject());
                topLeft.setLocation(childX, childY);
                paintTree(g, clip, child, dimensionsChild, topLeft);
                childX += cInfo.getSubtreeSize().getWidth();
            }
        }
    }
    
    public Dimension getPreferredSize(JComponent c){
        if(canvas != c) throw(new IllegalArgumentException("Wrong canvas"));
        Insets insets = (canvas.getBorder() != null) ? canvas.getBorder().getBorderInsets(canvas) : new Insets(0,0,0,0);
        NodeBoundsInfo bInfo = (nodeDimensionRoot != null)? nodeDimensionRoot.getBounds() : null;
        Dimension subtreeSize = (bInfo != null)? bInfo.getSubtreeSize() : new Dimension(0,0);
        return new Dimension((int)subtreeSize.getWidth() + insets.left + insets.right, (int)subtreeSize.getHeight() + insets.top + insets.bottom);
    }
    
    public Dimension getMinimumSize(JComponent c){
        return new Dimension(300,300); 
    }
    
    public Dimension getMaximumSize(JComponent c){
        return getPreferredSize(c);
    }
    
    
    public void installUI(JComponent c){
        if(!(c instanceof VTreeCanvas)){
            throw(new IllegalArgumentException("VTreeCanvas expected."));
        }
        
        canvas = (VTreeCanvas)c;
        canvas.addPropertyChangeListener(this);
        root = canvas.getRoot();
        
        mutationSupport = canvas.getMutationSupport();
        if(mutationSupport != null) mutationSupport.addListener(this);
        
        expansionState = canvas.getExpansionState();
        if(expansionState != null) expansionState.addListener(this);
        
        
        selectionModel = canvas.getSelectionModel();
        if(selectionModel != null) selectionModel.addListener(this);
        
        cellRenderer = canvas.getCellRenderer();
        
        if(root != null && cellRenderer != null){
            nodeDimensionRoot = allocateBoundsTreeNode(root);
            computeBounds(root, nodeDimensionRoot);
        }
    }
    
    public void uninstallUI(JComponent c){
        if(c != canvas) throw(new IllegalArgumentException("Wrong component"));
        
        canvas.removePropertyChangeListener(this);
        if(mutationSupport != null) mutationSupport.removeListener(this);
        if(expansionState != null) expansionState.removeListener(this);
        if(selectionModel != null) selectionModel.removeListener(this);
    }
    
    
    public void propertyChange(PropertyChangeEvent evt) {
        String name = evt.getPropertyName();
        
        if(name.equals(VTreeCanvas.TreeRootProperty)){
            root = (TreeNode)(evt.getNewValue());
            
            if(root != null && cellRenderer != null){
                nodeDimensionRoot = allocateBoundsTreeNode(root);
                computeBounds(root, nodeDimensionRoot);
            }
            else if(root == null){
                nodeDimensionRoot = null;
            }
            
        }else if(name.equals(VTreeCanvas.TreeMutationSupportProperty)){
            if(mutationSupport != null) mutationSupport.removeListener(this);
            mutationSupport = (TreeMutationSupport)(evt.getNewValue());
            if(mutationSupport != null) mutationSupport.addListener(this);
            
        }else if(name.equals(VTreeCanvas.SelectionModelProperty)){
            if(selectionModel != null) selectionModel.removeListener(this);
            selectionModel = (VTreeSelectionModel)(evt.getNewValue());
            if(selectionModel != null) selectionModel.addListener(this);
            
        }else if(name.equals(VTreeCanvas.ExpansionStateProperty)){
            if(expansionState != null) expansionState.removeListener(this);
            expansionState = (VTreeExpansionState)(evt.getNewValue());
            if(expansionState != null) expansionState.addListener(this);
            if(root != null && cellRenderer != null) computeBounds(root, nodeDimensionRoot);
        }else if(name.equals(VTreeCanvas.CellRendererProperty)){
            cellRenderer = (VTreeCellRenderer)(evt.getNewValue());
            
            if(root != null && cellRenderer != null){
                nodeDimensionRoot = allocateBoundsTreeNode(root);
                computeBounds(root, nodeDimensionRoot);
            }
            
        }
        
    }
    
    public void childAdded(MutableTreeNode parent, int index) {
        TreeNode child = parent.getChildAt(index);
        BoundsTreeNode bChild = allocateBoundsTreeNode(child);
        computeBounds(child, bChild);
        
        BoundsTreeNode pBounds = (BoundsTreeNode)(getNodeForAddress(nodeDimensionRoot, getAddress(parent)));
        pBounds.insert(bChild, index);
        fixBoundsToRoot(parent, pBounds);
    }
    
    public void childRemoved(MutableTreeNode parent, MutableTreeNode child, int oldChildIndex) {
        BoundsTreeNode pBounds = (BoundsTreeNode)(getNodeForAddress(nodeDimensionRoot, getAddress(parent)));
        pBounds.remove(oldChildIndex);
        fixBoundsToRoot(parent, pBounds);
    }
    
    public void subtreeDamaged(MutableTreeNode subtreeRoot) {
        if(subtreeRoot == root){
            nodeDimensionRoot = allocateBoundsTreeNode(root);
            computeBounds(root, nodeDimensionRoot);
        }
        else{
            TreeNode parent = subtreeRoot.getParent();
            int indexInParent = subtreeRoot.getParent().getIndex(subtreeRoot);
            BoundsTreeNode pBounds = (BoundsTreeNode)(getNodeForAddress(nodeDimensionRoot, getAddress(parent)));
            pBounds.remove(indexInParent);
            childAdded((MutableTreeNode)parent, indexInParent);
        }
    }
    
    public void nodeObjectChanged(MutableTreeNode node, Object oldUserObject) {
        BoundsTreeNode nBounds = (BoundsTreeNode)(getNodeForAddress(nodeDimensionRoot, getAddress(node)));
        boolean isSelected = (selectionModel == null)? false : selectionModel.isNodeSelected(node);
        boolean isExpanded = (expansionState == null)? true : expansionState.isExpanded(node);
        boolean hasFocus = false;
        boolean isLeaf = node.isLeaf();
        Dimension nodeBounds = cellRenderer.getTreeCellRendererComponent(canvas, node, isSelected, hasFocus, isLeaf, isExpanded).getPreferredSize();
        if(!(nBounds.getBounds().getNodePreferredSize().equals(nodeBounds))){
            fixBoundsToRoot(node, nBounds);
        }
    }
    
    
    public void nodeCollapsed(VTreeExpansionState state, TreeNode node) {
        Dimension oldSize = getPreferredSize(canvas);
        BoundsTreeNode nBounds = (BoundsTreeNode)(getNodeForAddress(nodeDimensionRoot, getAddress(node)));
        computeBounds(node, nBounds);
        fixBoundsToRoot(node, nBounds);
        canvas.revalidate();
        if(canvas.isShowing()){
            canvas.repaint();
        }
    }
    
    public void nodeExpanded(VTreeExpansionState state, TreeNode node) {
        BoundsTreeNode nBounds = (BoundsTreeNode)(getNodeForAddress(nodeDimensionRoot, getAddress(node)));
        computeBounds(node, nBounds);
        fixBoundsToRoot(node, nBounds);
        canvas.revalidate();
        if(canvas.isShowing()){
           canvas.repaint();
        }
        
    }
    
    public void nodeAdded(VTreeSelectionModel model, TreeNode node) {
        if(canvas.isShowing()){
            Rectangle location = null;
            if(model.getSelectionInterpretation() == VTreeSelectionModel.SubtreeInterpretation){
                location = getSubtreeLocation(node);
            }
            else{
                location = getNodeLocation(node);
            }
            canvas.revalidate();
            canvas.repaint((int)(location.getX()), (int)(location.getY()), (int)(location.getWidth()), (int)(location.getHeight()));
        }
    }
    
    public void nodeRemoved(VTreeSelectionModel model, TreeNode node) {
        if(canvas.isShowing()){
            Rectangle location = null;
            if(model.getSelectionInterpretation() == VTreeSelectionModel.SubtreeInterpretation){
                location = getSubtreeLocation(node);
            }
            else{
                location = getNodeLocation(node);
            }
            canvas.revalidate();
            canvas.repaint((int)(location.getX()), (int)(location.getY()), (int)(location.getWidth()), (int)(location.getHeight()));
        }
    }
    
    
    public void selectionCleared(VTreeSelectionModel model) {
        if(canvas.isShowing()) canvas.repaint();
    }
    
    public void selectionInterpretationChanged(VTreeSelectionModel model, int oldInterpretation) {
        if(canvas.isShowing()) canvas.repaint();
    }
    
    public void selectionModeChanged(VTreeSelectionModel model, int oldMode) {
        if(canvas.isShowing()) canvas.repaint();
    }
    
    public void rootChanged(TreeNode newRoot, TreeNode oldRoot) {
    }
    
    public class PaintingInfoPool{
        private Stack pool = new Stack();
        
        public PaintingInfoPool(){
            
        }
        
        public PaintingInfo newPaintingInfo(TreeNode node, DefaultMutableTreeNode dimensionsNode, Point topLeft){
            if(!(pool.isEmpty())){
                PaintingInfo pInfo = (PaintingInfo)(pool.pop());
                pInfo.setInfo(node, dimensionsNode, topLeft);
                
                return pInfo;
            }
            
            return new PaintingInfo(node, dimensionsNode, topLeft);
        }
        
        public void returnPaintingInfo(PaintingInfo pInfo){
            pool.push(pInfo);
        }
    }
    
    public class PaintingInfo{
        private TreeNode node;
        
        private DefaultMutableTreeNode dimensionsNode;
        
        private Point topLeft;
        
        private GeneralPath linesToChildren = new GeneralPath();
        
        private Rectangle nodeRectangle = new Rectangle();
        
        private Rectangle subtreeRectangle = new Rectangle();
        
        private boolean isPaintingLeaf = false;
        
        public PaintingInfo(TreeNode node, DefaultMutableTreeNode dimensionsNode, Point topLeft){
            setInfo(node, dimensionsNode, topLeft);
        }
        
        public TreeNode getNode(){
            return node;
        }
        
        public Rectangle getNodeRectangle(){
            return nodeRectangle;
        }
        
        public GeneralPath getLinesToChildren(){
            return linesToChildren;
        }
        
        public Rectangle getSubtreeRectangle(){
            return subtreeRectangle;
        }
        
        public boolean isPaintingLeaf(){
            return isPaintingLeaf;
        }
        
        public void setInfo(TreeNode node, DefaultMutableTreeNode dimensionsNode, Point topLeft){
            this.node = node;
            
            isPaintingLeaf = dimensionsNode.isLeaf();
            
            NodeBoundsInfo bInfo = (NodeBoundsInfo)(dimensionsNode.getUserObject());
            Dimension subtreeDim = bInfo.getSubtreeSize();
            double subtreeWidth = subtreeDim.getWidth();
            double subtreeHeight = subtreeDim.getHeight();
            
            Dimension nodeDim = bInfo.getNodePreferredSize();
            double nodeWidth = nodeDim.getWidth();
            double nodeHeight = nodeDim.getHeight();
            
            double tlX = topLeft.getX();
            double tlY = topLeft.getY();
            
            double nodeX = tlX + ((subtreeWidth - nodeWidth)/2);
            double nodeY = tlY;
            
            nodeRectangle.setRect(nodeX, nodeY, nodeWidth, nodeHeight);
            
            double pathOrigX = nodeX + nodeWidth/2;
            double pathOrigY = nodeY + nodeHeight;
            
            linesToChildren.reset();
            
            Enumeration children = dimensionsNode.children();
            double childrenWidth = bInfo.getChildrenWidth();
            double cTlX = tlX + (subtreeWidth - childrenWidth)/2.;
            double cTlY = tlY + (2 * nodeHeight);
            double subtreeRectWidth = 0.;
            
            while(children.hasMoreElements()){
                DefaultMutableTreeNode childDimNode = (DefaultMutableTreeNode)(children.nextElement());
                NodeBoundsInfo cInfo = (NodeBoundsInfo)(childDimNode.getUserObject());
                
                Dimension cSubtreeDim = cInfo.getSubtreeSize();
                double cSubtreeWidth = cSubtreeDim.getWidth();
                double cSubtreeHeight = cSubtreeDim.getHeight();
                
                Dimension cNodeDim = cInfo.getNodePreferredSize();
                double cNodeWidth = cSubtreeDim.getWidth();
                double cNodeHeight = cSubtreeDim.getHeight();
                
                double lineEndX = cTlX + ((cSubtreeWidth - cNodeWidth)/2) + cNodeWidth/2;
                double lineEndY = cTlY;
                
                linesToChildren.moveTo((float)pathOrigX, (float)pathOrigY);
                linesToChildren.lineTo((float)lineEndX, (float)lineEndY);
                
                cTlX += cSubtreeWidth;
                subtreeRectWidth += cSubtreeWidth;
            }
            
            double subtreeRectHeight = (dimensionsNode.isLeaf())? 0 : subtreeHeight - (2 * nodeHeight);
            
            double subtreeRectX = tlX + (subtreeWidth - childrenWidth)/2.;
            double subtreeRectY = tlY + (2 * nodeHeight);
            
            subtreeRectangle.setRect(subtreeRectX, subtreeRectY, subtreeRectWidth, subtreeRectHeight);
        }
    }
    
    public class NodeBoundsInfo{
        private Dimension nodePreferredSize = new Dimension();
        
        private Dimension subtreeSize = new Dimension();
        
        private double childrenWidth;
        
        public NodeBoundsInfo(){
            
        }
        
        public Dimension getNodePreferredSize(){
            return nodePreferredSize;
        }
        
        public void setNodePreferredSize(double width, double height){
            nodePreferredSize.setSize(width, height);
        }
        
        public Dimension getSubtreeSize(){
            return subtreeSize;
        }
        
        public void setSubtreeSize(double width, double height){
            subtreeSize.setSize(width, height);
        }
        
        public double getChildrenWidth(){
            return childrenWidth;
        }
        
        public void setChildrenWidth(double cWidth){
            childrenWidth = cWidth;
        }
    }
    
    public class BoundsTreeNode extends DefaultMutableTreeNode{
        
        private boolean isPaintingLeaf = false;
        
        public BoundsTreeNode(NodeBoundsInfo info){
            super(info);
        }
        
        public void setIsPaintingLeaf(boolean isLeaf){
            this.isPaintingLeaf = isLeaf;
        }
        
        public boolean isPaintingLeaf(){
            return isLeaf() || isPaintingLeaf;
        }
        
        public NodeBoundsInfo getBounds(){
            return (NodeBoundsInfo)getUserObject();
        }
    }
}
