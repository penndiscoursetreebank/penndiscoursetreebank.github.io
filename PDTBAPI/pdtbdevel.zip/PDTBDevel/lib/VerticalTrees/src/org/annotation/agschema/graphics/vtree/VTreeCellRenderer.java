/*
 * VTreeCellRenderer.java
 *
 * Created on September 7, 2004, 11:40 AM
 */

package org.annotation.agschema.graphics.vtree;

import java.awt.Component;
import javax.swing.tree.TreeNode;

/**
 * Similar to the CellRenderer in the javax.swing.tree package. Gives
 * a component which will paint the node. Note that all nodes may use the
 * same component, because it is not really added to the VTreeCanvas. The canvas
 * just asks it to paint itself in the appropriate position. As a result, you may not
 * want to set listeners on this component.
 * 
 * This method will be messaged before each node is painted, so that the 
 * component can be updated. If the size of a node changes, with no corresponding 
 * mutation event, then a fake mutation event correponding to nodeObject changed 
 * should be passed to the canvas.
 *
 * @author  nikhild
 */
public interface VTreeCellRenderer {
    
    public Component getTreeCellRendererComponent(VTreeCanvas vTree, TreeNode node, boolean isSelected,
    boolean hasFocus, boolean isLeaf, boolean isExpanded);
}
