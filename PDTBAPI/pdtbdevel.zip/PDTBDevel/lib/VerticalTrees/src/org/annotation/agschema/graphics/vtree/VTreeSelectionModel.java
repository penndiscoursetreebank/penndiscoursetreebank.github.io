/*
 * VTreeSelectionModel.java
 *
 * Created on September 7, 2004, 11:23 AM
 */

package org.annotation.agschema.graphics.vtree;

import javax.swing.tree.TreeNode;
import java.util.Enumeration;
import java.beans.PropertyChangeListener;

/**
 * There are two parameters to the selection model.
 *
 * <ol>
 *   <li>
 *     The selection mode - The mode decides which nodes can be
 *     selected together if any. In the SingleNodeSelection mode
 *     only one node can be selected at a time. In the SiblingSelection
 *     mode, if a node is selected, only siblings can be added to 
 *     the selection. In the Discontinuous selection mode, an arbitrary
 *     set of nodes can be selected.
 *   </li>
 *   <li>
 *     The selection interpretation - This characterizes how the
 *     selection should be interpreted. With the SingleNodeInterpretation
 *     only nodes explicitly added to the selection model are
 *     selected. With the SubtreeInterpretation, when a node is
 *     selected, it is assumed that all its children are selected.
 *    </li>
 * </ol>
 *
 * @author  nikhild
 */
public interface VTreeSelectionModel extends PropertyChangeListener{
    
    /*
     * Only one node can be selected at a time. Adding a node
     * when another node is selected will erase the previous
     * selection.
     */
    public static final int SingleNodeSelection = 0;
    
    /*
     * Only a set of siblings can be selected.
     */
    public static final int SiblingSelection = 1;
    
    /*
     * An arbitrary set of nodes can be selected.
     */
    public static final int DiscontinuousSelection = 2;
    
    /*
     * Only the nodes added to the model count as selected.
     */
    public static final int SingleNodeInterpretation = 0;
    
    /*
     * The nodes added to the model and its descendants count
     * as selected.
     */
    public static final int SubtreeInterpretation = 1;
    
    /*
     * Adds a listener to the model. The listener should be aware
     * of the selection interpretation, because with the subtree 
     * interpretation, only a message for the highest node added 
     * will be sent.
     *
     * @param l the listener to add
     */
    public void addListener(VTreeSelectionListener l);
    
    /*
     * Removes the listener from the model.
     *
     * @param l the listener to remove
     */
    public void removeListener(VTreeSelectionListener l);
    
    /*
     * Adds the node to the selection
     *
     * @param node the node to add to the selection
     */
    public void add(TreeNode node);
    
    /*
     * Returns a enumeration of the selected nodes. Note that
     * no order guarantees are made.
     */
    public Enumeration getSelectedNodes();
    
    /*
     * The last node added to the selection.
     */
    public TreeNode getLeadSelectionNode();
    
    /*
     * Removes the node from the selection
     *
     * @param node the node to remove
     */
    public void remove(TreeNode node);
    
    /*
     * Removes all nodes from the selection
     */
    public void clear();
    
    /*
     * Returns true if the node is selected under the current
     * interpretation
     */
    public boolean isNodeSelected(TreeNode node);
    
    /*
     * Sets the selection mode. Should be one of the modes
     * listed above.
     */
    public void setMode(int mode);
    
    /*
     * Returns the root of the tree, for which this is a selection
     * model.
     */
    public TreeNode getRoot();
    
    /*
     * Sets the selection interpretation. Should be one of the
     * interpretations listed above.
     */
    public void setSelectionInterpretation(int interpretation);
    
    /*
     * Returns the selection interpretation.
     */
    public int getSelectionInterpretation();
}
