/*
 * VTreeExpansionStateImpl.java
 *
 * Created on September 8, 2004, 1:21 PM
 */

package org.annotation.agschema.graphics.vtree;

import java.util.HashSet;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.tree.TreeNode;
import java.beans.PropertyChangeEvent;

/**
 * A simple implementation of the expansion state. Note that when
 * a node is collapsed all it's children if previously collapsed, will
 * now be treated as hidden, and expanding this node will make all its
 * children expanded. Applications should write their own expansion state
 * tailored to their needs.
 *
 * @author  nikhild
 */
public class VTreeExpansionStateImpl implements VTreeExpansionState{
    
    private HashSet collapsedNodes = new HashSet();
    
    private TreeNode root;
    
    private Vector treeExpansionListeners = new Vector();
    
    /** Creates a new instance of VTreeExpansionStateImpl */
    public VTreeExpansionStateImpl(TreeNode root) {
        this.root = root;
    }
    
    public void collapse(TreeNode node) {
        if(!(isCollapsed(node))){
            collapsedNodes.add(node);
            removeDescendants(node);
            fireNodeCollapsed(node);
        }
        
    }
    
    private void removeDescendants(TreeNode node){
        Enumeration e = node.children();
        while(e.hasMoreElements()){
            TreeNode child = (TreeNode)(e.nextElement());
            collapsedNodes.remove(child);
            removeDescendants(child);
        }
    }
    
    public void expand(TreeNode node) {
        if(ancestorExpanded(node) && collapsedNodes.contains(node)){
            collapsedNodes.remove(node);
            fireNodeExpanded(node);
        }
    }
    
    public TreeNode getRoot() {
        return root;
    }
    
    public boolean isCollapsed(TreeNode node) {
        return collapsedNodes.contains(node);
    }
    
    private boolean ancestorExpanded(TreeNode node){
        while(node != root){
            node = node.getParent();
            if(collapsedNodes.contains(node)){
                return false;
            }
        }
        return true;
    }
    
    public boolean isExpanded(TreeNode node) {
        return (collapsedNodes.contains(node))? false : ancestorExpanded(node);
    }
    
    public boolean isHidden(TreeNode node) {
        return (collapsedNodes.contains(node))? false : !(ancestorExpanded(node));
    }
    
    public void addListener(VTreeExpansionListener l) {
        treeExpansionListeners.add(l);
    }
    
    public void removeListener(VTreeExpansionListener l) {
        treeExpansionListeners.remove(l);
    }
    
    protected void fireNodeExpanded(TreeNode node){
        Enumeration listeners = treeExpansionListeners.elements();
        while(listeners.hasMoreElements()){
            VTreeExpansionListener l = (VTreeExpansionListener)(listeners.nextElement());
            l.nodeExpanded(this, node);
        }
    }
    
    protected void fireNodeCollapsed(TreeNode node){
        Enumeration listeners = treeExpansionListeners.elements();
        while(listeners.hasMoreElements()){
            VTreeExpansionListener l = (VTreeExpansionListener)(listeners.nextElement());
            l.nodeCollapsed(this, node);
        }
    }
    
    public void propertyChange(PropertyChangeEvent evt){
        String name = evt.getPropertyName();
        if(name.equals(VTreeCanvas.TreeRootProperty)){
            collapsedNodes.clear();
            TreeNode root = (TreeNode) (evt.getNewValue());
        }
    }
}
