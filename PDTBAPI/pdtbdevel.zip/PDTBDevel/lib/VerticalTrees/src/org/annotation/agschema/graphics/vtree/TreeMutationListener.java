/*
 * TreeMutationListener.java
 *
 * Created on September 7, 2004, 6:45 PM
 */

package org.annotation.agschema.graphics.vtree;

import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;

/**
 * Listens for mutations of a tree. For now only MutableTreeNodes can have
 * mutation events, but this is worth reconsidering, since that interface can
 * be a pain to implement.
 *
 * @author  nikhild
 */
public interface TreeMutationListener {
    
    /*
     * Messaged when a child is added to the parent at the appropriate position
     *
     * @param parent the parent node
     * @param index the index at which the child has been added
     */
    public void childAdded(MutableTreeNode parent, int index);
    
    /*
     * Messaged when a child is removed
     *
     * @param parent the parent node
     * @param child the child that has been removed
     * @param oldChildIndex the index of the child before removal
     */
    public void childRemoved(MutableTreeNode parent, MutableTreeNode child, int oldChildIndex);
    
    /*
     * Messaged when the userobject is changed
     *
     * @param node the node whose object has changed
     * @param oldUserObject the old user object
     */
    public void nodeObjectChanged(MutableTreeNode node, Object oldUserObject);
    
    /*
     * If many mutations happen, messaging after every mutation can slow things
     * down. So this can be messaged to indicate that a subtree has changed. If
     * the root of the tree is used, then the assumption is that anything in the
     * tree may have changed
     *
     * @param subtreeRoot the root of the subtree which has changed
     */
    public void subtreeDamaged(MutableTreeNode subtreeRoot);
    
    /*
     * The tree was changed on the canvas
     */
    public void rootChanged(TreeNode newRoot, TreeNode oldRoot);
}
