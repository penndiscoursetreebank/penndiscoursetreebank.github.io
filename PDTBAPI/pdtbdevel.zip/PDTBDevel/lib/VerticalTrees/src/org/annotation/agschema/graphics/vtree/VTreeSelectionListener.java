/*
 * VTreeSelectionListener.java
 *
 * Created on September 7, 2004, 11:30 AM
 */

package org.annotation.agschema.graphics.vtree;

import javax.swing.tree.TreeNode;

/**
 *
 * @author  nikhild
 */
public interface VTreeSelectionListener {
    
    public void nodeAdded(VTreeSelectionModel model, TreeNode node);
    
    public void nodeRemoved(VTreeSelectionModel model, TreeNode node);
    
    public void selectionCleared(VTreeSelectionModel model);
    
    public void selectionModeChanged(VTreeSelectionModel model, int oldMode);
    
    public void selectionInterpretationChanged(VTreeSelectionModel model, int oldInterpretation);
}
