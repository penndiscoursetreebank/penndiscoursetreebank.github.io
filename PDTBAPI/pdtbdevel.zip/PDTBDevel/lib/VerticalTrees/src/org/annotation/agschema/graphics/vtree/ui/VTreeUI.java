/*
 * VTreeUI.java
 *
 * Created on September 10, 2004, 1:33 AM
 */

package org.annotation.agschema.graphics.vtree.ui;

import java.util.HashSet;
import java.util.Iterator;

import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;

import javax.swing.plaf.ComponentUI;

import java.awt.Rectangle;
import java.awt.Dimension;

import org.annotation.agschema.graphics.vtree.*;

/**
 *
 * @author  nikhild
 */
public abstract class VTreeUI extends ComponentUI{
    
    private HashSet mutationListeners = new HashSet();
    
    /** Creates a new instance of VTreeUI */
    public VTreeUI() {
        super();
    }
    
    public abstract Rectangle getNodeLocation(TreeNode node);
    
    public abstract TreeNode getNode(int x, int y);
    
    
}
