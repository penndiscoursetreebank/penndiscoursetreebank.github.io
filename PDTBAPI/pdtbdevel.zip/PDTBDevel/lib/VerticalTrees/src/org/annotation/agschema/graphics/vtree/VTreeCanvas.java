/*
 * VTreeCanvas.java
 *
 * Created on August 26, 2004, 1:46 PM
 */

package org.annotation.agschema.graphics.vtree;

import javax.swing.JComponent;
import javax.swing.tree.TreeNode;
import javax.swing.Scrollable;


import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Dimension;

import java.awt.geom.AffineTransform;
import java.awt.event.*;

import java.util.Enumeration;
import java.util.Vector;

import org.annotation.agschema.graphics.vtree.ui.*;

/**
 *
 * @author  nikhild
 */
public class VTreeCanvas extends JComponent implements Scrollable{
    
    public static final String SelectionModelProperty = "VTreeSelectionModel";
    
    private VTreeSelectionModel selectionModel = null;
    
    public static final String ExpansionStateProperty = "VTreeExpansionState";
    
    private VTreeExpansionState expansionState = null;
    
    public static final String TreeMutationSupportProperty = "TreeMutationSupport";
    
    private TreeMutationSupport mutationSupport = null;
    
    public static final String TreeRootProperty = "Root";
    
    private TreeNode root = null;
    
    public static final String CellRendererProperty = "CellRenderer";
    
    private VTreeCellRenderer cellRenderer = null;
    
    /** Creates a new instance of VTreeCanvas */
    public VTreeCanvas() {
        super();
        setUI(BoundedSubtreeUI.createUI(this));
    }
    
    public VTreeExpansionState getExpansionState(){
        return expansionState;
    }
    
    public void setExpansionState(VTreeExpansionState state) 
    throws IllegalArgumentException{
        if(state != null && root != state.getRoot()){
            throw(new IllegalArgumentException("The root node provided by the " +
            "expansion state and the root node set must be the same."));
        }
        
        if(state != expansionState){
            VTreeExpansionState oldValue = expansionState;
            expansionState = state;
            firePropertyChange(ExpansionStateProperty, oldValue, expansionState);
        }
    }
    
    public VTreeSelectionModel getSelectionModel(){
        return selectionModel;
    }
    
    public void setSelectionModel(VTreeSelectionModel model) 
    throws IllegalArgumentException{
        if(model != null && root != model.getRoot()){
            throw(new IllegalArgumentException("The root node provided by the " +
            "selection model and the root node set must be the same."));
        }
        
        if(model != selectionModel){
            VTreeSelectionModel oldValue = selectionModel;
            if(oldValue != null){
                removePropertyChangeListener(oldValue);
            }
            selectionModel = model;
            firePropertyChange(SelectionModelProperty, oldValue, selectionModel);
            addPropertyChangeListener(selectionModel);
        }
    }
    
    public TreeMutationSupport getMutationSupport(){
        return mutationSupport;
    }
    
    public void setMutationSupport(TreeMutationSupport support)
    throws IllegalArgumentException{
        if(support != null && root != support.getRoot()){
            throw(new IllegalArgumentException("The root node provided by the " +
            "selection model and the root node set must be the same."));
        }
        
        if(support != mutationSupport){
            TreeMutationSupport oldValue = mutationSupport;
            if(oldValue != null){
                removePropertyChangeListener(oldValue);
            }
            mutationSupport = support;
            firePropertyChange(TreeMutationSupportProperty, oldValue, mutationSupport);
            addPropertyChangeListener(mutationSupport);
        }
    }
    
    public TreeNode getRoot(){
        return root;
    }
    
    public void setRoot(TreeNode root){
        if(this.root != root){
            TreeNode oldValue = this.root;
            this.root = root;
            firePropertyChange(TreeRootProperty, oldValue, root);
        }
    }
    
    public VTreeCellRenderer getCellRenderer(){
        return cellRenderer;
    }
    
    public void setCellRenderer(VTreeCellRenderer r){
        if(cellRenderer != r){
            VTreeCellRenderer oldValue = cellRenderer;
            cellRenderer = r;
            firePropertyChange(CellRendererProperty, oldValue, cellRenderer);
        }
    }
    
    public Rectangle getNodeLocation(TreeNode node){
        VTreeUI vtreeUI = (VTreeUI)ui;
        return vtreeUI.getNodeLocation(node);
    }
    
    public TreeNode getNode(int x, int y){
        VTreeUI vtreeUI = (VTreeUI)ui;
        return vtreeUI.getNode(x,y);
    }
    
    public Dimension getMaximumSize(){
        return ui.getMaximumSize(this);
    }
    
    public Dimension getMinimumSize(){
        return ui.getMinimumSize(this);
    }
    
    public Dimension getPreferredSize(){
        return ui.getPreferredSize(this);
    }
    
    protected void paintComponent(Graphics g){
        ui.paint(g, this);
    }
    
    public Dimension getPreferredScrollableViewportSize() {
        Dimension d = getPreferredSize();
        //return getPreferredSize();
        
        return new Dimension(((d.getWidth() > 100)? 100 : (int) (d.getWidth())),
        ((d.getHeight() > 500)? 500 : (int) (d.getHeight())));
        
    }
    
    public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
        return 100;
    }
    
    public boolean getScrollableTracksViewportHeight() {
        return false;
    }
    
    public boolean getScrollableTracksViewportWidth() {
        return false;
    }
    
    public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
        return 100;
    }
    
}
