/*
 * TreeMutationSupport.java
 *
 * Created on September 10, 2004, 8:52 PM
 */

package org.annotation.agschema.graphics.vtree;

import java.util.HashSet;
import java.util.Iterator;

import javax.swing.tree.TreeNode;
import javax.swing.tree.MutableTreeNode;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

/**
 * Convenience class that maintains a set of listeners and notifies
 * them of the appropriate event. No order guarantees are made on the
 * order in which the listeners are messaged.
 *
 * @author  nikhild
 */
public class TreeMutationSupport implements PropertyChangeListener{
    
    private TreeNode root;
    
    private HashSet listeners = new HashSet();
    
    /** Creates a new instance of TreeMutationSupport */
    public TreeMutationSupport(TreeNode root) {
        this.root = root;
    }
    
    /**
     * Convenience method to get the root
     */
    public TreeNode getRoot(){
        return root;
    }
    
    /*
     * Adds the listener to the list if it is not already present.
     *
     * @param l the listener to add
     */
    public void addListener(TreeMutationListener l){
        listeners.add(l);
    }
    
    /**
     * The listener to remove
     *
     * @param l the listener to remove
     */
    public void removeListener(TreeMutationListener l){
        listeners.remove(l);
    }
    
    /**
     * Notifies the listeners of the childAdded event
     */
    public void fireChildAdded(MutableTreeNode parent, int childIndex){
        Iterator iter = listeners.iterator();
        while(iter.hasNext()){
            TreeMutationListener l = (TreeMutationListener)(iter.next());
            l.childAdded(parent, childIndex);
        }
    }
    
    /**
     * Notifies the listeners of the childRemoved event
     */
    public void fireChildRemoved(MutableTreeNode parent, MutableTreeNode child, int oldChildIndex){
        Iterator iter = listeners.iterator();
        while(iter.hasNext()){
            TreeMutationListener l = (TreeMutationListener)(iter.next());
            l.childRemoved(parent, child, oldChildIndex);
        }
    }
    
    /**
     * Notifies the listeners of the nodeObjectChanged event
     */
    public void fireNodeObjectChanged(MutableTreeNode node, Object oldUserObject){
        Iterator iter = listeners.iterator();
        while(iter.hasNext()){
            TreeMutationListener l = (TreeMutationListener)(iter.next());
            l.nodeObjectChanged(node, oldUserObject);
        }
    }
    
    /**
     * Notifies the listeners of the subtreeDamaged event
     */
    public void fireSubtreeDamaged(MutableTreeNode subtreeRoot){
        Iterator iter = listeners.iterator();
        while(iter.hasNext()){
            TreeMutationListener l = (TreeMutationListener)(iter.next());
            l.subtreeDamaged(subtreeRoot);
        }
    }
    
    private void fireRootChanged(TreeNode newRoot, TreeNode oldRoot){
        Iterator iter = listeners.iterator();
        while(iter.hasNext()){
            TreeMutationListener l = (TreeMutationListener)(iter.next());
            l.rootChanged(newRoot, oldRoot);
        }
    }
    
    public void propertyChange(PropertyChangeEvent evt){
        String name = evt.getPropertyName();
        if(name.equals(VTreeCanvas.TreeRootProperty)){
            TreeNode newRoot = (TreeNode) (evt.getNewValue());
            fireRootChanged(newRoot, root);
            root = newRoot;
        }
    }
}
