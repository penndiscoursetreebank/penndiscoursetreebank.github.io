/*
 * VTreeSelectionModelImpl.java
 *
 * Created on September 7, 2004, 12:21 PM
 */

package org.annotation.agschema.graphics.vtree;

import java.util.Stack;
import java.util.HashSet;
import java.util.Enumeration;
import java.util.Vector;
import java.beans.PropertyChangeEvent;
import javax.swing.tree.TreeNode;

/**
 * Implementation of the selection model interface. 
 * 
 * @author  nikhild
 */
public class VTreeSelectionModelImpl implements VTreeSelectionModel{
    
    private TreeNode root;
    
    private Stack selectedNodeStack = new Stack();
    
    private HashSet selectedNodes = new HashSet();
    
    private TreeNode leadSelectionNode = null;
    
    private int selectionMode = VTreeSelectionModel.SingleNodeSelection;
    
    private Vector treeSelectionListeners = new Vector();
    
    private int selectionInterpretation = SingleNodeInterpretation;
    
    /** Creates a new instance of VTreeSelectionModelImpl */
    public VTreeSelectionModelImpl(TreeNode root) {
        this.root = root;
    }
    
    protected void fireNodeAdded(TreeNode node){
        Enumeration listeners = treeSelectionListeners.elements();
        while(listeners.hasMoreElements()){
            VTreeSelectionListener l = (VTreeSelectionListener)(listeners.nextElement());
            l.nodeAdded(this, node);
        }
    }
    
    protected void fireNodeRemoved(TreeNode node){
        Enumeration listeners = treeSelectionListeners.elements();
        while(listeners.hasMoreElements()){
            VTreeSelectionListener l = (VTreeSelectionListener)(listeners.nextElement());
            l.nodeRemoved(this, node);
        }
    }
    
    protected void fireSelectionCleared(){
        Enumeration listeners = treeSelectionListeners.elements();
        while(listeners.hasMoreElements()){
            VTreeSelectionListener l = (VTreeSelectionListener)(listeners.nextElement());
            l.selectionCleared(this);
        }
    }
    
    protected void fireModeChanged(int oldMode){
        Enumeration listeners = treeSelectionListeners.elements();
        while(listeners.hasMoreElements()){
            VTreeSelectionListener l = (VTreeSelectionListener)(listeners.nextElement());
            l.selectionModeChanged(this, oldMode);
        }
    }
    
    protected void fireInterpretationChanged(int oldInterpretation){
        Enumeration listeners = treeSelectionListeners.elements();
        while(listeners.hasMoreElements()){
            VTreeSelectionListener l = (VTreeSelectionListener)(listeners.nextElement());
            l.selectionModeChanged(this, oldInterpretation);
        }
    }
    
    public void add(TreeNode node) {
        if(isNodeSelected(node) || !(checkNodeInTree(node))){
            return;
        }
        
        if(selectionMode == SiblingSelection){
            if(leadSelectionNode != null && 
            !(leadSelectionNode.getParent() == node.getParent())){
                return;
            }
            
        }
        
        leadSelectionNode = node;
        selectedNodeStack.push(node);
        selectedNodes.add(node);
        
        fireNodeAdded(node);
    }
    
    
    private boolean checkNodeInTree(TreeNode node){
        while(node != root && (node.getParent() != null)){
            node = node.getParent();
        }
        
        return (node == root);
    }
    
    
    public void addListener(VTreeSelectionListener l) {
        treeSelectionListeners.add(l);
    }
    
    public void removeListener(VTreeSelectionListener l){
        treeSelectionListeners.remove(l);
    }
    
    public void clear() {
        selectedNodes.clear();
        selectedNodeStack.removeAllElements();
        leadSelectionNode = null;
        fireSelectionCleared();
    }
    
    public TreeNode getRoot() {
        return root;
    }
    
    public Enumeration getSelectedNodes(){
        return selectedNodeStack.elements();
    }
    
    public TreeNode getLeadSelectionNode(){
        return leadSelectionNode;
    }
    
    public void remove(TreeNode node) {
        selectedNodeStack.remove(node);
        selectedNodes.remove(node);
        if(leadSelectionNode == node){
            leadSelectionNode = (selectedNodeStack.isEmpty())? null : (TreeNode)(selectedNodeStack.peek());
        }
        
        fireNodeRemoved(node);
    }
    
    public void setMode(int mode) {
        if(selectionMode != mode && (mode == SingleNodeSelection 
        || mode == SiblingSelection || mode == DiscontinuousSelection)){
            int oldMode = selectionMode;
            selectionMode = mode;
            fireModeChanged(oldMode);
        }
    }
    
    public boolean isNodeSelected(TreeNode node) {
        if(selectedNodes.contains(node)){
            return true;
        }
        else{
            if(selectionInterpretation == SubtreeInterpretation){
                while(node != root && node != null){
                    node = node.getParent();
                    if(selectedNodes.contains(node)){
                        return true;
                    }
                }
                
            }
        }
        
        return false;
    }
    
    public void setSelectionInterpretation(int interpretation) {
        if(interpretation != selectionInterpretation && 
        (interpretation == SingleNodeInterpretation || 
        interpretation == SubtreeInterpretation)){
            int oldInterpretation = selectionInterpretation;
            selectionInterpretation = interpretation;
            fireInterpretationChanged(oldInterpretation);
        }
    }
    
    public int getSelectionInterpretation() {
        return selectionInterpretation;
    }
    
    public void propertyChange(PropertyChangeEvent evt){
        String name = evt.getPropertyName();
        if(name.equals(VTreeCanvas.TreeRootProperty)){
            clear();
            root = (TreeNode) (evt.getNewValue());
        }
    }
}
 