/*
 * VTreeExpansionListener.java
 *
 * Created on September 8, 2004, 1:16 PM
 */

package org.annotation.agschema.graphics.vtree;

import javax.swing.tree.TreeNode;

/**
 * Listen for expansion events. For very large trees, it may be
 * undesirable to show the whole tree at once, and the user may
 * want to draw hide a subtree temporarily. 
 *
 * @author  nikhild
 */
public interface VTreeExpansionListener {
    
    /**
     * Notification that a node has collapsed, and from the perspective
     * of viewing, it is now a leaf.
     *
     * @param state the expansion/collapse state of various nodes in the
     * tree.
     *
     * @param node the node which has been collapsed
     */
    public void nodeCollapsed(VTreeExpansionState state, TreeNode node);
    
    /**
     * Notification that a node has expanded, and from the perspective
     * of viewing, all its children will be displayed.
     *
     * @param state the expansion/collapse state of various nodes in the
     * tree.
     *
     * @param node the node which has been expanded.
     */
    public void nodeExpanded(VTreeExpansionState state, TreeNode node);
}
