/*
 * VTreeCellRendererImpl.java
 *
 * Created on September 19, 2004, 7:50 PM
 */

package org.annotation.agschema.graphics.vtree;

import javax.swing.JLabel;
import java.awt.Component;
import java.awt.Color;
import java.awt.Rectangle;
import javax.swing.tree.TreeNode;
import java.awt.Graphics;

/**
 * Expansion and focus are not handled yet.
 *
 * @author  nikhild
 */
public class VTreeCellRendererImpl extends JLabel implements VTreeCellRenderer{
    protected Color textSelectionColor = Color.BLACK;
    
    protected Color textNonSelectionColor = Color.BLACK;
    
    protected Color backgroundSelectionColor = Color.BLUE;
    
    protected Color backgroundNonSelectionColor = Color.LIGHT_GRAY;
    
    private VTreeCanvas canvas = null;
    
    /** Creates a new instance of VTreeCellRendererImpl */
    public VTreeCellRendererImpl() {
        super();
    }
    
    public Color getTextSelectionColor(){
        return textSelectionColor;
    }
    
    public void setTextSectionColor(Color c){
        textSelectionColor = c;
    }
    
    public Color getTextNonSelectionColor(){
        return textNonSelectionColor;
    }
    
    public void setTextNonSectionColor(Color c){
        textNonSelectionColor = c;
    }
    
    public Color getBackgroundSelectionColor(){
        return backgroundSelectionColor;
    }
    
    public void setBackgroundSectionColor(Color c){
        backgroundSelectionColor = c;
    }
    
    public Color getBackgroundNonSelectionColor(){
        return backgroundNonSelectionColor;
    }
    
    public void setBackgroundNonSectionColor(Color c){
        backgroundNonSelectionColor = c;
    }
    
    /**
     * Sets the text of the lable using node.toString() and
     * returns a reference to self.
     */
    public Component getTreeCellRendererComponent(VTreeCanvas vTree, TreeNode node, boolean isSelected, boolean hasFocus, boolean isLeaf, boolean isExpanded) {
        if(canvas == null) canvas = vTree;
        
        if(canvas != vTree) throw(new IllegalArgumentException("Wrong canvas"));
        
        setBackground((isSelected)? backgroundSelectionColor : backgroundNonSelectionColor);
        setForeground((isSelected)? textSelectionColor : textNonSelectionColor);
        setText(node.toString());
        return this;
    }
    
    protected void firePropertyChange(String propertyName, Object oldValue, Object newValue){
        if(propertyName.equals("text"))
            super.firePropertyChange(propertyName, oldValue, newValue);
    }
    
    public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue){}
    
    public void firePropertyChange(String propertyName, int oldValue, int newValue){}
    
    public void firePropertyChange(String propertyName, char oldValue, char newValue){}
    
    public void firePropertyChange(String propertyName, double oldValue, double newValue){}
    
    public void firePropertyChange(String propertyName, float oldValue, float newValue){}
    
    public void firePropertyChange(String propertyName, long oldValue, long newValue){}
    
    public void firePropertyChange(String propertyName, byte oldValue, byte newValue){}
    
    public void validate(){}
    
    public void revalidate(){}
    
    public void repaint(long tm, int x, int y, int width, int height){}
    
    public void repaint(Rectangle r){}
    
    public void paint(Graphics g){
        g.setColor(getBackground());
        g.fillRect(0,0,getWidth(), getHeight());
        super.paint(g);
    }
}
