/*
 * PTBTreeNode.java
 *
 * Created on December 4, 2004, 2:34 PM
 */

package edu.upenn.cis.ptb;

import javax.swing.tree.MutableTreeNode;
import java.util.regex.Pattern;
import java.util.Enumeration;
import java.io.Writer;
import java.io.IOException;

/**
 * <p>
 * A node in the PTB. The label of the node is {@link PTBLabel}.
 *  This is similar to various other
 * interfaces to the PTB, but Java&trade;'s
 * treatment of method namespaces results in incompatibilities
 * between the Swing interfaces and/or DOM and other treebank
 * interfaces. The intended uses for this interface are mainly
 * querying and display.
 * </p>
 * <p>
 * The setter methods here are for internal use only with
 * the exception of setLabel, and ptbAppendChild, and implementations
 * may impose their own semantics. To mutate the tree, use
 * the methods provided by the MutableTreeNode
 * superinterface. Also note that the label and userObject
 * are separate.
 * </p>
 *
 * <p>
 * To avoid name clashes, some commonly used methods are
 * prefixed with ptb.
 * </p>
 *
 * <p>
 * <b> Version 2 Changes: </b> Two methods: "ptbSetAttribute" and
 *  "ptbGetAttribute" have been removed for performance reasons.
 *  There is no way to add custom attributes now. {@link PTBLabel} has
 *  a corresponding change.
 *  </p>
 *
 * @version 2
 * @since 0.1
 * @author nikhild
 * @see edu.upenn.cis.ptb.xpath.PTBNavigator
 */
public interface PTBTreeNode extends MutableTreeNode{
    
    public static final Pattern NonPunctPOSPattern = Pattern.compile("CC|CD|DT|EX|" +
    "IN|JJ|JJR|JJS|MD|NN|NNS|NNP|NNPS|PTD|POS|PRP|PRP$|RB|RBR|RBS|RP|TO|UH|VB|VBD|VBG|VBN|VBP|" +
    "VBZ|WDT|WP|WP$|WRB|FW");
    
    public static final String TypeAttributeQName = "type";
    
    public static final String RolesAttributeQName = "roles";
    
    public static final String MovementIndexAttributeQName = "movementIndex";
    
    public static final String GapIndexAttributeQName = "gapIndex";
    
    public static final String RawAttributeQName = "raw";
    
    
    /**
     * Get the associated PTBLabel
     */    
    public PTBLabel getLabel();
    
    /**
     * Sets the label
     */    
    public void setLabel(PTBLabel label);
    
    /**
     * Equivalent to isLeaf()
     */
    public boolean isTerminal();
    
    /**
     * Equivalent to getParent().isTracePreterminal()
     */
    public boolean isTraceTerminal();
    
    /**
     * Equivalent to getChildCount() == 1 && getChildAt(0).isLeaf()
     */
    public boolean isPreterminal();
    
    /**
     * Equivalent to isPreterminal() && hasRole("NONE")
     */
    public boolean isTracePreterminal();
    
    /**
     * isPreterminal(), and getLabel().getType() is not in NonPunctuationPOS
     */
    public boolean isPunctPreterminal();
    
    /**
     * Equivalent to getParent().isPunctPreterminal()
     */
    public boolean isPunct();
    
    /**
     * The first child of this node or null if it is a leaf.
     */    
    public PTBTreeNode ptbGetFirstChild();
    
    /**
     * The last child of this node or null if it is a leaf
     */    
    public PTBTreeNode ptbGetLastChild();
    
    /**
     * The previous sibling if one exists, null otherwise.
     */    
    public PTBTreeNode ptbGetPreviousSibling();
    
    /**
     * The next sibling if one exists, null otherwise.
     */    
    public PTBTreeNode ptbGetNextSibling();
    
    /**
     * Implementation specific.
     */    
    public void ptbSetFirstChild(PTBTreeNode firstChild);
    
    /**
     * Implementation specific.
     */    
    public void ptbSetLastChild(PTBTreeNode lastChild);
    
    /**
     * Implementation specific.
     */
    public void ptbSetPreviousSibling(PTBTreeNode prevSibling);
    
    /**
     * Implementation specific.
     */
    public void ptbSetNextSibling(PTBTreeNode nextSibling);
    
    /**
     * Adds the node supplied as the last child of this node.
     */    
    public void ptbAppendChild(MutableTreeNode newChild);
    
    public Enumeration ptbGetAttributes();
    
    public Object getUserObject();
    
    public void save(Writer writer) throws IOException;
    
    public void save(Writer writer, int indent, int indentIncr) throws IOException;
}
