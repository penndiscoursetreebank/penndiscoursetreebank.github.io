/*
 * CorpusFileIterator.java
 *
 * Created on March 4, 2007, 11:13 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package edu.upenn.cis.ptb.util;

import java.io.*;

/**
 * Utility class for iterating over files in the PTB. For example:
 *
 *  <pre>
 *   ....
 *   PTBLoader loader = new PTBLoaderImpl();
 *   for(CorpusFileIterator cfi = new CorpusFileIterator(ptbRoot);
 *       cfi.hasMoreFiles();){
 *      cfi.nextFile();
 *      loader.load(cfi.currentFile());
 *      ....
 *  }
 *  </pre>
 *
 * @since 0.2.3
 * @author nikhild
 */
public class CorpusFileIterator implements FilenameFilter{
    
    private File fPtbRoot;
    
    private boolean[][] fFileDatabase = new boolean[25][100];
    
     private int secNo = 0;
   
    private int nextSecNo = 0;
    
    private int maxSec = 25;
    
    private int minSec = 0;
    
    private int fileNo = -1;
    
    private int nextFileNo = 0;
    
    private int maxFile = 100;
    
    private int minFile = 0;
       
    private String currentPtbFile = null;
    
    private String nextPtbFile = null;

    
    /** Creates a new instance of CorpusFileIterator */
    public CorpusFileIterator(String ptbRoot) {
        fPtbRoot = new File(ptbRoot);
        if(!(fPtbRoot.isDirectory())){
            throw(new IllegalArgumentException(ptbRoot + " is not a directory"));
        }
        
        initDatabase();
        setNext();
    }
    
    private void initDatabase(){
	for(int i = 0; i < 25; i++){
	    File secFile = new File(fPtbRoot, (i < 10)? "0" + i : "" + i);
	    secFile.list(this);
	    
	}

    }
    
    public boolean accept(File dir, String name){
	try{
	    char i1 = name.charAt(4);
	    char i2 = name.charAt(5);
	    char i3 = name.charAt(6);
	    char i4 = name.charAt(7);
	    int sn = Character.digit(i1,10) * 10 + Character.digit(i2,10);
	    int fn = Character.digit(i3,10) * 10 + Character.digit(i4,10);
            if(name.endsWith("mrg")){
                fFileDatabase[sn][fn]  = true;
            }
	}
	catch(Exception e){
	}
	return false;
    }
    
    public boolean hasMoreFiles(){
        return nextPtbFile != null;
    }
    
    public void nextFile(){
        currentPtbFile = nextPtbFile;
        secNo = nextSecNo;
        fileNo = nextFileNo;
        
        setNext();
        
    }
    
    private void setNext(){
        nextFileNo++;
        
        if(nextFileNo == maxFile){
            nextFileNo = minFile;
            nextSecNo++;
        }
        
        while(nextSecNo < maxSec){
            String sec = (nextSecNo < 10)? "0" + nextSecNo : "" + nextSecNo;
            while(nextFileNo < maxFile){
		if(fFileDatabase[nextSecNo][nextFileNo]){
		    String file = (nextFileNo < 10)? "0" + nextFileNo : "" + nextFileNo;
                
		    
                    nextPtbFile = fPtbRoot.getAbsolutePath() + File.separatorChar +
                        sec + File.separatorChar +
                        "wsj_" + sec + file + ".mrg";

		    return;
                }
                
                nextFileNo++;
            }
            
            nextSecNo++;
            nextFileNo = 0;
        }
        
        nextPtbFile = null;
    }
    
    public String getSecNoStr(){
        return (secNo < 10)? "0" + secNo : "" + secNo;
    }
    
    public int getSecNo(){
        return secNo;
    }
    
    public String getFileNoStr(){
        return (fileNo < 10)? "0" + fileNo : "" + fileNo;
    }
    
    public int getFileNo(){
        return fileNo;
    }
    
    public String currentFile(){
        return currentPtbFile;
    }
}
