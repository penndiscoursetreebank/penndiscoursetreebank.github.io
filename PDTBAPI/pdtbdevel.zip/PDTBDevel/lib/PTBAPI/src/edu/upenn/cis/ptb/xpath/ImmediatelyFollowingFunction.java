/*
 * SubtreeScoping.java
 *
 * Created on February 11, 2006, 7:20 PM
 */

package edu.upenn.cis.ptb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import org.jaxen.Navigator;
import org.jaxen.XPath;
import java.util.List;
import java.util.WeakHashMap;
import java.util.Iterator;
import java.util.LinkedList;
import edu.upenn.cis.ptb.*;

/**
 * Functional definition of the Immediately Following Axis in LPath. This function has the signature:
 *
 * <pre>
 *  node-set i-foll(node-set, string )
 * </pre>
 *
 * The second argument is a string which should be a valid XPath expression. This
 * expression will be run against each node in the immediately following axis
 * (see LPath Bird et al) of nodes in the nodset. The immediately following axis
 * starts from the first node of the following axis (say x), and includes all nodes
 * on the path from x to its first leaf.
 *
 * <pre>
 *  i-foll(>>::VB,'=::NP')
 * </pre>
 *
 * Select NP nodes which immediately follow a VB node. See the PTBXPath class for
 * how to write recursive expressions.
 *
 * @author  nikhild
 * @see PTBXPath
 */
public class ImmediatelyFollowingFunction implements Function {
    
    private WeakHashMap fExpressionMap = new WeakHashMap();
    
    private String fPreviousXPathStr = null;
    
    private XPath  fPreviousXPath = null;
    
    /** Creates a new instance of SubtreeScoping */
    public ImmediatelyFollowingFunction() {
    }
    
    public Object call(Context context, List list) throws org.jaxen.FunctionCallException {
        if(list.size() != 2){
            throw(new FunctionCallException("Number of arguments expected is 2." + list.size() + "supplied"));
        }
        
        Object arg = list.get(1);
        if(!(arg instanceof String)){
            throw(new FunctionCallException("Argument at index 1 should be a string representing the xpath expression." + arg.getClass().getName() + " supplied"));
        }
        
        Navigator nav = context.getNavigator();
        
        String xpathStr = (String)(arg);
        XPath xp = null;
        if(xpathStr == fPreviousXPathStr){
            xp = fPreviousXPath;
        }
        else{
            fPreviousXPathStr = xpathStr;
            xpathStr = PTBXPath.unEscapeExpr(xpathStr);
            xp = (XPath)(fExpressionMap.get(xpathStr));
            fPreviousXPath = xp;
        }
        
        if(xp == null){
            try{
                xp = nav.parseXPath(xpathStr);
                fPreviousXPath = xp;
            }catch(Exception e){
                throw(new FunctionCallException("Invalid xpath: " + xpathStr, e));
            }
            fExpressionMap.put(xpathStr, xp);
        }
        
        arg = list.get(0);
        if(!(arg instanceof List)){
            throw(new FunctionCallException("Argument at index 0 should be a list representing the nodes." + arg.getClass().getName() + " supplied"));
        }
        
        List nodes = (List)(arg);
        LinkedList result = new LinkedList();
        
        for(Iterator iter = nodes.iterator(); iter.hasNext();){
            Object node = iter.next();
            for(Iterator iter2 = getImmediatelyFollowingAxisIterator(node, nav); iter2.hasNext();){
                try{
                    result.addAll(xp.selectNodes(iter2.next()));
                }catch(Exception e){
                    throw(new FunctionCallException("XPath selection failed.", e));
                }
            }
        }
        
        return result;
    }
    
    private Object getFirstNodeOnFollowingAxis(Object node, Navigator nav) throws FunctionCallException{
        if(!(node instanceof PTBTreeNode)){
            return null;
        }
        
        PTBTreeNode root = ((PTBNavigator) nav).getRoot();
        for(PTBTreeNode n = (PTBTreeNode) node; n != root; n = (PTBTreeNode)(n.getParent())){
            if(n.ptbGetNextSibling() != null){
                return n.ptbGetNextSibling();
            }
        }
        
        return null;
    }
    
    private Iterator getImmediatelyFollowingAxisIterator(Object node, Navigator nav) throws FunctionCallException{
        Object firstNode = getFirstNodeOnFollowingAxis(node, nav);
        if(firstNode == null){
            return PTBNavigator.EmptyIterator;
        }
        
        
        final PTBTreeNode treeNode = (PTBTreeNode) firstNode;
        return (new Iterator(){
           
            private PTBTreeNode currentNode = treeNode;
            
            public boolean hasNext(){
                return currentNode != null;
            }
            
            public Object next(){
                PTBTreeNode ret = currentNode;
                currentNode = currentNode.ptbGetFirstChild();
                return ret;
            }
            
            public void remove(){
                
            }
            
        });
    }
    
}
