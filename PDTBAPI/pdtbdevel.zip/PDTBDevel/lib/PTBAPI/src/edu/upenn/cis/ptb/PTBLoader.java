/*
 * PTBLoader.java
 *
 * Created on February 2, 2006, 4:04 PM
 */

package edu.upenn.cis.ptb;

import java.io.Reader;

import java.io.IOException;

/**
 * Loads a file containing a list of parse trees. The parse trees occur
 * as children of the node returned by the load methods. This "root" node
 * has a label with type=root.
 *
 * @author  nikhild
 */
public interface PTBLoader {
    
    /**
     * Load from reader which will be closed after reading.
     */
    public PTBTreeNode load(Reader reader) throws IOException;
    
    /**
     * Load the file with the given fileName.
     */
    public PTBTreeNode load(String ptbFileName) throws IOException;
    
    /**
     * Load the file ptbRoot/ + secNo + /wsj_ + secNo + fileNo + .mrg.
     */
    public PTBTreeNode load(String ptbRoot, String secNo, String fileNo) throws IOException;
}
