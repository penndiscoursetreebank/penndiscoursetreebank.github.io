/*
 * PTBNamespaceContext.java
 *
 * Created on February 11, 2006, 7:51 PM
 */

package edu.upenn.cis.ptb.xpath;

import org.jaxen.SimpleNamespaceContext;

/**
 * This does nothing since 0.2.3.
 *
 * @author  nikhild
 * @see PTBXPath
 */
public class PTBNamespaceContext extends SimpleNamespaceContext{
    
    public static final String PTBFunctionNamespace = "";
    
    public static final String PTBFunctionNamespacePrefix = "ptbxp";
    
    
    /** Creates a new instance of PTBNamespaceContext */
    public PTBNamespaceContext() {
        super();
        //addNamespace(PTBFunctionNamespacePrefix, PTBFunctionNamespace);
    }
    
}
