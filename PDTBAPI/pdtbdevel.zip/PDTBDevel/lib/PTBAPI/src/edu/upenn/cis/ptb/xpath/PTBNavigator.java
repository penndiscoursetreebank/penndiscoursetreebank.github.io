/*
 * PTBMRGNavigator.java
 *
 * Created on June 4, 2005, 12:17 PM
 */

package edu.upenn.cis.ptb.xpath;

import org.jaxen.Navigator;
import org.jaxen.XPath;
import org.jaxen.UnsupportedAxisException;
import org.jaxen.FunctionCallException;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Enumeration;
import java.util.Stack;
import java.util.List;
import java.util.HashSet;

import org.w3c.dom.Node;

import edu.upenn.cis.ptb.*;
import edu.upenn.cis.ptb.util.*;
import java.io.*;

/**
 * This interfaces with the <a href="http://jaxen.sourceforge.net">Jaxen</a> XPath API.
 * For example the following produces the total number of nodes selected by an
 * xpath expression:
 *
 * <pre>
 *     public int getCount(String ptbRoot, String xpathExpr) throws Exception{
 *       PTBNavigator nav = new PTBNavigator(null);
 *       PTBXPath xp = (PTBXPath)(nav.parseXPath(xpathExpr));
 *       
 *       int count = 0;
 *       for(PTBTask task = new PTBTask(ptbRoot);task.hasNext();){
 *           PTBTreeNode root = task.next();
 *           for(Enumeration children = root.children(); children.hasMoreElements();){
 *               nav.setRoot((PTBTreeNode)(children.nextElement()));
 *               count += ((List)xp.evaluate(nav.getRoot())).size();
 *           }
 *           
 *       }
 *       return count;
 *   }
 *
 * </pre>
 * 
 * <p>
 *
 * Basically each node in the tree behaves like an Element node, with the QName 
 * equivalent to getLabel().getType(). See the PTBAttribute interface for the
 * list of attributes associated with the element. See {@link PTBXPath} for examples and discussion, 
 * and
 * <a href="http://www.w3.org/TR/xpath">XPath</a> recommendation for further 
 * info on XPath.
 * </p>
 *
 * <p>
 * The Function classes give extensions with which LPath expressions (Bird et al)
 * can be written. See the PTBXPath class for details.
 *
 * </p>
 *
 * @author  nikhild
 * @see edu.upenn.cis.ptb.PTBAttribute
 * @see PTBXPath
 */
public class PTBNavigator implements Navigator{
    
    protected PTBTreeNode root;
    
    protected PTBMRGDocument doc;
    
    public static final Iterator EmptyIterator = (
    new Iterator() {
        public boolean hasNext(){
            return false;
        }
        
        public Object next(){
            return null;
        }
        
        public void remove(){
            
        }
    }
    );
    
    public static final String EmptyString = "";
    
    /** Creates a new instance of PTBMRGNavigator */
    public PTBNavigator(PTBTreeNode root) {
        this.root = root;
        doc = new PTBMRGDocument(root);
    }
    
    public void setRoot(PTBTreeNode root){
        this.root = root;
        doc = new PTBMRGDocument(root);
    }
    
    public PTBTreeNode getRoot(){
        return root;
    }
    
    public PTBMRGDocument getDocument(){
        return doc;
    }
    
    protected Iterator getConcatenatedIterator(final Object obj, final Iterator iter){
        return (new Iterator(){
           private boolean retFirst = false;
           
           public boolean hasNext(){
               return (retFirst)? iter.hasNext() : true;
           }
           
           public Object next(){
               if(!retFirst){
                   retFirst = true;
                   return obj;
               }
               else{
                   return iter.next();
               }
           }
           
           public void remove(){
               
           }
           
        });
    }
    
    protected Iterator getConcatenatedIterator(final Stack iterators){
        return (new Iterator(){
           private Iterator iteratorSet = iterators.iterator();
           private Iterator currentIter = (iteratorSet.hasNext())? (Iterator)(iteratorSet.next()) : null;
           
           public boolean hasNext(){
               if(currentIter == null){
                   return false;
               }
               else{
                   if(currentIter.hasNext()){
                       return true;
                   }
                   else{
                       while(iteratorSet.hasNext() && !(currentIter.hasNext())){
                           currentIter = (Iterator)(iteratorSet.next());
                       }
                       
                       if(currentIter.hasNext()){
                           return true;
                       }
                       else{
                           currentIter = null;
                           return false;
                       }
                   }
               }
           }
           
           public Object next(){
               return currentIter.next();
           }
           
           public void remove(){
           }
           
        });
    }
    
    public Iterator getAncestorAxisIterator(Object obj) throws UnsupportedAxisException {
        if(isDocument(obj)){
            return EmptyIterator;
        }
        
        if(isAttribute(obj)){
            return getAncestorOrSelfAxisIterator((((PTBAttribute)obj)).ptbGetOwnerNode());
        }
        
        
        final PTBTreeNode r = root;
        final PTBMRGDocument d = doc;
        final PTBTreeNode node = (PTBTreeNode)obj;
        
        return (new Iterator(){
            private PTBTreeNode currentNode = (node == root)? node : (PTBTreeNode)(node.getParent());
            private boolean rootReturned = false;
            
            public boolean hasNext(){
                return (currentNode != null);
            }
            
            public Object next(){
                if(currentNode == root && rootReturned){
                    currentNode = null;
                    return d;
                }
                else{
                    PTBTreeNode retVal = currentNode;
                    if(retVal == root){
                        rootReturned = true;
                    }
                    else{
                        currentNode = (PTBTreeNode)(currentNode.getParent());
                    }
                    return retVal;
                }
            }
            
            public void remove(){
            }
        });
        
    }
    
    public Iterator getAncestorOrSelfAxisIterator(Object obj) throws UnsupportedAxisException {
        return getConcatenatedIterator(obj, getAncestorAxisIterator(obj));
    }
    
    public Iterator getAttributeAxisIterator(Object obj) throws UnsupportedAxisException {
        final Enumeration e = ((PTBTreeNode) obj).ptbGetAttributes();
        return (new Iterator(){
           public boolean hasNext(){
               return e.hasMoreElements();
           }
           
           public Object next(){
               return e.nextElement();
           }
           
           public void remove(){
               
           }
           
        });
    }
    
    public String getAttributeName(Object obj) {
        return ((PTBAttribute)obj).ptbGetLocalName();
        
    }
    
    public String getAttributeNamespaceUri(Object obj) {
        return ((PTBAttribute)obj).ptbGetNamespaceURI();
    }
    
    public String getAttributeQName(Object obj) {
        return ((PTBAttribute)obj).ptbGetQName();
        
    }
    
    public String getAttributeStringValue(Object obj) {
        return ((PTBAttribute)obj).ptbGetValue();
    }
    
    public java.util.Iterator getChildAxisIterator(Object obj) throws org.jaxen.UnsupportedAxisException {
        if(isDocument(obj)){
            return getConcatenatedIterator(root, EmptyIterator);
        }
        
        if(isAttribute(obj)){
            return EmptyIterator;
        }
        
        final PTBTreeNode node = (PTBTreeNode)obj;
        return (new Iterator(){
            private PTBTreeNode currentChild = (PTBTreeNode)(node.ptbGetFirstChild());
            
            public boolean hasNext(){
                return (currentChild != null);
            }
            
            public Object next(){
                PTBTreeNode retVal = currentChild;
                currentChild = currentChild.ptbGetNextSibling();
                
                return retVal;
            }
            
            public void remove(){
                
            }
            
            
        });
    }
    
    public String getCommentStringValue(Object obj) {
        return null;
    }
    
    public Iterator getDescendantAxisIterator(Object obj) throws UnsupportedAxisException {
        //System.err.println("Desc. Axis");
        if(isDocument(obj)){
            return getDescendantOrSelfAxisIterator(root);
        }
        
        if(isAttribute(obj)){
            return EmptyIterator;
        }
        
        final PTBTreeNode node = (PTBTreeNode)obj;
        
        return (new Iterator(){
	   private PTBTreeNode currentNode = node.ptbGetFirstChild();
           public boolean hasNext(){
               return currentNode != null;
           }
           
           public Object next(){
               PTBTreeNode retVal = currentNode;
               
               currentNode = retVal.ptbGetFirstChild();
               if(currentNode != null){
                   return retVal;
               }
               
               currentNode = retVal.ptbGetNextSibling();
               if(currentNode != null){
                   return retVal;
               }
               
               for(currentNode =  (PTBTreeNode) retVal.getParent();
               currentNode.ptbGetNextSibling() == null && currentNode != node;
               currentNode = (PTBTreeNode) currentNode.getParent()){
               }
               currentNode = (currentNode == node)? null: currentNode.ptbGetNextSibling();
 
               return retVal;
           }
           
           public void remove(){
           }
           
        });
    }
    
    public Iterator getDescendantOrSelfAxisIterator(Object obj) throws UnsupportedAxisException {
        return getConcatenatedIterator(obj, getDescendantAxisIterator(obj));
    }
    
    public Object getDocument(String str) throws FunctionCallException {
        try {
            PTBLoader loader = new PTBLoaderImpl();
            this.root = loader.load(str);
            this.doc.setDocumentElement(root);
            return this.doc;
        }catch(Exception e){
            throw(new FunctionCallException("Load Document Failed", e));
        }
    }
    
    public Object getDocumentNode(Object obj) {
        return doc;
    }
    
    public Object getElementById(Object obj, String str) {
        return null;
    }
    
    public String getElementName(Object obj) {
        return ((PTBTreeNode)obj).getLabel().getType();
    }
    
    public String getElementNamespaceUri(Object obj) {
        return null;
    }
    
    public String getElementQName(Object obj) {
        return ((PTBTreeNode)obj).getLabel().getType();
    }
    
    public String getElementStringValue(Object obj) {
        return EmptyString;
    }
    
    public Iterator getFollowingAxisIterator(Object obj) throws UnsupportedAxisException {
        if(obj instanceof PTBMRGDocument){
            return EmptyIterator;
        }
        
        if(obj instanceof PTBAttribute){
            PTBAttribute attr = (PTBAttribute)obj;
            getConcatenatedIterator(attr.ptbGetOwnerNode(), getFollowingAxisIterator(attr.ptbGetOwnerNode()));
        }
        
        PTBTreeNode node = (PTBTreeNode)obj;
	for(;node.ptbGetNextSibling()==null && node != root; node = (PTBTreeNode) node.getParent()){
	}
	node = (node == root)? null: node.ptbGetNextSibling();
        
	final PTBTreeNode n = node;
        return (new Iterator(){
	   private PTBTreeNode currentNode = n;
           public boolean hasNext(){
               return currentNode != null;
           }
           
           public Object next(){
               PTBTreeNode retVal = currentNode;
               currentNode = retVal.ptbGetFirstChild();
               
               if(currentNode != null){
                   return retVal;
               }
               
               currentNode = retVal.ptbGetNextSibling();
               if(currentNode != null){
                   return retVal;
               }
               
               for(currentNode =  (PTBTreeNode) retVal.getParent();
               currentNode.ptbGetNextSibling() == null && currentNode != root;
               currentNode = (PTBTreeNode) currentNode.getParent()){
               }
               currentNode = (currentNode == root)? null: currentNode.ptbGetNextSibling();
               
               return retVal;
           }
           
           public void remove(){
               
           }
        });
    }
    
    public java.util.Iterator getFollowingSiblingAxisIterator(Object obj) throws org.jaxen.UnsupportedAxisException {
        if(isDocument(obj) || isAttribute(obj) || obj == root){
            return EmptyIterator;
        }
        
        final PTBTreeNode n = (PTBTreeNode)obj;
        
        return (new Iterator(){
           PTBTreeNode currNode = (PTBTreeNode)(n.ptbGetNextSibling());
           
           public boolean hasNext(){
               return (currNode != null);
           }
           
           public Object next(){
               PTBTreeNode retVal = currNode;
               currNode = (PTBTreeNode)(currNode.ptbGetNextSibling());
               return retVal;
           }
           
           public void remove(){
               
           }
           
        });

    }
    
    public Iterator getNamespaceAxisIterator(Object obj) throws org.jaxen.UnsupportedAxisException {
        return EmptyIterator;
    }
    
    public String getNamespacePrefix(Object obj) {
        return EmptyString;
    }
    
    public String getNamespaceStringValue(Object obj) {
        return EmptyString;
    }
    
    public short getNodeType(Object obj) {
        if(obj instanceof PTBTreeNode){
            return Node.ELEMENT_NODE;
        }
        else if(obj instanceof PTBAttribute){
            return Node.ATTRIBUTE_NODE;
        }else if(obj instanceof PTBMRGDocument){
            return Node.DOCUMENT_NODE;
        }
        
        throw(new IllegalArgumentException("Wrong object."));
    }
    
    public Iterator getParentAxisIterator(Object obj) throws UnsupportedAxisException {
        return getConcatenatedIterator(getParentNode(obj), EmptyIterator);
        
    }
    
    public Object getParentNode(Object obj) throws UnsupportedAxisException {
        if(obj instanceof PTBMRGDocument){
            return null;
        }
        
        if(obj instanceof PTBAttribute){
            return ((PTBAttribute)obj).ptbGetOwnerNode();
        }
        
        
        Object retVal = ((PTBTreeNode)obj).getParent();
        if(retVal == null){
            return doc;
        }
        
        return retVal;
    }   
    
    public Iterator getPrecedingAxisIterator(Object obj) throws UnsupportedAxisException {
        if(obj instanceof PTBMRGDocument){
            return EmptyIterator;
        }
        
        if(obj instanceof PTBAttribute){
            PTBAttribute attr = (PTBAttribute)obj;
            getConcatenatedIterator(attr.ptbGetOwnerNode(), getPrecedingAxisIterator(attr.ptbGetOwnerNode()));
        }
        
        PTBTreeNode node = (PTBTreeNode)obj;
	for(;node.ptbGetPreviousSibling()==null && node != root; node = (PTBTreeNode) node.getParent()){
	}
	node = (node == root)? null: node.ptbGetPreviousSibling();
        
	final PTBTreeNode n = node;
        return (new Iterator(){
	   private PTBTreeNode currentNode = n;
           public boolean hasNext(){
               return currentNode != null;
           }
           
           public Object next(){
               PTBTreeNode retVal = currentNode;
               
               currentNode = retVal.ptbGetLastChild();
	       if(currentNode != null){
		   return retVal;
	       }
               
               currentNode = retVal.ptbGetPreviousSibling();
               if(currentNode != null){
                   return retVal;
               }
               
               for(currentNode =  (PTBTreeNode) retVal.getParent();
               currentNode.ptbGetPreviousSibling() == null && currentNode != root;
               currentNode = (PTBTreeNode) currentNode.getParent()){
               }
               currentNode = (currentNode == root)? null: currentNode.ptbGetPreviousSibling();

 
               return retVal;
           }
           
           public void remove(){
           }
           
        });
    }
    
    public Iterator getPrecedingSiblingAxisIterator(Object obj) throws UnsupportedAxisException {
        if(isAttribute(obj) || isDocument(obj) || obj == root){
            return EmptyIterator;
        }
        
        final PTBTreeNode n = (PTBTreeNode)obj;
        
        return (new Iterator(){
           PTBTreeNode currNode = (PTBTreeNode)(n.ptbGetPreviousSibling());
           
           public boolean hasNext(){
               return (currNode != null);
           }
           
           public Object next(){
               PTBTreeNode retVal = currNode;
               currNode = (PTBTreeNode)(currNode.ptbGetPreviousSibling());
               return retVal;
           }
           
           public void remove(){
               
           }
           
        });

    }
    
    public String getProcessingInstructionData(Object obj) {
        return EmptyString;
    }
    
    public String getProcessingInstructionTarget(Object obj) {
        return EmptyString;
    }
    
    public Iterator getSelfAxisIterator(Object obj) throws UnsupportedAxisException {
        return getConcatenatedIterator(obj, EmptyIterator);
    }
    
    public String getTextStringValue(Object obj) {
        return EmptyString;
    }
    
    public boolean isAttribute(Object obj) {
        return (obj instanceof PTBAttribute);
    }
    
    public boolean isComment(Object obj) {
        return false;
    }
    
    public boolean isDocument(Object obj) {
        return (obj instanceof PTBMRGDocument);
    }
    
    public boolean isElement(Object obj) {
        return (obj instanceof PTBTreeNode);
    }
    
    public boolean isNamespace(Object obj) {
        return false;
    }
    
    public boolean isProcessingInstruction(Object obj) {
        return false;
    }
    
    public boolean isText(Object obj) {
        return false;
    }
    
    public org.jaxen.XPath parseXPath(String str) throws org.jaxen.saxpath.SAXPathException {
        return (new PTBXPath(str, this));
    }
    
    public String translateNamespacePrefixToUri(String str, Object obj) {
        return EmptyString;
    }
    
    public static void main(String[] args){
        String ptbRoot = "Corpora/PTB/combined/wsj";
        
        try{
            PTBNavigator nav = new PTBNavigator(null);
            PTBLoaderImpl loader = new PTBLoaderImpl();
              PTBXPath xp = (PTBXPath)(nav.parseXPath("=>>::*[@raw='NP-SBJ']"));
            
            int count = 0;
            long startTime = System.currentTimeMillis();
            for(PTBTask task = new PTBTask(ptbRoot);task.hasNext();){
                PTBTreeNode root = task.next();
                
                for(Enumeration children = root.children(); children.hasMoreElements();){
                    nav.setRoot((PTBTreeNode)(children.nextElement()));
                    count += ((List)xp.evaluate(nav.getRoot())).size();
                    
                    /*
                    LinkedList ll = new LinkedList();
                    for(Iterator iter = nav.getDescendantAxisIterator(nav.getRoot()); iter.hasNext();){
                        PTBTreeNode node = (PTBTreeNode) iter.next();
                        if(node.getLabel().getType().equals("NP")){
                            count++;
                            ll.add(node);
                        }
                    }
                     */   
                     
                }
                    
                
            }
            
            
            long endTime = System.currentTimeMillis();
            System.err.println("Time taken = " + (endTime - startTime)+ "secs");
            System.err.println("Number of nodes selected = " + count);
        }catch(Exception e){
            e.printStackTrace();
            System.exit(0);
        }
        
    }
    
    public class PTBMRGDocument{
        private PTBTreeNode root;
        
        public PTBMRGDocument(PTBTreeNode root){
            this.root = root;
        }
        
        public PTBTreeNode getDocumentElement(){
            return root;
        }
        
        public void setDocumentElement(PTBTreeNode root){
            this.root = root;
        }
    }
    
}
