/*
 * SubtreeScoping.java
 *
 * Created on February 11, 2006, 7:20 PM
 */

package edu.upenn.cis.ptb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import org.jaxen.XPath;
import java.util.List;
import java.util.WeakHashMap;
import java.util.Iterator;
import java.util.LinkedList;
import edu.upenn.cis.ptb.*;

/**
 * Functional definition of the Subtree Scoping operation in LPath.. This function has the signature:
 *
 * <pre>
 *  node-set subtree(node-set, string)
 * </pre>
 *
 * The second argument is a string which should be a valid XPath expression. This
 * expression will be run against each element in the nodeset, pretending as if
 * the tree is rooted at that element. Achieves the subtree scoping effect of
 * LPath (Bird et al). For example:
 *
 * <pre>
 *  subtree(>>=::VP, '>::VB/-->::NN')
 * </pre>
 *
 * Within a VP with a VB child, select all the NN nodes which follow this VB. See
 * the PTBXPath class for how to make recursive calls.
 *
 * @author  nikhild
 * @see PTBXPath
 *
 */
public class SubtreeFunction implements Function {
    
    private PTBNavigator fNavigator = new PTBNavigator(null);
    
    private WeakHashMap fExpressionMap = new WeakHashMap();   
    
    private String fPreviousXPathStr = null;
    
    private XPath  fPreviousXPath = null;
    
    /** Creates a new instance of SubtreeScoping */
    public SubtreeFunction() {
    }
    
    public Object call(Context context, List list) throws org.jaxen.FunctionCallException {
        if(list.size() != 2){
            throw(new FunctionCallException("Number of arguments expected is 2." + list.size() + "supplied"));
        }
        
        Object arg = list.get(1);
        if(!(arg instanceof String)){
            throw(new FunctionCallException("Argument at index 1 should be a string representing the xpath expression." + arg.getClass().getName() + " supplied"));
        }
        
        String xpathStr = (String)(arg);
        XPath xp = null;
        if(xpathStr == fPreviousXPathStr){
            xp = fPreviousXPath;
        }
        else{
            fPreviousXPathStr = xpathStr;
            xpathStr = PTBXPath.unEscapeExpr(xpathStr);
            xp = (XPath)(fExpressionMap.get(xpathStr));
            fPreviousXPath = xp;
        }
        
        if(xp == null){
            try{
                xp = fNavigator.parseXPath(xpathStr);
                fPreviousXPath = xp;
            }catch(Exception e){
                throw(new FunctionCallException("Invalid xpath: " + xpathStr, e));
            }
            fExpressionMap.put(xpathStr, xp);
        }
        
        
        arg = list.get(0);
        if(!(arg instanceof List)){
            throw(new FunctionCallException("Argument at index 0 should be a list representing the nodes." + arg.getClass().getName() + " supplied"));
        }
        
        List nodes = (List)(arg);
        LinkedList result = new LinkedList();
        for(Iterator iter = nodes.iterator(); iter.hasNext();){
            Object node = iter.next();
            if(!(node instanceof PTBTreeNode)){
                throw(new FunctionCallException("Can only be evaluated in the context of PTBTreeNodes. " + node.getClass().getName() + " was in context"));
            }
            else{
                fNavigator.setRoot((PTBTreeNode)(node));
                try{
                    result.addAll(xp.selectNodes(node));
                }catch(Exception e){
                    throw(new FunctionCallException("XPath selection failed.", e));
                }
            }
        }
        fNavigator.setRoot(null);
        return result;
    }
    
}
