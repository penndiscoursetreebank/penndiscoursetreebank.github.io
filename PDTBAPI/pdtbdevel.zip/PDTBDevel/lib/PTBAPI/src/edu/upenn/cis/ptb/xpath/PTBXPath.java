/*
 * PTBXPath.java
 *
 * Created on February 11, 2006, 7:59 PM
 */

package edu.upenn.cis.ptb.xpath;

import org.jaxen.BaseXPath;
import org.jaxen.Navigator;
import org.jaxen.FunctionContext;
import org.jaxen.NamespaceContext;
import org.jaxen.JaxenException;
import org.jaxen.XPathFunctionContext;
import java.util.WeakHashMap;
import edu.upenn.cis.ptb.PTBStringBuffer;

/**
 * XPath expression providing access to the additional functions.
 *
 * <p>
 *<b> This documentation has changed since v0.2.3.</b>
 *</p>
 *
 * The following syntactic shortenings are supported:
 *
 * <table border="1">
 *   <tr><td>Standard XPath</td><td>Short Form</td></tr>
 *   <tr><td><code>self::NP</code></td><td><code>=::NP</code></td></tr>
 *   <tr><td><code>child::NP</code></td><td><code> >::NP</code></td></tr>
 *   <tr><td><code>parent::NP </code></td><td><code> <::NP</code></td></tr>
 *   <tr><td><code>descendant::NP </code></td><td><code> >>::NP</code></td></tr>
 *   <tr><td><code>descendant-or-self::NP</code></td><td><code> =>>::NP</code></td></tr>
 *   <tr><td><code>ancestor-or-self::NP</code></td><td><code> <<=::NP</code></td></tr>
 *   <tr><td><code>following::NP</code></td><td><code> ->::NP</code></td></tr>
 *   <tr><td><code>preceding::NP</code></td><td><code> <-::NP</code></td></tr>
 *   <tr><td><code>following-sibling::NP</code></td><td><code>$>::NP</code></td></tr>
 *   <tr><td><code>preceding-sibling::NP </code></td><td><code><$::NP</code></td></tr>
 * </table>
 *
 * <p>
 * All the standard functions and axes
 * should work as expected. Here are some simple Xpath queries:
 *
 * <pre>
 *  =>>::NP - selects all the nodes with constituent label NP
 *
 *  =>>::S[contains(@roles,"TPC")] - selects all the nodes with constituent label S, and
 *  role TPC.
 *
 *  =>>::John[->::Mary] - selects all the nodes with label John (terminals) 
 *  which are followed by nodes with label Mary. 
 *
 *  =>>::John/->::Mary - to select the nodes with label Mary in the query
 * above.
 * </pre>
 *
 *
 *<p>
 * The additional functions in this package are for the
 * LPath extensions (Bird et al). Nested function calls needs
 * some extra syntax, since XPath 1.0 doesn't really allow recursion. 
 * </p>
 * 
 * <p>
 * For example, consider a query to select, within a VP, all NP nodes that immediately follow
 * a VB that is a child of the VP. What we want is roughly:
 *
 * <pre>
 *  subtree(>>::VP, 'i-foll(>::VB,'=::NP')')
 * </pre>
 *
 * However this has embedded quotes which is not allowed. For this reason, quotes can be
 * replaced by curly braces.
 *
 * <pre>
 * subtree(>>::VP, {i-foll(>::VB,{=::NP})})
 * </pre>
 *
 *
 *
 * @version 2
 * @since 0.1
 * @author  nikhild
 */
public class PTBXPath extends BaseXPath{
    
    private FunctionContext fc = new PTBFunctionContext();
    private NamespaceContext nc = new PTBNamespaceContext();
    
    protected static WeakHashMap fEscapedExprMap = new WeakHashMap();
    
    /** Creates a new instance of PTBXPath */
    public PTBXPath(String xpathExpr, Navigator nav) throws JaxenException{
        super(desugarExpr(xpathExpr), nav);
    }
    
    protected FunctionContext createFunctionContext(){
        return fc;
    }
    
    protected NamespaceContext createNamespaceContext(){
        return nc;
    }
    
    public static String desugarExpr(String xpathExpr){
        PTBStringBuffer sb = new PTBStringBuffer(xpathExpr.length());
        
        int depth = 0;
        int len = xpathExpr.length();
        for(int i = 0; i < len; i++){
            char c = xpathExpr.charAt(i);
            depth = (c == '}')? depth - 1: depth;
            if(c == '{' || c == '}'){
                if(depth == 0){
                    sb.append('\'');
                }
                else{
                    sb.append('&');
                    for(int j = 1; j < depth; j++){
                        sb.append("amp;");
                    }
                    sb.append("apos;");
                }
                depth = (c == '{')? depth + 1 : depth;
            }
            else{
                if(xpathExpr.startsWith("=>>::",i)){
                    sb.append("descendant-or-self::");
                    i += 4;
                }
                else if(xpathExpr.startsWith(">>::",i)){
                    sb.append("descendant::");
                    i += 3;
                }
                else if(xpathExpr.startsWith("<<=::",i)){
                    sb.append("ancestor-or-self::");
                    i += 4;
                }
                else if(xpathExpr.startsWith("<<::",i)){
                    sb.append("ancestor::");
                    i += 3;
                }
                else if(xpathExpr.startsWith("=::",i)){
                    sb.append("self::");
                    i += 2;
                }
                else if(xpathExpr.startsWith("<::",i)){
                    sb.append("parent::");
                    i += 2;
                }
                else if(xpathExpr.startsWith(">::",i)){
                    sb.append("child::");
                    i += 2;
                }
                else if(xpathExpr.startsWith("->::",i)){
                    sb.append("following::");
                    i += 3;
                }
                else if(xpathExpr.startsWith("<-::",i)){
                    sb.append("preceding::");
                    i +=3;
                }
                else if(xpathExpr.startsWith("<$::",i)){
                    sb.append("preceding-sibling::");
                    i +=3;
                }
                else if(xpathExpr.startsWith("$>::",i)){
                    sb.append("following-sibling::");
                    i +=3;
                }
                else{
                    sb.append(c);
                }
            }
        }
        
        return sb.toString();
    }
    
    /**
     * Convenience method for creating recursive expressions. Using this makes
     * sense only if the functions are one of immediately-following, immediately-preceding, 
     * or subtree, in order to embed them inside each other. See the class level
     * docs for an example of use.
     *
     */
    public static String createExpression(String prefix, String functionName, String xpathStr, String selectorStr){
        PTBStringBuffer sb = new PTBStringBuffer(xpathStr.length());
        
        sb.append(prefix);
        if(!(prefix.equals(""))){
            sb.append(':');
        }
        sb.append(functionName);
        
        sb.append('(');
        sb.append('\'');
        for(int i = 0; i < xpathStr.length(); i++){
            char c = xpathStr.charAt(i);
            if(c == '&'){
                sb.append("&amp;");
            }
            else if(c == '\''){
                sb.append("&apos;");
            }else if(c == '"'){
                sb.append("&quot;");
            }else{
                sb.append(c);
            }
        }
        sb.append('\'');
        sb.append(',');
        sb.append(selectorStr);
        sb.append(')');
        
        return sb.toString();
    }
    
    public static String unEscapeExpr(String xpathStr){
        String unEsc = (String)(fEscapedExprMap.get(xpathStr));
        if(unEsc != null){
            return unEsc;
        }
        
        int level = 0;
        PTBStringBuffer sb = new PTBStringBuffer(xpathStr.length());
        for(int i = 0; i < xpathStr.length(); i++){
            char c = xpathStr.charAt(i);
            if(c == '&' && level == 0){
                if(xpathStr.startsWith("&apos;", i)){
                    sb.append('\'');
                    i = i + 5;
                }
                else if(xpathStr.startsWith("&quot;", i)){
                    sb.append('"');
                    i = i + 5;
                }
                else if(xpathStr.startsWith("&amp;", i)){
                    sb.append('&');
                    i = i + 4;
                }
            }
            else{
                sb.append(c);
            }
        }
        
        String val = sb.toString();
        fEscapedExprMap.put(xpathStr, val);
        return val;
    }
    
}
