/*
 * PTBLabel.java
 *
 * Created on May 12, 2005, 11:44 AM
 */

package edu.upenn.cis.ptb;

import java.util.Enumeration;
import java.io.Writer;
import java.io.IOException;

/**
 * The label associated with a PTBTreeNode.  The use of
 * the various fields are explained in the {@link PTBAttribute}
 * interface. Here are some examples:
 *
 * <pre>
 * Example 1:
 *
 *  raw: S-NOM-SBJ
 *  type: S
 *  roles: -NOM-SBJ
 *  movementIndex: -1
 *  gapIndex: -1
 *
 * Example 2:
 *
 * raw: S-TPC=2-3
 * type: S
 * roles: -TPC
 * movementIndex: 3
 * gapIndex: 2
 *
 * Example 3: (Preterminal)
 *
 * raw: -NONE-
 * type:
 * roles: -NONE-
 * movementIndex: -1
 * gapIndex: -1
 *
 * Example 4: (Terminal)
 *
 * raw: *ICH*-1
 * type: *ICH*
 * roles:
 * movementIndex: 1
 * gapIndex: -1
 *
 * Example 5: (Terminal)
 *
 * raw: Vinken
 * type: Vinken
 * roles:
 * movementIndex: -1
 * gapIndex: -1
 * 
 *
 * </pre>
 *
 * For XPath queries, all these fields are treated as attributes of a {@link PTBTreeNode}.
 * The name of the node is the <code>type</code> field. The attributes
 * <code>movementIndex</code> and <code>gapIndex</code> are considered to
 * exist iff they don't have the value -1. This makes it convenient, for example, to
 * search for all sentences containing a gap using the XPath expression 
 *  <code> .[=>>::*[@gapIndex]]</code>
 *
 *<p/>
 *
 * <b> Version 2 Changes: </b> A method updateAttributesOnNode
 * has been removed for performance reasons, and the corresponding
 * methods removed from the {@link PTBTreeNode} interface. 
 *
 * @version 2
 * @since 0.1
 * @author nikhild
 * @see PTBAttribute
 * @see PTBTreeNode
 */
public interface PTBLabel {
    public String getRaw();
    
    public String getType();
    
    public String getRoles();
    
    public boolean hasRole(String role);
    
    public int getMovementIndex();
    
    public boolean hasMovementIndex();
    
    public int getGapIndex();
    
    public boolean hasGapIndex();
    
    public PTBTreeNode getOwnerNode();
    
    public void setOwnerNode(PTBTreeNode owner);
    
    public void save(Writer writer) throws IOException;
    
}
