/*
 * PTBAttribute.java
 *
 * Created on June 10, 2005, 11:03 AM
 */

package edu.upenn.cis.ptb;

/**
 * An attribute asscoiated with a PTBTreeNode. The
 * following attributes may be present:
 *
 * <ol>
 *   <li>QName: "type" which is the constituent label. E.g. S, NP, VP, 
 *    NN (on a preterminal), John (on a terminal) </li>
 *   <li>QName: "roles" which is a hyphen separated list of roles
 *       associated with the node. Examples of roles are SBJ for subject
 *       TPC for topic etc.</li>
 *   <li>QName: "movementIndex" - A badly named attribute. If present it
 *       gives an index associated with a node. In most cases it
 *       indicates movement of an item, in which case, there will be a trace
 *       terminal with the same movementIndex. But it is also used in the first
 *       coordinate in a gapping structure. For example John ate chicken and
 *       Bill peas. The NPs John and chicken will have a movementIndices 1 and 2 resply., 
 *        and the NPs Bill and peas will have gapIndices 1 and 2 resply.
 *   </li>
 *   <li>
 *      QName: "gapIndex" - as mentioned above. Associated with nodes (not in the
 *      first coordinate in a gapping structure). 
 *   </li>
 *   <li>QName: "raw" - the raw unprocessed label. Eg. S, S-NOM-SBJ, S-TPC=2-3
      (2 is the gapIndex, and 3 is the movementIndex). </li>
 * </ol>
 *
 * For non trace terminals only the "type" and "raw" attributes will
 * be present, and they have the same values, and the same is
 * true of POS tags. Other nodes can have any of the attributes. Index 
 * and role attributes will occur only if present.
 *
 * @author nikhild
 */
public interface PTBAttribute {
    
    /**
     * The namespaceURI of the attribute.
     */    
    public String ptbGetNamespaceURI();
    
    /**
     * The local name of the attribute
     */    
    public String ptbGetLocalName();
    
    /**
     * The prefix associated with the namespace URI
     */    
    public String ptbGetPrefix();
    
    /**
     * The qualified name of the attribute
     */    
    public String ptbGetQName();
    
    /**
     * The value of the attribute
     */    
    public String ptbGetValue();
    
    /**
     * The PTBTreeNode with which this attribute is associated
     */    
    public PTBTreeNode ptbGetOwnerNode();
    
}
