/*
 * PTBTreeNodeImpl.java
 *
 * Created on May 28, 2005, 6:32 PM
 */

package edu.upenn.cis.ptb;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.MutableTreeNode;
import java.util.Enumeration;
import java.util.Vector;
import java.util.Iterator;
import java.util.TreeSet;

import java.io.Writer;
import java.io.IOException;

import edu.upenn.cis.ptb.*;




/**
 *
 * @author  nikhild
 */
public class PTBTreeNodeImpl implements PTBTreeNode{
    
    protected PTBTreeNode previousSibling = null;
    
    protected PTBTreeNode nextSibling = null;
    
    protected PTBTreeNode firstChild = null;
    
    protected PTBTreeNode lastChild = null;
    
    protected PTBLabel label = null;
    
    protected MutableTreeNode parent = null;
    
    protected Object userObject = null;
    
    private PTBAttributeImpl[] fAttributes = null;
    
    
    /** Creates a new instance of PTBTreeNodeImpl */
    public PTBTreeNodeImpl(PTBLabel label) {
        if(label.getOwnerNode() != null){
            throw(new IllegalArgumentException("Label already has an owner"));
        }
        label.setOwnerNode(this);
        
        this.label = label;
        //addAttributes();
    }
    
    private void addAttributes(){
        int count = 2;       
        
        int gapIndex = label.getGapIndex();
        count = (gapIndex == -1)? count : count + 1;
        
        int movementIndex = label.getMovementIndex();
        count = (movementIndex == -1)? count : count + 1;
        
        String roles = label.getRoles();
        int rolesLen = roles.length();
        
        count = (rolesLen == 0)? count : count + 1;
        
        fAttributes = new PTBAttributeImpl[count];
        
        int index = 0;
        
        if( gapIndex != -1){
            fAttributes[index++] = new PTBAttributeImpl("", GapIndexAttributeQName, GapIndexAttributeQName, "", "" + gapIndex,this);
        }
        
        
        if(movementIndex != -1){
            fAttributes[index++] = new PTBAttributeImpl("", MovementIndexAttributeQName, MovementIndexAttributeQName, "", "" + movementIndex,this);
        }
        
         fAttributes[index++]= new PTBAttributeImpl("", RawAttributeQName, RawAttributeQName, "", label.getRaw(),this);
        
         
        if(rolesLen != 0){
            fAttributes[index++] = new PTBAttributeImpl("", RolesAttributeQName, RolesAttributeQName, "", roles,this);
        }
        
        
        fAttributes[index] = new PTBAttributeImpl("", TypeAttributeQName, TypeAttributeQName, "", label.getType(), this);
        
    }
    
    
    public PTBLabel getLabel() {
        return label;
    }
    
    public boolean isPreterminal() {
        return (firstChild != null && firstChild == lastChild && firstChild.isLeaf());
    }
    
    public boolean isTerminal() {
        return isLeaf();
    }
    
    public boolean isTracePreterminal() {
        return (isPreterminal() && getLabel().hasRole("NONE"));
    }
    
    public boolean isTraceTerminal() {
        PTBTreeNode parent = (PTBTreeNode) (getParent());
        return ((parent == null)? false : parent.isTracePreterminal());
    }
    
    public void setLabel(PTBLabel label){
        this.label = label;
        fAttributes = null;
        addAttributes();
    }
    
    public void ptbSetFirstChild(PTBTreeNode firstChild){
        this.firstChild = firstChild;
    }
    
    public void ptbSetLastChild(PTBTreeNode lastChild){
        this.lastChild = lastChild;
    }
    
    public void ptbSetPreviousSibling(PTBTreeNode previousSibling){
        this.previousSibling = previousSibling;
    }
    
    public void ptbSetNextSibling(PTBTreeNode nextSibling){
        this.nextSibling = nextSibling;
    }
    
    public void setParent(MutableTreeNode parent){
        this.parent = parent;
    }
    
    public PTBTreeNode ptbGetFirstChild(){
        return firstChild;
    }
    
    public PTBTreeNode ptbGetLastChild(){
        return lastChild;
    }
    
    public PTBTreeNode ptbGetNextSibling(){
        return nextSibling;
    }
    
    public PTBTreeNode ptbGetPreviousSibling(){
        return previousSibling;
    }
    
    public TreeNode getParent(){
        return parent;
    }
    
    public String toString(){
        return getLabel().getRaw();
    }
    
    
    public TreeNode getChildAt(int childIndex){
        if(childIndex < 0){
            throw(new RuntimeException("Child Index should be > 0. Value supplied = " + childIndex));
        }
        
        PTBTreeNode child = firstChild;
        for(int i = 0; i < childIndex && (child != null); i++){
            child = child.ptbGetNextSibling();
        }
        
        
        return child;
    }
    
    public int getChildCount(){
        int i = 0;
        for(PTBTreeNode child = firstChild; child != null; child = child.ptbGetNextSibling()){
            i++;;
        }
        
        return i;
    }
    
    public int getIndex(TreeNode node){
        int i = 0;
        PTBTreeNode child = firstChild;
        for(; child != null && child != node; child = child.ptbGetNextSibling()){
            if(child != null){
                i++;
            }
        }

        return (child == null)? -1 : i;
    }
    
    public boolean getAllowsChildren(){
        return true;
    }
    
    public boolean isLeaf(){
        return (firstChild == null);
    }
    
    public Enumeration children(){
        final PTBTreeNode fc = firstChild;
        return (new Enumeration(){
            private PTBTreeNode currChild = fc;
            
            public boolean hasMoreElements(){
                return (currChild != null);
            }
            
            public Object nextElement(){
                PTBTreeNode retVal = currChild;
                currChild = currChild.ptbGetNextSibling();
                return retVal;
            }
            
        });
    }
    
    
    public void ptbAppendChild(MutableTreeNode nc){
        PTBTreeNode newChild = (PTBTreeNode)(nc);
        PTBTreeNode prevLastChild = lastChild;
        
        if(firstChild == null){
            firstChild = newChild;
        }
        
        lastChild = newChild;
        lastChild.ptbSetPreviousSibling(prevLastChild);
        lastChild.ptbSetNextSibling(null);
        lastChild.setParent(this);
        
        if(prevLastChild != null){
            prevLastChild.ptbSetNextSibling(lastChild);
        }        
        
    }
    
    public void insert(MutableTreeNode nc, int index){
        PTBTreeNode nextSib = (PTBTreeNode)(getChildAt(index));
        PTBTreeNode prevSib = (nextSib == null)? null : nextSib.ptbGetPreviousSibling();
        
        if(nextSib == null && prevSib == null && firstChild != null){
            throw(new RuntimeException("Illegal position to insert"));
        }
        
        PTBTreeNode newChild = (PTBTreeNode) nc;
        
        if(newChild.getParent() != null){
            throw(new RuntimeException("Child is already attached to some node"));
        }
        
        newChild.ptbSetPreviousSibling(prevSib);
        newChild.ptbSetNextSibling(nextSib);
        newChild.setParent(this);
        if(prevSib != null){
            prevSib.ptbSetNextSibling(newChild);
        }
        else{
            firstChild = newChild;
        }
        
        if(nextSib != null){
            nextSib.ptbSetPreviousSibling(newChild);
        }
        else{
            lastChild = newChild;
        }        
        
    }
    
    public void remove(int index){
        remove((MutableTreeNode)(getChildAt(index)));
    }
    
    public void remove(MutableTreeNode aChild){
        if(aChild.getParent() == this){
            PTBTreeNode child = (PTBTreeNode)(aChild);
            PTBTreeNode prevSib = child.ptbGetPreviousSibling();
            PTBTreeNode nextSib = child.ptbGetNextSibling();
            
            if(prevSib != null){
                prevSib.ptbSetNextSibling(nextSib);
            }
            else{
                firstChild = nextSib;
            }
            
            if(nextSib != null){
                nextSib.ptbSetPreviousSibling(prevSib);
            }
            else{
                lastChild = prevSib;
            }
            
            child.ptbSetNextSibling(null);
            child.ptbSetPreviousSibling(null);
            child.setParent(null);
        }
    }
    
    public void removeFromParent(){
        if(parent != null){
            parent.remove(this);
        }
    }
    
    public Object getUserObject(){
        return userObject;
    }
    
    public void setUserObject(Object userObject){
        this.userObject = userObject;
    }    
    
    
    public boolean isPunct() {
        PTBTreeNode parent = (PTBTreeNode)(getParent());
        if(parent != null){
            return parent.isPunctPreterminal();
        }
        return false;
    }
    
    public boolean isPunctPreterminal() {
        if(isPreterminal()){
            String type = getLabel().getType();
            return !(NonPunctPOSPattern.matcher(type).matches());
        }
        else{
            return false;
        }
    }
    
    public Enumeration ptbGetAttributes() {
        if(fAttributes == null){
            addAttributes();
        }
        final PTBAttributeImpl[] attrs = fAttributes;
        return (new Enumeration(){
           int index = 0;
           int length = attrs.length;
           
            public boolean hasMoreElements(){
                return (index != length);
                
            }
            
            public Object nextElement(){
                return attrs[index++];
            }
        });
    }
    
    public void save(Writer writer) throws IOException{
        save(writer, 0, 3);
    }
    
    public void save(Writer writer, int indent, int indentIncr) throws IOException{
        if(isPreterminal()){
            if(previousSibling == null || previousSibling.isPreterminal()){
                writer.write(' ');
            }
            
            writer.write('(');
            label.save(writer);
            writer.write(' ');
            firstChild.getLabel().save(writer);
            writer.write(')');
            
            if(nextSibling != null && !nextSibling.isPreterminal()){
                writer.write('\n');
                for(int i = 0; i < indent; i++){
                    writer.write(' ');
                }
            }
            
            return;
        }
        
        if(isTerminal()){
            label.save(writer);
            return;
        }
        
        
        if(parent != null){
            if(previousSibling == null && parent.getParent() != null){
                writer.write('\n');
                for(int i = 0; i < indent; i++){
                    writer.write(' ');
                }
                
            }
            writer.write('(');
            label.save(writer);
        }
        
        boolean hasNonPreterminalChild = false;
        for(PTBTreeNode child = firstChild; child != null; child = child.ptbGetNextSibling()){
            
            if(parent == null){
                writer.write('(');
            }
            
            child.save(writer, indent + indentIncr, indentIncr);
            
            if(parent == null){
                writer.write(')');
                writer.write('\n');
            }
        }
        
        if(nextSibling != null && parent != null && parent.getParent() != null){
            writer.write(')');
            writer.write('\n');
            for(int i = 0; i < indent; i++){
                writer.write(' ');
            }
        } else if(parent != null) {
            writer.write(')');
        }
        
    }
     
    
    
    public class PTBAttributeImpl implements PTBAttribute, Comparable{
        
        private String fNamespaceURI;
        
        private String fLocalName;
        
        private String fQName;
        
        private String fPrefix;
        
        private String fValue;
        
        private PTBTreeNode fOwner = null;
        
        public PTBAttributeImpl(String namespaceURI, String localName, String qName, String prefix, String value, PTBTreeNode owner){
            fNamespaceURI = namespaceURI;
            fLocalName = localName;
            fQName = qName;
            fPrefix = prefix;
            fValue = value;
            fOwner = owner;
        }
        
        public PTBAttributeImpl(){
            
        }
        
        public String ptbGetLocalName() {
            return fLocalName;
        }
        
        public String ptbGetNamespaceURI() {
            return fNamespaceURI;
        }
        
        public PTBTreeNode ptbGetOwnerNode() {
           return fOwner; 
        }
        
        public String ptbGetPrefix() {
            return fPrefix;
        }
        
        public String ptbGetQName() {
            return fQName;
        }
        
        public String ptbGetValue() {
            return fValue;
        }
        
        public boolean equals(Object o){
            PTBAttribute other = (PTBAttribute)o;
            return fQName.equals(other.ptbGetQName());
        }
        
        public int compareTo(Object o){
            PTBAttribute other = (PTBAttribute)o;
            return fQName.compareTo(other.ptbGetQName());
        }
        
        
        
    }
}
    