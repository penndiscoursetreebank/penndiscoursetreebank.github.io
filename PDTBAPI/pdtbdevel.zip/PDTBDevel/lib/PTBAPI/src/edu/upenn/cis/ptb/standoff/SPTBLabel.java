package edu.upenn.cis.ptb.standoff;

import edu.upenn.cis.ptb.*;

/**
 * Extends PTBLabel with a span. The span of a label
 * gives the character offsets in the raw file. Traces have
 * a zero length span.
 *
 * @author nikhild
 */
public interface SPTBLabel extends PTBLabel {
    
    public Span getSpan();
}
