/*
 * PTBLabelImpl.java
 *
 * Created on May 12, 2005, 11:58 AM
 */

package edu.upenn.cis.ptb;

import java.awt.Label;
import java.util.Vector;
import java.util.Iterator;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.regex.*;

import java.io.Writer;
import java.io.IOException;

import edu.upenn.cis.ptb.*;

/**
 *
 * @author  nikhild
 */
public class PTBLabelImpl implements PTBLabel{
    
    private String fRaw = null;
    
    private String fType = null;
    
    private int fMovementIndex = -1;
    
    private int fGapIndex = -1;
    
    private LinkedList fRoles;
    
    private PTBTreeNode fOwner = null;
    
    private String fRolesStr = null;
    
    /** Creates a new instance of PTBLabelImpl */
    public PTBLabelImpl(String type, String rolesStr, int gapIndex, int movementIndex,  String raw) {
        fType = type;
        fMovementIndex = movementIndex;
        fGapIndex = gapIndex;
        fRolesStr = rolesStr;
        fRaw = raw;
    }
    
    
    public String getRaw() {
        return fRaw;
    }
    
    public String getRoles() {
        return fRolesStr;
    }
    
    public int getMovementIndex() {
        return fMovementIndex;
    }
    
    public String getType() {
        return fType;
    }
    
    public boolean hasRole(String role) {
        return (fRolesStr.indexOf(role) != -1);
    }
    
    public boolean hasMovementIndex() {
        return fMovementIndex != -1;
    }
    
    public String toString(){
        return fRaw;
    }
    
    public PTBTreeNode getOwnerNode() {
        return fOwner;
    }
        
    public int getGapIndex() {
        return fGapIndex;
    }    
    
    public boolean hasGapIndex() {
        return fGapIndex != -1;
    }
    
    public void setOwnerNode(PTBTreeNode owner) {
        fOwner = owner;
    }
    
    public void save(Writer writer) throws IOException{
        writer.write(fRaw);
    }
    
}
