/*
 * PTBLoaderImpl.java
 *
 * Created on February 2, 2006, 4:26 PM
 */

package edu.upenn.cis.ptb;

import java.io.*;
import edu.upenn.cis.ptb.lexyacc.*;
import java_cup.runtime.Symbol;
import java.util.Enumeration;

/**
 * Loader with returns instances of PTBTreeNodeImpl with label PTBLabelImpl.
 * The Lex and Yacc specs do the grunt work.
 *
 * @author  nikhild
 */
public class PTBLoaderImpl implements PTBLoader{
    private Yylex fScanner = null;
    
    
    /** Creates a new instance of PTBLoaderImpl */
    public PTBLoaderImpl() {
        
    }
    
    
    public PTBTreeNode load(String ptbFileName) throws IOException {
        return load(new FileReader(new File(ptbFileName)));
    }
    
    public PTBTreeNode load(Reader reader) throws IOException {
        try{
            if(fScanner == null){
                fScanner = new Yylex(reader);
            }
            else{
                fScanner.yyreset(reader);
                fScanner.resetTreeContext();
            }
            PTBTreeNode root = fScanner.yylex();
            
            reader.close();
            return root;
            
        }catch(Exception e1){
            IOException e2 = new IOException("Read Failed.");
            e2.initCause(e1);
            throw(e2);
        }

    }
    
    public PTBTreeNode load(String ptbRoot, String secNo, String fileNo) throws IOException {
        File f = new File(new File(ptbRoot), 
                                      secNo + File.separator + "wsj_" + secNo + fileNo + ".mrg");
       
        return load(new FileReader(f));
    }
    
    
    public static void printTreeNode(PTBTreeNode node, int indent, int indentIncr){
        char[] spaces = new char[indent];
        for(int i = 0;i < indent; i++){spaces[i] = ' ';}
        
        String sp = new String(spaces);
        if(!node.isLeaf()){
            System.err.println();
            System.err.print(sp + "(");
        }
        System.err.print(node.getLabel().getRaw() + " ");
        
        for(Enumeration children = node.children(); children.hasMoreElements();){
            PTBTreeNode child = (PTBTreeNode)(children.nextElement());
            printTreeNode(child, indent + indentIncr, indentIncr);
        }
        
        if(!node.isLeaf()){
            System.err.print(")");
        }
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            if(args.length != 1){
                System.err.println("Usage: java edu.upenn.cis.ptb.PTBLoaderImpl <ptbFileName>");
                System.exit(0);
            }
            
            PTBLoaderImpl loader = new PTBLoaderImpl();
            long startTime = System.currentTimeMillis();
            PTBTreeNode root = loader.load(args[0]);
            long endTime = System.currentTimeMillis();
            
            //loader.printTreeNode(root, 3, 3);
            System.err.println("Time to load " + ((endTime - startTime)) + "ms");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
}
