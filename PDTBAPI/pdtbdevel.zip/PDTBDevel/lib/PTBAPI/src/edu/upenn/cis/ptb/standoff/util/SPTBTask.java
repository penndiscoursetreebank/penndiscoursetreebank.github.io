/*
 * PTBTask.java
 *
 * Created on March 4, 2007, 11:28 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package edu.upenn.cis.ptb.standoff.util;

import edu.upenn.cis.ptb.*;
import edu.upenn.cis.ptb.standoff.*;
import edu.upenn.cis.ptb.util.CorpusFileIterator;

import java.io.IOException;

/**
  * Utility class for iterating over the PTB. 
 *
 *  <pre>
 *   ....
 *   for(PTBTask task = new PTBTask(ptbRoot); task.hasNext(); ){
 *      PTBTreeNode root = task.next();
 *      ....
 *  }
 *  </pre>
 *
 * @since 0.2.3
 * @author nikhild
 */
public class SPTBTask {
    
    private PTBLoader fLoader = new SPTBLoaderImpl();
    
    private CorpusFileIterator fCfi;
    
    /** Creates a new instance of PTBTask */
    public SPTBTask(String ptbRoot)  {
        fCfi = new CorpusFileIterator(ptbRoot);
    }
    
    public boolean hasNext(){
        return fCfi.hasMoreFiles();
    }
    
    public PTBTreeNode next() throws IOException{
        if(fCfi.hasMoreFiles()){
            fCfi.nextFile();
            return fLoader.load(fCfi.currentFile());
        }
        return null;
    }
    
    public int getSecNo(){
        return fCfi.getSecNo();
    }
    
    public String getSecNoStr(){
        return fCfi.getSecNoStr();
    }
    
    public int getFileNo(){
        return fCfi.getFileNo();
    }
    
    public String getFileNoStr(){
        return fCfi.getFileNoStr();
    }
}
