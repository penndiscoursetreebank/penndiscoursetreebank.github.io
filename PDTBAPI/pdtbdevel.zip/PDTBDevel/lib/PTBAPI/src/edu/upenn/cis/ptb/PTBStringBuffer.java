/*
 * PDTBStringBuffer.java
 *
 * Created on April 14, 2006, 12:55 AM
 */

package edu.upenn.cis.ptb;

/**
 * Internal use only. This provides a small subset of the functionality of
 * StringBuffer, but avoids synchronization overhead. Amortized cost of inserting
 * a character is O(1).
 *
 * @author  nikhild
 */
public class PTBStringBuffer {
    
    private char[] fValue = null;
    
    private int fSize = 0;
    
    /** Creates a new instance of PDTBStringBuffer */
    public PTBStringBuffer(int initialCapacity) {
        fValue = new char[initialCapacity];
    }
    
    private void ensureCapacity(int capacity){
        int len = fValue.length;
        if(capacity > len){
            int newCapacity = Math.max(capacity, 2 * len);
            char[] newValue = new char[newCapacity];
            System.arraycopy(fValue, 0, newValue, 0, fSize);
            fValue = newValue;
        }
    }
    
    public void append(char c){
        if(fSize == fValue.length){
            ensureCapacity(fSize + 1);
        }
        fValue[fSize++] = c;
    }
    
    public void append(String s, int start, int end){
        ensureCapacity(fSize + end - start);
        
        for(int i = start; i < end; i++){
            fValue[fSize] = s.charAt(i);
            fSize++;
        }
    }
    
    public void append(String s){
        int len = s.length();
        ensureCapacity(fSize + len);
        
        for(int i = 0; i < len; i++){
            fValue[fSize] = s.charAt(i);
            fSize++;
        }
    }
    
    public void append(char[] s, int start, int end){
        ensureCapacity(fSize + end - start);
        
        for(int i = start; i < end; i++){
            fValue[fSize] = s[i];
            fSize++;
        }
    }
    
    public void append(char[] s){
        int len = s.length;
        ensureCapacity(fSize + len);
        
        for(int i = 0; i < len; i++){
            fValue[fSize] = s[i];
            fSize++;
        }
    }
    
    public void delete(){
        fSize = 0;
    }
    
    public int length(){
        return fSize;
    }
    
    
    public String toString(){
        return new String(fValue, 0, fSize);
    }
    
}
