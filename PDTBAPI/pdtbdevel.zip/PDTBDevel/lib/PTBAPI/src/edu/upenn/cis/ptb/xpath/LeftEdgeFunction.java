/*
 * SubtreeScoping.java
 *
 * Created on February 11, 2006, 7:20 PM
 */

package edu.upenn.cis.ptb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import org.jaxen.Navigator;
import org.jaxen.XPath;
import java.util.List;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import edu.upenn.cis.ptb.*;

/**
 * Left Edge check of LPath. This function has the signature:
 *
 * <pre>
 * boolean l-edge()
 * </pre>
 *
 * Returns true if the context node has no node on its preceding axis, i.e.,
 * it is on the left periphery of the tree. For example:
 *
 * <pre>
 *  =>>::S/=>>::NP[l-edge()]
 * </pre>
 * 
 * Selects all the NPs on the left edge that are dominated by an S.
 *
 * @author  nikhild
 * @see PTBXPath
 */
public class LeftEdgeFunction implements Function {
    
    private PTBNavigator fNavigator = new PTBNavigator(null);
    
    private HashMap fExpressionMap = new HashMap();
    
    /** Creates a new instance of SubtreeScoping */
    public LeftEdgeFunction() {
    }
    
    public Object call(Context context, List list) throws org.jaxen.FunctionCallException {
        int position = context.getPosition();
        int size = Math.min(context.getSize(), context.getNodeSet().size());
        
        if(size == 1 && position > size){
            position = 1;
        }
        
        //System.err.println("Node set size = " + context.getNodeSet().size() + " ContextSize=" + size + " ContextPosition=" + position);
        Object node = (position > size)? null : context.getNodeSet().get(position - 1);
        if(node == null){
            return new Boolean(false);
        }
        else{
            return hasNoPrecedingNode(node, context.getNavigator());
        }
    }
    
    private Boolean hasNoPrecedingNode(Object node, Navigator nav) throws FunctionCallException{
        try{
            for(Iterator iter = nav.getAncestorOrSelfAxisIterator(node);iter.hasNext();){
                for(Iterator iter2 = nav.getPrecedingSiblingAxisIterator(iter.next());iter2.hasNext();){
                    return new Boolean(false);
                }
            }
        }catch(Exception e){
            throw(new FunctionCallException("Exception while searching for the first node in following axis.", e));
        }
        return new Boolean(true);
    }
    
    
    
}
