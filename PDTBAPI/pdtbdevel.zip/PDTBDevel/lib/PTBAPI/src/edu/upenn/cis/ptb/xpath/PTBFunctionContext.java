/*
 * PTBFunctionContext.java
 *
 * Created on February 11, 2006, 7:47 PM
 */

package edu.upenn.cis.ptb.xpath;

import org.jaxen.SimpleFunctionContext;
import org.jaxen.function.CountFunction;
import org.jaxen.XPathFunctionContext;

/**
 * This class does nothing since 0.2.3.
 *
 * @author  nikhild
 * @see PTBXPath
 */
public class PTBFunctionContext extends XPathFunctionContext{
    
    public static final String PTBSubtreeScopingFunctionName = "subtree";
    
    public static final String PTBImmediatelyFollowingFunctionName = "i-foll";
    
    public static final String PTBImmediatelyPrecedingFunctionName = "i-prec";
    
    public static final String PTBRightEdgeFunction = "r-edge";
    
    public static final String PTBLeftEdgeFunction = "l-edge";
    
    /** Creates a new instance of PTBFunctionContext */
    public PTBFunctionContext() {
        super();
        registerFunction(null, 
        PTBSubtreeScopingFunctionName, new SubtreeFunction());
        registerFunction(null, 
        PTBImmediatelyFollowingFunctionName, new ImmediatelyFollowingFunction());
        registerFunction(null, 
        PTBImmediatelyPrecedingFunctionName, new ImmediatelyPrecedingFunction());
        registerFunction(null, 
        PTBRightEdgeFunction, new RightEdgeFunction());
        registerFunction(null, 
        PTBLeftEdgeFunction, new LeftEdgeFunction());
        registerFunction(null, "regexp", new RegexpFunction());
    }
    
    
    
}
