package edu.upenn.cis.ptb.standoff;

import edu.upenn.cis.ptb.*;

/**
 * 
 * @author nikhild
 */
public class SPTBLabelImpl extends PTBLabelImpl implements SPTBLabel {
    
    private Span fSpan;
    
    public SPTBLabelImpl(String type, String rolesStr, int gapIndex, int movementIndex,  String raw, Span s) {
        super(type, rolesStr, gapIndex, movementIndex, raw);
        fSpan = s;
    }

    public SPTBLabelImpl(PTBLabel label, Span s){
        this(label.getType(), label.getRoles(), label.getGapIndex(), label.getMovementIndex(), label.getRaw() + "{" + s.toString() + "}", s);
    }
    
    public Span getSpan(){
        return fSpan;
    }
    
}
