package edu.upenn.cis.ptb.standoff;

import edu.upenn.cis.ptb.*;
import edu.upenn.cis.ptb.util.*;
import java.util.logging.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;

/**
 * Script to create a standoff version of the PTB.
 *
 * @author nikhild
 */
public class MakeStandoff {
    
    public static final Logger log = Logger.getLogger("MakeStandoffLogger");
    
    public MakeStandoff() {
    }
    
    /**
     * Creates a standoff version of the PTB. Parameters are as follows:
     *
     * @param ptbRoot The root dir of the .mrg files
     * @param rawRoot The root dir of the raw files
     * @param outputRoot The directory in which the standoff version is written
     * @param logFile Logs the results. Grep the log file for "Fail" to see the files for which
     * conversion failed. It should fail for 8 files.
     *
     * @throws IOException If there is a read or write failure. Conversion failures will be written to the logFile.
     *
     */
    public static void makeStandoff(String ptbRoot, String rawRoot, String outputRoot, String logFile) throws IOException {
        Handler logHandler = new FileHandler(logFile);
        log.addHandler(logHandler);
        log.setLevel(Level.FINE);
        
        File rawRootDir = new File(rawRoot);
        PTBStringBuffer buff = new PTBStringBuffer(8192);
        char[] rawBuffer = new char[8192];
        
        File outputDir = new File(outputRoot);
        if(!outputDir.exists()){
            outputDir.mkdirs();
        }
            
        for(PTBTask task = new PTBTask(ptbRoot); task.hasNext();){
            PTBTreeNode root = task.next();
            String secNo = task.getSecNoStr();
            String fileNo = task.getFileNoStr();
            
            File rawFile = new File(rawRootDir, secNo + File.separator + "wsj_" + secNo + fileNo);
            FileReader fr = new FileReader(rawFile);
            int numChars;
            
            while((numChars = fr.read(rawBuffer)) != -1){
                buff.append(rawBuffer, 0, numChars);
            }
            
            fr.close();
            
            String rawText = buff.toString();
            buff.delete();
            
            PTBTreeNode standoffRoot = makeStandoff(root, rawText, secNo, fileNo);
            
            if(standoffRoot != null){
                File secDir = new File(outputDir, secNo);
                secDir.mkdirs();
                File outFile = new File(secDir, "wsj_" + secNo + fileNo + ".mrg");
                Writer writer = new BufferedWriter(new FileWriter(outFile));
                standoffRoot.save(writer);
                writer.close();
            }
        }
        
        log.removeHandler(logHandler);
        logHandler.flush();
        logHandler.close();
    }
    
    public static PTBTreeNode makeStandoff(PTBTreeNode root, String rawText, String secNo, String fileNo){
        int currentIndex = 0;
            
        try{

            log.fine("Processing Section " + secNo + " File " + fileNo);
            
            
            Span sp = new Span(0, rawText.length());
            PTBLabel rootLabel = new SPTBLabelImpl(root.getLabel(), sp);
            PTBTreeNode standoffRoot = new PTBTreeNodeImpl(rootLabel);
            
            for(Enumeration children = root.children(); children.hasMoreElements();){
                currentIndex = advanceOverWhitespace(rawText, currentIndex);
                PTBTreeNode child = alignToText((PTBTreeNode) children.nextElement(), rawText, currentIndex);
                currentIndex = ((SPTBLabelImpl) child.getLabel()).getSpan().getEnd();
                standoffRoot.ptbAppendChild(child);
            }
            
            
            log.fine("Successful");
            
            return standoffRoot;
            
        }catch(Exception e){
            int startIndex = currentIndex;
            int endIndex = (rawText.length() > startIndex + 11)? startIndex + 10 : rawText.length();
            log.fine("Failed. For " + " Section-" + secNo + " File-" + fileNo + ". The currentIndex was " + currentIndex + " Relevant substring = " + rawText.substring(startIndex, endIndex));
            log.fine(e.getMessage());
        }
        
        return null;
        
    }
    
    public static PTBTreeNode alignToText(PTBTreeNode node, String rawText, int currentIndex){
        int oldIndex = currentIndex;
        
        if(node.isTerminal()){
            String labelStr = node.getLabel().toString();
            
            
            if(!node.isTraceTerminal()){
                oldIndex = advanceOverWhitespace(rawText, currentIndex);
                
                labelStr = (labelStr.equals("``"))? "\"" : labelStr;
                labelStr = (labelStr.equals("''"))? "\"" : labelStr;
                labelStr = (labelStr.equals("-LRB-"))? "(" : labelStr;
                labelStr = (labelStr.equals("-RRB-"))? ")" : labelStr;
                labelStr = (labelStr.equals("-LSB-"))? "[" : labelStr;
                labelStr = (labelStr.equals("-RSB-"))? "]" : labelStr;
                labelStr = (labelStr.equals("-LCB-"))? "{" : labelStr;
                labelStr = (labelStr.equals("-RCB-"))? "}" : labelStr;
                labelStr = (labelStr.equals("..."))? ". . ." : labelStr;
                labelStr = labelStr.replaceAll("\\\\", "");
                labelStr = labelStr.replaceAll("``", "\"");
                labelStr = labelStr.replaceAll("''", "\"");
                labelStr = labelStr.equals("'T-")? "'T" : labelStr;
                
                try{
                    currentIndex = advanceByString(rawText, oldIndex, labelStr);
                }catch(IllegalArgumentException e){
                    String saveLabel = labelStr;
                    if(labelStr.equals(".")){
                        currentIndex = oldIndex;
                    }
                    else{
                        labelStr = labelStr.replaceFirst("'","`");
                        
                        try{
                            currentIndex = advanceByString(rawText, oldIndex, labelStr);
                        }catch(IllegalArgumentException e1){
                            try{
                                labelStr = saveLabel;
                                labelStr = labelStr.replaceAll("`", "'");
                                currentIndex = advanceByString(rawText, oldIndex, labelStr);
                            }catch(IllegalArgumentException e2){
                                try{
                                    labelStr = saveLabel;
                                    labelStr = labelStr.toLowerCase();
                                    currentIndex = advanceByString(rawText, oldIndex, labelStr);
                                }catch(IllegalArgumentException e3){
                                    
                                        labelStr = saveLabel;
                                        
                                        if(labelStr.equals(". . .")){
                                            labelStr = "...";
                                            currentIndex = advanceByString(rawText, oldIndex, labelStr);
                                        }else{
                                    
                                        labelStr = saveLabel;
                                        
                                        labelStr = labelStr.replaceAll("\\.","");
                                        currentIndex = advanceByString(rawText, oldIndex, labelStr);
                                        }
                                        
                                    
                                }
                            }
                        }
                    }
                  
                }
            } 
            
            Span sp = new Span(oldIndex, currentIndex);
            PTBLabel label = new SPTBLabelImpl(node.getLabel(), sp);
            return new PTBTreeNodeImpl(label);
 
            
        }
        else{
            
            Vector cVect = new Vector();
            for(Enumeration children = node.children(); children.hasMoreElements();){
                PTBTreeNode child = (PTBTreeNode) children.nextElement();
                PTBTreeNode retChild  = alignToText(child, rawText, currentIndex);
                cVect.add(retChild);
                currentIndex = ((SPTBLabelImpl) retChild.getLabel()).getSpan().getEnd();
                
                
            }
            
            PTBTreeNode firstChild = (PTBTreeNode) cVect.firstElement();
            PTBTreeNode lastChild = (PTBTreeNode) cVect.lastElement();
            Span sp = new Span(((SPTBLabelImpl) firstChild.getLabel()).getSpan().getStart(),
                                             ((SPTBLabelImpl) lastChild.getLabel()).getSpan().getEnd());
            
            PTBTreeNode retVal = new PTBTreeNodeImpl(new SPTBLabelImpl(node.getLabel(), sp));
            for(Enumeration children = cVect.elements(); children.hasMoreElements();){
                PTBTreeNode child = (PTBTreeNode) children.nextElement();
                retVal.ptbAppendChild(child);
            }
            
            return retVal;
            
        }
        
        
    }
    
    public static int advanceByString(String orig, int start, String advanceBy){
        try{
            
            if(orig.substring(start, start + 4).equals("----")){
                start += 2;
                
            }
            
            if(orig.substring(start, start + 3).equals("---")){
                start++;
            }
        }catch(Exception e){
            
        }
        
        int len = advanceBy.length();
        
        String subs = orig.substring(start, start + len);

        if(!subs.equals(advanceBy)){
            for(int i = 0; i < len ; i++){
                if(orig.charAt(start) != advanceBy.charAt(i)){
                    throw(new IllegalArgumentException("Attempted to advance by wrong string " + advanceBy + " actual string = " + subs));
                }
                else{
                    start++;
                    start = advanceOverWhitespace(orig,start);
                }
            }
            
            return start;
            
        }
        
        return start + len;
        
    }
    
    public static int advanceOverWhitespace(String orig, int start){
        char c = orig.charAt(start);
        int len = orig.length();
        
        while((c == ' ' || c == '\r' || c == '\n' || c == '\t' || c == '>' || c == '<' || c == (char)(213) || c == (char)(229)) && start < (len - 1)){
            start++;
            c = orig.charAt(start);
        }
        
        if(start + 6 <= orig.length() && orig.substring(start, start + 6).equals(".START")){
            start += 6;
            
            return advanceOverWhitespace(orig, start);
        }
        
        if(start + 2 <= orig.length() && orig.substring(start, start + 2).equals("e/")){
            start += 2;
            
            return advanceOverWhitespace(orig, start);
        }
        
        return start;
    }
    
    /**
     * Main method. Usage:
     *
     * <pre>
     *   java edu.upenn.cis.ptb.standoff.MakeStandoff <ptbRoot> <rawRoot> <outputRoot> <logFile>
     * </pre>
     */
    public static void main(String[] args){
        if(args.length != 4){
            System.err.println("Usage: java edu.upenn.cis.ptb.standoff.MakeStandoff <ptbRoot> <rawRoot> <outputRoot> <logFile>");
            System.err.println( "" + args.length);
            System.exit(0);
        }
        
        try{
            makeStandoff(args[0], args[1], args[2], args[3]);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
