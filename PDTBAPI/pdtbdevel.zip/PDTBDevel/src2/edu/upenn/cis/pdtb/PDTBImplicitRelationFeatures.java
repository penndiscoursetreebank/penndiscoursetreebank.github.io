/*
 * PDTBImplicitRelationFeatures.java
 *
 * Created on January 22, 2006, 6:33 PM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.pdtb.util.TreeEnumFeature;

/**
 * Features associated with an implicit relation.
 * @author nikhild, geraud
 */
public interface PDTBImplicitRelationFeatures extends PDTBConnFeatures {
    /**
     * QName of the attribute whose value gives a connective expressing the
     * relation. Used iff the type is PDTBImplicitRelationFeatures.EConn.
     */    
    public static final String Conn1AttrQName = "conn1";
    
    /**
     * QName of the attribute whose value gives the semantic class of the value
     * of PDTBImplicitRelationFeatures.Conn1.
     */    
    public static final TreeEnumFeature SClass1A = new TreeEnumFeature("sClass1A", semanticClassesTree);
    public static final TreeEnumFeature SClass1B = new TreeEnumFeature("sClass1B", semanticClassesTree);
    
    /**
     * QName of the attribute whose value gives a connective expressing the
     * relation. Used only if the type is PDTBImplicitRelationFeatures.EConn.
     */    
    public static final String Conn2AttrQName = "conn2";
    
    /**
     * QName of the attribute whose value gives the semantic class of the value
     * of PDTBImplicitRelationFeatures.Conn2
     */    
    public static final TreeEnumFeature SClass2A = new TreeEnumFeature("sClass2A", semanticClassesTree);
    public static final TreeEnumFeature SClass2B = new TreeEnumFeature("sClass2B", semanticClassesTree);
    
    /**
     * Get a connective that expresses the relation
     */    
    public String getConn1();
    
    /**
     * Get the first semantic class of Conn1.
     */    
    public TreeEnumFeature getSClass1A();
    
    /**
     * Get the second semantic class of Conn1.
     */    
    public TreeEnumFeature getSClass1B();
    
    /**
     * Get a second connective that expresses the relation.
     */    
    public String getConn2();
    
    /**
     * Get the first semantic class of Conn2.
     */  
    public TreeEnumFeature getSClass2A();
    
    /**
     * Get the second semantic class of Conn2.
     */  
    public TreeEnumFeature getSClass2B();
}
