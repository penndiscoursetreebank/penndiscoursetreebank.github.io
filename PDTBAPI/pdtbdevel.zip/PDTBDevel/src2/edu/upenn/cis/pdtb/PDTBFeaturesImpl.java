/*
 * PDTBFeaturesImpl.java
 *
 * Created on November 28, 2005, 11:57 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

import edu.upenn.cis.pdtb.util.EnumFeature.EnumIndex;

/**
 * Implementation of the PDTBFeatures interface.
 * 
 * @author nikhild, geraud
 */
public abstract class PDTBFeaturesImpl implements PDTBFeatures{

	private PDTBNode fNode;

	private EnumIndex fSource;

	private EnumIndex fType;

	private EnumIndex fPolarity;

	private EnumIndex fDeterminancy;
	
	protected PDTBSelection fSel;

	public PDTBNode getPDTBNode() {
		return fNode;
	}

	public EnumIndex getSource() {
		return fSource;
	}

	public EnumIndex getType() {
		return fType;
	}

	public EnumIndex getPolarity() {
		return fPolarity;
	}

	public EnumIndex getDeterminancy() {
		return fDeterminancy;
	}
	
	public void setSource(EnumIndex i) {
		fSource = i;
	}

	public void setType(EnumIndex i) {
		fType = i;
	}

	public void setPolarity(EnumIndex i) {
		fPolarity = i;
	}

	public void setDeterminancy(EnumIndex i) {
		fDeterminancy = i;
	}

    public void setSelection(PDTBSelection sel) {
    	fSel = sel;
    	fSel.updateAttributesOnNode();
    }
	
	public PDTBSelection getSelection(){
		return fSel;
	}
	
	public void setPDTBNode(PDTBNode node) {
		fNode = node;
	}

	public abstract void updateAttributesOnNode();

	public abstract void save(Writer writer) throws IOException;

}
