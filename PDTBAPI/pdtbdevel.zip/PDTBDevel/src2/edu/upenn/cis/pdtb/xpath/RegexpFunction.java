/*
 * RegexpFunction.java
 *
 * Created on February 11, 2006, 7:20 PM
 */

package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import org.jaxen.function.StringFunction;
import java.util.List;
import java.util.WeakHashMap;
import java.util.regex.*;

/**
 * Regular Expressions. This function has the signature:
 * 
 * <pre>
 *  boolean regexp(string, string, string (optional))
 * </pre>
 * 
 * The first argument is a string, the second argument is a regular expression,
 * and the third optional argument is a boolean. If the third argument is true,
 * ignores case (false by default if omitted). Returns true if the first argument matches
 * the second. Used by PDTBXPath. For example:
 * 
 * <pre>
 * //*[@connHead='if' and child::Arg2[regexp(@rawText,&quot;.*\\W*not\\W*.*&quot;)]]
 * </pre>
 * 
 * 
 * @author nikhild, geraud
 * @see PDTBXPath
 * 
 */
public class RegexpFunction implements Function {

	private WeakHashMap fExpressionMap = new WeakHashMap();

	private StringFunction sf = new StringFunction();

	public RegexpFunction() {
	}

	public Object call(Context context, List list)
			throws org.jaxen.FunctionCallException {
		if (list.size() != 2 && list.size() != 3) {
			throw (new FunctionCallException(
					"Number of arguments expected is 2 or 3." + list.size()
							+ "supplied"));
		}

		Object arg = list.get(0);
		if (!(arg instanceof String)) {
			if (arg instanceof List) {
				arg = sf.call(context, (List) arg);
			} else {
				throw (new FunctionCallException(
						"Argument at index 0 should be a string"));
			}
		}

		String toBeMatched = (String) arg;

		arg = list.get(1);
		if (!(arg instanceof String)) {
			throw (new FunctionCallException(
					"Argument at index 1 should be a regular expression"));
		}
		String regexStr = (String) arg;

		Pattern pat = (Pattern) fExpressionMap.get(regexStr);

		boolean caseInsensitive = false;
		if (list.size() == 3) {
			arg = list.get(2);
			if (!(arg instanceof String)) {
				throw (new FunctionCallException(
						"Argument at index 2 should be a Boolean"));
			}
			caseInsensitive = ((String) arg).equalsIgnoreCase("true");
		}

		if (pat == null) {
			if (caseInsensitive) {
				pat = Pattern.compile(regexStr, Pattern.DOTALL
						| Pattern.CASE_INSENSITIVE);
			} else {
				pat = Pattern.compile(regexStr, Pattern.DOTALL);
			}
			fExpressionMap.put(regexStr, pat);
		}

		if (pat.matcher(toBeMatched).matches()) {
			return Boolean.TRUE;
		}

		return Boolean.FALSE;
	}

}
