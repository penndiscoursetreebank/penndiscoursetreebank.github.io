/*
 * PDTBArgFeatures.java
 *
 * Created on July 09, 2007, 4:00 PM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.pdtb.util.EnumFeature;

/**
 * The base class of the features associated with a PDTBNode. In this base form,
 * it is associated with PDTBArg. Subclasses are associated with relations.
 * 
 * @since 3.0
 * @author geraud
 */
public interface PDTBArgFeatures extends PDTBFeatures {

	/**
	 * Possible values: "Arb", "Inh", "Ot", "Wr"
	 */
	public static final EnumFeature SourceFeature = options.getArgSourceFeature();

	/**
	 * Possible values: "Comm", "Ctrl", "Ftv", "Null", "PAtt"
	 */
	public static final EnumFeature TypeFeature = options.getArgTypeFeature();

	/**
	 * Possible values: "Neg", "Null"
	 */
	public static final EnumFeature PolarityFeature = options.getArgPolarityFeature();

	/**
	 * Possible values: "Indet", "Null"
	 */
	public static final EnumFeature DeterminancyFeature = options.getArgDeterminancyFeature();
}
