/*
 * VTreeCellRendererImpl.java
 *
 * Created on September 19, 2004, 7:50 PM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.JLabel;
import java.awt.Component;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.tree.TreeNode;
import java.awt.Graphics;
import org.annotation.agschema.graphics.vtree.*;
import edu.upenn.cis.ptb.*;
import edu.upenn.cis.pdtb.*;
import java.util.HashSet;
import edu.upenn.cis.pdtb.util.*;
import java.util.Enumeration;
import java.util.Iterator;
import edu.upenn.cis.ptb.xpath.*;

/**
 * Each node is drawn as a label with text obtained by messaging toString() on
 * the node. The backround color is set if the correponding PDTBNode is
 * selected, i.e., if an Arg1 PDTBNode is selected, and the node to be rendered
 * is a descendant of some node in getSelection().getPTBNodes(), then the
 * appropriate background is set.
 * 
 * @author nikhild, geraud
 */
public class PTBCellRendererImpl extends JLabel implements VTreeCellRenderer,
		PDTBNodeSelectionListener, FontChangeListener {
	// hashes of treenodes corresponding to the appropriate PDTBNode that is
	// selected. AltLex selection goes in fExplicitConnHash, and the implicit
	// relation inference site has no effect here.
	private HashSet fExplicitConnHash = new HashSet();

	private HashSet fArg1Hash = new HashSet();

	private HashSet fArg2Hash = new HashSet();

	private HashSet fSup1Hash = new HashSet();

	private HashSet fSup2Hash = new HashSet();

	private HashSet fConnFeatHash = new HashSet();

	private HashSet fArg1FeatHash = new HashSet();

	private HashSet fArg2FeatHash = new HashSet();

	// The currently selected trees need to be repainted.
	private boolean[] fRepaintSet;

	// One canvas for each parse tree, so repaints can be messaged.
	private VTreeCanvas[] fCanvases;

	private int fNumCanvases;

	// Root node of the PTB file. Parse tree roots are its children
	private PTBTreeNode fRoot;

	// Some iterators are used from the navigator
	private PTBNavigator fNavigator;

	/** Creates a new instance of VTreeCellRendererImpl */
	public PTBCellRendererImpl(PTBTreeNode root, VTreeCanvas[] canvases) {
		super();

		setFont(FontProvider.PDTBBrowserFontProvider.getCurrentFont());
		FontProvider.PDTBBrowserFontProvider.addListener(this);

		// Set this as the cell rendere for all the canvases
		fRoot = root;
		fCanvases = canvases;
		fNumCanvases = fCanvases.length;
		for (int i = 0; i < fNumCanvases; i++) {
			fCanvases[i].setCellRenderer(this);
		}

		fRepaintSet = new boolean[fNumCanvases];

		fNavigator = new PTBNavigator(fRoot);

	}

	/**
	 * Clears the old selection.
	 */
	private void refreshSelection() {
		HashSet[] hashes = { fExplicitConnHash, fArg1Hash, fArg2Hash,
				fSup1Hash, fSup2Hash, fConnFeatHash, fArg1FeatHash,
				fArg2FeatHash };

		for (int i = 0; i < hashes.length; i++) {
			hashes[i].clear();
		}

		for (int i = 0; i < fNumCanvases; i++) {
			boolean repaint = fRepaintSet[i];
			// if the canvas was in the selection, it needs repainting
			if (repaint) {
				fCanvases[i].repaint();
				fRepaintSet[i] = false;
			}
		}

	}

	/**
	 * Update the hashes.
	 */
	private void updateHash(HashSet s, PDTBSup sup) {
		GornAddressList gal = sup.getSelection().getAddresses();
		for (Enumeration e = GornAddressUtils.getNodes(gal, fRoot); e
				.hasMoreElements();) {
			try {
				// add the node and it's descendants to the appropriate set
				for (Iterator iter = fNavigator
						.getDescendantOrSelfAxisIterator(e.nextElement()); iter
						.hasNext();) {
					s.add(iter.next());
				}
			} catch (Exception exception) {

			}

		}
		// Update the repaint set
		for (Iterator iter = gal.iterator(); iter.hasNext();) {
			int i = ((int[]) (iter.next()))[0];
			fRepaintSet[i] = true;
		}

	}

	private void updateHash(HashSet s, PDTBFeatures feats) {
		PDTBSelection sel = feats.getSelection();
		if (sel != null) {
			GornAddressList gal = sel.getAddresses();
			for (Enumeration e = GornAddressUtils.getNodes(gal, fRoot); e
					.hasMoreElements();) {
				try {
					// add the node and it's descendants to the appropriate set
					for (Iterator iter = fNavigator
							.getDescendantOrSelfAxisIterator(e.nextElement()); iter
							.hasNext();) {
						s.add(iter.next());
					}
				} catch (Exception exception) {

				}

			}
			// Update the repaint set
			for (Iterator iter = gal.iterator(); iter.hasNext();) {
				int i = ((int[]) (iter.next()))[0];
				fRepaintSet[i] = true;
			}
		}

	}

	private void updateHash(HashSet s, PDTBExplicitRelation rel) {
		GornAddressList gal = rel.getSelection().getAddresses();
		for (Enumeration e = GornAddressUtils.getNodes(gal, fRoot); e
				.hasMoreElements();) {
			try {
				for (Iterator iter = fNavigator
						.getDescendantOrSelfAxisIterator(e.nextElement()); iter
						.hasNext();) {
					s.add(iter.next());

				}
			} catch (Exception exception) {

			}

		}

		for (Iterator iter = gal.iterator(); iter.hasNext();) {
			int i = ((int[]) (iter.next()))[0];
			fRepaintSet[i] = true;
		}

	}

	private void updateHash(HashSet s, PDTBAltLexRelation rel) {
		GornAddressList gal = rel.getSelection().getAddresses();
		for (Enumeration e = GornAddressUtils.getNodes(gal, fRoot); e
				.hasMoreElements();) {
			try {
				for (Iterator iter = fNavigator
						.getDescendantOrSelfAxisIterator(e.nextElement()); iter
						.hasNext();) {
					s.add(iter.next());

				}
			} catch (Exception exception) {

			}

		}

		for (Iterator iter = gal.iterator(); iter.hasNext();) {
			int i = ((int[]) (iter.next()))[0];
			fRepaintSet[i] = true;
		}

	}

	private void repaintCanvases() {
		for (int i = 0; i < fNumCanvases; i++) {
			if (fRepaintSet[i]) {
				fCanvases[i].repaint();
			}
		}
	}

	public Component getTreeCellRendererComponent(VTreeCanvas vTree,
			TreeNode node, boolean isSelected, boolean hasFocus,
			boolean isLeaf, boolean isExpanded) {
		// Set the text
		setText(node.toString());

		// Set the background colour
		if (fExplicitConnHash.contains(node)) {
			setBackground(ColorConstants.ExplicitConnColor);
		} else if (fConnFeatHash.contains(node)) {
			setBackground(ColorConstants.ExplicitConnAttribColor);
		} else if (fArg1Hash.contains(node)) {
			setBackground(ColorConstants.Arg1Color);
		} else if (fArg1FeatHash.contains(node)) {
			setBackground(ColorConstants.Arg1AtrribColor);
		} else if (fArg2Hash.contains(node)) {
			setBackground(ColorConstants.Arg2Color);
		} else if (fArg2FeatHash.contains(node)) {
			setBackground(ColorConstants.Arg2AtrribColor);
		} else if (fSup1Hash.contains(node)) {
			setBackground(ColorConstants.Sup1Color);
		} else if (fSup2Hash.contains(node)) {
			setBackground(ColorConstants.Sup2Color);
		} else {
			setBackground(vTree.getBackground());
		}
		if (fConnFeatHash.contains(node) || fArg1FeatHash.contains(node)
				|| fArg2FeatHash.contains(node)) {
			Font font = getFont();
			setFont(new Font(font.getName(), Font.ITALIC, font.getSize()));
		}
		/*
		 * else if(fExplicitConnHash.contains(node) || fArg1Hash.contains(node) ||
		 * fArg2Hash.contains(node) || fSup1Hash.contains(node) ||
		 * fSup2Hash.contains(node)){ Font font = getFont(); setFont(new
		 * Font(font.getName(), Font.BOLD, font.getSize())); vTree.repaint(); }
		 */
		else {
			Font font = getFont();
			setFont(new Font(font.getName(), Font.PLAIN, font.getSize()));
		}
		return this;
	}

	protected void firePropertyChange(String propertyName, Object oldValue,
			Object newValue) {
		if (propertyName.equals("text"))
			super.firePropertyChange(propertyName, oldValue, newValue);
	}

	public void firePropertyChange(String propertyName, boolean oldValue,
			boolean newValue) {
	}

	public void firePropertyChange(String propertyName, int oldValue,
			int newValue) {
	}

	public void firePropertyChange(String propertyName, char oldValue,
			char newValue) {
	}

	public void firePropertyChange(String propertyName, double oldValue,
			double newValue) {
	}

	public void firePropertyChange(String propertyName, float oldValue,
			float newValue) {
	}

	public void firePropertyChange(String propertyName, long oldValue,
			long newValue) {
	}

	public void firePropertyChange(String propertyName, byte oldValue,
			byte newValue) {
	}

	public void validate() {
	}

	public void revalidate() {
	}

	public void repaint(long tm, int x, int y, int width, int height) {
	}

	public void repaint(Rectangle r) {
	}

	public void paint(Graphics g) {
		g.setColor(getBackground());
		g.fillRect(0, 0, getWidth(), getHeight());
		super.paint(g);
	}

	public void arg1Selected(PDTBSup arg1) {
		refreshSelection();
		updateHash(fArg1Hash, arg1);
		if (arg1 instanceof PDTBArg) {
			updateHash(fArg1FeatHash, ((PDTBArg) arg1).getFeatures());
		}
		repaintCanvases();

	}

	public void arg2Selected(PDTBSup arg2) {
		refreshSelection();
		updateHash(fArg2Hash, arg2);
		if (arg2 instanceof PDTBArg) {
			updateHash(fArg2FeatHash, ((PDTBArg) arg2).getFeatures());
		}
		repaintCanvases();
	}

	public void explicitRelationSelected(PDTBExplicitRelation rel) {
		refreshSelection();
		updateHash(fExplicitConnHash, rel);
		updateHash(fConnFeatHash, rel.getFeatures());
		updateHash(fArg1Hash, rel.getArg1());
		updateHash(fArg1FeatHash, ((PDTBArg) rel.getArg1()).getFeatures());
		updateHash(fArg2Hash, rel.getArg2());
		updateHash(fArg2FeatHash, ((PDTBArg) rel.getArg2()).getFeatures());
		if (rel.getSup1() != null) {
			updateHash(fSup1Hash, rel.getSup1());
		}
		if (rel.getSup2() != null) {
			updateHash(fSup2Hash, rel.getSup2());
		}
		repaintCanvases();
	}

	public void sup1Selected(PDTBSup sup1) {
		refreshSelection();
		updateHash(fSup1Hash, sup1);
		repaintCanvases();
	}

	public void sup2Selected(PDTBSup sup2) {
		refreshSelection();
		updateHash(fSup2Hash, sup2);
		repaintCanvases();
	}

	public void altLexRelationSelected(PDTBAltLexRelation rel) {
		refreshSelection();
		updateHash(fExplicitConnHash, rel);
		updateHash(fConnFeatHash, rel.getFeatures());
		updateHash(fArg1Hash, rel.getArg1());
		updateHash(fArg1FeatHash, ((PDTBArg) rel.getArg1()).getFeatures());
		updateHash(fArg2Hash, rel.getArg2());
		updateHash(fArg2FeatHash, ((PDTBArg) rel.getArg2()).getFeatures());
		if (rel.getSup1() != null) {
			updateHash(fSup1Hash, rel.getSup1());
		}
		if (rel.getSup2() != null) {
			updateHash(fSup2Hash, rel.getSup2());
		}
		repaintCanvases();
	}

	public void implicitRelationSelected(PDTBImplicitRelation rel) {
		refreshSelection();
		updateHash(fConnFeatHash, rel.getFeatures());
		updateHash(fArg1Hash, rel.getArg1());
		updateHash(fArg1FeatHash, ((PDTBArg) rel.getArg1()).getFeatures());
		updateHash(fArg2Hash, rel.getArg2());
		updateHash(fArg2FeatHash, ((PDTBArg) rel.getArg2()).getFeatures());
		if (rel.getSup1() != null) {
			updateHash(fSup1Hash, rel.getSup1());
		}
		if (rel.getSup2() != null) {
			updateHash(fSup2Hash, rel.getSup2());
		}
		repaintCanvases();
	}

	public void entityRelationSelected(PDTBEntityRelation rel) {
		refreshSelection();
		updateHash(fArg1Hash, rel.getArg1());
		updateHash(fArg2Hash, rel.getArg2());

		repaintCanvases();
	}

	public void noRelationSelected(PDTBNoRelation rel) {
		refreshSelection();
		updateHash(fArg1Hash, rel.getArg1());
		updateHash(fArg2Hash, rel.getArg2());

		repaintCanvases();
	}

	public void fontChanged(Font newFont) {
		setFont(newFont);
		int numCanvases = fCanvases.length;
		for (int i = 0; i < numCanvases; i++) {
			VTreeCanvas c = fCanvases[i];

			c.getMutationSupport().fireSubtreeDamaged(
					(PTBTreeNode) (c.getRoot()));
			c.repaint();
		}
	}

}
