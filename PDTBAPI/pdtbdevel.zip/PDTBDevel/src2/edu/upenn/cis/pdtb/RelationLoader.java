/*
 * RelationParser.java
 *
 * Created on November 28, 2005, 6:56 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Reader;
import java.io.IOException;

import edu.upenn.cis.pdtb.util.CorpusFileIterator;
import edu.upenn.cis.ptb.*;

/**
 * <p>
 * Implementations of this assist in loading annotations into memory. The
 * following conventions are assumed on a Linux/Unix filesystem (use the
 * appropriate file separators on other platforms):
 *
 * <OL>
 *
 * <li>
 * RAW refers to the Wall Street Journal raw text. RAW is assumed to be divided
 * into 25 sections, each with atmost 100 files. The directory textRoot refers to
 * the directory such that textRoot/00/wsj_0003 is the RAW file for section 00,
 * file 03.
 * </li>
 * <li>
 * PDTB refers to the Penn Discourse Treebank. pdtbRoot refers to
 * the directory such that pdtbRoot/00/wsj_0003.pdtb contains the PDTB
 * annotations for  textRoot/00/wsj_0003.
 * </li>
 * <li>
 * PTB refers to the Penn Treebank. PTB files are assumed to be in
 * symbolic expression form, and ptbRoot/00/wsj_0003.mrg contains the
 * parse trees for textRoot/00/wsj_0003.
 * </li>
 * <li>
 * Given a PDTB file pdtbRoot/ij/wsj_ijkl.pdtb, the associated RAW file is
 * textRoot/ij/wsj_ijkl, and the associated PTB file is ptbRoot/ij/wsj_ijkl.
 * </li>
 * </OL>
 *
 * </p>
 * @author nikhild, geraud
 * @see edu.upenn.cis.pdtb.util.CorpusFileIterator
 */
public interface RelationLoader {
    /**
     * Loads a list of relations from a PDTB file, and its associated PTB and
     * RAW files.
     *
     * @param textFile The name of the RAW file.
     * @param ptbFile The name of the PTB file.
     * @param pdtbFile The name of the PTB file.
     */    
    public PDTBRelationList loadRelations(String textFile, String ptbFile, String pdtbFile) throws IOException;
    
    /**
     * Loads a list of relations from a CorpusFileIterator
     *
     * @param cfi The Corpus File Iterator object.
     */    
    public PDTBRelationList loadRelations(final CorpusFileIterator cfi) throws IOException;
    
    /**
     * Loads the PDTB file, and its associated RAW and PTB files given the
     * section and file numbers. Existence of the file should be ensured before
     * invoking, otherwise an exception will be thrown.
     *
     * @param textRoot The root dir for RAW files.
     * @param ptbRoot The root dir for PTB files.
     * @param pdtbRoot The root dir for PDTB files.
     * @param secNo The section number as a string. Note that the section numbers
     * are 00, 01, 02...09, 10, 11, ... 24
     * @param fileNo The file number as a string. 00, 01, ...09, 10, 11, ... 99 are
     * possible.
     */    
    public PDTBRelationList loadRelations(String textRoot, String ptbRoot, String pdtbRoot, String secNo, String fileNo) throws IOException;
    
    /**
     * Loads a PDTB file given the RAW text and a tree node whose children are
     * the parse trees for each sentence. Convenience method for those who hate
     * entity resolution imposed on them.
     */    
    public PDTBRelationList loadRelations(Reader r, String rawString, PTBTreeNode root) throws IOException;
}
