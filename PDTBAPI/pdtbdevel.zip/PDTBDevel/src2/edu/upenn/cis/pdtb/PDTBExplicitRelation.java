/*
 * PDTBExplicitRelation.java
 *
 * Created on November 29, 2005, 5:45 PM
 */

package edu.upenn.cis.pdtb;

/**
 * An ExplicitRelation established by a connective.
 * @author nikhild, geraud
 */
public interface PDTBExplicitRelation extends PDTBRelation {
    
    /**
     * Get the features
     */    
    public PDTBExplicitRelationFeatures getFeatures();
    
    /**
     * Set the features
     */    
    public void setFeatures(PDTBExplicitRelationFeatures attribs);
    
    /**
     * Get the selection associated with the connective.
     */    
    public PDTBSelection getSelection();
    
    /**
     * Set the selection associated with the connective.
     */    
    public void setSelection(PDTBSelection sel);
    
    
}
