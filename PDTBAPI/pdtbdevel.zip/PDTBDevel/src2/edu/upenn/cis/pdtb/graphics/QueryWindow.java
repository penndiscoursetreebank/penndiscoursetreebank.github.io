package edu.upenn.cis.pdtb.graphics;

import javax.swing.*;
import javax.swing.border.BevelBorder;

import edu.upenn.cis.pdtb.PDTBArgFeatures;
import edu.upenn.cis.pdtb.PDTBConnFeatures;
import edu.upenn.cis.pdtb.PDTBExplicitRelationFeatures;
import edu.upenn.cis.pdtb.PDTBImplicitRelationFeatures;
import edu.upenn.cis.pdtb.PDTBNode;
import edu.upenn.cis.pdtb.PDTBSelection;
import edu.upenn.cis.pdtb.xpath.PDTBXPath;

import java.awt.*;
import java.awt.event.*;

/**
 * The New Query Popup.
 * 
 * @author geraud
 */
public class QueryWindow extends JPanel {

	private final JCheckBox[] checkBoxes = new JCheckBox[5];

	private final Cluster[] conn = new Cluster[2];

	private final Cluster[] connFeats = new Cluster[4];

	private final Cluster[] arg1Feats = new Cluster[4];

	private final Cluster[] arg2Feats = new Cluster[4];

	private final JTextField queryTF = new JTextField();

	private final JScrollPane scrollPane = new JScrollPane(new JList(
			new String[] {}));

	private static final int padding = 10;

	private JTextField lastTF = null;

	private final JProgressBar progressBar = new JProgressBar();

	public static final String progressString = "Progress";

	private static final String connPreReg = "(\\s*|.+\\s+)(";
	
	private static final String connPostReg = ")\\s*";
	
	private static final String classPreReg = ".*(";
	
	private static final String classPostReg = ")";
	
	private static final String featPreReg = ".*(";
	
	private static final String featPostReg = ").*";

	/** Creates a new instance of PDTBBrowser */
	public QueryWindow(final String browserArgs[], final JFrame parentFrame) {

		/*-------CheckBoxes-------*/

		checkBoxes[0] = new JCheckBox(PDTBNode.ExplicitRelationQName, true);
		checkBoxes[1] = new JCheckBox(PDTBNode.ImplicitRelationQName, true);
		checkBoxes[2] = new JCheckBox(PDTBNode.AltLexRelationQName, true);
		checkBoxes[3] = new JCheckBox(PDTBNode.EntityRelationQName, true);
		checkBoxes[4] = new JCheckBox(PDTBNode.NoRelationQName, true);
		final JPanel panelCB = new JPanel();
		panelCB.setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		panelCB.setBorder(BorderFactory.createTitledBorder(BorderFactory
				.createEtchedBorder(), "Relations"));
		for (int i = 0; i < checkBoxes.length; i++) {
			checkBoxes[i].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					updateQueryString();
				}
			});
			checkBoxes[i].setSelected(false);
			panelCB.add(checkBoxes[i], constraints);
		}
		constraints.gridy = 1;
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.WEST;
		JLabel cbLabel = new JLabel(
				"*(Leave all boxes unchecked to search all relation types)");
		cbLabel.setFont(new Font("", Font.ITALIC, 11));
		panelCB.add(cbLabel, constraints);

		/*-------Conn and Classes-------*/

		conn[0] = new Cluster("Conn:", PDTBConnFeatures.conns, connPreReg, connPostReg);
		conn[1] = new Cluster("S-Class:",
				PDTBConnFeatures.semanticClassesShort,
				PDTBConnFeatures.semanticClassesLong, classPreReg, classPostReg);

		final JPanel panelConn = createPanel("Conn", conn);

		/*-------Conn Feats-------*/

		connFeats[0] = new Cluster("Src:", PDTBConnFeatures.SourceFeature
				.getValues(), featPreReg, featPostReg);
		connFeats[1] = new Cluster("Type:", PDTBConnFeatures.TypeFeature
				.getValues(), featPreReg, featPostReg);
		connFeats[2] = new Cluster("Pol:", PDTBConnFeatures.PolarityFeature
				.getValues(), featPreReg, featPostReg);
		connFeats[3] = new Cluster("Det:", PDTBConnFeatures.DeterminancyFeature
				.getValues(), featPreReg, featPostReg);

		final JPanel panelConnFeat = createPanel("Conn Feats", connFeats);

		/*-------Arg1 Feats-------*/

		arg1Feats[0] = new Cluster("Src:", PDTBArgFeatures.SourceFeature
				.getValues(), featPreReg, featPostReg);
		arg1Feats[1] = new Cluster("Type:", PDTBArgFeatures.TypeFeature
				.getValues(), featPreReg, featPostReg);
		arg1Feats[2] = new Cluster("Pol:", PDTBArgFeatures.PolarityFeature
				.getValues(), featPreReg, featPostReg);
		arg1Feats[3] = new Cluster("Det:", PDTBArgFeatures.DeterminancyFeature
				.getValues(), featPreReg, featPostReg);

		final JPanel panelArg1Feat = createPanel("Arg1 Feats", arg1Feats);

		/*-------Arg2 Feats-------*/

		arg2Feats[0] = new Cluster("Src:", PDTBArgFeatures.SourceFeature
				.getValues(), featPreReg, featPostReg);
		arg2Feats[1] = new Cluster("Type:", PDTBArgFeatures.TypeFeature
				.getValues(), featPreReg, featPostReg);
		arg2Feats[2] = new Cluster("Pol:", PDTBArgFeatures.PolarityFeature
				.getValues(), featPreReg, featPostReg);
		arg2Feats[3] = new Cluster("Det:", PDTBArgFeatures.DeterminancyFeature
				.getValues(), featPreReg, featPostReg);

		final JPanel panelArg2Feat = createPanel("Arg2 Feats", arg2Feats);

		/*-------QueryString / SearchButton-------*/

		queryTF.setEditable(false);
		final JButton regexButton = new JButton("Search!");
		regexButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String xPathString = queryTF.getText();
					int count = PDTBXPath.runQuery(browserArgs, xPathString,
							progressBar);
					if (count > 0) {
						parentFrame.dispose();
					} else {
						JOptionPane.showMessageDialog(parentFrame,
								"Your query returned no results.",
								"No Results", JOptionPane.INFORMATION_MESSAGE);
						progressBar.setValue(0);
						progressBar.setString(progressString);
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		final JPanel panelRegex = new JPanel();
		panelRegex.setBorder(BorderFactory.createTitledBorder(BorderFactory
				.createEtchedBorder(), "Full Query String"));
		panelRegex.setLayout(new GridBagLayout());
		GridBagConstraints regexConstraints = new GridBagConstraints();
		regexConstraints.fill = GridBagConstraints.HORIZONTAL;
		regexConstraints.weightx = 1.0;
		panelRegex.add(queryTF, regexConstraints);
		regexConstraints.fill = GridBagConstraints.NONE;
		regexConstraints.gridy = 1;
		panelRegex.add(regexButton, regexConstraints);

		/*-------CheckList-------*/

		final JPanel panelCheckList = new JPanel();
		panelCheckList.setBorder(BorderFactory.createTitledBorder(BorderFactory
				.createEtchedBorder(), "Options"));
		panelCheckList.setLayout(new GridBagLayout());
		GridBagConstraints checkListConstraints = new GridBagConstraints();
		checkListConstraints.fill = GridBagConstraints.VERTICAL;
		checkListConstraints.insets = new Insets(padding, padding, padding,
				padding);
		checkListConstraints.weighty = 1.0;
		panelCheckList.add(scrollPane, checkListConstraints);

		/*-------Status Panel-------*/

		progressBar.setString(progressString);
		progressBar.setStringPainted(true);
		progressBar.setBorderPainted(true);
		progressBar.setBackground(new Color(200, 200, 200));

		JPanel panelStatus = new JPanel();
		panelStatus.setLayout(new BorderLayout());
		panelStatus.add(progressBar, BorderLayout.CENTER);
		panelStatus.setBorder(new BevelBorder(BevelBorder.LOWERED));

		/*-------Outer Panels-------*/

		GridBagConstraints windowConstraints = new GridBagConstraints();
		setLayout(new GridBagLayout());
		windowConstraints.fill = GridBagConstraints.HORIZONTAL;
		add(panelCB, windowConstraints);
		windowConstraints.gridx = 0;
		add(panelConn, windowConstraints);
		add(panelConnFeat, windowConstraints);
		add(panelArg1Feat, windowConstraints);
		add(panelArg2Feat, windowConstraints);
		add(panelRegex, windowConstraints);
		windowConstraints.gridx = 1;
		windowConstraints.gridheight = getComponentCount();
		windowConstraints.fill = GridBagConstraints.VERTICAL;
		add(panelCheckList, windowConstraints);
		windowConstraints.gridx = 0;
		windowConstraints.gridheight = 1;
		windowConstraints.gridwidth = 2;
		windowConstraints.fill = GridBagConstraints.HORIZONTAL;
		add(panelStatus, windowConstraints);
		updateQueryString();

	}

	private JPanel createPanel(String title, Cluster[] components) {
		final JPanel panel = new JPanel();
		panel.setBorder(BorderFactory.createTitledBorder(BorderFactory
				.createEtchedBorder(), title));
		panel.setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.weightx = 1.0 / components.length;
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.insets = new Insets(0, 0, 0, padding);
		panel.add(components[0].getJLabel(), constraints);
		constraints.insets = new Insets(0, padding, 0, padding);
		for (int i = 1; i < components.length - 1; i++) {
			panel.add(components[i].getJLabel(), constraints);
		}
		constraints.insets = new Insets(0, padding, 0, 0);
		panel.add(components[components.length - 1].getJLabel(), constraints);
		constraints.gridy = 1;
		constraints.insets = new Insets(0, 0, 0, padding);
		panel.add(components[0].getJTextField(), constraints);
		constraints.insets = new Insets(0, padding, 0, padding);
		for (int i = 1; i < components.length - 1; i++) {
			panel.add(components[i].getJTextField(), constraints);
		}
		constraints.insets = new Insets(0, padding, 0, 0);
		panel.add(components[components.length - 1].getJTextField(),
				constraints);
		return panel;
	}

	private boolean isEmpty(Cluster[] components) {
		for (int i = 0; i < components.length; i++) {
			String text = components[i].getJTextField().getText();
			if (!text.equals("")) {
				return false;
			}
		}
		return true;
	}

	private boolean isEmpty(JCheckBox[] components) {
		for (int i = 0; i < components.length; i++) {
			if (components[i].isSelected()) {
				return false;
			}
		}
		return true;
	}

	private String getArgFeatQuery(Cluster[] argFeats) {
		String queryString = "";
		String temp;
		boolean needAnd = false;
		temp = argFeats[0].getJTextField().getText();
		if (!temp.equals("")) {
			needAnd = true;
			queryString += "regexp(@" + PDTBArgFeatures.SourceFeature.getName()
					+ ",'" + temp + "')";
		}
		temp = argFeats[1].getJTextField().getText();
		if (!temp.equals("")) {
			if (needAnd) {
				queryString += "and";
			}
			needAnd = true;
			queryString += "regexp(@" + PDTBArgFeatures.TypeFeature.getName()
					+ ",'" + temp + "')";
		}
		temp = argFeats[2].getJTextField().getText();
		if (!temp.equals("")) {
			if (needAnd) {
				queryString += "and";
			}
			needAnd = true;
			queryString += "regexp(@"
					+ PDTBArgFeatures.PolarityFeature.getName() + ",'" + temp
					+ "')";
		}
		temp = argFeats[3].getJTextField().getText();
		if (!temp.equals("")) {
			if (needAnd) {
				queryString += "and";
			}
			queryString += "regexp(@"
					+ PDTBArgFeatures.DeterminancyFeature.getName() + ",'"
					+ temp + "')";
		}
		return queryString;
	}

	private void updateQueryString() {

		String defaultString = ">::*";
		String queryString = defaultString;
		boolean needOr = false;
		/* Which Relations? */
		if (checkBoxes[0].isSelected()) {
			queryString += "[regexp(local-name(),'(";
			needOr = true;
			queryString += PDTBNode.ExplicitRelationQName.replaceFirst(
					"Relation", "");
		}
		if (checkBoxes[1].isSelected()) {
			if (needOr) {
				queryString += "|";
			} else {
				queryString += "[regexp(local-name(),'(";
			}
			needOr = true;
			queryString += PDTBNode.ImplicitRelationQName.replaceFirst(
					"Relation", "");
		}
		if (checkBoxes[2].isSelected()) {
			if (needOr) {
				queryString += "|";
			} else {
				queryString += "[regexp(local-name(),'(";
			}
			needOr = true;
			queryString += PDTBNode.AltLexRelationQName.replaceFirst(
					"Relation", "");
		}
		if (checkBoxes[3].isSelected()) {
			if (needOr) {
				queryString += "|";
			} else {
				queryString += "[regexp(local-name(),'(";
			}
			needOr = true;
			queryString += PDTBNode.EntityRelationQName.replaceFirst(
					"Relation", "");
		}
		if (checkBoxes[4].isSelected()) {
			if (needOr) {
				queryString += "|";
			} else {
				queryString += "[regexp(local-name(),'(";
			}
			needOr = true;
			queryString += PDTBNode.NoRelationQName
					.replaceFirst("Relation", "");
		}
		if (needOr) {
			queryString += ").*')";
		}
		/* Which Conns, S-Classes, and Conn Feats? */
		if (checkBoxes[0].isSelected() || checkBoxes[1].isSelected()
				|| checkBoxes[2].isSelected() || isEmpty(checkBoxes)) {
			/* Which Conns? */
			String temp = conn[0].getJTextField().getText();
			if (!temp.equals("")) {
				if (queryString.equals(defaultString)) {
					queryString += "[";
				} else {
					queryString += "and";
				}
				queryString += "(attribute::*[regexp(local-name(),'";
				needOr = false;
				if (checkBoxes[0].isSelected() || checkBoxes[2].isSelected()
						|| isEmpty(checkBoxes)) {
					needOr = true;
					queryString += PDTBSelection.RawTextAttributeQName;
				}
				if (checkBoxes[1].isSelected() || isEmpty(checkBoxes)) {
					if (needOr) {
						queryString += "|";
					}
					queryString += PDTBImplicitRelationFeatures.Conn1AttrQName
							+ "|" + PDTBImplicitRelationFeatures.Conn2AttrQName;
				}
				//'true' for case insensitivity
				queryString += "')andregexp(string(),'" + temp + "','true')])";
			}
			/* Which S-Classes? */
			temp = conn[1].getJTextField().getText();
			if (!temp.equals("")) {
				if (queryString.equals(defaultString)) {
					queryString += "[";
				} else {
					queryString += "and";
				}
				queryString += "(attribute::*[regexp(local-name(),'";
				needOr = false;
				if (checkBoxes[0].isSelected() || checkBoxes[2].isSelected()
						|| isEmpty(checkBoxes)) {
					needOr = true;
					queryString += PDTBExplicitRelationFeatures.SClassA
							.getName()
							+ "|"
							+ PDTBExplicitRelationFeatures.SClassB
									.getName();
				}
				if (checkBoxes[1].isSelected() || isEmpty(checkBoxes)) {
					if (needOr) {
						queryString += "|";
					}
					queryString += PDTBImplicitRelationFeatures.SClass1A
							.getName()
							+ "|"
							+ PDTBImplicitRelationFeatures.SClass1B
									.getName()
							+ "|"
							+ PDTBImplicitRelationFeatures.SClass2A
									.getName()
							+ "|"
							+ PDTBImplicitRelationFeatures.SClass2B
									.getName();
				}
				queryString += "')andregexp(string(),'" + temp + "')])";
			}
			/* Which Conn Feats? */
			temp = connFeats[0].getJTextField().getText();
			if (!temp.equals("")) {
				if (queryString.equals(defaultString)) {
					queryString += "[";
				} else {
					queryString += "and";
				}
				queryString += "(attribute::*[local-name()='"
						+ PDTBConnFeatures.SourceFeature.getName()
						+ "'andregexp(string(),'" + temp + "')])";
			}

			temp = connFeats[1].getJTextField().getText();
			if (!temp.equals("")) {
				if (queryString.equals(defaultString)) {
					queryString += "[";
				} else {
					queryString += "and";
				}
				queryString += "(attribute::*[local-name()='"
						+ PDTBConnFeatures.TypeFeature.getName()
						+ "'andregexp(string(),'" + temp + "')])";
			}

			temp = connFeats[2].getJTextField().getText();
			if (!temp.equals("")) {
				if (queryString.equals(defaultString)) {
					queryString += "[";
				} else {
					queryString += "and";
				}
				queryString += "(attribute::*[local-name()='"
						+ PDTBConnFeatures.PolarityFeature.getName()
						+ "'andregexp(string(),'" + temp + "')])";
			}

			temp = connFeats[3].getJTextField().getText();
			if (!temp.equals("")) {
				if (queryString.equals(defaultString)) {
					queryString += "[";
				} else {
					queryString += "and";
				}
				queryString += "(attribute::*[local-name()='"
						+ PDTBConnFeatures.DeterminancyFeature.getName()
						+ "'andregexp(string(),'" + temp + "')])";
			}

		}
		/* Which Arg Feats? */
		if (!isEmpty(arg1Feats)) {
			if (queryString.equals(defaultString)) {
				queryString += "[";
			} else {
				queryString += "and";
			}
			queryString += ">::" + PDTBNode.Arg1QName + "["
					+ getArgFeatQuery(arg1Feats) + "]";
		}
		if (!isEmpty(arg2Feats)) {
			if (queryString.equals(defaultString)) {
				queryString += "[";
			} else {
				queryString += "and";
			}
			queryString += ">::" + PDTBNode.Arg2QName + "["
					+ getArgFeatQuery(arg2Feats) + "]";
		}
		if (!queryString.equals(defaultString)) {
			queryString += "]";
		}
		queryTF.setText(queryString);
	}

	/*
	 * A Cluster is a group of controls that consists of JTextfield, a JLabel,
	 * and a CheckList. An array of Clusters make up the main panels.
	 */
	public class Cluster {
		private final JTextField tf;

		private final JLabel label;

		private final String preReg;
		
		private final String postReg;
		
		public Cluster(String labelText, final String[] display,
				final String[] data, String preReg, String postReg) {
			label = new JLabel(labelText);
			tf = new JTextField();
			this.preReg = preReg;
			this. postReg = postReg;
			construct(display, data);
		}

		public Cluster(String labelText, final String[] display, String preReg, String postReg) {
			label = new JLabel(labelText);
			tf = new JTextField();
			this.preReg = preReg;
			this. postReg = postReg;
			construct(display, display);
		}

		private void construct(final String[] display, final String[] data) {
			final Color oldBackground = tf.getBackground();
			final Color oldForeground = tf.getForeground();
			tf.setEditable(false);
			tf.setBackground(oldBackground);
			tf.setForeground(oldForeground);
			final JList list = new JList(display);
			final CheckList checkList = new CheckList(list);
			list.addMouseListener(new MouseAdapter() {
				public void mouseClicked(MouseEvent e) {
					String JTFString = "";
					boolean needOr = false;
					for (int i = 0; i < list.getModel().getSize(); i++) {
						if (checkList.getSelectionModel().isSelectedIndex(i)) {
							if (needOr) {
								JTFString += "|";
							}
							needOr = true;
							JTFString += data[i];						
						}
					}
					if (needOr) {
						JTFString = preReg + JTFString + postReg;
					}
					tf.setText(JTFString);
					updateQueryString();
				}
			});
			tf.addFocusListener(new FocusAdapter() {
				public void focusGained(FocusEvent e) {
					scrollPane.setViewportView(list);
					if (lastTF != null) {
						lastTF.setBackground(oldBackground);
					}
					lastTF = tf;
					tf.setBackground(new Color(255, 255, 0));
				}
			});
		}

		public JTextField getJTextField() {
			return tf;
		}

		public JLabel getJLabel() {
			return label;
		}
	}

}
