/*
 * PTBPanel.java
 *
 * Created on December 6, 2005, 12:22 AM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import edu.upenn.cis.ptb.*;
import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.pdtb.util.*;
import org.annotation.agschema.graphics.vtree.*;
import java.util.Enumeration;
import javax.swing.border.*;
import java.awt.GridLayout;

/**
 * Contains the parse trees for a PTB file. Each parse tree is a VTreeCanvas.
 * The panel also listens for PDTBNode selection events to implement to scroll
 * the appropriate area into visiblity.
 *
 * @author  nikhild
 * @see org.annotation.agschema.graphics.vtree.VTreeCanvas
 */
public class PTBPanel extends JPanel implements PDTBNodeSelectionListener, Scrollable{
    
    private PTBTreeNode fRoot;
    
    private VTreeCanvas[] fCanvases;
    
    
    /** Creates a new instance of PTBPanel */
    public PTBPanel(PTBTreeNode root, JTree pdtbTree) {
        super();
        
        int numCanvases = root.getChildCount();
        VTreeCanvas[] canvases = new VTreeCanvas[numCanvases];
        setLayout(new GridLayout(numCanvases,1));
        
        //For toggling the expansion state
        MouseListener ms = (new MouseAdapter() {
                public void mouseClicked(MouseEvent e){
                    VTreeCanvas can = (VTreeCanvas)(e.getComponent());
                        Point p = e.getPoint();
                        PTBTreeNode node = (PTBTreeNode)(can.getNode((int)p.getX(), (int)p.getY()));
                        
                    if(e.getButton() == MouseEvent.BUTTON1){
                        if(node != null){
                            VTreeExpansionState es = can.getExpansionState();
                            if(es.isCollapsed(node)){
                                es.expand(node);
                            }
                            else{
                                es.collapse(node);
                            }
                        }
                    }
                }
            });
        
        
            
        int i = 0;
        //Set up the canvases, one for each sentence.
        for(Enumeration e = root.children(); e.hasMoreElements(); i++){
            PTBTreeNode child = (PTBTreeNode)(e.nextElement());
            VTreeCanvas c = new VTreeCanvas();
            c.setBorder(new EtchedBorder());
            c.setRoot(child);
            VTreeExpansionState es = new VTreeExpansionStateImpl(child);
            c.setExpansionState(es);
            
            TreeMutationSupport tms = new TreeMutationSupport(child);
            c.setMutationSupport(tms);
        
            c.addMouseListener(ms);
            canvases[i] = c;
            
            add(c);
            
        }
        
        fRoot = root;
        fCanvases = canvases;
        setBackground(Color.WHITE);
        
        //Create the cellRendere and add it as a listener to the JTree of the
        //PDTB annotations.
        PTBCellRendererImpl cellRenderer = new PTBCellRendererImpl(root, canvases);
        TreeSelectionListenerImpl listener = new TreeSelectionListenerImpl();
        listener.add(cellRenderer);
        listener.add(this);
        pdtbTree.getSelectionModel().addTreeSelectionListener(listener);
        
    }
    
    public void arg1Selected(PDTBSup arg1) {
        makeVisible(arg1);
    }
    
    public void arg2Selected(PDTBSup arg2) {
        makeVisible(arg2);
    }
    
    public void explicitRelationSelected(PDTBExplicitRelation rel) {
        makeVisible(rel);
    }
    
    public void sup1Selected(PDTBSup sup1) {
        makeVisible(sup1);
    }
    
    public void sup2Selected(PDTBSup sup2) {
        makeVisible(sup2);
    }
    
    private void makeVisible(PDTBNode node){
        if(node instanceof PDTBSup){
            GornAddressList gal = ((PDTBSup)node).getSelection().getAddresses();
            int[] firstAddress = (int[])(gal.first());
            makeVisible(firstAddress);
        }
        else{
            if(node instanceof PDTBExplicitRelation){
                GornAddressList gal = ((PDTBExplicitRelation)node).getSelection().getAddresses();
                int[] firstAddress = (int[])(gal.first());
                makeVisible(firstAddress);
            }
            else if(node instanceof PDTBAltLexRelation){
                GornAddressList gal = ((PDTBAltLexRelation)node).getSelection().getAddresses();
                int[] firstAddress = (int[])(gal.first());
                makeVisible(firstAddress);
            }
            else if(node instanceof PDTBImplicitRelation){
                GornAddressList gal = ((PDTBImplicitRelation)node).getArg2().getSelection().getAddresses();
                int[] firstAddress = (int[])(gal.first());
                makeVisible(firstAddress);
            }
            else if(node instanceof PDTBEntityRelation){
                GornAddressList gal = ((PDTBEntityRelation)node).getArg2().getSelection().getAddresses();
                int[] firstAddress = (int[])(gal.first());
                makeVisible(firstAddress);
            }
        }
    }
    
    /**
     * Scrolls node denoted by the address into the center of the screen.
     */
    private void makeVisible(int[] address){
        PTBTreeNode treeNode = (PTBTreeNode)(GornAddressUtils.getNode(address, fRoot));
        boolean alignToTop = (address.length == 1);
        
        int comp = address[0];
        VTreeCanvas can = fCanvases[comp];
        
        Rectangle r = can.getNodeLocation(treeNode);
        int y = 0;
        for(int i = 0; i < comp; i++){
            y += can.getHeight();
        }
        r.y += y;
        
        Rectangle v = getVisibleRect();
        r.height = (v.height/2);
        r.width = (v.width/2);
        
        if(alignToTop){
            //int diffY = r.y - v.y;
            r.y = ((r.y - v.y) > 0)? r.y + v.height/2 : r.y;
            
            
            int centerX = v.x + v.width/2;
            int diffX = r.x - centerX;
            r.x = (diffX <= 0)? r.x - v.width/2 : r.x;
            
            if(r.x < 0){
                r.x = 0;
            }
        }
        else{
            int centerY = v.y + v.height/2;
            int diffY = r.y - centerY ;
            r.y = (diffY > 0)? r.y : r.y - v.height/2;
            
            
            int centerX = v.x + v.width/2;
            int diffX = r.x - centerX;
            r.x = (diffX <= 0)? r.x - v.width/2 : r.x;
            
            if(r.x < 0){
                r.x = 0;
            }
        }
        scrollRectToVisible(r);
    }

    public Dimension getPreferredScrollableViewportSize() {
        Dimension d = getPreferredSize();
        //return getPreferredSize();
        
        return new Dimension(((d.getWidth() > 500)? 500 : (int) (d.getWidth())),
        ((d.getHeight() > 500)? 500 : (int) (d.getHeight())));
    }
    
    public int getScrollableBlockIncrement(Rectangle rectangle, int param, int param2) {
        return 50;
    }
    
    public boolean getScrollableTracksViewportHeight() {
        return false;
    }
    
    public boolean getScrollableTracksViewportWidth() {
        return false;
    }
    
    public int getScrollableUnitIncrement(Rectangle rectangle, int param, int param2) {
        return 50;
    }
    
    public void altLexRelationSelected(PDTBAltLexRelation rel) {
        makeVisible(rel);
    }
    
    public void implicitRelationSelected(PDTBImplicitRelation rel) {
        makeVisible(rel);
    }
    
    public void entityRelationSelected(PDTBEntityRelation rel) {
        makeVisible(rel);
    }
    
    public void noRelationSelected(PDTBNoRelation rel) {
        makeVisible(rel);
    }
    
}
