/*
 * PDTBImplicitRelationImpl.java
 *
 * Created on January 22, 2006, 7:01 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;
import edu.upenn.cis.pdtb.util.ArraySet;

/**
 * Implementation of the PDTBImplicitRelation interface.
 * @author nikhild, geraud
 */
public class PDTBImplicitRelationImpl extends PDTBRelationImpl implements PDTBImplicitRelation{
    
    private PDTBInferenceSite fInfSite;
    
    private PDTBImplicitRelationFeatures fFeats;
    
    /** Creates a new instance of PDTBImplicitRelationImpl */
    public PDTBImplicitRelationImpl(PDTBInferenceSite infSite, PDTBImplicitRelationFeatures feats, 
    PDTBSup sup1, PDTBArg arg1, PDTBArg arg2, PDTBSup sup2) {
        super(sup1, arg1, arg2, sup2);
        
        fInfSite = infSite;
        fFeats = feats;
        
        fInfSite.setPDTBNode(this);
        fFeats.setPDTBNode(this);
        
        pdtbSetName("", ImplicitRelationQName, ImplicitRelationQName);
    }
    
    protected void initAttributes(){
        fAttributes = new ArraySet(fAttributesComparator, 5);
        fFeats.updateAttributesOnNode();
        fInfSite.updateAttributesOnNode();
    }
    
    public PDTBImplicitRelationFeatures getFeatures() {
        return fFeats;
    }
    
    public PDTBInferenceSite getInferenceSite() {
        return fInfSite;
    }
    
    public void setFeatures(PDTBImplicitRelationFeatures feats) {
        if(fFeats != null){
            fFeats.setPDTBNode(null);
        }
        
        feats.setPDTBNode(this);
        
        fFeats = feats;
        fFeats.updateAttributesOnNode();
    }
    
    public void setInferenceSite(PDTBInferenceSite infSite) {
        if(fInfSite != null){
            fInfSite.setPDTBNode(null);
        }
        
        fInfSite.setPDTBNode(this);
        
        fInfSite = infSite;
        fInfSite.updateAttributesOnNode();
    }
    
    public void save(Writer writer) throws IOException{
        writer.write("________________________________________________________\n");
        writer.write("____Implicit____\n");
        ((PDTBInferenceSiteImpl)fInfSite).save(writer);
        writer.write("#### Features ####\n");
        ((PDTBImplicitRelationFeaturesImpl)fFeats).save(writer);
        super.save(writer);
        writer.write("________________________________________________________\n");
    }
    
}
