/*
 * PDTBBrowser.java
 *
 * Created on December 7, 2005, 8:27 PM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import edu.upenn.cis.pdtb.util.*;
import java.util.LinkedList;
import java.io.File;
import javax.swing.plaf.metal.MetalLookAndFeel;

/**
 * The top level browser.
 * 
 * @since 0.1
 * @version 3 Added a mode for comparing connectives.
 * @version 2 Added Prev and Next Buttons.
 * @author nikhild, geraud
 */
public class PDTBBrowser extends JPanel {
	
	public static final String NoFilesFoundMessage = "------------------------------------------------------------\n\n"
			+ "No files were found. This could mean that  one or more\n"
			+ "of the directories supplied were incorrect or empty.\n\n"
			+ "Please ensure that the directories point to the appropriate\n "
			+ "places,e.g.,  PtbRoot"
			+ File.separatorChar
			+ "00"
			+ File.separatorChar
			+ "wsj_0001.mrg should exist.\n\n"
			+ "\n-------------------------------------------------------------\n";

	/** Creates a new instance of PDTBBrowser */
	public PDTBBrowser(final String textRoot, final String ptbRoot, final String pdtbRoot, final String origPDTBRoot) {
		final LinkedList[] fileNumbers = new LinkedList[25];

		for (int i = 0; i < 25; i++) {
			fileNumbers[i] = new LinkedList();
		}

		// Collect the names of files that occur, so that only valid files can
		// be loaded
		System.err.print("....Building database of files....");
		for (CorpusFileIterator cfi = new CorpusFileIterator(textRoot, ptbRoot,
				pdtbRoot); cfi.hasMoreFiles();) {
			cfi.nextFile();
			int secNo = cfi.getSecNo();
			String fileNoStr = cfi.getFileNoStr();
			fileNumbers[secNo].addLast(fileNoStr);
		}
		System.err.println("Done");

		final JButton newQueryButton = new JButton("New Query");
		newQueryButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						final JFrame queryFrame = new JFrame("Query Window");
						queryFrame.getContentPane().setLayout(new GridLayout(1, 1));
						queryFrame.setResizable(false);
						queryFrame.setDefaultCloseOperation ( JFrame.DISPOSE_ON_CLOSE );
						final QueryWindow qw = new QueryWindow(new String[]{textRoot, ptbRoot, origPDTBRoot}, queryFrame);
						queryFrame.getContentPane().add(qw);
						queryFrame.pack();
						queryFrame.setVisible(true);
					}
				});
			}
		});

		final FileNoComboBoxModel fileModel = new FileNoComboBoxModel(
				fileNumbers);
		final SecNoComboBoxModel secModel = new SecNoComboBoxModel(fileNumbers);
		final FontSizeComboBoxModel fontModel = new FontSizeComboBoxModel();

		final JComboBox fileComboBox = new JComboBox(fileModel);
		final JComboBox secComboBox = new JComboBox(secModel);
		final JComboBox fontSizeComboBox = new JComboBox(fontModel);
		secComboBox.addItemListener(fileModel);

		// Set up the tabs
		final PDTBBrowserTab tabs = new PDTBBrowserTab(textRoot, ptbRoot,
				pdtbRoot);
		tabs.addChangeListener(fileModel);
		tabs.addChangeListener(secModel);

		String firstSecNo = (String) (secModel.getSelectedItem());
		String firstFileNo = (String) (fileModel.getSelectedItem());

		if (firstSecNo.equals("") || firstFileNo.equals("")) {
			System.err.println(NoFilesFoundMessage);
			System.err.println("The directories given were as follows:\n");
			System.err.println("RawRoot       " + textRoot);
			System.err.println("PtbRoot       " + ptbRoot);
			System.err.println("PdtbRoot      " + pdtbRoot);
			System.err
					.println("\n-------------------------------------------------------------\n");
		} else {
			// load the first file...otherwise the window is too small
			tabs.addTab(firstSecNo, firstFileNo);
		}

		// Load a file
		JButton loadButton = new JButton("Load");
		loadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String secNo = (String) (secModel.getSelectedItem());
				String fileNo = (String) (fileModel.getSelectedItem());
				if (secNo != null && fileNo != null) {
					tabs.addTab(secNo, fileNo, ((IntegratedPanel)tabs.getSelectedComponent()).getSplitPointL(), ((IntegratedPanel)tabs.getSelectedComponent()).getSplitPointR());
				}
			}
		});

		// Close a file
		JButton closeButton = new JButton("Close Tab");
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tabs.getSelectedComponent() != null) {
					tabs.removeTabAt(tabs.indexOfComponent(tabs
							.getSelectedComponent()));
				}
			}
		});

		JButton prevButton = new JButton("Prev");
		prevButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String secNo = (String) secModel.getSelectedItem();
				String fileNo = (String) fileModel.getSelectedItem();

				fileNo = fileModel.getPrevFileNo();

				if (fileNo == null) {
					secNo = secModel.getPrevSecNo();
					if (secNo != null) {
						secComboBox.setSelectedItem(secNo);
						fileNo = fileModel.getLastFileNo();
						if (fileNo != null) {
							fileComboBox.setSelectedItem(fileNo);
						}
					}

				} else {
					fileComboBox.setSelectedItem(fileNo);
				}

				if (secNo != null && fileNo != null) {
					tabs.addTab(secNo, fileNo, ((IntegratedPanel)tabs.getSelectedComponent()).getSplitPointL(), ((IntegratedPanel)tabs.getSelectedComponent()).getSplitPointR());
				}

			}
		});

		JButton nextButton = new JButton("Next");
		nextButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String secNo = (String) secModel.getSelectedItem();
				String fileNo = (String) fileModel.getSelectedItem();

				fileNo = fileModel.getNextFileNo();

				if (fileNo == null) {
					secNo = secModel.getNextSecNo();
					if (secNo != null) {
						secComboBox.setSelectedItem(secNo);
						fileNo = fileModel.getFirstFileNo();
						if (fileNo != null) {
							fileComboBox.setSelectedItem(fileNo);
						}
					}

				} else {
					fileComboBox.setSelectedItem(fileNo);
				}

				if (secNo != null && fileNo != null) {
					tabs.addTab(secNo, fileNo, ((IntegratedPanel)tabs.getSelectedComponent()).getSplitPointL(), ((IntegratedPanel)tabs.getSelectedComponent()).getSplitPointR());
				}
			}
		});

		final JToggleButton compareModeCheckBox = new JToggleButton("Split",
				false);
		compareModeCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabs.setCompareMode(compareModeCheckBox.isSelected());
			}
		});

		JPanel fontPanel = new JPanel();
		fontPanel.setLayout(new GridLayout(1, 2));
		JLabel l2 = new JLabel("Font ", SwingConstants.RIGHT);
		fontPanel.add(l2);
		fontPanel.add(fontSizeComboBox);

		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;

		JPanel p1 = new JPanel();
		p1.setLayout(gbl);

		gbl.setConstraints(newQueryButton, c);
		p1.add(newQueryButton);

		gbl.setConstraints(prevButton, c);
		p1.add(prevButton);

		gbl.setConstraints(nextButton, c);
		p1.add(nextButton);

		JLabel lsep1 = new JLabel(" ");
		gbl.setConstraints(lsep1, c);
		p1.add(lsep1);

		gbl.setConstraints(secComboBox, c);
		p1.add(secComboBox);

		gbl.setConstraints(fileComboBox, c);
		p1.add(fileComboBox);

		gbl.setConstraints(loadButton, c);
		p1.add(loadButton);

		gbl.setConstraints(closeButton, c);
		p1.add(closeButton);

		JLabel lsep2 = new JLabel(" ");
		gbl.setConstraints(lsep2, c);
		p1.add(lsep2);

		// c.gridwidth = 1;
		gbl.setConstraints(compareModeCheckBox, c);
		p1.add(compareModeCheckBox);

		JLabel lsep3 = new JLabel(" ");
		gbl.setConstraints(lsep3, c);
		p1.add(lsep3);

		gbl.setConstraints(fontPanel, c);
		p1.add(fontPanel);

		setLayout(new BorderLayout());
		add(p1, BorderLayout.NORTH);
		add(tabs, BorderLayout.CENTER);

		final StatusBar statusBar = new StatusBar();
		add(statusBar, BorderLayout.SOUTH);  

	}

	public static void runBrowser(final String[] args, final String origPDTBRoot, int count, final boolean isPDTBTemp) {
		try {
			try {
				UIManager.setLookAndFeel(new MetalLookAndFeel());
			} catch (Exception e) {
				System.err.println("Could not set the look and feel.");
			}

			PDTBBrowser browser = new PDTBBrowser(args[0], args[1], args[2], origPDTBRoot);
			final JFrame frame;
			if(isPDTBTemp){
				frame = new JFrame("PDTB Browser (" + count + " Results)");
			}
			else{
				frame = new JFrame("PDTB Browser");
			}
			frame.setDefaultCloseOperation ( JFrame.DISPOSE_ON_CLOSE );
			WindowListener wl = (new WindowAdapter() {
				public void windowClosing(WindowEvent e) {
					if (isPDTBTemp) {
						File dir = new File(args[2]);
						int retVal = JOptionPane.showConfirmDialog(frame,
								"Would you like to keep the directory with these query results ("
										+ dir.getAbsolutePath() + ")?", "Delete Query?",
								JOptionPane.YES_NO_OPTION,
								JOptionPane.QUESTION_MESSAGE);

						if (retVal == JOptionPane.NO_OPTION) {
							if (dir.exists()) {
								File[] folders = dir.listFiles();
								for (int i = 0; i < folders.length; i++) {
									File[] files = folders[i].listFiles();
									for (int j = 0; j < files.length; j++) {
										files[j].delete();
									}
									folders[i].delete();
								}
								dir.delete();
							}
						}
					}
				}

				public void windowGainedFocus(WindowEvent e) {
					e.getWindow().repaint();
				}
			});

			frame.getContentPane().setLayout(new GridLayout(1, 1));

			frame.getContentPane().add(browser);

			frame.addWindowListener(wl);
			frame.setSize(300, 300);

			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					frame.pack();
					frame.setVisible(true);

				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Starts the browser given textRoot, ptbRoot and pdtbRoot.
	 * 
	 */
	public static void main(String[] args) {
		try {
			String textRoot = null;
			String ptbRoot = null;
			String pdtbRoot = null;

			if (args.length != 3) {
				JFrame mainFrame = new JFrame();
				int retVal = JOptionPane
						.showConfirmDialog(
								mainFrame,
								"You will be asked to select a directory RawRoot.\n"
										+ "This is the directory such that RawRoot"
										+ File.separatorChar
										+ "00"
										+ File.separatorChar
										+ "wsj_0003\n gives the Raw text file for Section 00 file 03.",
								"Text Directory", JOptionPane.YES_NO_OPTION,
								JOptionPane.INFORMATION_MESSAGE);

				if (retVal == JOptionPane.CANCEL_OPTION) {
					System.exit(0);
				}

				JFileChooser fc = new JFileChooser();
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

				retVal = fc.showDialog(mainFrame, "RawRoot");
				if (retVal == JFileChooser.APPROVE_OPTION) {
					textRoot = fc.getSelectedFile().getAbsolutePath();
				} else {
					System.exit(0);
				}

				retVal = JOptionPane
						.showConfirmDialog(
								mainFrame,
								"You will be asked to select a directory PtbRoot.\n"
										+ "This is the directory such that PtbRoot"
										+ File.separatorChar
										+ "00"
										+ File.separatorChar
										+ "wsj_0003.mrg\n gives the PTB file for Section 00 file 03.",
								"Syntax Directory", JOptionPane.YES_NO_OPTION,
								JOptionPane.INFORMATION_MESSAGE);

				if (retVal == JOptionPane.CANCEL_OPTION) {
					System.exit(0);
				}

				retVal = fc.showDialog(mainFrame, "PtbRoot");
				if (retVal == JFileChooser.APPROVE_OPTION) {
					ptbRoot = fc.getSelectedFile().getAbsolutePath();
				} else {
					System.exit(0);
				}

				retVal = JOptionPane
						.showConfirmDialog(
								mainFrame,
								"You will be asked to select a directory PdtbRoot.\n"
										+ "This is the directory such that PdtbRoot"
										+ File.separatorChar
										+ "00"
										+ File.separatorChar
										+ "wsj_0003.pdtb\n gives the PDTB file for Section 00 file 03.",
								"Discourse Directory",
								JOptionPane.YES_NO_OPTION,
								JOptionPane.INFORMATION_MESSAGE);

				if (retVal == JOptionPane.CANCEL_OPTION) {
					System.exit(0);
				}

				retVal = fc.showDialog(mainFrame, "PdtbRoot");
				if (retVal == JFileChooser.APPROVE_OPTION) {
					pdtbRoot = fc.getSelectedFile().getAbsolutePath();
				} else {
					System.exit(0);
				}
				mainFrame.dispose();
			} else {
				textRoot = args[0];
				ptbRoot = args[1];
				pdtbRoot = args[2];
			}
			runBrowser(new String[] { textRoot, ptbRoot, pdtbRoot },pdtbRoot, 0, false);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
