/*
 * PDTBAltLexRelationFeaturesImpl.java
 *
 * Created on November 30, 2005, 7:30 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

import edu.upenn.cis.pdtb.util.TreeEnumFeature;

/**
 * Implementation of the PDTBAltLexRelationFeatures interface.
 * 
 * @author nikhild, geraud
 */
public class PDTBAltLexRelationFeaturesImpl extends PDTBConnFeaturesImpl
		implements PDTBAltLexRelationFeatures {

	private TreeEnumFeature fSClassA;

	private TreeEnumFeature fSClassB;

	/** Creates a new instance of PDTBAltLexRelationFeaturesImpl */
	public PDTBAltLexRelationFeaturesImpl(String source, String type,
			String polarity, String determinancy, PDTBSelection sel,
			String sClassA, String sClassB) {
		super(source, type, polarity, determinancy, sel);
		fSClassA = SClassA.indexOf(sClassA);
		fSClassB = SClassB.indexOf(sClassB);
	}

	/**
	 * Adds the semantic class attributes to the ownerNode
	 */
	public void updateAttributesOnNode() {
		PDTBNode node = getPDTBNode();
		if (fSClassA == null) {
			System.err
					.println("Missing an sClassA for an AltLex relation.\nAlso, may have created a 'QueryOut' folder without deleting.");
		}
		node.pdtbSetAttribute("", SClassA.getName(), SClassA.getName(), "",
				fSClassA.getValue(), 2);
		if (fSClassB != null) {
			node.pdtbSetAttribute("", SClassB.getName(), SClassB.getName(), "",
					fSClassB.getValue(), 3);
		}
		super.updateAttributesOnNode();
	}

	public TreeEnumFeature getSClassA() {
		return fSClassA;
	}

	public TreeEnumFeature getSClassB() {
		return fSClassB;
	}

	public void save(Writer writer) throws IOException {
		super.save(writer);
		if (fSClassA != null) {
			writer.write(fSClassA.getValue());
			if (fSClassB != null) {
				writer.write(", " + fSClassB.getValue());
			}
			writer.write('\n');
		}
	}

}
