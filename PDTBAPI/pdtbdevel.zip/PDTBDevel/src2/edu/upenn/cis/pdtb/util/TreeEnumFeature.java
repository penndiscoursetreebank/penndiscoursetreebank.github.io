package edu.upenn.cis.pdtb.util;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.ListIterator;

/**
 * This class is used to store a tree of features, specifically the semantic
 * classes (or senses).
 * 
 * The senses are organized in a hierarchy, where some connectives are
 * classified generally as belonging for example to the class "Comparison" and
 * other connectives are classified more specifically as belonging for example
 * to the class "Comparison.Concession.Contra-expectation". To see a complete
 * tree of the hierarchy of senses, go to the annotation manual available at <a
 * href="http://www.seas.upenn.edu/~pdtb">The PDTB Page</a>.
 * 
 * To create a leaf node in this tree, use the constructor with one argument,
 * for example:
 * 
 * <pre>
 * new TreeEnumFeature(&quot;Contra-expectation&quot;)
 * </pre>
 * 
 * To create a parent to a leaf, use the constructor with two arguments, for
 * example:
 * 
 * <pre>
 * new TreeEnumFeature(&quot;Comparison&quot;, new TreeEnumFeature[] { new TreeEnumFeature(
 * 		&quot;Concession&quot;, new TreeEnumFeature[] {
 * 				new TreeEnumFeature(&quot;Contra-expectation&quot;),
 * 				new TreeEnumFeature(&quot;Expectation&quot;) }) })
 * </pre>
 * 
 * Calling getValuesLong() on this specific TreeEnumFeature will produce the
 * following String array:
 * 
 * <pre>
 * { &quot;Comparison&quot;, &quot;Comparison.Concession&quot;,
 * 		&quot;Comparison.Concession.Contra-expectation&quot;,
 * 		&quot;Comparison.Concession.Expectation&quot; }
 * </pre>
 * 
 * Calling getValuesShort() on this specific TreeEnumFeature will produce
 * something like the following String array, depending on the spacing:
 * 
 * <pre>
 * { &quot;Comparison&quot;, &quot;  Concession&quot;, &quot;    Contra-expectation&quot;, &quot;    Expectation&quot; }
 * </pre>
 * 
 * To get a node in the tree, given a String, use indexOf(). For example:
 * 
 * <pre>
 * new TreeEnumFeature(&quot;Comparison&quot;, new TreeEnumFeature[] { new TreeEnumFeature(
 * 		&quot;Concession&quot;, new TreeEnumFeature[] {
 * 				new TreeEnumFeature(&quot;Contra-expectation&quot;),
 * 				new TreeEnumFeature(&quot;Expectation&quot;) }) })
 * 		.indexOf(&quot;Comparison.Concession&quot;)
 * </pre>
 * 
 * will return the Concession node, whose parent is the Comparison node. To then
 * get the String "Concession", given this Concession node, use getName(). To
 * get the String "Comparison.Concession", given this Concession node, use
 * getValue(). For the Comparison node, getName() and getValue() will be the
 * same.
 * 
 * To use XPath to search all relations for the only the Comparison node and not
 * it's children, use a query like:
 * 
 * <pre>
 * &gt;::*[(attribute::*[regexp(local-name(),'sClassA|sClassB|sClass1A|sClass1B|sClass2A|sClass2B')andregexp(string(),'.*(Comparison)')])]
 * </pre>
 * 
 * To also search for it's subclasses, use a query like
 * 
 * <pre>
 * &gt;::*[(attribute::*[regexp(local-name(),'sClassA|sClassB|sClass1A|sClass1B|sClass2A|sClass2B')andregexp(string(),'.*(Comparison).*')])]
 * </pre>
 * 
 * @author geraud
 */
public class TreeEnumFeature implements Comparable {

	private TreeEnumFeature[] fChildren;
	private String fName;
	private final static String spacing = "        ";
	private TreeEnumFeature fParent;

	/**
	 * Instantiation for an inner node
	 * 
	 * @param name
	 *            A string representation of the feature group name
	 * @param children
	 *            An TreeEnumFeature array of the feature's children
	 */
	public TreeEnumFeature(String name, TreeEnumFeature[] children) {
		fName = name;
		Arrays.sort(children);
		fParent = null;
		fChildren = children;
		for (int i = 0; i < fChildren.length; i++) {
			fChildren[i].setParent(this);
		}
	}

	/**
	 * Instantiation for a leaf node
	 * 
	 * @param name
	 *            A string representation of the feature group name
	 */
	public TreeEnumFeature(String name) {
		fName = name;
		fChildren = null;
		fParent = null;
	}

	/**
	 * Returns an array of TreeEnumFeatures, given a formatted LinkedList
	 * 
	 * @param list
	 *            A LinkedList of .-formatted nodes
	 * @return an array of TreeEnumFeatures
	 */
	public static TreeEnumFeature[] TreeEnumFeatureFromList(final LinkedList list) {
		LinkedList ret = new LinkedList();
		LinkedList sub = null;
		String parentStr = null;
		for (ListIterator i = list.listIterator(); i.hasNext();) {
			String str = (String) i.next();
			if (str.charAt(0) == '.') {
				sub.add(str.substring(1));
			} else {
				if (parentStr != null) {
					if (sub == null) {
						ret.add(new TreeEnumFeature(parentStr));
					} else {
						ret.add(new TreeEnumFeature(parentStr,
								TreeEnumFeatureFromList(sub)));
					}
				}
				parentStr = str;
				sub = new LinkedList();
			}
			if (!i.hasNext()) {
				if (sub == null) {
					ret.add(new TreeEnumFeature(parentStr));
				} else {
					ret.add(new TreeEnumFeature(parentStr,
							TreeEnumFeatureFromList(sub)));
				}
			}
		}
		TreeEnumFeature[] retArr = new TreeEnumFeature[ret.size()];
		for (ListIterator i = ret.listIterator(); i.hasNext(); retArr[i
				.nextIndex()] = (TreeEnumFeature) i.next()) {
		}
		return retArr;
	}

	private void setParent(TreeEnumFeature parent) {
		fParent = parent;
	}

	/**
	 * Gets the parent node
	 * 
	 * @return The TreeEnumFeature parent
	 */
	public TreeEnumFeature getParent() {
		return fParent;
	}

	/**
	 * Gets the name of the group of features
	 * 
	 * @return The name of the group of features
	 */
	public String getName() {
		return fName;
	}

	/**
	 * Gets the feature string
	 * 
	 * @return The requested feature string
	 */
	public String getValue() {
		if (fParent == null || fParent.getParent() == null) {
			return fName;
		} else {
			return fParent.getValue() + "." + fName;
		}
	}

	private LinkedList getValuesLong(String beginning) {
		LinkedList ret = new LinkedList();
		if (fChildren != null) {
			for (int i = 0; i < fChildren.length; i++) {
				String val = beginning + "." + fChildren[i].getName();
				ret.add(val);
				ret.addAll(fChildren[i].getValuesLong(val));
			}
		}
		return ret;
	}

	/**
	 * Gets the the whole tree of features as a linear array, with the features
	 * in their full form
	 * 
	 * @return The whole String array of features
	 */
	public String[] getValuesLong() {
		LinkedList ret = new LinkedList();
		for (int i = 0; i < fChildren.length; i++) {
			String val = fChildren[i].getName();
			ret.add(val);
			ret.addAll(fChildren[i].getValuesLong(val));
		}
		return (String[]) ret.toArray(new String[ret.size()]);
	}

	private LinkedList getValuesShort(String beginning) {
		LinkedList ret = new LinkedList();
		if (fChildren != null) {
			for (int i = 0; i < fChildren.length; i++) {
				String val = beginning + fChildren[i].getName();
				ret.add(val);
				ret.addAll(fChildren[i].getValuesShort(beginning + spacing));
			}
		}
		return ret;
	}

	/**
	 * Gets the the whole tree of features as a linear array, with the features
	 * in their short form with spacing to replace parents
	 * 
	 * @return The whole String array of features
	 */
	public String[] getValuesShort() {
		LinkedList ret = new LinkedList();
		for (int i = 0; i < fChildren.length; i++) {
			String val = fChildren[i].getName();
			ret.add(val);
			ret.addAll(fChildren[i].getValuesShort(spacing));
		}
		return (String[]) ret.toArray(new String[ret.size()]);
	}

	/**
	 * Gets the TreeEnumFeature who has the given string value
	 * 
	 * @param value
	 *            The feature string whose owner is requested
	 * @return The TreeEnumFeature node who has the given string value
	 */
	public TreeEnumFeature indexOf(String value) {
		if (value != null) {
			String[] split = value.split("\\.");
			int i = Arrays.binarySearch(fChildren,
					new TreeEnumFeature(split[0]));
			if (split.length == 1) {
				return fChildren[i];
			} else {
				return fChildren[i].indexOf(value.replaceFirst(
						split[0] + "\\.", ""));
			}
		} else {
			return null;
		}
	}

	public final int compareTo(Object o) {
		return fName.compareTo(((TreeEnumFeature) o).getName());
	}

}