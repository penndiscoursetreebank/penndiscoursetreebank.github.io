/*
 * PDTBSelectionImpl.java
 *
 * Created on November 28, 2005, 5:55 PM
 */

package edu.upenn.cis.pdtb;

import java.util.Enumeration;
import java.util.Vector;
import java.util.Stack;
import java.io.IOException;
import java.io.Writer;

import edu.upenn.cis.pdtb.util.GornAddressList;
import edu.upenn.cis.pdtb.util.SpanList;

/**
 *
 * @author  nikhild
 */
public class PDTBSelectionImpl implements PDTBSelection{
    
    private SpanList fSpanList;
    
    private GornAddressList fGornAddressList;
    
    private String fRawText;
    
    private Vector fPTBTreeNodes = new Vector();
    
    private PDTBNode fParent;
    
    protected static final Stack PDTBSelectionPool = new Stack();
    
    /** Creates a new instance of PDTBSelectionImpl */
    public PDTBSelectionImpl(SpanList spanList, 
       GornAddressList gal, String rawText, Enumeration treeNodes) {
        fSpanList = spanList;
        fGornAddressList = gal;
        fRawText = rawText;
        for(;treeNodes.hasMoreElements();){
            fPTBTreeNodes.add(treeNodes.nextElement());
        }
    }
    
    public GornAddressList getAddresses() {
        return fGornAddressList;
    }
    
    
    public PDTBNode getPDTBNode() {
        return fParent;
    }
    
    public Enumeration getPTBNodes() {
        return fPTBTreeNodes.elements();
    }
    
    public String getRawText() {
        return fRawText;
    }
    
    public SpanList getSpans() {
        return fSpanList;
    }
    
    
    public void setPDTBNode(PDTBNode node) {
        fParent = node;
    }
     
    public void updateAttributesOnNode() {
        fParent.pdtbSetAttribute("", RawTextAttributeQName, RawTextAttributeQName, "", fRawText,11);
    }
    
    public void save(Writer writer) throws IOException{
        writer.write(fSpanList.toString()); writer.write('\n');
        writer.write(fGornAddressList.toString()); writer.write('\n');
    }
    
    
}
