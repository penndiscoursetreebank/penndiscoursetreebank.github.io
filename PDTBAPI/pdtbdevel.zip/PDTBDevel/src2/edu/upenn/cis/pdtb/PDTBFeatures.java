package edu.upenn.cis.pdtb;

import edu.upenn.cis.pdtb.util.EnumFeature.EnumIndex;

/**
 * The base class of the features associated with a PDTBNode. In this base form,
 * it is associated with Args and Conns. Subclasses are associated with
 * relations.
 * 
 * @author geraud
 */
public interface PDTBFeatures {

	public static final PDTBOptions options = new PDTBOptions("Options.properties");
	
	/**
	 * Get the source.
	 */
	public EnumIndex getSource();

	/**
	 * Get the factuality.
	 */
	public EnumIndex getType();

	/**
	 * Get the polarity.
	 */
	public EnumIndex getPolarity();

	/**
	 * Get the determinancy
	 */
	public EnumIndex getDeterminancy();

	public void setSource(EnumIndex i);

	public void setType(EnumIndex i);

	public void setPolarity(EnumIndex i);

	public void setDeterminancy(EnumIndex i);
	
	/**
	 * Get the selection
	 */
	public void setSelection(PDTBSelection sel);

	/**
	 * Set the selection
	 */
	public PDTBSelection getSelection();

	/**
	 * Get the node on with which these features are associated.
	 */
	public PDTBNode getPDTBNode();

	/**
	 * Set the node with which these features are associated.
	 */
	public void setPDTBNode(PDTBNode node);

	/**
	 * Update the attributes on the node to the string values of these features.
	 */
	public void updateAttributesOnNode();

}
