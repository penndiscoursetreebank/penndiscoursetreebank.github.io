/*
 * PDTBArg.java
 *
 * Created on November 27, 2005, 12:45 PM
 */

package edu.upenn.cis.pdtb;

/**
 * An argument of a relation.
 * @author nikhild, geraud
 */
public interface PDTBArg extends PDTBSup{
    
    /**
     * Get the features
     */    
    public PDTBArgFeatures getFeatures();
    
    /**
     * Set the features
     */    
    public void setFeatures(PDTBArgFeatures feats);
    
    /**
     * Set the selection
     */  
    public void setSelection(PDTBSelection sel);
    
    /**
     * Get the selection
     */  
    public PDTBSelection getSelection();
}
