/*
 * PDTBArgFeaturesImpl.java
 *
 * Created on July 09, 2007, 4:00 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

/**
 * Implementation of the PDTBArgFeatures interface.
 * 
 * @since 3.0
 * @author geraud
 */
public class PDTBArgFeaturesImpl extends PDTBFeaturesImpl implements
		PDTBArgFeatures {

	/** Creates a new instance of PDTBArgFeaturesImpl */
	public PDTBArgFeaturesImpl(String source, String type, String polarity,
			String determinancy, PDTBSelection sel) {
		setSource(SourceFeature.indexOf(source));
		setType(TypeFeature.indexOf(type));
		setPolarity(PolarityFeature.indexOf(polarity));
		setDeterminancy(DeterminancyFeature.indexOf(determinancy));
		fSel = sel;
	}

	public void updateAttributesOnNode() {
		PDTBNode node = getPDTBNode();
		node.pdtbSetAttribute("", SourceFeature.getName(), SourceFeature
				.getName(), "", getSource().toString(),7);
		node.pdtbSetAttribute("", TypeFeature.getName(),
				TypeFeature.getName(), "", getType().toString(),8);
		node.pdtbSetAttribute("", PolarityFeature.getName(), PolarityFeature
				.getName(), "", getPolarity().toString(),9);
		node.pdtbSetAttribute("", DeterminancyFeature.getName(),
				DeterminancyFeature.getName(), "", getDeterminancy().toString(),10);
	}

	public void save(Writer writer) throws IOException {
		writer.write(getSource() + ", ");
		writer.write(getType() + ", ");
		writer.write(getPolarity() + ", ");
		writer.write(getDeterminancy() + "\n");
		if (getSelection() != null) {
			((PDTBSelectionImpl) getSelection()).save(writer);
		}
	}

}
