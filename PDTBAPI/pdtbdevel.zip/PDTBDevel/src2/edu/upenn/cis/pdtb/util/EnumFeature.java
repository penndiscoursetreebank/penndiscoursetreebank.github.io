/*
 * EnumFeature.java
 *
 * Created on July 09, 2007, 4:00 PM
 */

package edu.upenn.cis.pdtb.util;

import java.util.Arrays;
import java.util.Comparator;

/**
 * This class is used to store a group of features. It takes an array of the
 * feature strings and sorts this array once. This makes it possible to look up
 * a value, given an index, in constant time, or look up an index, given a
 * value, in log(n) time.
 * 
 * For example, the EnumFeature for source would be created by:
 * 
 * <pre>
 * EnumFeature SourceFeature = new EnumFeature(&quot;Source&quot;, new String[] { &quot;Arb&quot;,
 * 		&quot;Ot&quot;, &quot;Wr&quot; }, 2);
 * </pre>
 * 
 * 2 Is the default index, and here it points to "Wr".
 * 
 * SourceFeature.getName() will return "Source".
 * 
 * To get the index of a given String in an EnumFeature, you would do something
 * like:
 * 
 * <pre>
 * EnumIndex i = SourceFeature.indexOf(&quot;Ot&quot;);
 * </pre>
 * 
 * You can then use this index to look up the String using:
 * 
 * <pre>
 * String s = i.toString();
 * </pre>
 * 
 * s will now be "Ot".
 * 
 * EnumIndex also has a built in equals() function for the most efficient
 * comparison of enumFeature Indices
 * 
 * @since 3.0
 * @author geraud
 */
public class EnumFeature {

	private String[] fValues;

	private String fName;

	private int fDefaultIndex = -1;

	private static final Comparator ignoreCaseCompare = new IgnoreCaseCompare();

	/**
	 * Instantiation
	 * 
	 * @param name
	 *            A string representation of the feature group name
	 * @param values
	 *            An string array of the feature
	 * @param defaultIndex
	 *            The index of the default value in the values param
	 */
	public EnumFeature(String name, String[] values, int defaultIndex) {
		fName = name;
		String defaultValue = null;
		if (defaultIndex >= 0) {
			defaultValue = values[defaultIndex];
		}
		Arrays.sort(values, ignoreCaseCompare);
		fValues = values;
		if (defaultValue != null) {
			fDefaultIndex = Arrays.binarySearch(fValues, defaultValue,
					ignoreCaseCompare);
		}
	}

	public EnumFeature(String name, String[] values) {
		fName = name;
		Arrays.sort(values, ignoreCaseCompare);
		fValues = values;
	}

	/**
	 * Gets the name of the group of features
	 * 
	 * @return The name of the group of features
	 */
	public String getName() {
		return fName;
	}

	/**
	 * Gets the feature index of the given feature string
	 * 
	 * @param value
	 *            The feature string whose index is requested
	 * @return The index of the requested feature string. Negative if the string
	 *         not found, default index if the string is null
	 */
	public EnumIndex indexOf(String value) {
		if (value == null) {
			return new EnumIndex(this, fDefaultIndex);
		}
		return new EnumIndex(this, Arrays.binarySearch(fValues, value,
				ignoreCaseCompare));
	}

	/**
	 * Gets the feature string at the given index
	 * 
	 * @param i
	 *            The index of the requested feature string
	 * @return The requested feature string at the given index, default value or
	 *         null if i is negative
	 */
	private String getValue(EnumIndex i) {
		if (i.getIndex() < 0) {
			if (fDefaultIndex >= 0) {
				return fValues[fDefaultIndex];
			} else {
				return null;
			}
		}
		return fValues[i.getIndex()];
	}

	/**
	 * Gets the the whole array of features
	 * 
	 * @return The whole String array of features
	 */
	public String[] getValues() {
		return fValues;
	}

	/**
	 * Gets the default value
	 * 
	 * @return The default feature string, null if none exists
	 */
	public String getDefaultValue() {
		if (fDefaultIndex >= 0) {
			return fValues[fDefaultIndex];
		} else {
			return null;
		}
	}

	/**
	 * Gets the default value's index
	 * 
	 * @return The index of the default value
	 */
	public EnumIndex getDefaultIndex() {
		return new EnumIndex(this, fDefaultIndex);
	}

	/**
	 * Representation of an EnumFeature index. Overloads the toString() and
	 * equals() method for printing out the value and comparing indices.
	 */
	public class EnumIndex {
		private final EnumFeature features;
		private final int i;

		private EnumIndex(final EnumFeature features, final int i) {
			this.features = features;
			this.i = i;
		}

		public String toString() {
			return features.getValue(this);
		}

		/**
		 * If EnumIndices were not created from the same EnumFeature Object,
		 * this function will always return false.
		 */
		public boolean equals(Object o) {
			if (o instanceof EnumIndex) {
				EnumIndex other = (EnumIndex) o;
				if (other.getFeatures() == features) {
					return other.getIndex() == i;
				}
				System.err.println("Warning: ");
			}
			return false;
		}

		private int getIndex() {
			return i;
		}

		private EnumFeature getFeatures() {
			return features;
		}
	}

}

/**
 * Comparator class that allows the sorting and searching of strings, ignoring
 * case
 */
class IgnoreCaseCompare implements Comparator {
	public final int compare(Object a, Object b) {
		return ((String) a).compareToIgnoreCase((String) b);
	}
}