/*
 * CachedAbsolutePathFunction.java
 *
 * Created on February 11, 2006, 7:20 PM
 */

package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import org.jaxen.XPath;
import java.util.List;
import java.util.WeakHashMap;
import java.lang.ref.WeakReference;

/**
 * Caching subexpressions. This function has the signature:
 *
 * <pre>
 *  node-set cache(string )
 * </pre>
 *
 * The argument is a string which should be a valid XPath expression. This
 * expression will be run against the RelationList of the current document. A
 * discussion of how to use it can be found on the 
 *  <a href="http://www.seas.upenn.edu/~nikhild/PDTBAPI/xpathextensions.html">XPath Extensions Page </a>
 * 
 * @since 0.2.6
 * @author  nikhild
 */
public class CachedAbsolutePathFunction implements Function {
    
    private WeakHashMap fExpressionMap = new WeakHashMap();
    
    private WeakHashMap fResultMap = new WeakHashMap();
    
    private WeakReference fCachedResultRef = null;
    
    private XPath  fPreviousXPath = null;
    
    private WeakReference fRoot =null;
    
    public CachedAbsolutePathFunction() {
    }
    
    public Object call(Context context, List list) throws org.jaxen.FunctionCallException {
        if(list.size() != 1){
            throw(new FunctionCallException("Number of arguments expected is 1. " + list.size() + "supplied"));
        }
        
        Object arg = list.get(0);
        if(!(arg instanceof String)){
            throw(new FunctionCallException("Argument should be a string representing the xpath expression." + arg.getClass().getName() + " supplied"));
        }
        
        PDTBNavigator nav = (PDTBNavigator) context.getNavigator();
        Object root = nav.getRoot();
        
        if(fRoot == null || root != fRoot.get()){
            fResultMap.clear();
            if(fCachedResultRef != null){
                fCachedResultRef.clear();
            }
            fRoot = new WeakReference(root);
        }
        
        String xpathStr = (String)(arg);
        XPath xp = (XPath) fExpressionMap.get(xpathStr);
        if(xp != null){
            if(xp == fPreviousXPath && fCachedResultRef.get() != null){
                return fCachedResultRef.get();
            }
            
            List result = (List) fResultMap.get(xpathStr);
            if(result != null){
                fPreviousXPath = xp;
                fCachedResultRef = new WeakReference(result);
                return result;
            }
            
            try{
                result = (List) xp.evaluate(root);
            }catch(Exception e){
                throw(new FunctionCallException("Invalid xpath: " + xpathStr, e));
            }
            
            fResultMap.put(xpathStr, result);
            fCachedResultRef = new WeakReference(result);
            fPreviousXPath = xp;
            return result;
        }
        
        
            try{
                xp = nav.parseXPath(edu.upenn.cis.ptb.xpath.PTBXPath.unEscapeExpr(xpathStr));
                fPreviousXPath = xp;
                List result = (List) xp.evaluate(nav.getDocumentNode(null));
                result = (List) xp.evaluate(root);
                fResultMap.put(xpathStr, result);
                fExpressionMap.put(xpathStr, xp);
                fCachedResultRef = new WeakReference(result);
                fPreviousXPath = xp;
                return result;
            }catch(Exception e){
                throw(new FunctionCallException("Invalid xpath: " + xpathStr, e));
            }

    }
    
}
