/*
 * WSJTextArea.java
 *
 * Created on December 7, 2005, 4:14 PM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.*;
import javax.swing.text.*;

import java.awt.*;

import javax.swing.plaf.TextUI;
import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.pdtb.util.Span;
import edu.upenn.cis.pdtb.util.SpanList;

import java.util.Iterator;

/**
 * The raw text corresponding to the discourse. Highlights the appropriate spans
 * when a PDTB node is selected, and scrolls to move the selection into the
 * center of the screen.
 *
 * @author  nikhild, geraud
 */
public class WSJTextPane extends JTextPane implements PDTBNodeSelectionListener, FontChangeListener{
    
    protected final WSJHighlightPainter ExplicitConnHighlightPainter = new WSJHighlightPainter(ColorConstants.ExplicitConnColor);
    
    protected final WSJHighlightPainter ExplicitConnAttribHighlightPainter = new WSJHighlightPainter(ColorConstants.ExplicitConnAttribColor);
    
    protected final WSJHighlightPainter Arg1HighlightPainter = new WSJHighlightPainter(ColorConstants.Arg1Color);
    
    protected final WSJHighlightPainter Arg1AttribHighlightPainter = new WSJHighlightPainter(ColorConstants.Arg1AtrribColor);
    
    protected final WSJHighlightPainter Arg2HighlightPainter = new WSJHighlightPainter(ColorConstants.Arg2Color);
    
    protected final WSJHighlightPainter Arg2AttribHighlightPainter = new WSJHighlightPainter(ColorConstants.Arg2AtrribColor);
    
    protected final WSJHighlightPainter Sup1HighlightPainter = new WSJHighlightPainter(ColorConstants.Sup1Color);
    
    protected final WSJHighlightPainter Sup2HighlightPainter = new WSJHighlightPainter(ColorConstants.Sup2Color);
    
    protected final static int Bold = 1;
    
    protected final static int Italics = 2;
    
    /** Creates a new instance of WSJTextArea */
    public WSJTextPane(String text, JTree pdtbTree) {
        super();
        
        setFont(FontProvider.PDTBBrowserFontProvider.getCurrentFont());    
        FontProvider.PDTBBrowserFontProvider.addListener(this);
        
        setMargin(new Insets(10,10,10,10));
        setEditable(false);
        TreeSelectionListenerImpl listener = new TreeSelectionListenerImpl();
        listener.add(this);
        pdtbTree.getSelectionModel().addTreeSelectionListener(listener);
       
        StyledDocument doc = getStyledDocument();
        try {
			doc.insertString(0, text, null);
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
    }
    
    protected void clearStyles(){
        getHighlighter().removeAllHighlights();
        StyledDocument doc = getStyledDocument();
        SimpleAttributeSet attrSet = new SimpleAttributeSet();
        StyleConstants.setBold(attrSet,false);
        StyleConstants.setItalic(attrSet, false);
        doc.setCharacterAttributes(0, getText().length(), attrSet, true);
    }
    
    protected void style(SpanList spans, Highlighter.HighlightPainter painter, int style){
    	highlight(spans,painter);
    	if(style==Bold){
    		bold(spans);
    	}else if(style==Italics){
    		italicize(spans);
    	}
    }
    
    protected void highlight(SpanList spans, Highlighter.HighlightPainter painter){
        for(Iterator iter = spans.iterator(); iter.hasNext();){
            Span s = (Span)(iter.next());
            try{
                getHighlighter().addHighlight(s.getStart(), s.getEnd(), painter);
            }catch(Exception e){
                
            }
        }
    }
    
    protected void bold(SpanList spans){
        for(Iterator iter = spans.iterator(); iter.hasNext();){
            Span s = (Span)(iter.next());
            StyledDocument doc = getStyledDocument();
            SimpleAttributeSet attrSet = new SimpleAttributeSet();
            StyleConstants.setBold(attrSet,true);
            doc.setCharacterAttributes(s.getStart(), s.getEnd()-s.getStart(), attrSet, false);
        }
    }
    
    protected void italicize(SpanList spans){
        for(Iterator iter = spans.iterator(); iter.hasNext();){
            Span s = (Span)(iter.next());
            StyledDocument doc = getStyledDocument();
            SimpleAttributeSet attrSet = new SimpleAttributeSet();
            StyleConstants.setItalic(attrSet,true);
            doc.setCharacterAttributes(s.getStart(), s.getEnd()-s.getStart(), attrSet, false);
        }
    }
    
    protected void style(PDTBNode node){
        if(node instanceof PDTBRelation){
            if(node instanceof PDTBExplicitRelation){
                PDTBExplicitRelation rel = (PDTBExplicitRelation)node;
                style(rel.getSelection().getSpans(), ExplicitConnHighlightPainter, Bold);
                
                PDTBSelection connFeatSel = rel.getFeatures().getSelection();
                if(connFeatSel!=null){
                	style(connFeatSel.getSpans(), ExplicitConnAttribHighlightPainter, Italics);
                }
                
                PDTBArg arg1 = rel.getArg1();
                style(arg1.getSelection().getSpans(), Arg1HighlightPainter, Bold);
                
                PDTBSelection arg1FeatSel = arg1.getFeatures().getSelection();
                if(arg1FeatSel!=null){
                	style(arg1FeatSel.getSpans(), Arg1AttribHighlightPainter, Italics);
                }
                
                PDTBArg arg2 = rel.getArg2();
                style(arg2.getSelection().getSpans(), Arg2HighlightPainter, Bold);

                PDTBSelection arg2FeatSel = arg2.getFeatures().getSelection();
                if(arg2FeatSel!=null){
                	style(arg2FeatSel.getSpans(), Arg2AttribHighlightPainter, Italics);
                }
                
                PDTBSup sup1 = rel.getSup1();
                if(sup1 != null){
                    style(sup1.getSelection().getSpans(), Sup1HighlightPainter, Bold);
                }
                
                PDTBSup sup2 = rel.getSup2();
                if(sup2 != null){
                    style(sup2.getSelection().getSpans(), Sup2HighlightPainter, Bold);
                }
            }
            else if(node instanceof PDTBAltLexRelation){
                PDTBAltLexRelation rel = (PDTBAltLexRelation)node;
                style(rel.getSelection().getSpans(), ExplicitConnHighlightPainter, Bold);
                
                PDTBSelection connFeatSel = rel.getFeatures().getSelection();
                if(connFeatSel!=null){
                	style(connFeatSel.getSpans(), ExplicitConnAttribHighlightPainter, Italics);
                }
                
                PDTBArg arg1 = rel.getArg1();
                style(arg1.getSelection().getSpans(), Arg1HighlightPainter, Bold);
                
                PDTBSelection arg1FeatSel = arg1.getFeatures().getSelection();
                if(arg1FeatSel!=null){
                	style(arg1FeatSel.getSpans(), Arg1AttribHighlightPainter, Italics);
                }
                
                PDTBArg arg2 = rel.getArg2();
                style(arg2.getSelection().getSpans(), Arg2HighlightPainter, Bold);
                
                PDTBSelection arg2FeatSel = arg2.getFeatures().getSelection();
                if(arg2FeatSel!=null){
                	style(arg2FeatSel.getSpans(), Arg2AttribHighlightPainter, Italics);
                }
                
                PDTBSup sup1 = rel.getSup1();
                if(sup1 != null){
                    style(sup1.getSelection().getSpans(), Sup1HighlightPainter, Bold);
                }
                
                PDTBSup sup2 = rel.getSup2();
                if(sup2 != null){
                    style(sup2.getSelection().getSpans(), Sup2HighlightPainter, Bold);
                }
            }
            else if(node instanceof PDTBImplicitRelation){
                PDTBImplicitRelation rel = (PDTBImplicitRelation)node;

                PDTBSelection connFeatSel = rel.getFeatures().getSelection();
                if(connFeatSel!=null){
                	style(connFeatSel.getSpans(), ExplicitConnAttribHighlightPainter, Italics);
                }
                
                PDTBArg arg1 = rel.getArg1();
                style(arg1.getSelection().getSpans(), Arg1HighlightPainter, Bold);
                
                PDTBSelection arg1FeatSel = arg1.getFeatures().getSelection();
                if(arg1FeatSel!=null){
                	style(arg1FeatSel.getSpans(), Arg1AttribHighlightPainter, Italics);
                }
                
                PDTBArg arg2 = rel.getArg2();
                style(arg2.getSelection().getSpans(), Arg2HighlightPainter, Bold);
                
                PDTBSelection arg2FeatSel = arg2.getFeatures().getSelection();
                if(arg2FeatSel!=null){
                	style(arg2FeatSel.getSpans(), Arg2AttribHighlightPainter, Italics);
                }
                
                PDTBSup sup1 = rel.getSup1();
                if(sup1 != null){
                    style(sup1.getSelection().getSpans(), Sup1HighlightPainter, Bold);
                }
                
                PDTBSup sup2 = rel.getSup2();
                if(sup2 != null){
                    style(sup2.getSelection().getSpans(), Sup2HighlightPainter, Bold);
                }
            }
            
            
        }
        else{
            if(node instanceof PDTBEntityRelation){
                PDTBEntityRelation rel = (PDTBEntityRelation)node;
                
                PDTBSup arg1 = rel.getArg1();
                style(arg1.getSelection().getSpans(), Arg1HighlightPainter, Bold);
                
                PDTBSup arg2 = rel.getArg2();
                style(arg2.getSelection().getSpans(), Arg2HighlightPainter, Bold);
                
            }
            else if(node instanceof PDTBArg){
                
                if(node == ((PDTBRelation) node.getParent()).getArg1()){
                    PDTBArg arg1 = (PDTBArg)node;
                    style(arg1.getSelection().getSpans(), Arg1HighlightPainter, Bold);
                    
                    PDTBSelection arg1FeatSel = arg1.getFeatures().getSelection();
                    if(arg1FeatSel!=null){
                    	style(arg1FeatSel.getSpans(), Arg1AttribHighlightPainter, Italics);
                    }
                }
                else{
                    PDTBArg arg2 = (PDTBArg)node;
                    style(arg2.getSelection().getSpans(), Arg2HighlightPainter, Bold);
                    
                    PDTBSelection arg2FeatSel = arg2.getFeatures().getSelection();
                    if(arg2FeatSel!=null){
                    	style(arg2FeatSel.getSpans(), Arg2AttribHighlightPainter, Italics);
                    }
                }
                
            }
            else{
                PDTBNode parent = (PDTBNode)(node.getParent());
                if(parent instanceof PDTBRelation){
                    if(node == ((PDTBRelation) parent).getSup1()){
                        style(((PDTBSup)node).getSelection().getSpans(), Sup1HighlightPainter, Bold);
                    }
                    else{
                        style(((PDTBSup)node).getSelection().getSpans(), Sup2HighlightPainter, Bold);
                    }
                }
                else{
                    if(node == ((PDTBEntityRelation) parent).getArg1()){
                        style(((PDTBSup)node).getSelection().getSpans(), Arg1HighlightPainter, Bold);
                    }
                    else{
                        style(((PDTBSup)node).getSelection().getSpans(), Arg2HighlightPainter, Bold);
                    }
                }
            }
        }
    }
    
    protected void makeVisible(PDTBNode node){
        Span s = null;
        if(node instanceof PDTBSup){
            s = (Span)(((PDTBSup)node).getSelection().getSpans().first());
        }
        else{
            if(node instanceof PDTBExplicitRelation){
                s = (Span)(((PDTBExplicitRelation)node).getSelection().getSpans().first());
            }
            else if(node instanceof PDTBAltLexRelation){
                s = (Span)(((PDTBAltLexRelation)node).getSelection().getSpans().first());
            }
            else if(node instanceof PDTBImplicitRelation){
                s = (Span)(((PDTBImplicitRelation)node).getArg2().getSelection().getSpans().first());
            }
            else if (node instanceof PDTBEntityRelation){
                s = (Span)(((PDTBEntityRelation)node).getArg2().getSelection().getSpans().first());
            }
        }
        
        TextUI ui = getUI();
        try{
            Rectangle r = ui.modelToView(this, s.getStart());
            Rectangle v = getVisibleRect();
            
            
            r.height = (v.height/2);
            r.width = (v.width/2);
            
            int centerY = v.y + v.height/2;
            int diffY = r.y - centerY;
            r.y = ((diffY) > 0)? r.y : r.y - v.height/2;
            
            
            int centerX = v.x + v.width/2;
            int diffX = r.x - centerX;
            r.x = (diffX <= 0)? r.x - v.width/2 : r.x;
            
            if(r.x < 0){
                r.x = 0;
            }
            
            scrollRectToVisible(r);
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
    }

    protected void select(PDTBNode node){
        clearStyles();
        style(node);
        makeVisible(node);
    }
    
    public void arg1Selected(PDTBSup arg1) {
        select(arg1);
    }
    
    public void arg2Selected(PDTBSup arg2) {
        select(arg2);
    }
    
    public void explicitRelationSelected(PDTBExplicitRelation rel) {
        select(rel);
    }
    
    public void sup1Selected(PDTBSup sup1) {
        select(sup1);
    }
    
    public void sup2Selected(PDTBSup sup2) {
        select(sup2);
    }
    
    public Dimension getPreferredScrollableViewportSize() {
        Dimension d = getPreferredSize();
        //return getPreferredSize();
        
        return new Dimension(((d.getWidth() > 100)? 100 : (int) (d.getWidth())),
        ((d.getHeight() > 100)? 100 : (int) (d.getHeight())));
    }
    
    public void altLexRelationSelected(PDTBAltLexRelation rel) {
        select(rel);
    }    
    
    public void implicitRelationSelected(PDTBImplicitRelation rel) {
        select(rel);
    }    
    
    public void entityRelationSelected(PDTBEntityRelation rel) {
        select(rel);
    }
    
    public void noRelationSelected(PDTBNoRelation rel) {
        select(rel);
    }
    
    public void fontChanged(Font newFont){
        setFont(newFont);
    }
    
    public class WSJHighlightPainter extends DefaultHighlighter.DefaultHighlightPainter{
        
        public WSJHighlightPainter(Color c){
            super(c);
        }
    }
    
}
