/*
 * FileNoComboBoxModel.java
 *
 * Created on December 7, 2005, 7:24 PM
 */

package edu.upenn.cis.pdtb.graphics;

import java.util.LinkedList;
import javax.swing.ComboBoxModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.util.Vector;
import java.util.Enumeration;

/**
 * Combo box representing the various sections that have atleast 1 file in them.
 * If no files are present in any section, it sets the current section to -1. 
 * Attempting to load files with then result in exceptions. Messages the 
 * FileNoComboBoxModel when the selection is changed.
 *
 * @author  nikhild
 * @see FileNoComboBoxModel
 */
public class SecNoComboBoxModel implements ComboBoxModel, ChangeListener{
    //Array containing the section numbers that have atleast 1 file in them
    private Integer[] fSectionNumbers;
    
    //The current section
    private Integer fCurrentSection;
    
    //The listeners
    private Vector fListeners = new Vector();
    
    /** 
     * Creates a new instance of SecNoComboBoxModel 
     *
     * @param fileNumbers Needed to know which sections actually have files in them.
     */
    public SecNoComboBoxModel(LinkedList[] fileNumbers) {
        Vector v = new Vector();
        boolean found = false;
        fCurrentSection = null;
        int len = fileNumbers.length;
        for(int i = 0; i < len; i++){
            if(fileNumbers[i].size() > 0){
                v.add(new Integer(i));
                if(!found){
                    found = true;
                    fCurrentSection = new Integer(i);
                }
                
            }
            
        }
        
        //Build the array of section numbers that have atleast 1 file.
        fSectionNumbers = new Integer[v.size()];
        int j = 0;
        for(Enumeration e = v.elements(); e.hasMoreElements(); j++){
            fSectionNumbers[j] = (Integer)(e.nextElement());
        }
        
    }
    
    public void addListDataListener(ListDataListener listDataListener) {
        fListeners.add(listDataListener);
    }
    
    public Object getElementAt(int param) {
        Integer obj = fSectionNumbers[param];
        int sec = obj.intValue();
        return (sec >= 0 && sec < 10)? "0" + sec : "" + sec;
    }
    
    public Object getSelectedItem() {
        if(fCurrentSection == null){
            return "";
        }
        
        int sec = fCurrentSection.intValue();
        return (sec >= 0 && sec < 10)? "0" + sec : "" + sec;
    }
    
    
    public int getSize() {
        return fSectionNumbers.length;
    }
    
    public void removeListDataListener(ListDataListener listDataListener) {
        fListeners.remove(listDataListener);
    }
    
    public void setSelectedItem(Object obj) {
        String secString = (String)obj;
        fCurrentSection = new Integer(secString);
        for(Enumeration e = fListeners.elements(); e.hasMoreElements();){
            ListDataListener l = (ListDataListener)(e.nextElement());
            l.contentsChanged(new ListDataEvent(this, ListDataEvent.CONTENTS_CHANGED, 0, getSize()));
        }
    }
    
    public String getNextSecNo(){
        String selectedItem = (String) getSelectedItem();
        if(selectedItem == null || selectedItem.equals("")){
            return null;
        }
        
        int len = getSize();
        for(int i = 0; i < len; i++){
            String item = (String) getElementAt(i);
            if(item.equals(selectedItem)){
                if(i == len - 1){
                    return null;
                }
                else{
                    return (String) getElementAt(i+1);
                }
            }
        }
        
        return null;
    }
    
    public String getPrevSecNo(){
        String selectedItem = (String) getSelectedItem();
        if(selectedItem == null || selectedItem.equals("")){
            return null;
        }
        
        int len = getSize();
        for(int i = 0; i < len; i++){
            String item = (String) getElementAt(i);
            if(item.equals(selectedItem)){
                if(i == 0){
                    return null;
                } else{
                    return (String) getElementAt(i -1);
                }
            }
        }
        
        return null;
    }

    public void stateChanged(ChangeEvent e) {
        Object source = e.getSource();
        if(source instanceof PDTBBrowserTab){
            PDTBBrowserTab tab = (PDTBBrowserTab) source;
            int index = tab.getSelectedIndex();
            if(index >= 0){
                String title = tab.getTitleAt(index);
                if(title != null && title.length() == 4){
                    String secNo = title.substring(0, 2);
                    if(!secNo.equals(getSelectedItem())){
                        setSelectedItem(secNo);
                    }
                    
                }
            }
        }
    }

}
