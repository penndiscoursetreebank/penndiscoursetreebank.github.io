/*
 * PDTBImplicitRelationFeaturesImpl.java
 *
 * Created on January 22, 2006, 6:42 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

import edu.upenn.cis.pdtb.util.TreeEnumFeature;

/**
 * Implementation of the PDTBImplicitRelationFeatures interface.
 * 
 * @author nikhild, geraud
 */
public class PDTBImplicitRelationFeaturesImpl extends PDTBConnFeaturesImpl
		implements PDTBImplicitRelationFeatures {

	private String fConn1;

	private String fConn2;

	private TreeEnumFeature fSClass1A;

	private TreeEnumFeature fSClass1B;

	private TreeEnumFeature fSClass2A;

	private TreeEnumFeature fSClass2B;

	/** Creates a new instance of PDTBImplicitRelationFeaturesImpl */
	public PDTBImplicitRelationFeaturesImpl(String source, String type,
			String polarity, String determinancy, PDTBSelection sel,
			String conn1, String sClass1A, String sClass1B, String conn2,
			String sClass2A, String sClass2B) {
		super(source, type, polarity, determinancy, sel);

		fConn1 = conn1;
		fSClass1A = SClass1A.indexOf(sClass1A);
		fSClass1B = SClass1B.indexOf(sClass1B);
		fConn2 = conn2;
		fSClass2A = SClass1A.indexOf(sClass2A);
		fSClass2B = SClass1B.indexOf(sClass2B);
	}

	public String getConn1() {
		return fConn1;
	}

	public TreeEnumFeature getSClass1A() {
		return fSClass1A;
	}

	public TreeEnumFeature getSClass1B() {
		return fSClass1B;
	}

	public String getConn2() {
		return fConn2;
	}

	public TreeEnumFeature getSClass2A() {
		return fSClass2A;
	}

	public TreeEnumFeature getSClass2B() {
		return fSClass2B;
	}

	public void updateAttributesOnNode() {
		PDTBNode node = getPDTBNode();

		node
				.pdtbSetAttribute("", Conn1AttrQName, Conn1AttrQName, "",
						fConn1, 1);
		if (fSClass1A == null) {
			System.err
					.println("Missing an sClass1A for an Implicit relation.\nAlso, may have created a 'QueryOut' folder without deleting.");
		}
		node.pdtbSetAttribute("", SClass1A.getName(), SClass1A.getName(), "",
				fSClass1A.getValue(), 2);
		if (fSClass1B != null) {
			node.pdtbSetAttribute("", SClass1B.getName(), SClass1B.getName(),
					"", fSClass1B.getValue(), 3);
		}
		if (fConn2 != null) {
			node.pdtbSetAttribute("", Conn2AttrQName, Conn2AttrQName, "",
					fConn2, 4);
			if (fSClass2A == null) {
				System.err
						.println("Missing an sClass2A for an Implicit relation with a Conn2.\nAlso, may have created a 'QueryOut' folder without deleting.");
			}
			node.pdtbSetAttribute("", SClass2A.getName(), SClass2A.getName(),
					"", fSClass2A.getValue(), 5);
			if (fSClass2B != null) {
				node.pdtbSetAttribute("", SClass2B.getName(), SClass2B
						.getName(), "", fSClass2B.getValue(), 6);
			}
		}
		super.updateAttributesOnNode();
	}

	public void save(Writer writer) throws IOException {
		super.save(writer);

		writer.write(fConn1);
		if (fSClass1A != null) {
			writer.write(", " + fSClass1A.getValue());
			if (fSClass1B != null) {
				writer.write(", " + fSClass1B.getValue());
			}
		}
		writer.write('\n');

		if (fConn2 != null) {
			writer.write(fConn2);
			if (fSClass2A != null) {
				writer.write(", " + fSClass2A.getValue());
				if (fSClass2B != null) {
					writer.write(", " + fSClass2B.getValue());
				}
			}
			writer.write('\n');
		}

	}

}
