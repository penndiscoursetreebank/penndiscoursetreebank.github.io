/*
 * PDTBExplicitRelationFeaturesImpl.java
 *
 * Created on November 30, 2005, 7:30 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;

import edu.upenn.cis.pdtb.util.TreeEnumFeature;

/**
 * Implementation of the PDTBExplicitRelationFeatures interface.
 * 
 * @author nikhild, geraud
 */
public class PDTBExplicitRelationFeaturesImpl extends PDTBConnFeaturesImpl
		implements PDTBExplicitRelationFeatures {

	private String fHead;

	private TreeEnumFeature fSClassA;

	private TreeEnumFeature fSClassB;

	/** Creates a new instance of PDTBExplicitRelationFeaturesImpl */
	public PDTBExplicitRelationFeaturesImpl(String source, String type,
			String polarity, String determinancy, PDTBSelection sel,
			String connHead, String sClassA, String sClassB) {
		super(source, type, polarity, determinancy, sel);
		fHead = connHead;
		fSClassA = SClassA.indexOf(sClassA);
		fSClassB = SClassB.indexOf(sClassB);
	}

	/**
	 * Sets the connHead attribute on the ownerNode.
	 */
	public void updateAttributesOnNode() {
		PDTBNode node = getPDTBNode();
		node.pdtbSetAttribute("", ConnHeadAttributeQName,
				ConnHeadAttributeQName, "", fHead, 1);
		if (fSClassA == null) {
			System.err
					.println("Missing an sClassA for an Explicit relation.\nAlso, may have created a 'QueryOut' folder without deleting.");
		}
		node.pdtbSetAttribute("", SClassA.getName(), SClassA.getName(), "",
				fSClassA.getValue(), 2);
		if (fSClassB != null) {
			node.pdtbSetAttribute("", SClassB.getName(), SClassB.getName(), "",
					fSClassB.getValue(), 3);
		}
		super.updateAttributesOnNode();
	}

	public String getConnHead() {
		return fHead;
	}

	public TreeEnumFeature getSClassA() {
		return fSClassA;
	}

	public TreeEnumFeature getSClassB() {
		return fSClassB;
	}

	public void save(Writer writer) throws IOException {
		super.save(writer);
		writer.write(fHead);
		if (fSClassA != null) {
			writer.write(", " + fSClassA.getValue());
			if (fSClassB != null) {
				writer.write(", " + fSClassB.getValue());
			}
		}
		writer.write('\n');
	}

}
