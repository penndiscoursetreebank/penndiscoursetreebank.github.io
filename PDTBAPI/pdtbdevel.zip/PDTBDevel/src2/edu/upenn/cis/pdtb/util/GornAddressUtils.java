/*
 * GornAddressUtils.java
 *
 * Created on December 10, 2004, 10:23 PM
 */

package edu.upenn.cis.pdtb.util;

import edu.upenn.cis.ptb.PTBTreeNode;

import java.util.Stack;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.tree.TreeNode;

/**
 * Several utility methods for working with Gorn addresses.
 *
 * @author  nikhild
 * @see edu.upenn.cis.pdtb.util.GornAddressList
 */
public class GornAddressUtils {
    
    /** Creates a new instance of GornAddressUtils */
    public GornAddressUtils() {
    }
    
    /**
     * Gets the address of a node.
     *
     * @param node The node
     *
     * @return The address.
     */
    public static int[] getGornAddress(TreeNode node){
        Stack addStack = new Stack();
        TreeNode parent = (TreeNode)(node.getParent());
        
        while(parent != null){
            int index = parent.getIndex(node);
            addStack.push(new Integer(index));
            node = parent;
            parent = (TreeNode)(parent.getParent());
        }
        
        int[] address = new int[addStack.size()];
        for(int i = 0; !(addStack.isEmpty()); i++){
            address[i] = ((Integer)(addStack.pop())).intValue();
        }
        
        return address;
    }
    
    /**
     * Get the node correponding to the address.
     *
     * @param gornAddress the address
     * @param root the root of the tree from which the address is to be interpreted
     *
     * @return the node if it exists. A runtime exception (NPE) will be thrown if the
     * node does not exist.
     * 
     */
    public static TreeNode getNode(int[] gornAddress, TreeNode root){
        TreeNode node = root;
        
        int len = gornAddress.length;
        for(int i = 0; i < len; i++){
            node = (TreeNode)(node.getChildAt(gornAddress[i]));
        }
        
        return node;
    }
    
    /**
     * Gets the nodes denoted by the Gorn address list.
     *
     * @param gal the list
     * @param root the root of the tree from which addresses are interpreted
     *
     * @return an enumeration containing the nodes.
     *
     */
    public static Enumeration getNodes(GornAddressList gal, TreeNode root){
        
        Vector nodes = new Vector();
        for(Iterator iter = gal.iterator();iter.hasNext();){
            nodes.add(getNode((int[])(iter.next()), root));
        }
        
        return nodes.elements();
    }
    
    /**
     * Convenience method for debugging. Prints to STDERR.
     */
    public static void printAddress(int[] address){
        int len = address.length;
        for(int i = 0; i < len; i++){
            System.err.print(address[i] + ",");
        }
        System.err.println();
    }
    
    /**
     * Produces a list containing all the addresses in the lists iterated over.
     */
    public static GornAddressList union(Iterator gornAddressLists){
        GornAddressList un = new GornAddressList();
        while(gornAddressLists.hasNext()){
            GornAddressList gal = (GornAddressList)(gornAddressLists.next());
            un.addAll(gal);
        }
        
        return un;
    }
    
    /**
     * Same as the other union method.
     */
    public static GornAddressList union(Enumeration gornAddressLists){
        GornAddressList un = new GornAddressList();
        while(gornAddressLists.hasMoreElements()){
            GornAddressList gal = (GornAddressList)(gornAddressLists.nextElement());
            un.addAll(gal);
        }
        
        return un;
    }
    
    /**
     * Returns true iff the address is a prefix (denoting an ancestor) of all the
     * addresses in the list.
     */
    public static boolean isPrefix(int[] address, GornAddressList gal){
        
        Iterator iter = gal.iterator();
        int len = address.length;
        while(iter.hasNext()){
            int[] add = (int[])(iter.next());
            if(add.length >= len){
                boolean isPrefix = true;
                for(int i = 0; i < len && isPrefix; i++){
                    if(address[i] != add[i]){
                        isPrefix = false;
                    }
                }
                if(!isPrefix){
                    return false;
                }
            }
            else{
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Returns true iff the address has a prefix (an ancestor) in the list.
     */
    public static boolean prefixExists(int[] address, GornAddressList gal){
        Iterator iter = gal.iterator();
        int len = address.length;
        while(iter.hasNext()){
            int[] add = (int[])(iter.next());
            int addLen = add.length;
            if(addLen <= len){
                
                boolean isPrefix = true;
                for(int i = 0; i < addLen && isPrefix; i++){
                    if(address[i] != add[i]){
                        isPrefix = false;
                    }
                }
                
                if(isPrefix){
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * Tree subtraction operator, useful in detecting arguments. See Dinesh et. al 2005 
     * "Attribution and the Non-Alignment of Syntactic and Discourse Arguments of Connectives".
     */
    public static GornAddressList subtract(int[] address, GornAddressList addList, TreeNode root){
        GornAddressList sub = new GornAddressList();
        TreeNode node = getNode(address, root);
        addIfNotPrefix(address, addList, node, sub);
        
        return sub;
    }
    
    private static void addIfNotPrefix(int[] address, GornAddressList addList, TreeNode node, GornAddressList sub){
        if(!isPrefix(address, addList)){
            int length = address.length;
            int[] addrClone = new int[length];
            for(int i = 0; i < length; i++){
                addrClone[i] = address[i];
            }
            
            sub.add(addrClone);
            return;
        }
        
        if(addList.contains(address)){
            return;
        }
        
        int len = address.length;
        int[] childAddress = new int[len + 1];
        
        for(int i = 0; i < len; i++){
            childAddress[i] = address[i];
        }
        
        int j = 0;
        Enumeration children = node.children();
        while(children.hasMoreElements()){
            PTBTreeNode child = (PTBTreeNode)(children.nextElement());
            childAddress[len] = j;
            addIfNotPrefix(childAddress, addList, child, sub);
            j++;
        }
        
    }
    
    public static String getText(GornAddressList addList, PTBTreeNode root){
        String s = "";
        
        Iterator iter = addList.iterator();
        while(iter.hasNext()){
            PTBTreeNode node = (PTBTreeNode)(getNode((int[])(iter.next()), root));
            s = s + getText(node);
        }
        
        return s;
    }
    
    public static String getText(PTBTreeNode node){
        if(node.isLeaf()){
            return node.getLabel().toString() + " ";
        }
        
        String s = "";
        Enumeration children = node.children();
        while(children.hasMoreElements()){
            PTBTreeNode child = (PTBTreeNode)(children.nextElement());
            s = s + getText(child);
        }
        
        return s;
    }
    
    /**
     * Returns true iff every address in addList2 is has a prefix in addList1.
     */
    public static boolean dominates(GornAddressList addList1, GornAddressList addList2){
        Iterator iter = addList2.iterator();
        boolean dominates = true;
        while(dominates && iter.hasNext()){
            int[] address = (int[])(iter.next());
            dominates = dominates && prefixExists(address, addList1);
        }
        
        return dominates;
    }
    
    public static String printTrees(PTBTreeNode root){
        String s = "";
        Enumeration children = root.children();
        while(children.hasMoreElements()){
            PTBTreeNode child = (PTBTreeNode)(children.nextElement());
            s = s + "(" + prnTree(child) + ")\n" ;
        }
        
        return s;
    }
    
    private static String prnTree(PTBTreeNode node){
        if(node.getChildCount() == 1 && node.getChildAt(0).isLeaf()){
            return "(" + node.toString() + " " + node.getChildAt(0).toString() + ")";
        }
        else{
            String s = "(" + node.toString() + " ";
            Enumeration children = node.children();
            while(children.hasMoreElements()){
                s = s + prnTree((PTBTreeNode)(children.nextElement()));
            }
            
            s = s + ")";
            
            System.err.println(s);
            return s;
        }
    }
    
}
