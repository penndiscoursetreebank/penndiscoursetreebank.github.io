/*
 * PDTBAltLexRelationImpl.java
 *
 * Created on January 22, 2006, 8:15 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;
import edu.upenn.cis.pdtb.util.ArraySet;

/**
 * Implementation of the PDTBAltLexRelation interface.
 * @author nikhild, geraud
 */
public class PDTBAltLexRelationImpl extends PDTBRelationImpl implements PDTBAltLexRelation{
    
    private PDTBSelection fSel;
    
    private PDTBAltLexRelationFeatures fFeats;
    
    /** Creates a new instance of PDTBAltLexRelationImpl */
    public PDTBAltLexRelationImpl(PDTBSelection sel, PDTBAltLexRelationFeatures feats, 
    PDTBSup sup1, PDTBArg arg1, PDTBArg arg2, PDTBSup sup2) {
               super(sup1, arg1, arg2, sup2);
               
               fSel = sel;
               fSel.setPDTBNode(this);
               fFeats = feats;
               fFeats.setPDTBNode(this);
               
               pdtbSetName("", AltLexRelationQName, AltLexRelationQName);
               
    }
     
    protected void initAttributes(){
        fAttributes = new ArraySet(fAttributesComparator, 5);
        fFeats.updateAttributesOnNode();
        fSel.updateAttributesOnNode();
    }
    
    
    public PDTBAltLexRelationFeatures getFeatures() {
        return fFeats;
    }
    
    public void setFeatures(PDTBAltLexRelationFeatures feats) {
        if(fFeats != null){
            fFeats.setPDTBNode(null);
        }
        
        feats.setPDTBNode(this);
        
        fFeats = feats;
        fFeats.updateAttributesOnNode();
    }
    
    public void setSelection(PDTBSelection sel) {
        if(fSel != null){
            fSel.setPDTBNode(null);
        }
        
        fSel = sel;
        fSel.setPDTBNode(this);
        fSel.updateAttributesOnNode();
    }
    
    
    public PDTBSelection getSelection(){
        return fSel;
    }
    
    public void save(Writer writer) throws IOException{
        writer.write("________________________________________________________\n");
        writer.write("____AltLex____\n"); 
        ((PDTBSelectionImpl)fSel).save(writer);
        writer.write("#### Features ####\n");
        ((PDTBAltLexRelationFeaturesImpl)fFeats).save(writer);
        super.save(writer);
        writer.write("________________________________________________________\n");
        
    }
    
}
