/*
 * IntegratedPanel.java
 *
 * Created on December 7, 2005, 6:28 PM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.*;

import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;

import edu.upenn.cis.pdtb.*;

/**
 * The panel is first split horizontally. In the top portion the PTBPanel is
 * added. The bottom part is then split vertically. The left side contains the
 * PDTB relations rendered in a JTree, and the right side contains the text in a
 * WSJTextPane.
 * 
 * @since 0.1
 * @version 2 Added support for compare mode.
 * @author nikhild, geraud
 * @see WSJTextPane
 * @see PTBPanel
 */
public class IntegratedPanel extends JPanel {

	private PDTBRelationList fRelationList;

	private boolean fCompareMode;

	private Point fSplitPointR;
	
	public IntegratedPanel(PDTBRelationList rlist, boolean compareMode,
			Point splitPointL, Point splitPointR) {
		super();
		setBackground(ColorConstants.DefaultBackground);
		fCompareMode = compareMode;

		if (fCompareMode) {
			setLayout(new GridLayout(1, 2));
		} else {
			setLayout(new GridLayout(1, 1));
		}

		fSplitPointR = splitPointR;
		fRelationList = rlist;
		add(new IntegratedSplitPane(fRelationList, splitPointL));

		if (fCompareMode) {
			add(new IntegratedSplitPane(fRelationList, splitPointR));
		}
	}

	public Point getSplitPointL() {
		return ((IntegratedSplitPane) getComponent(0)).getSplitPoint();
	}

	public Point getSplitPointR() {
		if (fCompareMode) {
			return ((IntegratedSplitPane) getComponent(1)).getSplitPoint();
		} else {
			return null;
		}
	}

	public PDTBRelationList getRelationList() {
		return fRelationList;
	}

	public void setCompareMode(boolean compareMode) {
		boolean oldCompareMode = fCompareMode;
		fCompareMode = compareMode;

		if (oldCompareMode != fCompareMode) {
			
			if (!fCompareMode){
				fSplitPointR = ((IntegratedSplitPane) getComponent(1)).getSplitPoint();
			}

			IntegratedSplitPane sp = (IntegratedSplitPane) getComponent(0);
			removeAll();

			if (fCompareMode) {
				setLayout(new GridLayout(1, 2));
			} else {
				setLayout(new GridLayout(1, 1));
			}

			add(sp);

			if (fCompareMode) {
				add(new IntegratedSplitPane(fRelationList, fSplitPointR));
			}

			revalidate();
		}
	}

	public boolean getCompareMode() {
		return fCompareMode;
	}

	public class IntegratedSplitPane extends JSplitPane implements
			FontChangeListener {

		private JTree fRelationTree;

		private PTBPanel fPTBPanel;

		private WSJTextPane fTextPane;

		private JSplitPane fHorizSplit;

		public IntegratedSplitPane(PDTBRelationList rlist, Point splitPoint) {
			super(JSplitPane.VERTICAL_SPLIT, true);

			// Create the PDTB component
			fRelationTree = new JTree(rlist);
			fRelationTree.setRootVisible(false);
			fRelationTree.setCellRenderer(new PDTBNodeRenderer(
					ColorConstants.PDTBNodeSelectionColor,
					ColorConstants.DefaultBackground));

			// Create the PTB component which listens to the PDTB component
			fPTBPanel = new PTBPanel(rlist.getPTBRoot(), fRelationTree);

			// Create the text component which listens to the PDTB component
			fTextPane = new WSJTextPane(rlist.getRawText(), fRelationTree);

			// The bottom portion of the screen
			fHorizSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true,
					new JScrollPane(fRelationTree), new JScrollPane(fTextPane));
			fHorizSplit.setPreferredSize(new Dimension(100, 100));

			if (splitPoint == null) {
				fHorizSplit.setDividerLocation(200);
			} else {
				fHorizSplit.setDividerLocation((int)splitPoint.getX());
			}

			setTopComponent(new JScrollPane(fPTBPanel));
			setBottomComponent(fHorizSplit);

			if (splitPoint == null) {
				setDividerLocation(300);
			} else {
				setDividerLocation((int)splitPoint.getY());
			}
			FontProvider.PDTBBrowserFontProvider.addListener(this);
		}

		public Point getSplitPoint() {
			return new Point(fHorizSplit.getDividerLocation(),
					getDividerLocation());
		}

		public void fontChanged(Font newFont) {
			fRelationTree.setCellRenderer(new PDTBNodeRenderer(
					ColorConstants.PDTBNodeSelectionColor,
					ColorConstants.DefaultBackground));
			fRelationTree.repaint();
			repaint();
		}
	}

}
