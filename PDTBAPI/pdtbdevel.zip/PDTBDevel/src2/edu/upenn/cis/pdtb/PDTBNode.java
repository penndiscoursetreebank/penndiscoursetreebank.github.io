/*
 * PDTBNode.java
 *
 * Created on November 29, 2005, 7:18 PM
 */

package edu.upenn.cis.pdtb;

import javax.swing.tree.*;
import java.util.Enumeration;

/**
 * Base class of all PDTBNodes. Extends the swing TreeNode interface for
 * easy display, and adds methods to interact with the Jaxen XPath API.
 * The mutation methods here are for internal use only, with the
 * exception of <EM>pdtbAddFirstChild</EM>, and <EM>pdtbAddLastChild</EM>.
 * For other mutation operations, methods from the MutableTreeNode
 * interface should be used.
 * @author nikhild
 * @see edu.upenn.cis.pdtb.xpath.PDTBNavigator
 */
public interface PDTBNode extends MutableTreeNode {
    
    public static final String RelationListQName = "RelationList";
    
    public static final String ExplicitRelationQName = "ExplicitRelation";
    
    public static final String ImplicitRelationQName = "ImplicitRelation";
    
    public static final String AltLexRelationQName = "AltLexRelation";
    
    public static final String EntityRelationQName = "EntityRelation";
    
    public static final String NoRelationQName = "NoRelation";
    
    public static final String Arg1QName = "Arg1";
    
    public static final String Arg2QName = "Arg2";
    
    public static final String Sup1QName = "Sup1";
    
    public static final String Sup2QName = "Sup2";
    
    public PDTBNode pdtbGetPreviousSibling();
    
    public PDTBNode pdtbGetNextSibling();
    
    public void pdtbSetNextSibling(PDTBNode node);
    
    public void pdtbSetPreviousSibling(PDTBNode node);
    
    public PDTBNode pdtbGetFirstChild();
    
    public void pdtbAddFirstChild(PDTBNode firstChild);
    
    public PDTBNode pdtbGetLastChild();
    
    public void pdtbAddLastChild(PDTBNode lastChild);
    
    public void pdtbSetAttribute(String namespaceURI, String localName, 
                   String qName, String prefix, String value, int priority);
    
    public void pdtbRemoveAttribute(String namespaceURI, String localName, String qName);
    
    public Enumeration pdtbGetAttributes();
    
    public Object getUserObject();
    
    public String pdtbGetNamespaceUri();
    
    public String pdtbGetLocalName();
    
    public String pdtbGetQName();
    
    public void pdtbSetName(String namespaceUri, String localName, String qName);
}
