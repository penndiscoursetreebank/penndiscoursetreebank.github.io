/*
 * PDTBBrowserTab.java
 *
 * Created on December 7, 2005, 7:14 PM
 */

package edu.upenn.cis.pdtb.graphics;

import javax.swing.*;

import edu.upenn.cis.pdtb.*;

import java.awt.Point;
import java.io.IOException;

/**
 * Represents the tabs in the browser. Each tab is an IntegratedPanel.
 * 
 * @since 0.1
 * @version 3 Added support for compare mode.
 * @version 2 Fixed to ensure that only one instance of a file appears as a tab.
 * @author nikhild, geraud
 * @see IntegratedPanel
 * @see edu.upenn.cis.pdtb.RelationLoader
 */
public class PDTBBrowserTab extends JTabbedPane {

	/**
	 * TextRoot or RAWRoot
	 */
	private String fTextRoot;

	// PTBRoot
	private String fPTBRoot;

	// PDTBRoot
	private String fPDTBRoot;

	private RelationLoader fLoader = new RelationLoaderImpl();

	private boolean fCompareMode;

	/** Creates a new instance of PDTBBrowserTab */
	public PDTBBrowserTab(String textRoot, String ptbRoot, String pdtbRoot) {
		super();
		fTextRoot = textRoot;
		fPTBRoot = ptbRoot;
		fPDTBRoot = pdtbRoot;
	}

	/**
	 * Adds an integrated panel as a tab using the textRoot, ptbRoot, pdtbRoot
	 * supplied to constructor and this secNo, and fileNo, to 
	 * determine selected tokens in the RAW, PTB and PDTB files.
	 */
	public void addTab(String secNo, String fileNo, Point splitPointL, Point splitPointR) {
		try {
			String name = secNo + fileNo;
			int tabCount = getTabCount();
			for (int i = 0; i < tabCount; i++) {
				String title = getTitleAt(i);
				if (title.equals(name)) {
					setSelectedIndex(i);
					return;
				}
			}

			PDTBRelationList rlist = fLoader.loadRelations(fTextRoot, fPTBRoot,
					fPDTBRoot, secNo, fileNo);
			int i = 0;
			for (; i < tabCount; i++) {
				String title = getTitleAt(i);
				if (title.compareTo(name) > 0) {
					break;
				}
			}

			IntegratedPanel p = new IntegratedPanel(rlist, fCompareMode, splitPointL, splitPointR);
			insertTab(name, null, p, name, i);
			setSelectedIndex(i);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void addTab(String secNo, String fileNo){
		addTab(secNo, fileNo, null, null);
	}
	
	public void removeTabAt(int ind) {
		super.removeTabAt(ind);

		int index = getSelectedIndex();
		int tabCount = getTabCount();
		if (index < 0 || index == tabCount) {
			index = tabCount - 1;
		}
		setSelectedIndex(index);
		fireStateChanged();
	}

	public void setCompareMode(boolean compareMode) {
		boolean oldCompareMode = fCompareMode;
		fCompareMode = compareMode;
		if (oldCompareMode != fCompareMode) {
			int tabCount = getTabCount();
			for (int i = 0; i < tabCount; i++) {
				IntegratedPanel p = (IntegratedPanel) getComponent(i);
				p.setCompareMode(fCompareMode);
			}
		}
	}

	public boolean getCompareMode() {
		return fCompareMode;
	}

}
