/*
 * Span.java
 *
 * Created on December 3, 2004, 5:35 PM
 */

package edu.upenn.cis.pdtb.util;

import java.util.regex.*;

/**
 * Vanilla spans. Added various predicates.
 *
 * @since 0.1
 * @version 3 Added a method for crossing comparison.
 * @version 2 Added comparison methods.
 * @author nikhild
 */
public class Span {
    
    int start;
    int end;
    
    private static final Pattern SpanPattern = Pattern.compile("\\.\\.");
    
    /** Creates a new instance of Span */
    public Span(String s) {
        String[] comps = SpanPattern.split(s);
        if(comps.length != 2){
            throw(new IllegalArgumentException("Invalid string for span " + s));
        }
        
        start = Integer.parseInt(comps[0]);
        end = Integer.parseInt(comps[1]);
        
    }
    
    public Span(int start, int end){
        this.start = start;
        this.end = end;
    }
    
    public int getStart(){
        return start;
    }
    
    public int getEnd(){
        return end;
    }
    
    /**
     * Equivalent to <code>start <= start2 && end2 <= end</code>.
     */
    public boolean contains(Span s2){
        int start2 = s2.getStart();
        int end2 = s2.getEnd();
        
        return (start <= start2 && end2 <= end);
    }
    
    /**
     * Equivalent to <code>start2 <= start && end <= end2</code>.
     */
    public boolean isContainedBy(Span s2){
        int start2 = s2.getStart();
        int end2 = s2.getEnd();
        
        return (start2 <= start && end <= end2);
    }
    
    /**
     * Equivalent to <code>(start >= start2 && start < end2) || (start2 >= start && start2 < end)</code>.
     */
    public boolean isOverlapping(Span s2){
        int start2 = s2.getStart();
        int end2 = s2.getEnd();
        
        return (start >= start2 && start < end2) || (start2 >= start && start2 < end);
    }
    
    /**
     * Equivalent to <code>(start < start2 && start2 < end && end2 > end) || (start2 < start && start < end2 && end > end2)</code>
     */
    public boolean crosses(Span s2){
        int start2 = s2.getStart();
        int end2 = s2.getEnd();
        
        return (start < start2 && start2 < end && end2 > end) || (start2 < start && start < end2 && end > end2);
    }
    
    
    public String toString(){
        return "" + this.start + ".." + this.end;
    }
    
    public boolean equals(Object o){
        Span s = (Span)o;
        
        return (this.start == s.getStart() && this.end == s.getEnd());
    }
    
}
