/*
 * DelimTextFunction.java
 *
 * Created on March 18, 2007, 7:07 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package edu.upenn.cis.pdtb.xpath;

import org.jaxen.Function;
import org.jaxen.FunctionCallException;
import org.jaxen.Context;
import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.pdtb.util.PDTBStringBuffer;
import edu.upenn.cis.pdtb.util.Span;
import edu.upenn.cis.pdtb.util.SpanList;

import java.util.List;
import java.util.Iterator;

/**
 * Transforms the raw text into delimited blocks, one for each span. This
 * function has the signature:
 *
 * <pre>
 *   string delim-text()
 * </pre>
 *
 * If the context node has multiple spans, then the spans are concatenated
 * with <code>####</code> as delimiter. This is perhaps useful in
 * conjunction with the <code> regexp</code> function to search for
 * text patterns within a span.
 * @author nikhild
 */
public class DelimTextFunction implements Function {
    
    private PDTBStringBuffer fBuffer = new PDTBStringBuffer(100);
    
    /** Creates a new instance of DelimTextFunction */
    public DelimTextFunction() {
    }
    
    public Object call(Context context, List args) throws FunctionCallException {
        Object contextNode = context.getNodeSet().get(0);
        if(contextNode instanceof PDTBNode){
             return getTextForNode((PDTBNode) contextNode);
            
        }
        return "";
    }
    
    public String getTextForNode(PDTBNode node){
        SpanList l = null;
        if(node instanceof PDTBSup){
            PDTBSup n = (PDTBSup) node;
            l = n.getSelection().getSpans();
            if(l.size() == 1){
                return n.getSelection().getRawText();
            }
        }
        else if(node instanceof PDTBExplicitRelation){
            PDTBExplicitRelation rel = (PDTBExplicitRelation) node;
            l = rel.getSelection().getSpans();
            if(l.size() == 1){
                return rel.getSelection().getRawText();
            }
            
            
        }
        else if(node instanceof PDTBAltLexRelation){
            PDTBAltLexRelation rel = (PDTBAltLexRelation) node;
            l = rel.getSelection().getSpans();
            if(l.size() == 1){
                return rel.getSelection().getRawText();
            }
        }
        
        if(l != null){
            PDTBNode parent = (PDTBNode) node.getParent();
            while(parent != null){
                node = parent;
                parent = (PDTBNode) parent.getParent();
            }
            
            PDTBRelationList rList = (PDTBRelationList) node;
            String rawText = rList.getRawText();
            return getRawText(rawText,l);
            
        }
        
        return "";
    }
    
    public String getRawText(String rawText, SpanList spans){
        for(Iterator iter = spans.iterator(); iter.hasNext();){
            Span s = (Span) iter.next();
            fBuffer.append(rawText, s.getStart(), s.getEnd());
            if(iter.hasNext()){
                fBuffer.append("####");
            }
        }
        String retVal = fBuffer.toString();
        fBuffer.delete();
        return retVal;
    }
    
}
