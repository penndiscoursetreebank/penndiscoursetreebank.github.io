/*
 * PDTBExplicitRelationFeatures.java
 *
 * Created on November 30, 2005, 7:29 PM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.pdtb.util.TreeEnumFeature;

/**
 * Features associated with an ExplicitRelation.
 * 
 * @author nikhild, geraud
 */
public interface PDTBExplicitRelationFeatures extends PDTBConnFeatures {

	/**
	 * The QName of the attribute whose value is the head of the connective.
	 */
	public static final String ConnHeadAttributeQName = "connHead";

	public static final TreeEnumFeature SClassA = new TreeEnumFeature(
			"sClassA", semanticClassesTree);

	public static final TreeEnumFeature SClassB = new TreeEnumFeature(
			"sClassB", semanticClassesTree);

	/**
	 * Get the head of the connective.
	 */
	public String getConnHead();

	/**
	 * Get the first semantic class of the connHead
	 */
	public TreeEnumFeature getSClassA();

	/**
	 * Get the second semantic class of the connHead
	 */
	public TreeEnumFeature getSClassB();

}
