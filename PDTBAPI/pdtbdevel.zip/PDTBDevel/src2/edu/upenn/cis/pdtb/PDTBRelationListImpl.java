/*
 * PDTBRelationListImpl.java
 *
 * Created on November 29, 2005, 3:52 PM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.ptb.*;
import java.io.Writer;
import java.io.IOException;
import java.util.Enumeration;
import edu.upenn.cis.pdtb.util.ArraySet;

/**
 *
 * @author  nikhild
 */
public class PDTBRelationListImpl extends PDTBNodeImpl implements PDTBRelationList{
    
    private String fSecNo;
    
    private String fFileNo;
    
    private PTBTreeNode fRoot;
    
    private String fRawText;
    
    /** Creates a new instance of PDTBRelationListImpl */
    public PDTBRelationListImpl(String rawText, PTBTreeNode root, String secNo, String fileNo){
        super();
        
        fRawText = rawText;
        fRoot = root;
        fSecNo = secNo;
        fFileNo = fileNo;
        
        pdtbSetName("", RelationListQName, RelationListQName);

    }
    
    protected void initAttributes(){
        fAttributes = new ArraySet(fAttributesComparator);
    }
    
    public boolean getAllowsChildren(){
        return true;
    }
    
    public String getFileNo() {
        return fFileNo;
    }
    
    public String getRawText() {
        return fRawText;
    }
    
    public String getSecNo() {
        return fSecNo;
    }
    
    public PTBTreeNode getPTBRoot(){
        return fRoot;
    }
    
    public void save(Writer writer) throws IOException {
        for(Enumeration e = children(); e.hasMoreElements();){
            PDTBNode child = (PDTBNode)(e.nextElement());
            if(child instanceof PDTBRelationImpl){
                PDTBRelationImpl rel = (PDTBRelationImpl)child;
                rel.save(writer);
            }
            else{
                PDTBEntityRelationImpl rel = (PDTBEntityRelationImpl)child;
                rel.save(writer);
            }
        }
    }    
    
}
