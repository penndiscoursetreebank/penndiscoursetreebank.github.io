/*
 * PDTBSelection.java
 *
 * Created on November 27, 2005, 12:35 PM
 */

package edu.upenn.cis.pdtb;

import java.util.Enumeration;

import edu.upenn.cis.pdtb.util.GornAddressList;
import edu.upenn.cis.pdtb.util.SpanList;

/**
 * A (possibly discontinuous) selection of text.
 * @author nikhild
 */
public interface PDTBSelection {
    
    /**
     * QName of the attribute whose value corresponds to the raw text selected.
     */    
    public static final String RawTextAttributeQName = "rawText";
    
    /**
     * A list of spans corresponding to the selection.
     */    
    public SpanList getSpans();
    
    /**
     * A list of Gorn addresses corresponding to the selection. See the release
     * documentation for details on how these are computed from spans.
     */    
    public GornAddressList getAddresses();
    
    /**
     * Get the associated PDTBNode.
     */    
    public PDTBNode getPDTBNode();
    
    /**
     * Set the associated node.
     */    
    public void setPDTBNode(PDTBNode node);
    
    /**
     * Get the raw text denoted by the span list.
     */    
    public String getRawText();
    
    /**
     * Get the tree nodes denoted by the Gorn address list.
     */    
    public Enumeration getPTBNodes();
    
    /**
     * Set the attributes on ownerNode.
     */    
    public void updateAttributesOnNode();
    
}
