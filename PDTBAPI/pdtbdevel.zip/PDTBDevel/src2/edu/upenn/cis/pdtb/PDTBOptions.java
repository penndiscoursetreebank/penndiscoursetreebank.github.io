package edu.upenn.cis.pdtb;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.LinkedList;

import edu.upenn.cis.pdtb.PDTBOptionsAccum.OptFeat;
import edu.upenn.cis.pdtb.lexyacc.Options;
import edu.upenn.cis.pdtb.util.EnumFeature;
import edu.upenn.cis.pdtb.util.TreeEnumFeature;

/**
 * Makes the options in Options.properties available for PDTBFeatures to read in
 * 
 * @author geraud
 */
public final class PDTBOptions {

	private static final String source = "Source";
	private static final String type = "Type";
	private static final String polarity = "Polarity";
	private static final String det = "Det";

	private static String[] conns;
	private static TreeEnumFeature[] semanticClassesTree;
	private static EnumFeature connSourceFeature;
	private static EnumFeature connTypeFeature;
	private static EnumFeature connPolarityFeature;
	private static EnumFeature connDeterminancyFeature;
	private static EnumFeature argSourceFeature;
	private static EnumFeature argTypeFeature;
	private static EnumFeature argPolarityFeature;
	private static EnumFeature argDeterminancyFeature;

	private static EnumFeature getEnumFeat(String name, OptFeat feats) {
		return new EnumFeature(name, (String[]) feats.getFeatVals().toArray(
				new String[0]), feats.getDef());
	}

	public PDTBOptions(String properties) {
		InputStream inFile = getClass().getResourceAsStream(properties);
		try {
			BufferedReader r = new BufferedReader(new InputStreamReader(inFile));
			Options fScanner = new Options(r);
			PDTBOptionsAccum opts = fScanner.yylex();

			conns = (String[]) opts.getConns().toArray(new String[0]);

			LinkedList classList = opts.getClasses();
			semanticClassesTree = TreeEnumFeature
					.TreeEnumFeatureFromList(classList);

			connSourceFeature = getEnumFeat(source, opts.getConnSource());
			connTypeFeature = getEnumFeat(type, opts.getConnType());
			connPolarityFeature = getEnumFeat(polarity, opts.getConnPolarity());
			connDeterminancyFeature = getEnumFeat(det, opts.getConnDet());
			argSourceFeature = getEnumFeat(source, opts.getArgSource());
			argTypeFeature = getEnumFeat(type, opts.getArgType());
			argPolarityFeature = getEnumFeat(polarity, opts.getArgPolarity());
			argDeterminancyFeature = getEnumFeat(det, opts.getArgDet());

			r.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String[] getConns() {
		return conns;
	}

	public TreeEnumFeature[] getSemanticClassesTree() {
		return semanticClassesTree;
	}

	public EnumFeature getConnSourceFeature() {
		return connSourceFeature;
	}

	public EnumFeature getConnTypeFeature() {
		return connTypeFeature;
	}

	public EnumFeature getConnPolarityFeature() {
		return connPolarityFeature;
	}

	public EnumFeature getConnDeterminancyFeature() {
		return connDeterminancyFeature;
	}

	public EnumFeature getArgSourceFeature() {
		return argSourceFeature;
	}

	public EnumFeature getArgTypeFeature() {
		return argTypeFeature;
	}

	public EnumFeature getArgPolarityFeature() {
		return argPolarityFeature;
	}

	public EnumFeature getArgDeterminancyFeature() {
		return argDeterminancyFeature;
	}

}
