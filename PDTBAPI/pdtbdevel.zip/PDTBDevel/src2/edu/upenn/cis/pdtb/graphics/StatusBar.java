package edu.upenn.cis.pdtb.graphics;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class StatusBar extends JPanel {
    private final JLabel ExplicitConnLabel = new JLabel("Conn/AltLex");
    
    private final JLabel ExplicitConnAttribLabel = new JLabel("Conn/AltLex Attr");
    
    private final JLabel Arg1Label = new JLabel("  Arg1  ");
    
    private final JLabel Arg1AttribLabel = new JLabel("Arg1 Attr");
    
    private final JLabel Arg2Label = new JLabel("  Arg2  ");
    
    private final JLabel Arg2AttribLabel = new JLabel("Arg2 Attr");
    
    private final JLabel Sup1Label = new JLabel("  Sup1  ");
    
    private final JLabel Sup2Label = new JLabel("  Sup2  ");
    
    /** Creates a new instance of StatusBar */
    public StatusBar() {
        super();
        setBackground(ColorConstants.DefaultBackground);

        ExplicitConnLabel.setBackground(ColorConstants.ExplicitConnColor);
        ExplicitConnAttribLabel.setBackground(ColorConstants.ExplicitConnAttribColor);
        Arg1Label.setBackground(ColorConstants.Arg1Color);
        Arg1AttribLabel.setBackground(ColorConstants.Arg1AtrribColor);
        Arg2Label.setBackground(ColorConstants.Arg2Color);
        Arg2AttribLabel.setBackground(ColorConstants.Arg2AtrribColor);
        Sup1Label.setBackground(ColorConstants.Sup1Color);
        Sup2Label.setBackground(ColorConstants.Sup2Color);

        ExplicitConnLabel.setOpaque(true);
        ExplicitConnAttribLabel.setOpaque(true);
        Arg1Label.setOpaque(true);
        Arg1AttribLabel.setOpaque(true);
        Arg2Label.setOpaque(true);
        Arg2AttribLabel.setOpaque(true);
        Sup1Label.setOpaque(true);
        Sup2Label.setOpaque(true);
        
        add(ExplicitConnLabel);
        add(ExplicitConnAttribLabel);
        add(Arg1Label);
        add(Arg1AttribLabel);
        add(Arg2Label);
        add(Arg2AttribLabel);
        add(Sup1Label);
        add(Sup2Label);
        
    }     
} 