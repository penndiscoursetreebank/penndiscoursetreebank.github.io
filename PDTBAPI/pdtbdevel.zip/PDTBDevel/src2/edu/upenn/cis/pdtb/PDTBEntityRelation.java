/*
 * PDTBEntityRelation.java
 *
 * Created on February 13, 2006, 4:29 PM
 */

package edu.upenn.cis.pdtb;

/**
 *
 * @author  nikhild, geraud
 */
public interface PDTBEntityRelation extends PDTBNode {
    
    public PDTBInferenceSite getInferenceSite();
    
    public void setInferenceSite(PDTBInferenceSite infSite);
    
    public PDTBSup getArg1();
    
    public void setArg1(PDTBSup arg1);
    
    public PDTBSup getArg2();
    
    public void setArg2(PDTBSup arg2);
}
