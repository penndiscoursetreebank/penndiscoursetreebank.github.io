/*
 * PDTBConnFeatures.java
 *
 * Created on July 09, 2007, 4:00 PM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.pdtb.util.EnumFeature;
import edu.upenn.cis.pdtb.util.TreeEnumFeature;

/**
 * The base class of the features associated with a PDTBNode. In this base form,
 * it is associated with the connectives, and not the args. Subclasses are
 * associated with relations.
 * 
 * @since 3.0
 * @author geraud
 */
public interface PDTBConnFeatures extends PDTBFeatures {

	/**
	 * Possible values: "Arb", "Inh", "Ot", "Wr"
	 */
	public static final EnumFeature SourceFeature = options.getConnSourceFeature();

	/**
	 * Possible values: "Comm", "Ctrl", "Ftv", "PAtt"
	 */
	public static final EnumFeature TypeFeature = options.getConnTypeFeature();

	/**
	 * Possible values: "Neg", "Null"
	 */
	public static final EnumFeature PolarityFeature = options.getConnPolarityFeature();

	/**
	 * Possible values: "Indet", "Null"
	 */
	public static final EnumFeature DeterminancyFeature = options.getConnDeterminancyFeature();

	public static final TreeEnumFeature[] semanticClassesTree = options.getSemanticClassesTree();

	public static final String[] semanticClassesLong = new TreeEnumFeature(
			"root", semanticClassesTree).getValuesLong();
	public static final String[] semanticClassesShort = new TreeEnumFeature(
			"root", semanticClassesTree).getValuesShort();

	public static final String[] conns = options.getConns();

}