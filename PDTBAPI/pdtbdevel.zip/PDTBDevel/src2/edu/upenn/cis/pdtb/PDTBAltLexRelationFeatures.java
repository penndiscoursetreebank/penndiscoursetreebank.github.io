/*
 * PDTBAltLexRelationFeatures.java
 *
 * Created on November 30, 2005, 7:29 PM
 */

package edu.upenn.cis.pdtb;

import edu.upenn.cis.pdtb.util.TreeEnumFeature;

/**
 * Features of an AltLexRelation
 * @author nikhild, geraud
 * @see edu.upenn.cis.pdtb.PDTBAltLexRelation
 */
public interface PDTBAltLexRelationFeatures extends PDTBConnFeatures {
    
    public static final TreeEnumFeature SClassA = new TreeEnumFeature("sClassA", semanticClassesTree);
    public static final TreeEnumFeature SClassB = new TreeEnumFeature("sClassB", semanticClassesTree);
    
    /**
     * Get the first semantic class
     */
    public TreeEnumFeature getSClassA();
    
    /**
     * Get the second semantic class
     */
    public TreeEnumFeature getSClassB();
    
    
}
