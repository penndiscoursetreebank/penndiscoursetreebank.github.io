/*
 * PDTBEntityRelationImpl.java
 *
 * Created on February 13, 2006, 4:33 PM
 */

package edu.upenn.cis.pdtb;

import java.io.Writer;
import java.io.IOException;
import edu.upenn.cis.pdtb.util.ArraySet;

/**
 *
 * @author  nikhild, geraud
 */
public class PDTBEntityRelationImpl extends PDTBNodeImpl implements PDTBEntityRelation{
    
    private PDTBInferenceSite fInfSite;
    
    /** Creates a new instance of PDTBEntityRelationImpl */
    public PDTBEntityRelationImpl(PDTBInferenceSite infSite, PDTBSup arg1, PDTBSup arg2) {
        super();
        
        fInfSite = infSite;
        fInfSite.setPDTBNode(this);
        fInfSite.updateAttributesOnNode();
        
        pdtbAddFirstChild(arg1);
        pdtbAddLastChild(arg2);
        
        arg1.pdtbSetName("", Arg1QName, Arg1QName);
        arg2.pdtbSetName("", Arg2QName, Arg2QName);
        
        pdtbSetName("", EntityRelationQName, EntityRelationQName);
    }
    
    protected void initAttributes(){
        fAttributes = new ArraySet(fAttributesComparator);
        fInfSite.updateAttributesOnNode();
    }
    
    public PDTBSup getArg1() {
        return (PDTBSup)pdtbGetFirstChild();
    }
    
    public PDTBSup getArg2() {
        return (PDTBSup)pdtbGetLastChild();
    }
    
    public PDTBInferenceSite getInferenceSite() {
        return fInfSite;
    }
    
    public void setArg1(PDTBSup arg1) {
        PDTBSup oldArg1 = getArg1();
        oldArg1.removeFromParent();
        pdtbAddFirstChild(arg1);
        arg1.pdtbSetName("", Arg1QName, Arg1QName);
    }
    
    public void setArg2(PDTBSup arg2) {
        PDTBSup oldArg2 = getArg2();
        oldArg2.removeFromParent();
        pdtbAddLastChild(arg2);
        arg2.pdtbSetName("", Arg2QName, Arg2QName);
    }
    
    public void setInferenceSite(PDTBInferenceSite infSite) {
        if(fInfSite != null){
            fInfSite.setPDTBNode(null);
        }
        
        fInfSite.setPDTBNode(this);
        
        fInfSite = infSite;
        fInfSite.updateAttributesOnNode();
    }
    
    public boolean getAllowsChildren() {
        return true;
    }
    
    public void save(Writer writer) throws IOException {
        writer.write("________________________________________________________\n");
        writer.write("____EntRel____\n");
        
        ((PDTBInferenceSiteImpl)fInfSite).save(writer);
        
        writer.write("____Arg1____\n");
        ((PDTBSupImpl)getArg1()).save(writer);
        
        writer.write("____Arg2____\n");
        ((PDTBSupImpl)getArg2()).save(writer);
        
        
        writer.write("________________________________________________________\n");
    }
    
}
