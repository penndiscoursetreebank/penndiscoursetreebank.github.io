package gui;

import edu.upenn.cis.anntool.util.SpringUtilities;
import edu.upenn.cis.ptb.standoff.MakeStandoff;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.border.BevelBorder;

import scripts.AnnToPdtb;
import scripts.FileExceptions;
import scripts.FolderExistsException;
import scripts.NoFolderException;
import scripts.PdtbToAnn;

//Pdtb To Ann

//Ann To Pdtb

//rawroot PA,AP
//ptbroot PA,AP
//sptbroot AP
//pdtbroot PA
//annroot PA,AP
//newpdtbroot AP
//connheadfile AP
//temproot AP

public class Conversion extends JFrame {

	private static final String fileLocation = "ConvertSettings.txt";
	private static final ProgressBar progressBar = new ProgressBar();

	private static enum FILE {
		RawRoot("This is the directory such that RawRoot" + File.separatorChar
				+ "00" + File.separatorChar
				+ "wsj_0003\n gives the Raw text file for Section 00 file 03.",
				JFileChooser.DIRECTORIES_ONLY), PtbRoot(
				"This is the directory such that PtbRoot"
						+ File.separatorChar
						+ "00"
						+ File.separatorChar
						+ "wsj_0003\n gives the PTB file for Section 00 file 03.",
				JFileChooser.DIRECTORIES_ONLY), SptbRoot(
				"This is the directory such that SptbRoot"
						+ File.separatorChar
						+ "00"
						+ File.separatorChar
						+ "wsj_0003\n gives the Standoff PTB file for Section 00 file 03. If the SPTB root is empty or does not contain files, the sptb set will be created.",
				JFileChooser.DIRECTORIES_ONLY), PdtbRoot(
				"This is the directory such that PdtbRoot"
						+ File.separatorChar
						+ "00"
						+ File.separatorChar
						+ "wsj_0003\n gives the Original PDTB file for Section 00 file 03.",
				JFileChooser.DIRECTORIES_ONLY), AnnRoot(
				"This is the directory such that AnnRoot"
						+ File.separatorChar
						+ "00"
						+ File.separatorChar
						+ "wsj_0003\n gives the Annotation file for Section 00 file 03.",
				JFileChooser.DIRECTORIES_ONLY), NewPdtbRoot(
				"This is the directory such that NewPdtbRoot"
						+ File.separatorChar
						+ "00"
						+ File.separatorChar
						+ "wsj_0003\n gives the New PDTB file for Section 00 file 03.",
				JFileChooser.DIRECTORIES_ONLY), ConnHeadFile(
				"File that contains the Connective Heads (probably ConnHeads.txt)",
				JFileChooser.FILES_ONLY), TempRoot(
				"This is the location of a directory that may be used/created and deleted.",
				JFileChooser.DIRECTORIES_ONLY);

		public final String description;
		public final int fileOrDir;

		FILE(String description, int fileOrDir) {
			this.description = description;
			this.fileOrDir = fileOrDir;
		}
	}

	private TFGroup tfg[];

	private JPanel radioPanel;
	private JPanel filesPanel;
	private JPanel panel;
	private JButton okBtn;
	private JRadioButton pdtbToAnn;
	private JRadioButton annToPdtb;

	Conversion() {

		super("File Dialog");
		tfg = new TFGroup[FILE.values().length];

		ButtonGroup btngrp = new ButtonGroup();

		pdtbToAnn = new JRadioButton("Convert PDTB files to Annotation files");
		btngrp.add(pdtbToAnn);
		pdtbToAnn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				okBtn.setEnabled(true);
				disableMost();
				tfg[FILE.PdtbRoot.ordinal()].enable();
			}
		});

		annToPdtb = new JRadioButton("Convert Annotation files to PDTB files");
		btngrp.add(annToPdtb);
		annToPdtb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				okBtn.setEnabled(true);
				disableMost();
				tfg[FILE.SptbRoot.ordinal()].enable();
				tfg[FILE.NewPdtbRoot.ordinal()].enable();
				tfg[FILE.ConnHeadFile.ordinal()].enable();
				tfg[FILE.TempRoot.ordinal()].enable();
			}
		});

		radioPanel = new JPanel();
		radioPanel.setLayout(new BoxLayout(radioPanel, BoxLayout.X_AXIS));
		radioPanel.add(pdtbToAnn);
		radioPanel.add(annToPdtb);

		panel = (JPanel) getContentPane();

		filesPanel = new JPanel();
		filesPanel.setLayout(new SpringLayout());

		for (int i = 0; i < tfg.length; i++) {
			FILE f = FILE.values()[i];
			tfg[i] = createTFGroup(f.toString(), f.description, f.fileOrDir);
		}

		disableMost();

		// set up real properties
		try {
			Properties fileLocations = new Properties();
			FileInputStream is = new FileInputStream(fileLocation);
			fileLocations.load(is);
			is.close();
			for (int i = 0; i < tfg.length; i++) {
				tfg[i].tf.setText(fileLocations
						.getProperty(tfg[i].tf.getName()));
			}
		} catch (IOException e) {
			// do nothing because text fields will just be null if the
			// properties file doesn't exist yet
		}

		okBtn = new JButton("Convert");
		okBtn.setEnabled(false);
		okBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				convert();
			}
		});

		JPanel btnPanel = new JPanel();
		btnPanel.add(okBtn);
		filesPanel.add(Box.createHorizontalStrut(0));
		filesPanel.add(btnPanel);
		filesPanel.add(Box.createHorizontalStrut(0));

		/*-------Progress Panel-------*/

		JPanel progressPanel = new JPanel();
		progressPanel.setLayout(new BorderLayout());
		progressPanel.add(progressBar, BorderLayout.CENTER);
		progressPanel.setBorder(new BevelBorder(BevelBorder.LOWERED));

		SpringUtilities.makeCompactGrid(filesPanel, // parent
				9, 3, // rows, cols
				3, 3, // initX, initY (left and top padding)
				0, 0); // xPad, yPad (right and bottom padding)
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(radioPanel);
		panel.add(filesPanel);
		panel.add(progressPanel);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);

	}

	public void convert() {
		boolean noBlanks = true;
		for (int i = 0; i < tfg.length; i++) {
			String text = tfg[i].tf.getText();
			noBlanks &= !tfg[i].lbl.isEnabled()
					|| !(text == null || text.equals(""));
		}
		if (noBlanks) {
			try {
				saveFilenames();
				try {
					if (pdtbToAnn.isSelected()) {
						pdtbToAnn();
					} else if (annToPdtb.isSelected()) {
						annToPdtb();
					}
					progressBar.maxOut();
					JOptionPane.showMessageDialog(this, "Conversion complete.");
					dispose();
				} catch (FolderExistsException f) {
					JOptionPane.showMessageDialog(this, f.getMessage());
					progressBar.reset();
				} catch (NoFolderException f) {
					JOptionPane.showMessageDialog(this, f.getMessage());
					progressBar.reset();
				}
			} catch (Exception exception) {
				JOptionPane.showMessageDialog(this,
						"One of the file locations is invalid?  Details:\n"
								+ exception.getMessage());
				progressBar.reset();
				exception.printStackTrace();
			}
		} else {
			JOptionPane.showMessageDialog(this,
					"Please provide all folder locations.");
		}
	}

	public void pdtbToAnn() throws IOException {
		progressBar.setMaximum(tfg[FILE.PdtbRoot.ordinal()].tf.getText(), 1,
				1, 1);
		PdtbToAnn.run(tfg[FILE.RawRoot.ordinal()].tf.getText(),
				tfg[FILE.PtbRoot.ordinal()].tf.getText(), tfg[FILE.PdtbRoot
						.ordinal()].tf.getText(),
				tfg[FILE.AnnRoot.ordinal()].tf.getText(), progressBar);
	}

//	private static final Pattern patchPattern = Pattern.compile(Pattern
//			.quote("(NP (NNP IBC) (POS 's) )"));
//	private static final String replacement = "(NP (NNP IBC\\\\/Donoghue) (POS 's) )";

	public void annToPdtb() throws Exception {
		// create tempdir
		String tempDirStr = tfg[FILE.TempRoot.ordinal()].tf.getText();
		FileExceptions.exceptionIfFolderContains(tempDirStr);
		File tempDir = new File(tempDirStr);
		tempDir.mkdirs();

		int parts = 1;

		// check if sptb is empty or not
		if (!FileExceptions.folderContains(tfg[FILE.SptbRoot.ordinal()].tf
				.getText())) {

			parts = 2;
			progressBar
					.standbyMessage("Creating SPTB for the first time. Please wait...");

			// patch ptb
			// File ptbPatchFile = new File(new File(
			// tfg[FILE.PtbRoot.ordinal()].tf.getText(), "00"),
			// "wsj_0004.mrg");
			// if (ptbPatchFile.exists()) {
			// String str = "";
			// BufferedInputStream inputStream = new BufferedInputStream(
			// new FileInputStream(ptbPatchFile));
			// while (inputStream.available() > 0) {
			// str += (char) inputStream.read();
			// }
			// inputStream.close();
			// Matcher patchMatcher = patchPattern.matcher(str);
			// if (patchMatcher.find()) {
			// ptbPatchFile.delete();
			// BufferedWriter outputStream = new BufferedWriter(
			// new FileWriter(ptbPatchFile));
			// outputStream.write(patchMatcher.replaceFirst(replacement));
			// outputStream.flush();
			// outputStream.close();
			// ptbPatchFile.setReadOnly();
			// System.out.println("Patched wsj_0004.mrg");
			// }
			// }
			MakeStandoff.makeStandoff(tfg[FILE.PtbRoot.ordinal()].tf.getText(),
					tfg[FILE.RawRoot.ordinal()].tf.getText(), tfg[FILE.SptbRoot
							.ordinal()].tf.getText(), tfg[FILE.TempRoot
							.ordinal()].tf.getText()
							+ File.separatorChar + "sptblog.log");
		}
		try {
			progressBar.setMaximum(tfg[FILE.AnnRoot.ordinal()].tf.getText(), 3,
					parts, parts);
			AnnToPdtb.run(tfg[FILE.RawRoot.ordinal()].tf.getText(),
					tfg[FILE.PtbRoot.ordinal()].tf.getText(), tfg[FILE.SptbRoot
							.ordinal()].tf.getText(), tfg[FILE.NewPdtbRoot
							.ordinal()].tf.getText(), tfg[FILE.AnnRoot
							.ordinal()].tf.getText(), tfg[FILE.TempRoot
							.ordinal()].tf.getText(), tfg[FILE.ConnHeadFile
							.ordinal()].tf.getText(), progressBar);
		} catch (Exception e) {
			delete(tempDir);
			throw e;
		}

		delete(tempDir);
	}

	public static void delete(File dir) {
		File[] dirs = dir.listFiles();
		for (File f : dirs) {
			if (f.isDirectory()) {
				delete(f);
			} else {
				f.delete();
			}
		}
		dir.delete();
	}

	private void disableMost() {
		tfg[FILE.SptbRoot.ordinal()].disable();
		tfg[FILE.PdtbRoot.ordinal()].disable();
		tfg[FILE.NewPdtbRoot.ordinal()].disable();
		tfg[FILE.ConnHeadFile.ordinal()].disable();
		tfg[FILE.TempRoot.ordinal()].disable();
	}

	private void saveFilenames() {
		try {
			Properties fileLocations = new Properties();
			for (int i = 0; i < tfg.length; i++) {
				fileLocations.setProperty(tfg[i].tf.getName(), tfg[i].tf
						.getText());
			}
			FileOutputStream os = new FileOutputStream(fileLocation);
			fileLocations
					.store(
							os,
							"This file contains user settings for your Annotator. It is safe to delete, but you will lose your settings.");
			os.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private TFGroup createTFGroup(final String labelText,
			final String description, final int type) {
		final JLabel lbl = new JLabel(labelText + ":");
		final JTextField tf = new JTextField(20);
		final JButton btn = new JButton("Browse...");
		lbl.setToolTipText(description);
		tf.setName(labelText);
		tf.setToolTipText(description);
		btn.setToolTipText(description);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser(tf.getText());
				fc.setFileSelectionMode(type);
				int retVal = fc.showDialog((JFrame) getParent(), labelText);
				if (retVal == JFileChooser.APPROVE_OPTION) {
					tf.setText(fc.getSelectedFile().getAbsolutePath());
				}
			}
		});
		filesPanel.add(lbl);
		filesPanel.add(tf);
		filesPanel.add(btn);
		return new TFGroup(lbl, tf, btn);
	}

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String args[]) {
		new Conversion();
	}

	class TFGroup {
		public JLabel lbl;
		public JTextField tf;
		public JButton btn;

		public TFGroup(JLabel lbl, JTextField tf, JButton btn) {
			this.lbl = lbl;
			this.tf = tf;
			this.btn = btn;
		}

		public void enable() {
			lbl.setEnabled(true);
			// tf.setEnabled(true);
			// btn.setEnabled(true);
			// lbl.setVisible(true);
			tf.setVisible(true);
			btn.setVisible(true);
		}

		public void disable() {
			lbl.setEnabled(false);
			// tf.setEnabled(false);
			// btn.setEnabled(false);
			// lbl.setVisible(false);
			tf.setVisible(false);
			btn.setVisible(false);
		}

	}

}
