package gui;

import java.awt.Color;
import java.io.File;

import javax.swing.JProgressBar;

public class ProgressBar extends JProgressBar {

	public static final String progressString = "Progress";
	private int part;
	private int numberOfParts;

	public ProgressBar() {
		this.setString(progressString);
		this.setStringPainted(true);
		this.setBorderPainted(true);
		this.setBackground(new Color(200, 200, 200));
	}

	public void reset() {
		this.setValue(0);
		this.setString(progressString);
	}

	public void standbyMessage(String message){
		this.setString(message);
		this.paintImmediately(this.getBounds());
	}
	
	public void setMaximum(String inputRoot, int numberOfSteps, int part,
			int numberOfParts) {
		this.part = part;
		this.numberOfParts = numberOfParts;
		int totalFiles = 0;
		File f = new File(inputRoot);
		File[] secs = f.listFiles();
		if (secs == null) {
			this.setMaximum(0);
			return;
		}
		for (File sec : secs) {
			File[] fils = sec.listFiles();
			if (fils != null) {
				totalFiles += fils.length;
			}
		}
		this.setMaximum(totalFiles * numberOfSteps);
	}

	public void increment() {
		this.setValue(this.getValue() + 1);
		this.setString(progressString + ": " + (this.getValue() * 100)
				/ this.getMaximum() + "% (Part " + part + "/" + numberOfParts
				+ ")");
		this.paintImmediately(this.getBounds());
	}
	
	public void maxOut(){
		this.setString(progressString + ": 100%");
	}
}
