package SpanToGAL;
/*
 * BarrierState.java
 *
 * Created on October 31, 2004, 11:35 AM
 */



import edu.upenn.cis.ptb.PTBTreeNode;

/**
 *
 * @author  nikhild
 */
public class BarrierState {
    
    public static final int BarrierContained = 0;
    
    public static final int BarrierCrossed = 1;
    
    public static final int BarrierEqual = 2;
    
    public int state = 0;
    
    public PTBTreeNode node = null;
    
    /** Creates a new instance of BarrierState */
    public BarrierState(PTBTreeNode node, int state) {
        this.node = node;
        this.state = state;
    }
    
    public int hashCode(){
        return this.node.hashCode();
    }
    
    public boolean equals(Object o){
        BarrierState other = (BarrierState)o;
        if(node == other.getNode() && state == other.getState()){
            return true;
        }
        return false;
    }
    
    public PTBTreeNode getNode(){
        return node;
    }
    
    public int getState(){
        return state;
    }
}
