/*
 * FixGornAddresses.java
 *
 * Created on January 17, 2006, 11:38 PM
 */

package SpanToGAL;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.upenn.cis.pdtb.PDTBAltLexRelation;
import edu.upenn.cis.pdtb.PDTBAltLexRelationImpl;
import edu.upenn.cis.pdtb.PDTBEntityRelationImpl;
import edu.upenn.cis.pdtb.PDTBExplicitRelation;
import edu.upenn.cis.pdtb.PDTBExplicitRelationImpl;
import edu.upenn.cis.pdtb.PDTBNode;
import edu.upenn.cis.pdtb.PDTBRelationImpl;
import edu.upenn.cis.pdtb.PDTBRelationList;
import edu.upenn.cis.pdtb.PDTBRelationListImpl;
import edu.upenn.cis.pdtb.PDTBSelection;
import edu.upenn.cis.pdtb.PDTBSup;
import edu.upenn.cis.pdtb.util.GornAddressList;
import edu.upenn.cis.pdtb.util.GornAddressUtils;
import edu.upenn.cis.pdtb.util.PDTBTask;
import edu.upenn.cis.ptb.PTBTreeNode;

/**
 * 
 * @author nikhild
 */
public class SiblingInclusion {

	public static final Logger log = Logger.getLogger("SiblingInclusion");

	public SiblingInclusion() {

	}

	public static boolean isClause(PTBTreeNode node) {
		return SpanStretch.isClause(node);
	}

	public static boolean punctOrTraceContainer(PTBTreeNode node) {
		return SpanStretch.isPunctOrTraceContainer(node);
	}

	public static boolean isAddressContained(int[] address,
			Vector addressesToCheck) {
		for (Enumeration e = addressesToCheck.elements(); e.hasMoreElements();) {
			GornAddressList gal = (GornAddressList) (e.nextElement());
			if (GornAddressUtils.prefixExists(address, gal)) {
				return true;
			}
		}

		return false;
	}

	public static void excludeOverlappingPunct(PTBTreeNode root,
			Vector addressesToCheck) {
		int i = 0;
		for (Enumeration e = addressesToCheck.elements(); e.hasMoreElements(); i++) {
			GornAddressList gal = (GornAddressList) (e.nextElement());
			Vector addressesToRemove = new Vector();
			int j = 0;
			for (Enumeration e1 = addressesToCheck.elements(); e1
					.hasMoreElements(); j++) {
				GornAddressList gal1 = (GornAddressList) (e1.nextElement());
				Vector addressesToRemove1 = new Vector();
				if (i < j) {
					for (Iterator iter = gal.iterator(); iter.hasNext();) {
						int[] address = (int[]) (iter.next());
						PTBTreeNode node = (PTBTreeNode) (GornAddressUtils
								.getNode(address, root));
						if (punctOrTraceContainer(node)) {
							if (GornAddressUtils.prefixExists(address, gal1)) {
								if (gal1.contains(address)) {
									addressesToRemove1.add(address);
								} else {
									addressesToRemove.add(address);
								}
							}

						}
					}
				}
				gal1.removeAll(addressesToRemove1);
			}
			gal.removeAll(addressesToRemove);
		}
	}

	public static boolean fixGA(GornAddressList gal, PTBTreeNode root) {
		return SpanStretch.fixGA(gal, root);
	}

	public static void includeSiblings(GornAddressList gal, PTBTreeNode root,
			Vector addressesToCheck) {
		GornAddressList gal2 = new GornAddressList();
		for (Iterator iter = gal.iterator(); iter.hasNext();) {
			int[] address = (int[]) (iter.next());
			PTBTreeNode node = (PTBTreeNode) (GornAddressUtils.getNode(address,
					root));
			String type = node.getLabel().getType();

			if (!(isClause(node))) {
				PTBTreeNode parent = (PTBTreeNode) (node.getParent());
				if (parent.getParent() != null) {
					boolean done = false;

					for (PTBTreeNode sib = node; sib != null && !done; sib = sib
							.ptbGetPreviousSibling()) {
						if (punctOrTraceContainer(sib)) {
							int[] address2 = GornAddressUtils
									.getGornAddress(sib);
							if (!isAddressContained(address2, addressesToCheck)) {
								gal2.add(address2);
							}
						}

						if (sib.getLabel().getType().equals("CC")) {
							String leaf = ((PTBTreeNode) sib.getChildAt(0))
									.getLabel().getType();
							String leafLower = leaf.toLowerCase();
							if (leafLower.equals(leaf)) {
								done = true;
							}
						}

					}

					done = false;
					for (PTBTreeNode sib = node.ptbGetNextSibling(); sib != null
							&& !done; sib = sib.ptbGetNextSibling()) {
						if (punctOrTraceContainer(sib)) {
							int[] address2 = GornAddressUtils
									.getGornAddress(sib);
							if (!isAddressContained(address2, addressesToCheck)) {
								gal2.add(address2);
							}
						}

						if (sib.getLabel().getType().equals("CC")) {
							done = true;
						}

					}

				}
			}
		}
		gal.addAll(gal2);
		fixGA(gal, root);
	}

	public static void includeSiblings(PDTBSup n, PTBTreeNode root,
			Vector addressesToCheck) {
		if (n == null) {
			return;
		}

		GornAddressList gal = n.getSelection().getAddresses();
		includeSiblings(gal, root, addressesToCheck);
	}

	public static void includeSiblings(PDTBNode o, PTBTreeNode root)
			throws IOException {

		Vector addressesToCheck = new Vector();

		if (o instanceof PDTBRelationImpl) {
			PDTBRelationImpl rel = (PDTBRelationImpl) o;
			if (rel instanceof PDTBExplicitRelation) {
				PDTBExplicitRelationImpl expRel = (PDTBExplicitRelationImpl) (rel);
				PDTBSelection sel = expRel.getSelection();

				addressesToCheck.add(sel.getAddresses());

			} else if (rel instanceof PDTBAltLexRelation) {
				PDTBAltLexRelationImpl expRel = (PDTBAltLexRelationImpl) (rel);

				PDTBSelection sel = expRel.getSelection();

				addressesToCheck.add(sel.getAddresses());

			}

			for (Enumeration e1 = rel.children(); e1.hasMoreElements();) {
				addressesToCheck.add(((PDTBSup) (e1.nextElement()))
						.getSelection().getAddresses());
			}

			includeSiblings(rel.getArg1(), root, addressesToCheck);
			includeSiblings(rel.getArg2(), root, addressesToCheck);
			includeSiblings(rel.getSup1(), root, addressesToCheck);
			includeSiblings(rel.getSup2(), root, addressesToCheck);

			excludeOverlappingPunct(root, addressesToCheck);
			// At this point args and conn are fine
			// call includeSiblings(attr.gal, root, addressesToCheck)

		} else {
			PDTBEntityRelationImpl entRel = (PDTBEntityRelationImpl) o;
			PDTBSup arg1 = entRel.getArg1();
			PDTBSup arg2 = entRel.getArg2();
			addressesToCheck.add(arg1.getSelection().getAddresses());
			addressesToCheck.add(arg2.getSelection().getAddresses());
			includeSiblings(arg1, root, addressesToCheck);
			includeSiblings(arg2, root, addressesToCheck);
			excludeOverlappingPunct(root, addressesToCheck);
		}
	}

	public static void includeSiblings(PDTBRelationList relList, Writer writer)
			throws IOException {
		PTBTreeNode root = relList.getPTBRoot();
		for (Enumeration e = relList.children(); e.hasMoreElements();) {
			Object o = e.nextElement();
			includeSiblings((PDTBNode) o, root);
		}
		((PDTBRelationListImpl) relList).save(writer);
	}

	public static void includeSiblings(String rawRoot, String ptbRoot,
			String pdtbRoot, String outputRoot) throws IOException {

		File outputDir = new File(outputRoot);
		outputDir.mkdirs();

		for (PDTBTask task = new PDTBTask(rawRoot, ptbRoot, pdtbRoot); task
				.hasNext();) {

			PDTBRelationList relList = task.next();
			String secNo = task.getSecNoStr();
			String fileNo = task.getFileNoStr();
			System.out.println(task.getSecNoStr() + task.getFileNoStr());

			// if(task.getSecNo() == 6 && task.getFileNo() == 32){
			// System.out.println("breakpoint");
			// }

			File outputSec = new File(outputDir, secNo);
			outputSec.mkdirs();
			File outFile = new File(outputSec, "wsj_" + secNo + fileNo
					+ ".pdtb");
			Writer writer = new BufferedWriter(new FileWriter(outFile));

			includeSiblings(relList, writer);

			writer.flush();
			writer.close();
		}
	}

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here
		if (args.length != 5) {
			System.err
					.println("Usage: java edu.upenn.cis.pdtb.scripts.link.SpanStretch <rawRoot> <ptbRoot> <pdtbRoot> <outputRoot> <logFile>");
			System.exit(0);
		}

		try {
			// test(rawRoot, ptbRoot, pdtbRoot, logFile);
			includeSiblings(args[0], args[1], args[2], args[3]);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
