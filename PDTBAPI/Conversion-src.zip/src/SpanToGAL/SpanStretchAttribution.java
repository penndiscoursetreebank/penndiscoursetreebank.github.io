package SpanToGAL;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import edu.upenn.cis.pdtb.PDTBAltLexRelationImpl;
import edu.upenn.cis.pdtb.PDTBExplicitRelationImpl;
import edu.upenn.cis.pdtb.PDTBImplicitRelationImpl;
import edu.upenn.cis.pdtb.PDTBNode;
import edu.upenn.cis.pdtb.PDTBRelationImpl;
import edu.upenn.cis.pdtb.PDTBRelationList;
import edu.upenn.cis.pdtb.PDTBRelationListImpl;
import edu.upenn.cis.pdtb.PDTBSelection;
import edu.upenn.cis.pdtb.util.GornAddressList;
import edu.upenn.cis.pdtb.util.PDTBTask;
import edu.upenn.cis.pdtb.util.SpanList;
import edu.upenn.cis.pdtb.xpath.SpanListSizeFunction;
import edu.upenn.cis.ptb.PTBLoader;
import edu.upenn.cis.ptb.PTBTreeNode;
import edu.upenn.cis.ptb.standoff.SPTBLoaderImpl;

public class SpanStretchAttribution {

	private static final PTBLoader loader = new SPTBLoaderImpl();

	public static void insertGornAddresses(String rawRoot, String ptbRoot,
			String sptbRoot, String pdtbRoot, String outputRoot,
			boolean includePunctuation) throws IOException {
		File outputDir = new File(outputRoot);
		outputDir.mkdirs();

		for (PDTBTask task = new PDTBTask(rawRoot, ptbRoot, pdtbRoot); task
				.hasNext();) {
			PDTBRelationList relList = task.next();
			String secNo = task.getSecNoStr();
			String fileNo = task.getFileNoStr();
			System.out.println(task.getSecNoStr() + task.getFileNoStr());
			File outputSec = new File(outputDir, secNo);
			outputSec.mkdirs();
			File outFile = new File(outputSec, "wsj_" + secNo + fileNo
					+ ".pdtb");
			PTBTreeNode root = loader.load(sptbRoot, secNo, fileNo);
			// relList.getPTBRoot();
			Writer writer = new BufferedWriter(new FileWriter(outFile));
			computeGA(relList, root, includePunctuation);
			((PDTBRelationListImpl) relList).save(writer);
			writer.flush();
			writer.close();
		}
	}

	public static void computeGA(PDTBNode node, PTBTreeNode root,
			boolean includePunctuation) {
		if (node instanceof PDTBExplicitRelationImpl
				|| node instanceof PDTBImplicitRelationImpl
				|| node instanceof PDTBAltLexRelationImpl) {

			PDTBRelationImpl rel = (PDTBRelationImpl) node;
			SpanList sp = SpanListSizeFunction.getSpanListForNode(node, true);
			List<PDTBSelection> selectionList = new ArrayList<PDTBSelection>();
			if (node instanceof PDTBExplicitRelationImpl) {
				PDTBExplicitRelationImpl relation = (PDTBExplicitRelationImpl) node;
				if (relation.getFeatures().getSelection() != null) {
					selectionList.add(relation.getFeatures().getSelection());
				}
			} else if (node instanceof PDTBImplicitRelationImpl) {
				PDTBImplicitRelationImpl relation = (PDTBImplicitRelationImpl) node;
				if (relation.getFeatures().getSelection() != null) {
					selectionList.add(relation.getFeatures().getSelection());
				}
			} else if (node instanceof PDTBAltLexRelationImpl) {
				PDTBAltLexRelationImpl relation = (PDTBAltLexRelationImpl) node;
				if (relation.getFeatures().getSelection() != null) {
					selectionList.add(relation.getFeatures().getSelection());
				}
			}
			if (rel.getArg1().getFeatures().getSelection() != null) {
				selectionList.add(rel.getArg1().getFeatures().getSelection());
			}
			if (rel.getArg2().getFeatures().getSelection() != null) {
				selectionList.add(rel.getArg2().getFeatures().getSelection());
			}

			for (Iterator<PDTBSelection> iter = selectionList.iterator(); iter
					.hasNext();) {

				PDTBSelection selection = (PDTBSelection) iter.next();

				SpanList value = selection.getSpans();

				// System.out.println(value);

				GornAddressList gal = SpanStretch.getGornAddressList(root,
						value, includePunctuation);
				// Change2
				boolean overlap = sp.isOverlapping(value);

				// Change3
				if (includePunctuation && !overlap) {
					SiblingInclusion.includeSiblings(gal, root, new Vector());
				}

				selection.getAddresses().clear();
				selection.getAddresses().addAll(gal);

			}

		}
	}

	public static void computeGA(PDTBRelationList relList, PTBTreeNode root,
			boolean includePunctuation) {
		for (Enumeration e = relList.children(); e.hasMoreElements();) {
			PDTBNode node = (PDTBNode) (e.nextElement());
			computeGA(node, root, includePunctuation);
		}
	}

	public static void main(String[] args) {
		if (args.length != 4) {
			System.err
					.println("Usage: java edu.upenn.cis.pdtb.scripts.link.SpanStretchAttribution <rawRoot> <ptbRoot> <sptbRoot> <pdtbRoot> <outputRoot>");
			System.exit(0);
		}
		try {
			insertGornAddresses(args[0], args[1], args[2], args[3], args[4],
					true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
