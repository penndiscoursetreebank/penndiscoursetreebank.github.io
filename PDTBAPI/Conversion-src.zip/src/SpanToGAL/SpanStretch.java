package SpanToGAL;
/*
 * SyntaxDiscourseLink.java
 *
 * Created on October 17, 2004, 4:47 PM
 */


import java.util.*;
import java.util.logging.*;

import java.io.*;

import edu.upenn.cis.pdtb.*;
import edu.upenn.cis.pdtb.util.*;
import edu.upenn.cis.ptb.*;
import edu.upenn.cis.ptb.standoff.SPTBLabel;
import edu.upenn.cis.ptb.standoff.SPTBLoaderImpl;
import edu.upenn.cis.ptb.xpath.PTBNavigator;
import gui.ProgressBar;

/**
 * 
 * @author nikhild, geraud
 */
public class SpanStretch {

	public static final String LeavesDominatedKey = "LeavesDominated";

	public static final Logger log = Logger.getLogger("SpanStretch");

	/** Creates a new instance of SyntaxDiscourseLink */
	public SpanStretch() {
	}

	/**
	 * Adds the indices of the leaves dominated by a node in the node's
	 * userData.
	 */
	public static int computeLeavesDominated(PTBTreeNode node, int nextLeaf) {
		int start = nextLeaf;

		for (Enumeration children = node.children(); children.hasMoreElements();) {
			nextLeaf = computeLeavesDominated((PTBTreeNode) (children
					.nextElement()), nextLeaf);
		}

		int end = nextLeaf;

		setUserData(node, LeavesDominatedKey, new LeavesDominated(start, (node
				.isLeaf()) ? end : end - 1));

		if (node.isLeaf()) {
			return ++nextLeaf;
		} else {
			return nextLeaf;
		}
	}

	/**
	 * Returns true iff the node is a clause. A node is a clause iff one of the
	 * following hold:
	 * 
	 * <ul>
	 * <li>The label starts with S</li>
	 * <li>The label is PRN, and the node has a child labeled S or VP</li>
	 * <li>The label is PP and the node has a child labeled S.</li>
	 * </ul>
	 * 
	 */
	public static boolean isClause(PTBTreeNode node) {
		String type = node.getLabel().getType();

		if (type.startsWith("S") || type.equals("INTJ") || type.equals("RRC")) {
			return true;
		} else {
			if (type.startsWith("PRN")) {
				for (Enumeration e = node.children(); e.hasMoreElements();) {
					PTBTreeNode child = (PTBTreeNode) (e.nextElement());
					String childType = child.getLabel().getType();
					if (childType.startsWith("S") || childType.startsWith("VP")) {
						return true;
					}
				}
			}

			if (type.startsWith("PP")) {
				for (Enumeration e = node.children(); e.hasMoreElements();) {
					PTBTreeNode child = (PTBTreeNode) (e.nextElement());
					if (child.getLabel().getType().startsWith("S")) {
						return true;
					}
				}
			}

			return false;
		}
	}

	/**
	 * Returns true iff a node dominates only punctuation or traces.
	 */
	public static boolean isPunctOrTraceContainer(PTBTreeNode node) {
		int childCount = node.getChildCount();
		boolean isPreterminal = (childCount == 1) ? node.getChildAt(0).isLeaf()
				: false;

		if (node.isLeaf()) {
			return false;
		}

		if (node.isPreterminal()) {

			if (node.isTracePreterminal() || node.isPunctPreterminal()) {
				return true;
			}

			return false;
		}

		for (Enumeration e = node.children(); e.hasMoreElements();) {
			PTBTreeNode child = (PTBTreeNode) (e.nextElement());
			if (!isPunctOrTraceContainer(child)) {
				return false;
			}
		}

		return true;

	}

	/**
	 * Returns true iff a node is a barrier. A node is a barrier iff the
	 * following conditions hold:
	 * 
	 * <ul>
	 * <li> <code>!isPunctOrTraceContainer(node)</code></li>
	 * <li> <code>isClause(node)</code></li>
	 * <li>If the parent is a clause, then it has a <code> child </code> other
	 * than <code> node </code> such that
	 * <code> !isPunctOrTraceContainer(child) </code></li>
	 * </ul>
	 */
	public static boolean isBarrier(PTBTreeNode node) {
		if (isPunctOrTraceContainer(node)) {
			return false;
		}

		if (isClause(node)) {
			PTBTreeNode parent = (PTBTreeNode) (node.getParent());
			if (parent != null && isClause(parent)) {

				for (Enumeration e = parent.children(); e.hasMoreElements();) {
					PTBTreeNode child = (PTBTreeNode) (e.nextElement());
					if (child != node && !isPunctOrTraceContainer(child)) {
						return true;
					}
				}

				return false;

			}

			return true;
		}

		return false;
	}

	public static Object getUserData(PTBTreeNode node, String key) {
		HashMap userDataMap = (HashMap) node.getUserObject();
		return userDataMap.get(key);
	}

	public static void setUserData(PTBTreeNode node, String key, Object value) {
		HashMap userDataMap = (HashMap) node.getUserObject();

		if (userDataMap == null) {
			userDataMap = new HashMap();
			node.setUserObject(userDataMap);
		}
		userDataMap.put(key, value);
	}

	/**
	 * Initializes the <code> barrierSet </code> with the barrier nodes with
	 * which <code> ld </code> has a containment or crossing relationship. Note
	 * that crossing here means overlap without proper containment.
	 */
	public static void computeBarrierState(PTBTreeNode node,
			HashSet barrierSet, LeavesDominated ld) {
		LeavesDominated ld1 = (LeavesDominated) (getUserData(node,
				LeavesDominatedKey));

		if (ld.end < ld1.start || ld.start > ld1.end) {
			return;
		}

		if (isBarrier(node)) {

			if ((ld.start <= ld1.start && ld.end > ld1.end)
					|| (ld.start <= ld1.start && ld.end > ld1.end)) {

				barrierSet.add(new BarrierState(node,
						BarrierState.BarrierContained));
			} else if ((ld.start < ld1.start && ld.end <= ld1.end)
					|| (ld.start >= ld1.start && ld.end > ld1.end)) {
				barrierSet.add(new BarrierState(node,
						BarrierState.BarrierCrossed));
			} else {
				log.finest("Barrier Not Properly Contained or Crossed.\n ld1="
						+ ld1.toString() + "\n ld=" + ld.toString());
			}

		}

		for (Enumeration children = node.children(); children.hasMoreElements();) {
			PTBTreeNode child = (PTBTreeNode) (children.nextElement());
			computeBarrierState(child, barrierSet, ld);
		}
	}

	/**
	 * Checks if <code>barrierSet</code> is respected by <code>ld</code>. This
	 * means that if
	 * <code> ld <code> contains a barrier, then it should be contained or crossed in the
	 * <code> barrierSet </code>. If
	 * <code> ld <code> crosses a barrier, then it should be
	 *  crossed by <code> barrierSet </code>.
	 */
	public static boolean checkBarrierState(PTBTreeNode node,
			HashSet barrierSet, LeavesDominated ld) {
		boolean barrierOutside = false;
		LeavesDominated ld1 = (LeavesDominated) (getUserData(node,
				LeavesDominatedKey));

		if (ld.end < ld1.start || ld.start > ld1.end) {
			return true;
		}

		if (isBarrier(node)) {

			log.finest("Barrier Node.\n ld1=" + ld1.toString() + "\n ld="
					+ ld.toString());

			if (ld.start <= ld1.start && ld.end >= ld1.end) {
				BarrierState bs = new BarrierState(node,
						BarrierState.BarrierContained);
				BarrierState bs2 = new BarrierState(node,
						BarrierState.BarrierCrossed);

				log.finest("Barrier contained.");

				if (!(barrierSet.contains(bs)) && !(barrierSet.contains(bs2))) {
					if (ld.start < ld1.start || ld.end > ld1.end) {
						log.finest("Barrier Violated.");

						return false;
					}
				}
			} else if ((ld.start < ld1.start && ld1.start <= ld.end && ld.end <= ld1.end)
					|| (ld.start >= ld1.start && ld.start <= ld1.end && ld.end > ld1.end)) {
				BarrierState bs = new BarrierState(node,
						BarrierState.BarrierCrossed);
				log.finest("Barrier crossed.");

				if (!(barrierSet.contains(bs))) {
					log.finest("Barrier violated. ");

					return false;
				}
			}

		}

		for (Enumeration children = node.children(); children.hasMoreElements();) {
			PTBTreeNode child = (PTBTreeNode) (children.nextElement());
			if (!checkBarrierState(child, barrierSet, ld)) {
				return false;
			}

		}

		return true;
	}

	public static PTBTreeNode findLeaf(PTBTreeNode node, int leaf) {
		LeavesDominated ld = (LeavesDominated) (getUserData(node,
				LeavesDominatedKey));

		if (node.isLeaf()) {
			if (ld.start == leaf) {
				return node;
			} else {
				return null;
			}
		}

		for (Enumeration e = node.children(); e.hasMoreElements();) {
			PTBTreeNode child = (PTBTreeNode) (e.nextElement());
			LeavesDominated ld1 = (LeavesDominated) (getUserData(child,
					LeavesDominatedKey));

			if (ld1.start <= leaf && ld1.end >= leaf) {
				return findLeaf(child, leaf);
			}

		}

		return null;

	}

	public static boolean isLeafCC(PTBTreeNode root, int leaf) {
		PTBTreeNode leafNode = findLeaf(root, leaf);
		PTBTreeNode preterm = (PTBTreeNode) (leafNode.getParent());
		String type = preterm.getLabel().getType();

		if (type.startsWith("CC")) {
			return true;
		}

		return false;
	}

	public static Iterator leafIterator(PTBTreeNode node) {
		try {
			PTBNavigator nav = new PTBNavigator(node);
			final Iterator desc = nav.getDescendantAxisIterator(node);
			PTBTreeNode leaf = null;
			while (leaf == null && desc.hasNext()) {
				PTBTreeNode n = (PTBTreeNode) desc.next();
				if (n.isLeaf()) {
					leaf = n;
				}
			}

			final PTBTreeNode firstLeaf = leaf;
			return (new Iterator() {
				private PTBTreeNode currentNode = firstLeaf;

				public boolean hasNext() {
					return currentNode != null;
				}

				public Object next() {
					PTBTreeNode retVal = currentNode;
					currentNode = null;
					while (currentNode == null && desc.hasNext()) {
						PTBTreeNode n = (PTBTreeNode) desc.next();
						if (n.isLeaf()) {
							currentNode = n;
						}
					}

					return retVal;

				}

				public void remove() {
				}

			});
		} catch (Exception e) {
			throw (new RuntimeException(e));
		}
	}

	public static int getSpanStart(PTBTreeNode node) {
		return ((SPTBLabel) node.getLabel()).getSpan().getStart();
	}

	public static int getSpanEnd(PTBTreeNode node) {
		return ((SPTBLabel) node.getLabel()).getSpan().getEnd();
	}

	/**
	 * Fixes gorn addresses for case where a span which should have be
	 * contiguous was mistakenly split into multiple spans.
	 */
	public static boolean fixGA(GornAddressList gal, PTBTreeNode root) {
		GornAddressList parentAddresses = new GornAddressList();

		for (Iterator iter = gal.iterator(); iter.hasNext();) {
			int[] address = (int[]) iter.next();
			PTBTreeNode node = (PTBTreeNode) GornAddressUtils.getNode(address,
					root);
			PTBTreeNode parent = (PTBTreeNode) node.getParent();
			if (parent.getParent() != null) {
				int[] addressCopy = new int[address.length];
				for (int i = 0; i < address.length - 1; i++) {
					addressCopy[i] = address[i];
				}

				boolean change = true;
				for (int i = 0; i < parent.getChildCount() && change; i++) {
					addressCopy[addressCopy.length - 1] = i;
					if (!gal.contains(addressCopy)) {
						change = false;
					}
				}
				if (change) {
					parentAddresses
							.add(GornAddressUtils.getGornAddress(parent));
				}
			}
		}

		for (Iterator iter = parentAddresses.iterator(); iter.hasNext();) {
			int[] pAddress = (int[]) iter.next();

			int[] addressCopy = new int[pAddress.length + 1];
			for (int i = 0; i < pAddress.length; i++) {
				addressCopy[i] = pAddress[i];
			}

			PTBTreeNode parent = (PTBTreeNode) GornAddressUtils.getNode(
					pAddress, root);
			for (int i = 0; i < parent.getChildCount(); i++) {
				addressCopy[addressCopy.length - 1] = i;
				gal.remove(addressCopy);
			}
			gal.add(pAddress);
		}

		if (parentAddresses.size() > 0) {
			fixGA(gal, root);
			return true;
		}

		return false;
	}

	/**
	 * Computes the possible leaves for a span to dominate. The idea is to
	 * compute leftmost and rightmost starting and ending points respectively.
	 * The leftmost and rightmost starting point will differ only due to
	 * punctuations or traces.
	 * 
	 * The basic pattern is:
	 * 
	 * <pre>
	 * leftmostStart(Punct | Trace) * rightmostStart(Punct | Trace | Word)
	 * 		* leftmostEnd(Punct | Trace) * rightmostEnd
	 * </pre>
	 * 
	 * The span's start is greater than or equal to <code>leftmostStart</code>
	 * and is less than or equal to <code> rightmostStart </code>. And similarly
	 * for the end points. Note that if the span goes across multiple sentences,
	 * we compute multiple <code>PossibleLeaves</code> objects, one for each
	 * sentence.
	 * 
	 * 
	 */
	public static Vector computePossibleLeaves(PTBTreeNode root, Span span) {
		log.finer("Entering computePossibleLeaves: " + span.toString());
		Vector result = new Vector();
		int spanStart = span.getStart();
		int spanEnd = span.getEnd();
		boolean weirdSpan = false;

		for (Enumeration sents = root.children(); sents.hasMoreElements();) {
			PTBTreeNode sent = (PTBTreeNode) sents.nextElement();
			int sentStart = getSpanStart(sent);
			int sentEnd = getSpanEnd(sent);

			if (!(spanStart >= sentEnd || sentStart >= spanEnd)) {
				LeavesDominated ld = (LeavesDominated) (getUserData(sent,
						LeavesDominatedKey));
				int ctr = ld.start;
				PossibleLeaves pl = new PossibleLeaves();
				boolean addPunctTrace = false;
				boolean seenTokenAfterEnd = false;

				pl.leftmostStart = -1;
				pl.rightmostStart = -1;
				pl.leftmostEnd = -1;
				pl.rightmostEnd = -1;

				for (Iterator leaves = leafIterator(sent); leaves.hasNext(); ctr++) {
					PTBTreeNode leaf = (PTBTreeNode) leaves.next();
					int leafStart = getSpanStart(leaf);
					int leafEnd = getSpanEnd(leaf);

					if (leaf.isPunct() || leaf.isTraceTerminal()) {

						// Span starts at a punctuation or at the end of a word
						if (leafStart == spanStart) {
							log
									.fine("[Warning] Span starts at a punctuation or at the end of a word: "
											+ span.toString());
							weirdSpan = true;
						}

						// Span ends at the end of a punctuation
						if (leaf.isPunct() && leafEnd == spanEnd) {
							log
									.fine("[Warning] Span ends at the end of a punctuation: "
											+ span.toString());
							weirdSpan = true;
						}

						if (!addPunctTrace && pl.rightmostStart == -1) {
							pl.leftmostStart = ctr;
						}

						if (addPunctTrace && !seenTokenAfterEnd
								&& pl.leftmostEnd != -1) {
							pl.rightmostEnd = ctr;
						}

						addPunctTrace = true;
					} else {

						if (pl.rightmostStart == -1 && leafStart >= spanStart) {
							pl.rightmostStart = ctr;
							pl.leftmostStart = (pl.leftmostStart == -1) ? pl.rightmostStart
									: pl.leftmostStart;

							/**
							 * Span starts in the middle of a word
							 */
							if (pl.leftmostStart == -1 && spanStart > sentStart
									&& leafStart != spanStart) {
								log
										.fine("[Warning] Span starts in the middle of a word: "
												+ span.toString());
								weirdSpan = true;
							}

						}

						// Start initialized
						if (pl.rightmostStart != -1) {

							if (leafEnd <= spanEnd) {
								// Ends at a token
								if (weirdSpan && leafEnd == spanEnd) {
									weirdSpan = false;
								} else {
									// Haven't found an exact end yet
									weirdSpan = true;
								}
							}

							// Span ends in the middle of a word
							// Not flagging this error because it results in too
							// many false positives
							// Sometimes due to punctuation spans do not align
							// to word boundaries.

							// if(leafEnd > spanEnd && pl.leftmostEnd == -1){
							// log.fine("[Warning] Span ends in the middle of a
							// word: " + span.toString());
							// weirdSpan = true;
							// }

							if (pl.leftmostEnd == -1 || leafEnd <= spanEnd
									|| leafStart < spanEnd) {
								pl.leftmostEnd = ctr;
								pl.rightmostEnd = ctr;
								addPunctTrace = true;

							}

						} else {
							addPunctTrace = false;
							if (pl.rightmostStart == -1) {
								pl.leftmostStart = -1;
							}
						}

						if (pl.leftmostEnd != -1 && leafStart >= spanEnd) {
							seenTokenAfterEnd = true;
						}

					}

				}
				// Sanity checks
				if (pl.leftmostStart == -1 || pl.rightmostStart == -1
						|| pl.leftmostEnd == -1 || pl.rightmostEnd == -1) {
					log
							.fine("[Error] Something bad happened. Possibly a bug. Span: "
									+ span.toString()
									+ " Possible Leaves: "
									+ pl.toString());

				} else {
					log.finest("Adding " + pl.toString());
					result.add(pl);
				}

			}
		}

		if (result.size() == 0) {
			log.fine("[Error] Span didn't line up: " + span.toString());
		} else if (weirdSpan) {
			StringBuffer sb = new StringBuffer();
			for (Enumeration e = result.elements(); e.hasMoreElements();) {
				sb.append(printLeaves(root, (PossibleLeaves) e.nextElement()));
				sb.append("\n");
			}
			log
					.fine("[Warning] Something weird about this span.\n Check for previous errors/warnings.\n The span: "
							+ span.toString()
							+ "\n Aligned to the following text: "
							+ sb.toString());
		} else if (log.isLoggable(Level.FINEST)) {
			StringBuffer sb = new StringBuffer();
			for (Enumeration e = result.elements(); e.hasMoreElements();) {
				sb.append(printLeaves(root, (PossibleLeaves) e.nextElement()));
				sb.append("\n");
			}
			log.finest("Everything went well for span: " + span.toString()
					+ "\n Aligned to the following text: \n " + sb.toString());
		}

		log.finer("Leaving computePossibleLeaves: " + span.toString());

		return result;
	}

	public static String printLeaves(PTBTreeNode root, PossibleLeaves pl) {
		int ctr = 0;
		StringBuffer sb = new StringBuffer();
		for (Iterator iter = leafIterator(root); iter.hasNext(); ctr++) {
			PTBTreeNode leaf = (PTBTreeNode) iter.next();
			if (ctr >= pl.leftmostStart && ctr <= pl.rightmostEnd) {
				sb.append(" " + leaf.getLabel().getRaw());
			}

			if (ctr > pl.rightmostEnd) {
				return sb.toString();
			}
		}

		return sb.toString();
	}

	/**
	 * Computes the leaves dominated by a span. The parameter
	 * <code> stretch </code> determines whether or not the span will be
	 * stretched. Only the span of a connective is not stretched. Note that if
	 * the span goes across multiple sentences, we compute multiple
	 * <code>LeavesDominated</code> objects, one for each sentence. The steps
	 * are as follows for each <code>PossibleLeaves</code> object returned by
	 * <code> computePossibleLeaves </code>:
	 * 
	 * <ul>
	 * <li>Intialize the leaves dominated <code> ld </code> such that
	 * <code> ld.start = pl.rightmostStart </code> and
	 * <code> ld.end = pl.leftmostEnd </code>.</li>
	 * <li>If <code> stretch == false </code>, we are done. Otherwise, we do the
	 * following:
	 * <ul>
	 * <li>Compute the <code> barrierSet </code> for <code> ld </code></li>
	 * <li>While the <code> barrierSet </code> is respected (
	 * <code> checkBarrierState(root,barrierSet,ld) </code>), move
	 * <code>ld.start</code> to the left, as long as it is greater than or equal
	 * to <code> pl.leftmostStart </code>.</li>
	 * <li>Similarly stretch <code> ld.end </code></li>
	 * </ul>
	 * 
	 * </ul>
	 */
	public static Vector getLeavesDominated(PTBTreeNode root, Span span,
			boolean stretch) {
		log.finer("Entering getLeavesDominated: " + span.toString() + " "
				+ stretch);

		Vector result = new Vector();
		Vector v = computePossibleLeaves(root, span);
		for (Enumeration l = v.elements(); l.hasMoreElements();) {

			PossibleLeaves pl = (PossibleLeaves) (l.nextElement());
			LeavesDominated ld = new LeavesDominated(pl.rightmostStart,
					pl.leftmostEnd);
			HashSet barrierSet = new HashSet();

			if (stretch) {
				computeBarrierState(root, barrierSet, ld);

				// Stretch left
				if (!isLeafCC(root, ld.start)) {
					while (ld.start > pl.leftmostStart) {
						ld.start--;
						if (!checkBarrierState(root, barrierSet, ld)) {
							ld.start++;
							pl.leftmostStart = ld.start;
						}
					}
				}

				// Stretch right
				while (ld.end < pl.rightmostEnd) {
					ld.end++;
					if (!checkBarrierState(root, barrierSet, ld)) {
						ld.end--;
						pl.rightmostEnd = ld.end;
					}
				}

			}

			result.add(ld);
		}

		log.finer("Leaving getLeavesDominated: " + span.toString() + " "
				+ stretch);

		return result;
	}

	public static void addNodesContained(PTBTreeNode node, LeavesDominated ld,
			HashSet nodeSet) {
		LeavesDominated ld1 = (LeavesDominated) (getUserData(node,
				LeavesDominatedKey));

		if (ld.start <= ld1.start && ld.end >= ld1.end) {
			nodeSet.add(node);
			return;
		}

		for (Enumeration children = node.children(); children.hasMoreElements();) {
			PTBTreeNode child = (PTBTreeNode) (children.nextElement());
			addNodesContained(child, ld, nodeSet);
		}

	}

	public static void printLeavesDominated(PTBTreeNode node, LeavesDominated ld) {
		LeavesDominated ld1 = (LeavesDominated) (getUserData(node,
				LeavesDominatedKey));

		if (node.isLeaf() && ld.start <= ld1.start && ld.end >= ld1.end) {
			System.err.print(node.getLabel().getRaw() + " ");
			return;
		}

		for (Enumeration children = node.children(); children.hasMoreElements();) {
			PTBTreeNode child = (PTBTreeNode) (children.nextElement());
			printLeavesDominated(child, ld);
		}

	}

	/**
	 * Computes the gorn address for the span list. Starts by computing the
	 * leaves dominated, and then selects the highest nodes in the tree which
	 * dominate exactly those leaves. The label of the nodes in the
	 * <code> root </code> argument should be of type
	 * <code> edu.upenn.cis.ptb.standoff.SPTBLabel </code>.
	 */
	public static GornAddressList getGornAddressList(PTBTreeNode root,
			SpanList splist, boolean stretch) {
		log.finer("Entering getGornAddressList: " + splist.toString() + " "
				+ stretch);

		GornAddressList gal = new GornAddressList();

		if (root.getUserObject() == null) {
			computeLeavesDominated(root, 0);
		}

		for (Iterator iter = splist.iterator(); iter.hasNext();) {
			Span span = (Span) iter.next();
			Vector ldVect = getLeavesDominated(root, span, stretch);
			for (Enumeration e = ldVect.elements(); e.hasMoreElements();) {
				LeavesDominated ld = (LeavesDominated) e.nextElement();
				HashSet nodeSet = new HashSet();
				addNodesContained(root, ld, nodeSet);
				for (Iterator nodesIter = nodeSet.iterator(); nodesIter
						.hasNext();) {
					PTBTreeNode node = (PTBTreeNode) nodesIter.next();
					gal.add(GornAddressUtils.getGornAddress(node));
				}
			}
		}

		if (fixGA(gal, root)) {
			log
					.fine("[Warning] Gorn address needed fixing. Perhaps the spanList is unnecessarily split: "
							+ splist.toString());
		}

		log.finer("Leaving getGornAddressList: " + splist.toString() + " "
				+ stretch + "\n " + gal.toString());

		if (log.isLoggable(Level.FINEST)) {
			try {
				StringWriter writer = new StringWriter();
				for (Enumeration e = GornAddressUtils.getNodes(gal, root); e
						.hasMoreElements();) {
					PTBTreeNode node = (PTBTreeNode) (e.nextElement());
					node.save(writer);
					writer.write("\n\n");
				}
				writer.flush();
				log.finest(writer.toString());
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

		return gal;

	}

	public static void computeGA(PDTBSup sup, PTBTreeNode root) {
		if (sup == null) {
			return;
		}

		PDTBSelection sel = sup.getSelection();
		SpanList splist = sel.getSpans();
		GornAddressList gal = getGornAddressList(root, splist, true);
		sel = new PDTBSelectionImpl(splist, gal, sel.getRawText(),
				GornAddressUtils.getNodes(gal, root));
		sup.setSelection(sel);
	}

	public static void computeGA(PDTBRelationList relList, PTBTreeNode root,
			Writer writer) throws IOException {
		String rawStr = relList.getRawText();
		int relNumber = 0;

		for (Enumeration e = relList.children(); e.hasMoreElements();) {
			Object o = e.nextElement();
			if (o instanceof PDTBRelationImpl) {
				PDTBRelationImpl rel = (PDTBRelationImpl) o;
				if (rel instanceof PDTBExplicitRelation) {
					PDTBExplicitRelationImpl expRel = (PDTBExplicitRelationImpl) (rel);
					PDTBSelection sel = expRel.getSelection();
					SpanList splist = sel.getSpans();
					GornAddressList gal = getGornAddressList(root, splist,
							false);
					sel = new PDTBSelectionImpl(splist, gal, sel.getRawText(),
							GornAddressUtils.getNodes(gal, root));
					expRel.setSelection(sel);

				} else if (rel instanceof PDTBAltLexRelation) {
					PDTBAltLexRelationImpl expRel = (PDTBAltLexRelationImpl) (rel);
					PDTBSelection sel = expRel.getSelection();
					SpanList splist = sel.getSpans();
					GornAddressList gal = getGornAddressList(root, splist,
							false);
					sel = new PDTBSelectionImpl(splist, gal, sel.getRawText(),
							GornAddressUtils.getNodes(gal, root));
					expRel.setSelection(sel);

				}

				computeGA(rel.getArg1(), root);
				computeGA(rel.getArg2(), root);
				computeGA(rel.getSup1(), root);
				computeGA(rel.getSup2(), root);

				if (rel instanceof PDTBImplicitRelation) {
					PDTBImplicitRelationImpl impRel = (PDTBImplicitRelationImpl) rel;
					try {
						int[] arg2Add = (int[]) impRel.getArg2().getSelection()
								.getAddresses().first();
						int sentenceNo = arg2Add[0];
						PTBTreeNode sentence = (PTBTreeNode) root
								.getChildAt(sentenceNo);
						// int offset = ((SPTBLabel) sentence.getLabel())
						// .getSpan().getStart();
						int offset = ((Span) impRel.getArg2().getSelection()
								.getSpans().first()).getStart();
						PDTBInferenceSite infSite = new PDTBInferenceSiteImpl(
								offset, sentenceNo, sentence);
						impRel.setInferenceSite(infSite);
					} catch (Exception exn) {
						log
								.fine("[Error] Implicit relation doesn't have a valid Arg2? Sec: "
										+ relList.getSecNo()
										+ " File: "
										+ relList.getFileNo()
										+ " RelationNo: "
										+ relNumber);
					}

				}

			} else {
				PDTBEntityRelationImpl entRel = (PDTBEntityRelationImpl) o;

				PDTBSup arg1 = entRel.getArg1();
				PDTBSup arg2 = entRel.getArg2();
				computeGA(arg1, root);
				computeGA(arg2, root);

				try {
					int[] arg2Add = (int[]) entRel.getArg2().getSelection()
							.getAddresses().first();
					int sentenceNo = arg2Add[0];
					PTBTreeNode sentence = (PTBTreeNode) root
							.getChildAt(sentenceNo);
					// int offset = ((SPTBLabel) sentence.getLabel()).getSpan()
					// .getStart();
					int offset = ((Span) entRel.getArg2().getSelection()
							.getSpans().first()).getStart();
					PDTBInferenceSite infSite = new PDTBInferenceSiteImpl(
							offset, sentenceNo, sentence);
					entRel.setInferenceSite(infSite);
				} catch (Exception exn) {
					log
							.fine("[Error] Implicit relation doesn't have a valid Arg2? Sec: "
									+ relList.getSecNo()
									+ " File: "
									+ relList.getFileNo()
									+ " RelationNo: "
									+ relNumber);
				}

			}
			SiblingInclusion.includeSiblings((PDTBNode)o, root);
			SpanStretchAttribution.computeGA((PDTBNode)o, root, true);
			relNumber++;
		}
		((PDTBRelationListImpl) relList).save(writer);
	}
	
	private static final PTBLoader loader = new SPTBLoaderImpl();
	
	public static void computeGA(String rawRoot, String ptbRoot,
			String pdtbRoot, String outputRoot, String sptbRoot, ProgressBar progressBar) throws IOException {

		File outputDir = new File(outputRoot);
		outputDir.mkdirs();

		for (PDTBTask task = new PDTBTask(rawRoot, ptbRoot, pdtbRoot); task.hasNext();) {			
			
			PDTBRelationList relList = task.next();
			String secNo = task.getSecNoStr();
			String fileNo = task.getFileNoStr();
			System.out.println(task.getSecNoStr() + task.getFileNoStr());
			PTBTreeNode root =loader.load(sptbRoot, secNo, fileNo); 
				//relList.getPTBRoot();

			if (root != null) {
				File outputSec = new File(outputDir, secNo);
				outputSec.mkdirs();
				File outFile = new File(outputSec, "wsj_" + secNo + fileNo
						+ ".pdtb");
				Writer writer = new BufferedWriter(new FileWriter(outFile));
				computeGA(relList, root, writer);
				writer.flush();
				writer.close();
				if(progressBar!=null){
					progressBar.increment();
				}
			}

		}
	}
	
}
