package scripts;

import gui.ProgressBar;

import java.io.File;
import java.io.IOException;

import SpanToGAL.SpanStretch;

public class AnnToPdtb {

	public static void run(String rawRoot, String ptbRoot, String sptbRoot,
			String convFinal, String annRoot, String tempDir,
			String connHeadFile, ProgressBar progressBar) throws IOException {

		Settings.rawRoot = rawRoot;
		Settings.ptbRoot = ptbRoot;
		Settings.sptbRoot = sptbRoot;
		Settings.convFinal = convFinal;
		Settings.annRoot = annRoot;
		Settings.tempDir = tempDir;
		Settings.connHeadFile = connHeadFile;

		// Settings.newPdtbRoot += "False";
		System.out.println("RawRoot: " + Settings.rawRoot);
		System.out.println("PtbRoot: " + Settings.ptbRoot);
		System.out.println("SptbRoot: " + Settings.sptbRoot);
		System.out.println("newPdtbRoot: " + Settings.convFinal);
		System.out.println("AnnRoot: " + Settings.annRoot);
		System.out.println("TempDir: " + Settings.tempDir);
		System.out.println("ConnHeadFile: " + Settings.connHeadFile);

		FileExceptions.exceptionIfFolderContains(Settings.convFinal);
		FileExceptions.exceptionIfNoFolder(Settings.annRoot);

		String tempDirs = "convP";

		AnnToPdtbNoGals.run(Settings.rawRoot, Settings.sptbRoot,
				Settings.annRoot, Settings.tempDir + File.separator + tempDirs
						+ "1", Settings.connHeadFile, progressBar);

		SpanStretch.computeGA(Settings.rawRoot, Settings.ptbRoot,
				Settings.tempDir + File.separator + tempDirs + "1",
				Settings.tempDir + File.separator + tempDirs + "2",
				Settings.sptbRoot, progressBar);

		AddText.run(Settings.rawRoot, Settings.ptbRoot, Settings.tempDir
				+ File.separator + tempDirs + "2", Settings.convFinal,
				progressBar);
	}

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		System.out
				.println("Usage: scripts.AnnToPdtb rawRoot ptbRoot sptbRoot newPdtbRoot annRoot tempDir connHeadFile");
		if (args.length == 7) {
			run(args[0], args[1], args[2], args[3], args[4], args[5], args[6],
					null);
		} else {
			System.err.println("Invalid Arguments");
			System.exit(0);
		}

	}

}

// FixGornAddresses.main(new String[] { Settings.rawRoot,
// Settings.ptbRoot, Settings.tempDir + "2", Settings.tempDir + "1" });