package scripts;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.upenn.cis.pdtb.PDTBExplicitRelation;
import edu.upenn.cis.pdtb.PDTBRelationList;
import edu.upenn.cis.pdtb.util.PDTBTask;

public class ConnHeads {

	public static void main(String[] args) throws IOException {
		System.out
				.println("Usage: ConnHeads rawRoot ptbRoot pdtbRoot connHeadFile");
		if (args.length == 4) {
			Settings.rawRoot = args[0];
			Settings.ptbRoot = args[1];
			Settings.pdtbRoot = args[2];
			Settings.connHeadFile = args[3];
		}
		System.out.println("RawRoot: " + Settings.rawRoot);
		System.out.println("PtbRoot: " + Settings.ptbRoot);
		System.out.println("PdtbRoot: " + Settings.pdtbRoot);
		System.out.println("ConnHeadFile: " + Settings.connHeadFile);

		Set<String> connHeads = new HashSet<String>();
		for (PDTBTask task = new PDTBTask(Settings.rawRoot, Settings.ptbRoot,
				Settings.pdtbRoot); task.hasNext();) {
			PDTBRelationList rellist = task.next();
			for (Enumeration children = rellist.children(); children
					.hasMoreElements();) {
				Object o = children.nextElement();
				if (o instanceof PDTBExplicitRelation) {
					PDTBExplicitRelation rel = (PDTBExplicitRelation) o;
					connHeads.add(rel.getFeatures().getConnHead().toLowerCase());
				}
			}
		}

		List<String> l = new ArrayList<String>();
		l.addAll(connHeads);
		Collections.sort(l, new connCompare());

		BufferedWriter writer = new BufferedWriter(new FileWriter(
				Settings.connHeadFile));
		for (String connHead : l) {
			writer.write(connHead + "\n");
		}
		writer.close();

	}

}

class connCompare implements Comparator<String> {

	public int compare(String o1, String o2) {
		return o2.length() - o1.length();
	}

}
