package scripts;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.Enumeration;

import edu.upenn.cis.pdtb.PDTBAltLexRelationImpl;
import edu.upenn.cis.pdtb.PDTBArgFeaturesImpl;
import edu.upenn.cis.pdtb.PDTBEntityRelationImpl;
import edu.upenn.cis.pdtb.PDTBExplicitRelationImpl;
import edu.upenn.cis.pdtb.PDTBImplicitRelationImpl;
import edu.upenn.cis.pdtb.PDTBInferenceSiteImpl;
import edu.upenn.cis.pdtb.PDTBNoRelationImpl;
import edu.upenn.cis.pdtb.PDTBNode;
import edu.upenn.cis.pdtb.PDTBRelationImpl;
import edu.upenn.cis.pdtb.PDTBRelationListImpl;
import edu.upenn.cis.pdtb.PDTBSelectionImpl;
import edu.upenn.cis.pdtb.PDTBSupImpl;
import edu.upenn.cis.pdtb.util.PDTBTask;
import gui.ProgressBar;

public class AddText {

	public static void run(String rawRoot, String ptbRoot, String inRoot,
			String outRoot, ProgressBar progressBar) {
		System.out.println("RawRoot: " + rawRoot);
		System.out.println("PtbRoot: " + ptbRoot);
		System.out.println("InRoot: " + inRoot);
		System.out.println("OutRoot: " + outRoot);

		File outputDir = new File(outRoot);
		outputDir.mkdirs();
		for (PDTBTask task = new PDTBTask(rawRoot, ptbRoot, inRoot); task
				.hasNext();) {
			try {
				PDTBRelationListImpl relList = (PDTBRelationListImpl) task
						.next();
				String secNo = task.getSecNoStr();
				String fileNo = task.getFileNoStr();
				System.out.println(task.getSecNoStr() + task.getFileNoStr());
				File outputSec = new File(outputDir, secNo);
				outputSec.mkdirs();

				File outFile = new File(outputSec, "wsj_" + secNo + fileNo
						+ ".pdtb");
				Writer writer = new BufferedWriter(new FileWriter(outFile));

				for (Enumeration e = relList.children(); e.hasMoreElements();) {
					PDTBNode node = (PDTBNode) e.nextElement();
					writer
							.write("________________________________________________________\n");
					if (node instanceof PDTBRelationImpl) {
						if (node instanceof PDTBExplicitRelationImpl) {
							writer.write("____Explicit____\n");
							PDTBExplicitRelationImpl rel = (PDTBExplicitRelationImpl) node;
							((PDTBSelectionImpl) rel.getSelection())
									.save(writer);
							writer.write("#### Text ####\n");
							writer
									.write(rel.getSelection().getRawText()
											+ "\n");
							writer.write("##############\n");

							writer.write("#### Features ####\n");
							writer.write(rel.getFeatures().getSource() + ", ");
							writer.write(rel.getFeatures().getType() + ", ");
							writer
									.write(rel.getFeatures().getPolarity()
											+ ", ");
							writer.write(rel.getFeatures().getDeterminancy()
									+ "\n");
							if (rel.getFeatures().getSelection() != null) {
								((PDTBSelectionImpl) rel.getFeatures()
										.getSelection()).save(writer);
								writer.write("#### Text ####\n");
								writer.write(rel.getFeatures().getSelection()
										.getRawText()
										+ "\n");
								writer.write("##############\n");
							}
							writer.write(rel.getFeatures().getConnHead());
							if (rel.getFeatures().getSClassA() != null) {
								writer.write(", "
										+ rel.getFeatures().getSClassA()
												.getValue());
								if (rel.getFeatures().getSClassB() != null) {
									writer.write(", "
											+ rel.getFeatures().getSClassB()
													.getValue());
								}
							}
							writer.write('\n');

						} else if (node instanceof PDTBImplicitRelationImpl) {
							writer.write("____Implicit____\n");
							PDTBImplicitRelationImpl rel = (PDTBImplicitRelationImpl) node;
							((PDTBInferenceSiteImpl) rel.getInferenceSite())
									.save(writer);

							writer.write("#### Features ####\n");
							writer.write(rel.getFeatures().getSource() + ", ");
							writer.write(rel.getFeatures().getType() + ", ");
							writer
									.write(rel.getFeatures().getPolarity()
											+ ", ");
							writer.write(rel.getFeatures().getDeterminancy()
									+ "\n");
							if (rel.getFeatures().getSelection() != null) {
								((PDTBSelectionImpl) rel.getFeatures()
										.getSelection()).save(writer);
								writer.write("#### Text ####\n");
								writer.write(rel.getFeatures().getSelection()
										.getRawText()
										+ "\n");
								writer.write("##############\n");
							}

							writer.write(rel.getFeatures().getConn1());
							if (rel.getFeatures().getSClass1A() != null) {
								writer.write(", "
										+ rel.getFeatures().getSClass1A()
												.getValue());
								if (rel.getFeatures().getSClass1B() != null) {
									writer.write(", "
											+ rel.getFeatures().getSClass1B()
													.getValue());
								}
							}
							writer.write('\n');

							if (rel.getFeatures().getConn2() != null) {
								writer.write(rel.getFeatures().getConn2());
								if (rel.getFeatures().getSClass2A() != null) {
									writer.write(", "
											+ rel.getFeatures().getSClass2A()
													.getValue());
									if (rel.getFeatures().getSClass2B() != null) {
										writer.write(", "
												+ rel.getFeatures()
														.getSClass2B()
														.getValue());
									}
								}
								writer.write('\n');
							}

						} else if (node instanceof PDTBAltLexRelationImpl) {
							writer.write("____AltLex____\n");
							PDTBAltLexRelationImpl rel = (PDTBAltLexRelationImpl) node;
							((PDTBSelectionImpl) rel.getSelection())
									.save(writer);
							writer.write("#### Text ####\n");
							writer
									.write(rel.getSelection().getRawText()
											+ "\n");
							writer.write("##############\n");

							writer.write("#### Features ####\n");
							writer.write(rel.getFeatures().getSource() + ", ");
							writer.write(rel.getFeatures().getType() + ", ");
							writer
									.write(rel.getFeatures().getPolarity()
											+ ", ");
							writer.write(rel.getFeatures().getDeterminancy()
									+ "\n");
							if (rel.getFeatures().getSelection() != null) {
								((PDTBSelectionImpl) rel.getFeatures()
										.getSelection()).save(writer);
								writer.write("#### Text ####\n");
								writer.write(rel.getFeatures().getSelection()
										.getRawText()
										+ "\n");
								writer.write("##############\n");
							}
							if (rel.getFeatures().getSClassA() != null) {
								writer.write(rel.getFeatures().getSClassA()
										.getValue());
								if (rel.getFeatures().getSClassB() != null) {
									writer.write(", "
											+ rel.getFeatures().getSClassB()
													.getValue());
								}
							}
							writer.write('\n');

						} else {
							System.err.println("Error:  Not a relation.");
						}
						PDTBRelationImpl relation = (PDTBRelationImpl) node;

						if (relation.getSup1() != null) {
							writer.write("____Sup1____\n");
							((PDTBSupImpl) relation.getSup1()).save(writer);
							writer.write("#### Text ####\n");
							writer.write(relation.getSup1().getSelection()
									.getRawText()
									+ "\n");
							writer.write("##############\n");
						}
						writer.write("____Arg1____\n");
						((PDTBSelectionImpl) relation.getArg1().getSelection())
								.save(writer);
						writer.write("#### Text ####\n");
						writer.write(relation.getArg1().getSelection()
								.getRawText()
								+ "\n");
						writer.write("##############\n");
						writer.write("#### Features ####\n");
						((PDTBArgFeaturesImpl) relation.getArg1().getFeatures())
								.save(writer);
						if (relation.getArg1().getFeatures().getSelection() != null) {
							writer.write("#### Text ####\n");
							writer.write(relation.getArg1().getFeatures()
									.getSelection().getRawText()
									+ "\n");
							writer.write("##############\n");
						}

						writer.write("____Arg2____\n");
						((PDTBSelectionImpl) relation.getArg2().getSelection())
								.save(writer);
						writer.write("#### Text ####\n");
						writer.write(relation.getArg2().getSelection()
								.getRawText()
								+ "\n");
						writer.write("##############\n");
						writer.write("#### Features ####\n");
						((PDTBArgFeaturesImpl) relation.getArg2().getFeatures())
								.save(writer);
						if (relation.getArg2().getFeatures().getSelection() != null) {
							writer.write("#### Text ####\n");
							writer.write(relation.getArg2().getFeatures()
									.getSelection().getRawText()
									+ "\n");
							writer.write("##############\n");
						}

						if (relation.getSup2() != null) {
							writer.write("____Sup2____\n");
							((PDTBSupImpl) relation.getSup2()).save(writer);
							writer.write("#### Text ####\n");
							writer.write(relation.getSup2().getSelection()
									.getRawText()
									+ "\n");
							writer.write("##############\n");
						}

					} else {
						if (node instanceof PDTBNoRelationImpl) {
							writer.write("____NoRel____\n");
						} else if (node instanceof PDTBEntityRelationImpl) {
							writer.write("____EntRel____\n");
						} else {
							System.err.println("Error:  Not a relation.");
						}

						PDTBEntityRelationImpl relation = (PDTBEntityRelationImpl) node;
						((PDTBInferenceSiteImpl) relation.getInferenceSite())
								.save(writer);

						writer.write("____Arg1____\n");
						((PDTBSelectionImpl) relation.getArg1().getSelection())
								.save(writer);
						writer.write("#### Text ####\n");
						writer.write(relation.getArg1().getSelection()
								.getRawText()
								+ "\n");
						writer.write("##############\n");

						writer.write("____Arg2____\n");
						((PDTBSelectionImpl) relation.getArg2().getSelection())
								.save(writer);
						writer.write("#### Text ####\n");
						writer.write(relation.getArg2().getSelection()
								.getRawText()
								+ "\n");
						writer.write("##############\n");

					}
					writer
							.write("________________________________________________________\n");
				}
				writer.flush();
				writer.close();
				if (progressBar != null) {
					progressBar.increment();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String args[]) {
		System.out.println("Usage: AddText rawRoot ptbRoot inRoot outRoot");
		if (args.length == 4) {
			run(args[0], args[1], args[2], args[3], null);
		} else {
			System.err.println("Invalid Arguments");
			System.exit(0);
		}
	}

}
