package scripts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import edu.upenn.cis.anntool.settings.Constants.LABELS;
import edu.upenn.cis.anntool.settings.Constants.RELTYPELABELS;
import edu.upenn.cis.pdtb.util.Span;
import edu.upenn.cis.pdtb.util.SpanList;
import edu.upenn.cis.ptb.PTBLoader;
import edu.upenn.cis.ptb.PTBTreeNode;
import edu.upenn.cis.ptb.standoff.SPTBLoaderImpl;
import gui.ProgressBar;

public class AnnToPdtbNoGals {

	private static final PTBLoader loader = new SPTBLoaderImpl();
	private static final List<String> connHeads = new ArrayList<String>();

	public static void run(String rawRoot, String sptbRoot, String annRoot,
			String outRoot, String connHeadFile, ProgressBar progressBar)
			throws IOException {
		System.out.println("RawRoot: " + rawRoot);
		System.out.println("SptbRoot: " + sptbRoot);
		System.out.println("AnnRoot: " + annRoot);
		System.out.println("OutRoot: " + outRoot);
		System.out.println("ConnHeadFile: " + connHeadFile);

		BufferedReader connHeadReader = new BufferedReader(new FileReader(
				connHeadFile));
		String tempString;
		while ((tempString = connHeadReader.readLine()) != null) {
			connHeads.add(tempString);
		}

		File newPdtbRoot = new File(outRoot);
		newPdtbRoot.mkdirs();

		File annDir = new File(annRoot);
		for (File f : annDir.listFiles()) {
			File newPdtbSec = new File(newPdtbRoot, f.getName());
			newPdtbSec.mkdir();
			if (f.isDirectory()) {
				for (File g : f.listFiles()) {

					File rawTextFile = new File(new File(rawRoot, f.getName()),
							g.getName());
					File ptbFile = new File(new File(sptbRoot, f.getName()), g
							.getName()
							+ ".mrg");
					if (rawTextFile.exists() && ptbFile.exists()) {

						File newPdtbFile = new File(newPdtbSec, g.getName()
								+ ".pdtb");
						newPdtbFile.createNewFile();

						// rawtext
						BufferedReader rawTextReader = new BufferedReader(
								new FileReader(rawTextFile));
						char[] b = new char[1024];
						String rawText = "";
						while (rawTextReader.read(b) != -1) {
							rawText += new String(b);
						}
						rawTextReader.close();

						// ptb
						System.out.println(f.getName()
								+ g.getName().substring(6));
						PTBTreeNode ptbRoot = loader.load(sptbRoot,
								f.getName(), g.getName().substring(6));

						BufferedReader reader = new BufferedReader(
								new FileReader(g));
						PDTBWriter writer = new PDTBWriter(new BufferedWriter(
								new FileWriter(newPdtbFile)));

						String line;
						while ((line = reader.readLine()) != null) {
							String[] parts = line.split(Pattern.quote("|"),
									LABELS.values().length);
							if (isComplete(parts)) {
								relation(writer, parts, rawText, ptbRoot);
							} else {
								System.err
										.println("Incomplete Relation in file: "
												+ f.getName()
												+ File.separator
												+ g.getName());
							}
						}
						writer.close();
						reader.close();
					}
					if (!rawTextFile.exists()) {
						System.err
								.println("Warning: there is no rawtext file corresponding with the ann file: "
										+ g.getAbsolutePath());
					}
					if (!ptbFile.exists()) {
						System.err
								.println("Warning: there is no sptb file corresponding with the ann file: "
										+ g.getAbsolutePath());
					}
					if (progressBar != null) {
						progressBar.increment();
					}
				}
			}
		}
	}

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		System.out
				.println("Usage: AnnToPdtbNoSpans rawRoot sptbRoot annRoot outRoot connHeadFile");
		if (args.length == 5) {
			run(args[0], args[1], args[2], args[3], args[4], null);
		} else {
			System.err.println("Invalid Arguments");
			System.exit(0);
		}

	}

	private static void relation(PDTBWriter writer, String[] parts,
			String rawText, PTBTreeNode ptbRoot) throws IOException {
		writer
				.writeln("________________________________________________________");
		RELTYPELABELS rel = RELTYPELABELS.valueOf(parts[LABELS.rel.ordinal()]);
		switch (rel) {
		case Explicit:
			explicit(writer, parts, rawText, ptbRoot);
			break;
		case Implicit:
			implicit(writer, parts, rawText, ptbRoot);
			break;
		case AltLex:
			altlex(writer, parts, rawText, ptbRoot);
			break;
		case EntRel:
			entrel(writer, parts, rawText, ptbRoot);
			break;
		case NoRel:
			norel(writer, parts, rawText, ptbRoot);
			break;
		}
		writer
				.writeln("________________________________________________________");
	}

	private static void explicit(PDTBWriter writer, String[] parts,
			String rawText, PTBTreeNode ptbRoot) throws IOException {
		parts[LABELS.conn1.ordinal()] = connhead(
				parts[LABELS.connSpanList.ordinal()], rawText).toLowerCase();
		selection(writer, parts[LABELS.connSpanList.ordinal()], rawText,
				"____Explicit____", ptbRoot);
		connFeats(writer, parts, rawText, ptbRoot);
		writer.write(parts[LABELS.conn1.ordinal()] + ", "
				+ parts[LABELS.sClass1A.ordinal()]);
		if (!parts[LABELS.sClass1B.ordinal()].equals("")) {
			writer.write(", " + parts[LABELS.sClass1B.ordinal()]);
		}
		writer.writeln();
		argssups(writer, parts, rawText, ptbRoot);
	}

	private static void implicit(PDTBWriter writer, String[] parts,
			String rawText, PTBTreeNode ptbRoot) throws IOException {
		selection(writer, parts, "____Implicit____", ptbRoot);
		connFeats(writer, parts, rawText, ptbRoot);
		writer.write(parts[LABELS.conn1.ordinal()] + ", "
				+ parts[LABELS.sClass1A.ordinal()]);
		if (!parts[LABELS.sClass1B.ordinal()].equals("")) {
			writer.write(", " + parts[LABELS.sClass1B.ordinal()]);
		}
		writer.writeln();
		if (!parts[LABELS.conn2.ordinal()].equals("")) {
			writer.write(parts[LABELS.conn2.ordinal()] + ", "
					+ parts[LABELS.sClass2A.ordinal()]);
			if (!parts[LABELS.sClass2B.ordinal()].equals("")) {
				writer.write(", " + parts[LABELS.sClass2B.ordinal()]);
			}
			writer.writeln();
		}
		argssups(writer, parts, rawText, ptbRoot);
	}

	private static void altlex(PDTBWriter writer, String[] parts,
			String rawText, PTBTreeNode ptbRoot) throws IOException {
		selection(writer, parts[LABELS.connSpanList.ordinal()], rawText,
				"____AltLex____", ptbRoot);
		connFeats(writer, parts, rawText, ptbRoot);
		writer.write(parts[LABELS.sClass1A.ordinal()]);
		if (!parts[LABELS.sClass1B.ordinal()].equals("")) {
			writer.write(", " + parts[LABELS.sClass1B.ordinal()]);
		}
		writer.writeln();
		argssups(writer, parts, rawText, ptbRoot);
	}

	private static void entrel(PDTBWriter writer, String[] parts,
			String rawText, PTBTreeNode ptbRoot) throws IOException {
		selection(writer, parts, "____EntRel____", ptbRoot);
		selection(writer, parts[LABELS.arg1SpanList.ordinal()], rawText,
				"____Arg1____", ptbRoot);
		selection(writer, parts[LABELS.arg2SpanList.ordinal()], rawText,
				"____Arg2____", ptbRoot);

	}

	private static void norel(PDTBWriter writer, String[] parts,
			String rawText, PTBTreeNode ptbRoot) throws IOException {
		selection(writer, parts, "____NoRel____", ptbRoot);
		selection(writer, parts[LABELS.arg1SpanList.ordinal()], rawText,
				"____Arg1____", ptbRoot);
		selection(writer, parts[LABELS.arg2SpanList.ordinal()], rawText,
				"____Arg2____", ptbRoot);
	}

	private static void features(PDTBWriter writer, String src, String type,
			String pol, String det, String spanlist, String rawText,
			PTBTreeNode ptbRoot) throws IOException {
		writer.writeln("#### Features ####");
		writer.writeln(src + ", " + type + ", " + pol + ", " + det);
		selection(writer, spanlist, ptbRoot);
		rawText(writer, spanlist, rawText);
	}

	private static void selection(PDTBWriter writer, String spanlist,
			String rawText, String title, PTBTreeNode ptbRoot)
			throws IOException {
		if (!spanlist.equals("")) {
			writer.writeln(title);
			selection(writer, spanlist, ptbRoot);
			rawText(writer, spanlist, rawText);
		}
	}

	private static void rawText(PDTBWriter writer, String spanlist,
			String rawText) throws IOException {
		if (!spanlist.equals("")) {
			writer.writeln("#### Text ####");
			writer.writeln(textFromSpanList(spanlist, rawText));
			writer.writeln("##############");
		}
	}

	private static void selection(PDTBWriter writer, String[] parts,
			String title, PTBTreeNode ptbRoot) throws IOException {
		SpanList spanList = new SpanList(parts[LABELS.arg2SpanList.ordinal()]);
		String spanlist = String.valueOf(((Span) spanList.first()).getStart());
		if (!spanlist.equals("")) {
			writer.writeln(title);
			selection(writer, spanlist, ptbRoot);
		}
	}

	private static void selection(PDTBWriter writer, String spanlist,
			PTBTreeNode ptbRoot) throws IOException {
		if (!spanlist.equals("")) {
			writer.writeln(spanlist);
			writer.writeln("0");
		}
	}

	private static String connhead(String spanlist, String rawText) {
		String wholeConn = textFromSpanList(spanlist, rawText).toLowerCase();
		for (String conn : connHeads) {
			if (wholeConn.endsWith(conn)) {
				return conn;
			}
		}
		for (String conn : connHeads) {
			if (wholeConn.contains(conn)) {
				return conn;
			}
		}
		return wholeConn;
	}

	private static String textFromSpanList(String spanlist, String rawText) {
		String ret = "";
		SpanList spanList = new SpanList(spanlist);
		for (Iterator<Span> i = spanList.iterator(); i.hasNext();) {
			Span span = i.next();
			ret += rawText.substring(span.getStart(), span.getEnd());
			if (i.hasNext()) {
				ret += " ";
			}
		}
		return ret;
	}

	private static void connFeats(PDTBWriter writer, String[] parts,
			String rawText, PTBTreeNode ptbRoot) throws IOException {
		features(writer, parts[LABELS.connAttrSrc.ordinal()],
				parts[LABELS.connAttrType.ordinal()], parts[LABELS.connAttrPol
						.ordinal()], parts[LABELS.connAttrDet.ordinal()],
				parts[LABELS.connAttrSpanList.ordinal()], rawText, ptbRoot);
	}

	private static void argssups(PDTBWriter writer, String[] parts,
			String rawText, PTBTreeNode ptbRoot) throws IOException {
		selection(writer, parts[LABELS.sup1SpanList.ordinal()], rawText,
				"____Sup1____", ptbRoot);
		selection(writer, parts[LABELS.arg1SpanList.ordinal()], rawText,
				"____Arg1____", ptbRoot);
		features(writer, parts[LABELS.arg1AttrSrc.ordinal()],
				parts[LABELS.arg1AttrType.ordinal()], parts[LABELS.arg1AttrPol
						.ordinal()], parts[LABELS.arg1AttrDet.ordinal()],
				parts[LABELS.arg1AttrSpanList.ordinal()], rawText, ptbRoot);
		selection(writer, parts[LABELS.arg2SpanList.ordinal()], rawText,
				"____Arg2____", ptbRoot);
		features(writer, parts[LABELS.arg2AttrSrc.ordinal()],
				parts[LABELS.arg2AttrType.ordinal()], parts[LABELS.arg2AttrPol
						.ordinal()], parts[LABELS.arg2AttrDet.ordinal()],
				parts[LABELS.arg2AttrSpanList.ordinal()], rawText, ptbRoot);
		selection(writer, parts[LABELS.sup2SpanList.ordinal()], rawText,
				"____Sup2____", ptbRoot);
	}

	public static boolean isComplete(String[] parts) {
		boolean isComplete = true;
		String relType = parts[LABELS.rel.ordinal()];
		RELTYPELABELS relTypeLabel;
		try {
			relTypeLabel = RELTYPELABELS.valueOf(relType);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		switch (relTypeLabel) {
		case Explicit:
		case AltLex:
			isComplete &= !parts[LABELS.connSpanList.ordinal()].equals("");
			isComplete &= !parts[LABELS.connAttrSrc.ordinal()].equals("");
			isComplete &= !parts[LABELS.connAttrType.ordinal()].equals("");
			isComplete &= !parts[LABELS.connAttrPol.ordinal()].equals("");
			isComplete &= !parts[LABELS.connAttrDet.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1SpanList.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1AttrSrc.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1AttrType.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1AttrPol.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1AttrDet.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2SpanList.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2AttrSrc.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2AttrType.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2AttrPol.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2AttrDet.ordinal()].equals("");
			isComplete &= !parts[LABELS.sClass1A.ordinal()].equals("");
			break;
		case Implicit:
			isComplete &= !parts[LABELS.connAttrSrc.ordinal()].equals("");
			isComplete &= !parts[LABELS.connAttrType.ordinal()].equals("");
			isComplete &= !parts[LABELS.connAttrPol.ordinal()].equals("");
			isComplete &= !parts[LABELS.connAttrDet.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1SpanList.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1AttrSrc.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1AttrType.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1AttrPol.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg1AttrDet.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2SpanList.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2AttrSrc.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2AttrType.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2AttrPol.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2AttrDet.ordinal()].equals("");
			isComplete &= !parts[LABELS.conn1.ordinal()].equals("");
			isComplete &= !parts[LABELS.sClass1A.ordinal()].equals("");
			if (!parts[LABELS.conn2.ordinal()].equals("")) {
				isComplete &= !parts[LABELS.sClass2A.ordinal()].equals("");
			}
			break;
		case EntRel:
		case NoRel:
			isComplete &= !parts[LABELS.arg1SpanList.ordinal()].equals("");
			isComplete &= !parts[LABELS.arg2SpanList.ordinal()].equals("");
			break;
		}
		return isComplete;
	}

}
