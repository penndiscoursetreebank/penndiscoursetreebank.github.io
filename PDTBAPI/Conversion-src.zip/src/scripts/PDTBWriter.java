package scripts;
import java.io.BufferedWriter;
import java.io.IOException;

public class PDTBWriter {

	private BufferedWriter writer;

	public PDTBWriter(BufferedWriter writer) {
		this.writer = writer;
	}

	public void write(String s) throws IOException {
		writer.write(s);
	}

	public void writeln() throws IOException {
		writer.write("\n");
	}

	public void writeln(String s) throws IOException {
		writer.write(s + "\n");
	}

	public void close() throws IOException {
		writer.close();
	}

}
