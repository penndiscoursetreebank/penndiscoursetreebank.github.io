package scripts;

import java.io.File;
import java.io.IOException;

public class FolderExistsException extends IOException {
	public FolderExistsException(File folder) {
		super(
				"The directory: "
						+ folder.getAbsolutePath()
						+ " already exists and contains files.\nPlease delete this directory or delete its contents before continuing.");
	}
}