package scripts;

import java.io.File;
import java.io.IOException;

public class NoFolderException extends IOException {
	public NoFolderException(File folder) {
		super(
				"The directory: "
						+ folder.getAbsolutePath()
						+ " is empty or does not exist.");
	}
}