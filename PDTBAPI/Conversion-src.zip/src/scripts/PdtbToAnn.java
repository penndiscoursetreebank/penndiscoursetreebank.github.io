package scripts;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;

import edu.upenn.cis.anntool.settings.Constants;
import edu.upenn.cis.anntool.util.Relation;
import edu.upenn.cis.pdtb.PDTBAltLexRelation;
import edu.upenn.cis.pdtb.PDTBEntityRelation;
import edu.upenn.cis.pdtb.PDTBExplicitRelation;
import edu.upenn.cis.pdtb.PDTBImplicitRelation;
import edu.upenn.cis.pdtb.PDTBNoRelation;
import edu.upenn.cis.pdtb.PDTBNode;
import edu.upenn.cis.pdtb.PDTBRelationListImpl;
import edu.upenn.cis.pdtb.util.PDTBTask;
import gui.ProgressBar;

public class PdtbToAnn {

	public static void run(String rawRoot, String ptbRoot, String pdtbRoot,
			String annRoot, ProgressBar progressBar) throws IOException {
		Settings.rawRoot = rawRoot;
		Settings.ptbRoot = ptbRoot;
		Settings.pdtbRoot = pdtbRoot;
		Settings.annRoot = annRoot;

		System.out.println("RawRoot: " + Settings.rawRoot);
		System.out.println("PtbRoot: " + Settings.ptbRoot);
		System.out.println("PdtbRoot: " + Settings.pdtbRoot);
		System.out.println("AnnRoot: " + Settings.annRoot);

		File annDir = new File(Settings.annRoot);
		FileExceptions.exceptionIfFolderContains(Settings.annRoot);
		annDir.mkdirs();

		for (PDTBTask task = new PDTBTask(Settings.rawRoot, Settings.ptbRoot,
				Settings.pdtbRoot); task.hasNext();) {
			PDTBRelationListImpl relList = (PDTBRelationListImpl) task.next();
			String secNo = task.getSecNoStr();
			String fileNo = task.getFileNoStr();

			File outputSec = new File(annDir, secNo);
			outputSec.mkdirs();
			File outFile = new File(outputSec, "wsj_" + secNo + fileNo);
			Writer writer = new BufferedWriter(new FileWriter(outFile));

			for (Enumeration children = relList.children(); children
					.hasMoreElements();) {
				PDTBNode pdtbNode = (PDTBNode) children.nextElement();
				String[] vals = new String[Constants.LABELS.values().length];
				if (pdtbNode instanceof PDTBExplicitRelation) {
					PDTBExplicitRelation rel = (PDTBExplicitRelation) pdtbNode;
					vals[Constants.LABELS.rel.ordinal()] = Constants.RELTYPELABELS.Explicit
							.toString();
					vals[Constants.LABELS.connSpanList.ordinal()] = rel
							.getSelection().getSpans().toString();
					vals[Constants.LABELS.connAttrSrc.ordinal()] = rel
							.getFeatures().getSource().toString();
					vals[Constants.LABELS.connAttrType.ordinal()] = rel
							.getFeatures().getType().toString();
					vals[Constants.LABELS.connAttrPol.ordinal()] = rel
							.getFeatures().getPolarity().toString();
					vals[Constants.LABELS.connAttrDet.ordinal()] = rel
							.getFeatures().getDeterminancy().toString();
					if (rel.getFeatures().getSelection() != null) {
						vals[Constants.LABELS.connAttrSpanList.ordinal()] = rel
								.getFeatures().getSelection().getSpans()
								.toString();
					}
					vals[Constants.LABELS.sClass1A.ordinal()] = rel
							.getFeatures().getSClassA().getValue();
					if (rel.getFeatures().getSClassB() != null) {
						vals[Constants.LABELS.sClass1B.ordinal()] = rel
								.getFeatures().getSClassB().getValue();
					}
					if (rel.getSup1() != null) {
						vals[Constants.LABELS.sup1SpanList.ordinal()] = rel
								.getSup1().getSelection().getSpans().toString();
					}
					vals[Constants.LABELS.arg1SpanList.ordinal()] = rel
							.getArg1().getSelection().getSpans().toString();
					vals[Constants.LABELS.arg1AttrSrc.ordinal()] = rel
							.getArg1().getFeatures().getSource().toString();
					vals[Constants.LABELS.arg1AttrType.ordinal()] = rel
							.getArg1().getFeatures().getType().toString();
					vals[Constants.LABELS.arg1AttrPol.ordinal()] = rel
							.getArg1().getFeatures().getPolarity().toString();
					vals[Constants.LABELS.arg1AttrDet.ordinal()] = rel
							.getArg1().getFeatures().getDeterminancy()
							.toString();
					if (rel.getArg1().getFeatures().getSelection() != null) {
						vals[Constants.LABELS.arg1AttrSpanList.ordinal()] = rel
								.getArg1().getFeatures().getSelection()
								.getSpans().toString();
					}
					vals[Constants.LABELS.arg2SpanList.ordinal()] = rel
							.getArg2().getSelection().getSpans().toString();
					vals[Constants.LABELS.arg2AttrSrc.ordinal()] = rel
							.getArg2().getFeatures().getSource().toString();
					vals[Constants.LABELS.arg2AttrType.ordinal()] = rel
							.getArg2().getFeatures().getType().toString();
					vals[Constants.LABELS.arg2AttrPol.ordinal()] = rel
							.getArg2().getFeatures().getPolarity().toString();
					vals[Constants.LABELS.arg2AttrDet.ordinal()] = rel
							.getArg2().getFeatures().getDeterminancy()
							.toString();
					if (rel.getArg2().getFeatures().getSelection() != null) {
						vals[Constants.LABELS.arg2AttrSpanList.ordinal()] = rel
								.getArg2().getFeatures().getSelection()
								.getSpans().toString();
					}
					if (rel.getSup2() != null) {
						vals[Constants.LABELS.sup2SpanList.ordinal()] = rel
								.getSup2().getSelection().getSpans().toString();
					}
				} else if (pdtbNode instanceof PDTBImplicitRelation) {
					PDTBImplicitRelation rel = (PDTBImplicitRelation) pdtbNode;
					vals[Constants.LABELS.rel.ordinal()] = Constants.RELTYPELABELS.Implicit
							.toString();
					vals[Constants.LABELS.connAttrSrc.ordinal()] = rel
							.getFeatures().getSource().toString();
					vals[Constants.LABELS.connAttrType.ordinal()] = rel
							.getFeatures().getType().toString();
					vals[Constants.LABELS.connAttrPol.ordinal()] = rel
							.getFeatures().getPolarity().toString();
					vals[Constants.LABELS.connAttrDet.ordinal()] = rel
							.getFeatures().getDeterminancy().toString();
					if (rel.getFeatures().getSelection() != null) {
						vals[Constants.LABELS.connAttrSpanList.ordinal()] = rel
								.getFeatures().getSelection().getSpans()
								.toString();
					}
					vals[Constants.LABELS.conn1.ordinal()] = rel.getFeatures()
							.getConn1();
					vals[Constants.LABELS.sClass1A.ordinal()] = rel
							.getFeatures().getSClass1A().getValue();
					if (rel.getFeatures().getSClass1B() != null) {
						vals[Constants.LABELS.sClass1B.ordinal()] = rel
								.getFeatures().getSClass1B().getValue();
					}
					if (rel.getFeatures().getConn2() != null) {
						vals[Constants.LABELS.conn2.ordinal()] = rel
								.getFeatures().getConn2();
						vals[Constants.LABELS.sClass2A.ordinal()] = rel
								.getFeatures().getSClass2A().getValue();
						if (rel.getFeatures().getSClass2B() != null) {
							vals[Constants.LABELS.sClass2B.ordinal()] = rel
									.getFeatures().getSClass2B().getValue();
						}
					}
					if (rel.getSup1() != null) {
						vals[Constants.LABELS.sup1SpanList.ordinal()] = rel
								.getSup1().getSelection().getSpans().toString();
					}
					vals[Constants.LABELS.arg1SpanList.ordinal()] = rel
							.getArg1().getSelection().getSpans().toString();
					vals[Constants.LABELS.arg1AttrSrc.ordinal()] = rel
							.getArg1().getFeatures().getSource().toString();
					vals[Constants.LABELS.arg1AttrType.ordinal()] = rel
							.getArg1().getFeatures().getType().toString();
					vals[Constants.LABELS.arg1AttrPol.ordinal()] = rel
							.getArg1().getFeatures().getPolarity().toString();
					vals[Constants.LABELS.arg1AttrDet.ordinal()] = rel
							.getArg1().getFeatures().getDeterminancy()
							.toString();
					if (rel.getArg1().getFeatures().getSelection() != null) {
						vals[Constants.LABELS.arg1AttrSpanList.ordinal()] = rel
								.getArg1().getFeatures().getSelection()
								.getSpans().toString();
					}
					vals[Constants.LABELS.arg2SpanList.ordinal()] = rel
							.getArg2().getSelection().getSpans().toString();
					vals[Constants.LABELS.arg2AttrSrc.ordinal()] = rel
							.getArg2().getFeatures().getSource().toString();
					vals[Constants.LABELS.arg2AttrType.ordinal()] = rel
							.getArg2().getFeatures().getType().toString();
					vals[Constants.LABELS.arg2AttrPol.ordinal()] = rel
							.getArg2().getFeatures().getPolarity().toString();
					vals[Constants.LABELS.arg2AttrDet.ordinal()] = rel
							.getArg2().getFeatures().getDeterminancy()
							.toString();
					if (rel.getArg2().getFeatures().getSelection() != null) {
						vals[Constants.LABELS.arg2AttrSpanList.ordinal()] = rel
								.getArg2().getFeatures().getSelection()
								.getSpans().toString();
					}
					if (rel.getSup2() != null) {
						vals[Constants.LABELS.sup2SpanList.ordinal()] = rel
								.getSup2().getSelection().getSpans().toString();
					}
				} else if (pdtbNode instanceof PDTBAltLexRelation) {
					PDTBAltLexRelation rel = (PDTBAltLexRelation) pdtbNode;
					vals[Constants.LABELS.rel.ordinal()] = Constants.RELTYPELABELS.AltLex
							.toString();
					vals[Constants.LABELS.connSpanList.ordinal()] = rel
							.getSelection().getSpans().toString();
					vals[Constants.LABELS.connAttrSrc.ordinal()] = rel
							.getFeatures().getSource().toString();
					vals[Constants.LABELS.connAttrType.ordinal()] = rel
							.getFeatures().getType().toString();
					vals[Constants.LABELS.connAttrPol.ordinal()] = rel
							.getFeatures().getPolarity().toString();
					vals[Constants.LABELS.connAttrDet.ordinal()] = rel
							.getFeatures().getDeterminancy().toString();
					if (rel.getFeatures().getSelection() != null) {
						vals[Constants.LABELS.connAttrSpanList.ordinal()] = rel
								.getFeatures().getSelection().getSpans()
								.toString();
					}
					vals[Constants.LABELS.sClass1A.ordinal()] = rel
							.getFeatures().getSClassA().getValue();
					if (rel.getFeatures().getSClassB() != null) {
						vals[Constants.LABELS.sClass1B.ordinal()] = rel
								.getFeatures().getSClassB().getValue();
					}
					if (rel.getSup1() != null) {
						vals[Constants.LABELS.sup1SpanList.ordinal()] = rel
								.getSup1().getSelection().getSpans().toString();
					}
					vals[Constants.LABELS.arg1SpanList.ordinal()] = rel
							.getArg1().getSelection().getSpans().toString();
					vals[Constants.LABELS.arg1AttrSrc.ordinal()] = rel
							.getArg1().getFeatures().getSource().toString();
					vals[Constants.LABELS.arg1AttrType.ordinal()] = rel
							.getArg1().getFeatures().getType().toString();
					vals[Constants.LABELS.arg1AttrPol.ordinal()] = rel
							.getArg1().getFeatures().getPolarity().toString();
					vals[Constants.LABELS.arg1AttrDet.ordinal()] = rel
							.getArg1().getFeatures().getDeterminancy()
							.toString();
					if (rel.getArg1().getFeatures().getSelection() != null) {
						vals[Constants.LABELS.arg1AttrSpanList.ordinal()] = rel
								.getArg1().getFeatures().getSelection()
								.getSpans().toString();
					}
					vals[Constants.LABELS.arg2SpanList.ordinal()] = rel
							.getArg2().getSelection().getSpans().toString();
					vals[Constants.LABELS.arg2AttrSrc.ordinal()] = rel
							.getArg2().getFeatures().getSource().toString();
					vals[Constants.LABELS.arg2AttrType.ordinal()] = rel
							.getArg2().getFeatures().getType().toString();
					vals[Constants.LABELS.arg2AttrPol.ordinal()] = rel
							.getArg2().getFeatures().getPolarity().toString();
					vals[Constants.LABELS.arg2AttrDet.ordinal()] = rel
							.getArg2().getFeatures().getDeterminancy()
							.toString();
					if (rel.getArg2().getFeatures().getSelection() != null) {
						vals[Constants.LABELS.arg2AttrSpanList.ordinal()] = rel
								.getArg2().getFeatures().getSelection()
								.getSpans().toString();
					}
					if (rel.getSup2() != null) {
						vals[Constants.LABELS.sup2SpanList.ordinal()] = rel
								.getSup2().getSelection().getSpans().toString();
					}
				} else if (pdtbNode instanceof PDTBNoRelation) {
					PDTBNoRelation rel = (PDTBNoRelation) pdtbNode;
					vals[Constants.LABELS.rel.ordinal()] = Constants.RELTYPELABELS.NoRel
							.toString();
					vals[Constants.LABELS.arg1SpanList.ordinal()] = rel
							.getArg1().getSelection().getSpans().toString();
					vals[Constants.LABELS.arg2SpanList.ordinal()] = rel
							.getArg2().getSelection().getSpans().toString();
				} else if (pdtbNode instanceof PDTBEntityRelation) {
					PDTBEntityRelation rel = (PDTBEntityRelation) pdtbNode;
					vals[Constants.LABELS.rel.ordinal()] = Constants.RELTYPELABELS.EntRel
							.toString();
					vals[Constants.LABELS.arg1SpanList.ordinal()] = rel
							.getArg1().getSelection().getSpans().toString();
					vals[Constants.LABELS.arg2SpanList.ordinal()] = rel
							.getArg2().getSelection().getSpans().toString();
				} else {
					System.err.println("Bad Relation type.");
				}
				writeVals(writer, vals);
			}

			writer.flush();
			writer.close();

			if (progressBar != null) {
				progressBar.increment();
			}

		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		System.out.println("Usage: PdtbToAnn rawRoot ptbRoot pdtbRoot annRoot");
		if (args.length == 4) {
			run(args[0], args[1], args[2], args[3], null);
		} else {
			System.err.println("Invalid Arguments");
			System.exit(0);
		}
	}

	private static void writeVals(Writer writer, String[] vals)
			throws IOException {
		String toWrite = "";
		for (int i = 0; i < vals.length; i++) {
			if (vals[i] != null) {
				toWrite += vals[i];
			}
			if (i < vals.length - 1) {
				toWrite += Relation.sep;
			}
		}
		writer.write(toWrite + "\n");
	}
}
