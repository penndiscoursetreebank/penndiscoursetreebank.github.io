package scripts;
public class Settings {

	public static String pdtbRoot = "D:/work/corpora/pdtb2-0";

	public static String ptbRoot = "D:/work/corpora/combined";

	public static String sptbRoot = "D:/work/corpora/oldCorpora/SPTB/combined";

	public static String rawRoot = "D:/work/corpora/raw";

	public static String annRoot = "D:/work/corpora/ann";
	
	public static String tempDir = "D:/work/corpora/temp";
	
	public static String convFinal = "D:/work/corpora/convFinal";

	public static String connHeadFile = "D:/work/Conversion/ConnHeads.txt";
}
