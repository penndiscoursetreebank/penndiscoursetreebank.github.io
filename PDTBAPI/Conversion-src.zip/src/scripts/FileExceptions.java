package scripts;

import java.io.File;

public class FileExceptions {

	public static void exceptionIfFolderContains(String folder)
			throws FolderExistsException {
		if (folderContains(folder)) {
			throw new FolderExistsException(new File(folder));
		}
	}

	public static boolean folderContains(String folder) {
		File f = new File(folder);
		File[] fs = f.listFiles();
		return fs != null && fs.length > 0;
	}

	public static void exceptionIfNoFolder(String folder)
			throws NoFolderException {
		File f = new File(folder);
		if (f.listFiles() == null) {
			throw new NoFolderException(f);
		}
	}
}
