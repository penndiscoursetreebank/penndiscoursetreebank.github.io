package edu.upenn.cis.anntool.gui;

public interface PanelInterface {

	public void setFontName(String fontName);
	
}
