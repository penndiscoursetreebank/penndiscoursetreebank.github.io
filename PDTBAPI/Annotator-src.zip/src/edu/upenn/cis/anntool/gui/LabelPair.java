package edu.upenn.cis.anntool.gui;

import javax.swing.JLabel;

public interface LabelPair {
	public JLabel getLabel();
}


