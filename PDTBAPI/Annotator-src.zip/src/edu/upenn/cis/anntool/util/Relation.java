package edu.upenn.cis.anntool.util;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Pattern;

import edu.upenn.cis.anntool.gui.AnnComponent;
import edu.upenn.cis.anntool.settings.Constants.LABELS;
import edu.upenn.cis.anntool.settings.Constants.RELTYPELABELS;

public class Relation implements Comparable<Relation>, Transferable {

	public final static String sep = "|";
	private String[] originalVals;
	private FileManager fileManager;
	private String comment = "";
	private String root;
	private boolean isGhost = false;
	private List<Relation> adjudicationRelations = new ArrayList<Relation>();
	private int subGroupNumber = 1;
	private int groupNumber = -1;
	private boolean adjudicatedFlag = false;

	/**
	 * Used to create a new default Relation
	 * 
	 * @param rawText
	 */
	public Relation(FileManager fileManager) {
		this.fileManager = fileManager;
		originalVals = new String[LABELS.values().length];
		for (int i = 0; i < originalVals.length; i++) {
			originalVals[i] = "";
		}
	}

	/**
	 * Used by the connective search to create a relation based on the
	 * Connective Spans
	 * 
	 * @param rawText
	 * @param connSpan
	 */
	public Relation(FileManager fileManager, Span connSpan) {
		this.fileManager = fileManager;
		originalVals = new String[LABELS.values().length];
		for (int i = 0; i < originalVals.length; i++) {
			originalVals[i] = "";
		}
		originalVals[LABELS.connSpanList.ordinal()] = connSpan.toString();
		originalVals[LABELS.rel.ordinal()] = RELTYPELABELS.Explicit.toString();
	}

	/**
	 * Used to create a relation from a line in an annotation file
	 * 
	 * @param rawText
	 * @param line
	 * @param commentMap
	 */
	public Relation(FileManager fileManager, String line, Properties commentMap) {
		this.fileManager = fileManager;
		if (fileManager == null) {
			this.root = "";
		} else {
			this.root = fileManager.getAnnRoot();
		}
		originalVals = line.split(Pattern.quote(sep), LABELS.values().length);
		if (commentMap.containsKey(getRelationID())) {
			comment = commentMap.getProperty(getRelationID());
		}
		if (fileManager != null) {
			groupNumber = fileManager.getAdjudicationGroupManager()
					.getGroupNumber(this);
		}
	}

	/**
	 * Used to create a relation from a line in an adjudication file
	 * 
	 * @param rawText
	 * @param line
	 * @param commentMap
	 * @param root
	 */
	public Relation(FileManager fileManager, String line,
			Properties commentMap, String root) {
		this.fileManager = fileManager;
		this.root = root;
		originalVals = line.split(Pattern.quote(sep), LABELS.values().length);
		if (commentMap.containsKey(getRelationID())) {
			comment = commentMap.getProperty(getRelationID());
		}
		groupNumber = fileManager.getAdjudicationGroupManager().getGroupNumber(
				this);
	}

	/**
	 * Used to create a ghost copy
	 */
	public Relation(Relation relation) {
		this.isGhost = true;
		this.fileManager = relation.fileManager;
		this.originalVals = new String[LABELS.values().length];
		for (int i = 0; i < originalVals.length; i++) {
			originalVals[i] = "";
		}
		this.originalVals[LABELS.rel.ordinal()] = relation.originalVals[LABELS.rel
				.ordinal()];
		this.originalVals[LABELS.connSpanList.ordinal()] = relation.originalVals[LABELS.connSpanList
				.ordinal()];
		this.originalVals[LABELS.arg2SpanList.ordinal()] = relation.originalVals[LABELS.arg2SpanList
				.ordinal()];
		subGroupNumber = 0;
		groupNumber = relation.groupNumber;
	}

	public void copyFrom(Relation relation) {
		this.isGhost = false;
		this.subGroupNumber = 1;
		for (int i = 0; i < relation.originalVals.length; i++) {
			this.originalVals[i] = relation.originalVals[i];
		}
		this.root = fileManager.getAnnRoot();
	}

	public void setGroupNumber(int i) {
		groupNumber = i;
		for (Relation adjudication : adjudicationRelations) {
			adjudication.groupNumber = i;
		}
	}

	public boolean isGhost() {
		return isGhost;
	}

	public String getRoot() {
		return root;
	}

	public List<Relation> getAdjudications() {
		return adjudicationRelations;
	}

	public void clearAdjudications() {
		adjudicationRelations.clear();
	}

	public void addAdjudication(Relation adjudication) {
		if (isEquivalent(adjudication)) {
			adjudication.subGroupNumber = 1;
		} else {
			boolean matchFound = false;
			for (Relation relation : adjudicationRelations) {
				if (adjudication.isEquivalent(relation)) {
					adjudication.subGroupNumber = relation.subGroupNumber;
					matchFound = true;
					break;
				}
			}
			if (!matchFound) {
				if (adjudicationRelations.isEmpty() && isGhost) {
					adjudication.subGroupNumber = 1;
				} else if (adjudicationRelations.isEmpty()) {
					adjudication.subGroupNumber = 2;
				} else {
					adjudication.subGroupNumber = adjudicationRelations
							.get(adjudicationRelations.size() - 1).subGroupNumber + 1;
				}
			}
		}
		adjudicationRelations.add(adjudication);
	}

	public int getSubGroupNumber() {
		return subGroupNumber;
	}

	public void setComponents(AnnComponent[] components,
			AnnComponent commentPane) {
		for (int i = 0; i < components.length; i++) {
			components[i].setAnnValue(originalVals[i]);
		}
		commentPane.setAnnValue(comment);
	}

	/**
	 * Checks if every part of a relation is equal to every part of another
	 */
	public boolean isEquivalent(AnnComponent[] components,
			AnnComponent commentPane) {
		for (int i = 0; i < components.length; i++) {
			if ((components[i].getJComponent().isEnabled() || !originalVals[i]
					.equals(""))
					&& !components[i].getAnnValue().equals(originalVals[i])) {
				// System.out.println(LABELS.values()[i] + " original, new: "
				// + originalVals[i] + ", " + components[i].getAnnValue());
				return false;
			}
		}
		if (!commentPane.getAnnValue().equals(comment)) {
			// System.out.println("Comment: original, new: " + comment + ", "
			// + commentPane.getAnnValue());
			return false;
		}
		return true;
	}

	/**
	 * Checks if all annotations within the same group are completely equal
	 * 
	 * @return
	 */
	public boolean areAdjudicationsEquivalent() {
		for (Relation relation : adjudicationRelations) {
			if (!isEquivalent(relation)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks if every part of a relation is equal to every part of another
	 */
	public boolean isEquivalent(Relation other) {
		for (int i = 0; i < LABELS.values().length; i++) {
			if (!originalVals[i].equals(other.originalVals[i])) {
				return false;
			}
		}
		return true;
	}

	public void setNewVals(AnnComponent[] components, AnnComponent commentPane) {
		for (int i = 0; i < components.length; i++) {
			if (components[i].getJComponent().isEnabled()) {
				originalVals[i] = components[i].getAnnValue();
			} else {
				originalVals[i] = "";
			}
		}
		comment = commentPane.getAnnValue();
		isGhost = false;
		root = fileManager.getAnnRoot();
	}

	public String getTextLine() {
		String ret = "";
		for (int i = 0; i < originalVals.length; i++) {
			ret += originalVals[i];
			if (i < originalVals.length - 1) {
				ret += sep;
			}
		}
		return ret;
	}

	public String getComment() {
		if (!comment.equals("")) {
			return comment;
		}
		return null;
	}

	public String getRelationID() {
		return originalVals[LABELS.rel.ordinal()] + sep
				+ originalVals[LABELS.connSpanList.ordinal()] + sep
				+ originalVals[LABELS.arg1SpanList.ordinal()] + sep
				+ originalVals[LABELS.arg2SpanList.ordinal()];
	}

	public boolean isComplete() {
		boolean isComplete = true;
		String relType = originalVals[LABELS.rel.ordinal()];
		RELTYPELABELS relTypeLabel;
		try {
			relTypeLabel = RELTYPELABELS.valueOf(relType);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		switch (relTypeLabel) {
		case Explicit:
		case AltLex:
			isComplete &= !originalVals[LABELS.connSpanList.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.connAttrSrc.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.connAttrType.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.connAttrPol.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.connAttrDet.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1SpanList.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1AttrSrc.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1AttrType.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1AttrPol.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1AttrDet.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2SpanList.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2AttrSrc.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2AttrType.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2AttrPol.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2AttrDet.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.sClass1A.ordinal()].equals("");
			break;
		case Implicit:
			isComplete &= !originalVals[LABELS.connAttrSrc.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.connAttrType.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.connAttrPol.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.connAttrDet.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1SpanList.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1AttrSrc.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1AttrType.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1AttrPol.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg1AttrDet.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2SpanList.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2AttrSrc.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2AttrType.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2AttrPol.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2AttrDet.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.conn1.ordinal()].equals("");
			isComplete &= !originalVals[LABELS.sClass1A.ordinal()].equals("");
			// Slight simplification of logic 2011-10-17
			isComplete &= originalVals[LABELS.conn2.ordinal()].equals("")
					|| !originalVals[LABELS.sClass2A.ordinal()].equals("");
			break;
		case EntRel:
		case NoRel:
			isComplete &= !originalVals[LABELS.arg1SpanList.ordinal()]
					.equals("");
			isComplete &= !originalVals[LABELS.arg2SpanList.ordinal()]
					.equals("");
			break;
		}
		return isComplete;
	}

	private RELTYPELABELS getRelTypeLabel() {
		try {
			return RELTYPELABELS.valueOf(originalVals[LABELS.rel.ordinal()]);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public int getLocationStart() {
		RELTYPELABELS relTypeLabel = getRelTypeLabel();
		if (relTypeLabel == RELTYPELABELS.Explicit
				|| relTypeLabel == RELTYPELABELS.AltLex) {
			return getLocationStart(LABELS.connSpanList);
		} else {
			return getLocationStart(LABELS.arg2SpanList);
		}
	}

	private int getLocationStart(LABELS label) {
		SpanList spanList = new SpanList(originalVals[label.ordinal()]);
		if (spanList.size() > 0) {
			Span span = (Span) spanList.first();
			return span.getStart();
		} else {
			return 0;
		}
	}

	public int getLocationEnd() {
		RELTYPELABELS relTypeLabel = getRelTypeLabel();
		if (relTypeLabel == RELTYPELABELS.Explicit
				|| relTypeLabel == RELTYPELABELS.AltLex) {
			return getLocationEnd(LABELS.connSpanList);
		} else {
			return getLocationEnd(LABELS.arg2SpanList);
		}
	}

	private int getLocationEnd(LABELS label) {
		SpanList spanList = new SpanList(originalVals[label.ordinal()]);
		if (spanList.size() > 0) {
			Span span = (Span) spanList.last();
			return span.getEnd();
		} else {
			return 0;
		}
	}

	private int getLocationRelType() {
		return getRelTypeLabel().ordinal();
	}

	public int getGroupNumber() {
		return groupNumber;
	}

	/**
	 * Adjudications are grouped together if they are "similar"
	 * */
	public boolean isSimilar(Relation o) {
		
		if ((getRelTypeLabel() == RELTYPELABELS.Explicit || getRelTypeLabel() == RELTYPELABELS.AltLex)
				&& (o.getRelTypeLabel() == RELTYPELABELS.Explicit || o
						.getRelTypeLabel() == RELTYPELABELS.AltLex)
				&& ((getLocationStart() <= o.getLocationStart() && getLocationEnd() > o
						.getLocationStart()) || (o.getLocationStart() <= getLocationStart() && o
						.getLocationEnd() > getLocationStart()))) {
			return true;
		} else if ((getRelTypeLabel() == RELTYPELABELS.Implicit
				|| getRelTypeLabel() == RELTYPELABELS.EntRel || getRelTypeLabel() == RELTYPELABELS.NoRel)
				&& (o.getRelTypeLabel() == RELTYPELABELS.Implicit
						|| o.getRelTypeLabel() == RELTYPELABELS.EntRel || o
						.getRelTypeLabel() == RELTYPELABELS.NoRel)
				&& getLocationStart() == o.getLocationStart()) {
			return true;
		}
		
		
//		if (getRelTypeLabel() == o.getRelTypeLabel()
//				|| (getRelTypeLabel() != RELTYPELABELS.Explicit && o
//						.getRelTypeLabel() != RELTYPELABELS.Explicit)) {
//			return getLocationStart() == o.getLocationStart();
//		}

		// if (getRelTypeLabel() == o.getRelTypeLabel()) {
		// if (getRelTypeLabel() == RELTYPELABELS.Explicit
		// || getRelTypeLabel() == RELTYPELABELS.AltLex) {
		// return getLocationStart() == o.getLocationStart();
		// } else {
		// /**
		// * If both have sentence nos, compare those, otherwise compare
		// * arg2 start
		// */
		// String sentenceNo1 = originalVals[LABELS.connSpanList.ordinal()];
		// String sentenceNo2 = o.originalVals[LABELS.connSpanList
		// .ordinal()];
		// if (sentenceNo1.equals("") || sentenceNo2.equals("")) {
		// return getLocationStart() == o.getLocationStart();
		// } else {
		// return sentenceNo1.equals(sentenceNo2);
		// }
		// }
		// }
		return false;
	}

	public int compareToDebugging(Relation o) {
		/* Current grouping */
		// if (getRelTypeLabel() == o.getRelTypeLabel()
		// || (getRelTypeLabel() != RELTYPELABELS.Explicit && o
		// .getRelTypeLabel() != RELTYPELABELS.Explicit)) {
		// return getLocationStart() - o.getLocationStart();
		// } else {
		// return -1;
		// }
		/* Just the starts */
		// return getLocationStart() - o.getLocationStart();
		/* AltLex/Expl vs Others */

		/* Explicits and Altlexs together */

		// if (getLocationStart() != o.getLocationStart()) {
		// return getLocationStart() - o.getLocationStart();
		// } else if (((getRelTypeLabel() == RELTYPELABELS.Explicit ||
		// getRelTypeLabel() == RELTYPELABELS.AltLex) && (o
		// .getRelTypeLabel() != RELTYPELABELS.Explicit && o
		// .getRelTypeLabel() != RELTYPELABELS.AltLex))
		// || (getRelTypeLabel() != RELTYPELABELS.Explicit
		// && getRelTypeLabel() != RELTYPELABELS.AltLex && (o
		// .getRelTypeLabel() == RELTYPELABELS.Explicit || o
		// .getRelTypeLabel() == RELTYPELABELS.AltLex))) {
		// return getLocationRelType() - o.getLocationRelType();
		// } else {
		// return 0;
		// }

		if ((getRelTypeLabel() == RELTYPELABELS.Explicit || getRelTypeLabel() == RELTYPELABELS.AltLex)
				&& (o.getRelTypeLabel() == RELTYPELABELS.Explicit || o
						.getRelTypeLabel() == RELTYPELABELS.AltLex)
				&& ((getLocationStart() <= o.getLocationStart() && getLocationEnd() > o
						.getLocationStart()) || (o.getLocationStart() <= getLocationStart() && o
						.getLocationEnd() > getLocationStart()))) {
			return 0;
		} else if ((getRelTypeLabel() == RELTYPELABELS.Implicit
				|| getRelTypeLabel() == RELTYPELABELS.EntRel || getRelTypeLabel() == RELTYPELABELS.NoRel)
				&& (o.getRelTypeLabel() == RELTYPELABELS.Implicit
						|| o.getRelTypeLabel() == RELTYPELABELS.EntRel || o
						.getRelTypeLabel() == RELTYPELABELS.NoRel)
				&& getLocationStart() == o.getLocationStart()) {
			return 0;
		} else {
			return -1;
		}

	}

	// @Override
	/**
	 * Used for sorting relations. negative if o is bigger If a duplicate
	 * relation is created, it does not save the relation and moves selection to
	 * the duplicate
	 */
	public int compareTo(Relation o) {
		if (getLocationStart() != o.getLocationStart()) {
			return getLocationStart() - o.getLocationStart();
		} /*
		 * else if (getLocationRelType() != o.getLocationRelType()) { return
		 * getLocationRelType() - o.getLocationRelType(); }
		 */
		else if ((getRelTypeLabel() == RELTYPELABELS.Explicit && o
				.getRelTypeLabel() != RELTYPELABELS.Explicit)
				|| (getRelTypeLabel() != RELTYPELABELS.Explicit && o
						.getRelTypeLabel() == RELTYPELABELS.Explicit)) {
			return getLocationRelType() - o.getLocationRelType();
		} else {
			return 0;
		}
	}

	/**
	 * Used by the contains method to see if a relation is already in the
	 * relation list. Not a full compare. Compares using the relation type and
	 * conn/arg2 starts
	 */
	@Override
	public boolean equals(Object o) {
		// System.out.println("Relation.equals on: " + o);
		if (o == null) {
			return false;
		}
		return compareTo((Relation) o) == 0;
	}

	// TODO: This has to be fixed for tokenization
	@Override
	public String toString() {

		String ret = "";

		/**
		 * Get group number
		 */
		ret += "(" + subGroupNumber + ") ";

		/**
		 * Get Annotation directory
		 */
		if (root != null) {
			final int rootTextLength = 16;
			ret += root.length() <= rootTextLength ? root : "..."
					+ root.substring(root.length() - rootTextLength + 3);
			ret += " - ";
		}

		/**
		 * Get Relation location
		 */
		ret += getLocationStart() + ": ";

		/**
		 * Get relation type
		 */
		if (isGhost()) {
			ret += getChildrenValues(LABELS.rel);
		} else {
			ret += originalVals[LABELS.rel.ordinal()];
		}

		/**
		 * Get Connective
		 */
		if (isGhost) {
			Set<String> childrenValues = new HashSet<String>();
			for (Relation relation : adjudicationRelations) {
				String val = relation.getConnString();
				if (!val.equals("")) {
					childrenValues.add(val);
				}
			}
			String childConns = "";
			for (Iterator<String> i = childrenValues.iterator(); i.hasNext();) {
				childConns += i.next() + "/";
			}
			if (!childConns.equals("")) {
				childConns = childConns.substring(0, childConns.length() - 1);
				ret += " - " + childConns;
			}
		} else {
			String conn = getConnString();
			if (!conn.equals("")) {
				ret += " - " + conn;
			}
		}

		/**
		 * Get SClasses
		 */
		if (isGhost) {
			String val;
			val = getChildrenValues(LABELS.sClass1A);
			if (!val.equals("")) {
				ret += " - " + val;
			}
			val = getChildrenValues(LABELS.sClass1B);
			if (!val.equals("")) {
				ret += " - " + val;
			}
			val = getChildrenValues(LABELS.sClass2A);
			if (!val.equals("")) {
				ret += " - " + val;
			}
			val = getChildrenValues(LABELS.sClass2B);
			if (!val.equals("")) {
				ret += " - " + val;
			}
		} else {
			String val;
			val = originalVals[LABELS.sClass1A.ordinal()];
			if (!val.equals("")) {
				ret += " - " + val;
			}
			val = originalVals[LABELS.sClass1B.ordinal()];
			if (!val.equals("")) {
				ret += " - " + val;
			}
			val = originalVals[LABELS.sClass2A.ordinal()];
			if (!val.equals("")) {
				ret += " - " + val;
			}
			val = originalVals[LABELS.sClass2B.ordinal()];
			if (!val.equals("")) {
				ret += " - " + val;
			}
		}

		/**
		 * Get arg1
		 */
		if (isGhost()) {
			ret += " - " + getChildrenValues(LABELS.arg1SpanList);
		} else {
			ret += " - " + originalVals[LABELS.arg1SpanList.ordinal()];
		}

		/**
		 * Get arg2
		 */
		if (isGhost()) {
			ret += " , " + getChildrenValues(LABELS.arg2SpanList);
		} else {
			ret += " , " + originalVals[LABELS.arg2SpanList.ordinal()];
		}

		return ret;
	}

	public String getConnString() {
		String ret = "";
		RELTYPELABELS relTypeLabel = RELTYPELABELS
				.valueOf(originalVals[LABELS.rel.ordinal()]);
		switch (relTypeLabel) {
		case Explicit:
		case AltLex:
			SpanList spanList = new SpanList(
					originalVals[LABELS.connSpanList.ordinal()]);
			for (Iterator<Span> i = spanList.iterator(); i.hasNext();) {
				Span span = i.next();
				Span detokenizedSpan = fileManager.getIndexSpanMap()
						.tokenToChar(span);
				ret += fileManager
						.getRawText()
						.substring(detokenizedSpan.getStart(),
								detokenizedSpan.getEnd()).toLowerCase();
			}
			break;
		case Implicit:
			ret += originalVals[LABELS.conn1.ordinal()];
			break;
		}
		return ret;
	}

	private String getChildrenValues(LABELS label) {
		Set<String> childrenValues = new HashSet<String>();
		for (Relation relation : adjudicationRelations) {
			String val = relation.originalVals[label.ordinal()];
			if (!val.equals("")) {
				childrenValues.add(val);
			}
		}
		String ret = "";
		for (Iterator<String> i = childrenValues.iterator(); i.hasNext();) {
			ret += i.next() + "/";
		}
		if (!ret.equals("")) {
			ret = ret.substring(0, ret.length() - 1);
		}
		return ret;
	}

	public static final DataFlavor flavor = new DataFlavor(Relation.class,
			Relation.class.getName());

	public Object getTransferData(DataFlavor flavor)
			throws UnsupportedFlavorException, IOException {
		if (flavor.equals(flavor)) {
			return this;
		}
		throw new UnsupportedFlavorException(flavor);
	}

	public DataFlavor[] getTransferDataFlavors() {
		return new DataFlavor[] { flavor };
	}

	public boolean isDataFlavorSupported(DataFlavor flavor) {
		return flavor.equals(flavor);
	}

}
