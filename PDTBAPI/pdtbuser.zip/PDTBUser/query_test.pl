#!/usr/bin/perl

use File::Basename;

#################################################################
## This program is provided under the Common Public
## License 1.0. The full license is in:
##
## htDocs/license
##
## It is important to note that:
##
## THIS PROGRAM IS PROVIDED ON AN "AS IS" BASIS, WITHOUT
## WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR
## IMPLIED INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES OR
## CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR
## FITNESS FOR A PARTICULAR PURPOSE. Each Recipient is solely
## responsible for determining the appropriateness of using and
## distributing the Program and assumes all risks associated with
## its exercise of rights under this Agreement, including but not
## limited to the risks and costs of program errors, compliance
## with applicable laws, damage to or loss of data, programs or
## equipment, and unavailability or interruption of operations.
#################################################################


###################################################
## Example XPath Queries. Uncomment the appropriate
## lines to run a query. The output of the query
## will be stored in the directory QueryOut, under
## the directory in which this script resides. This
## directory will be erased prior to each run.
###################################################

####################
## Simple Queries ##
####################


## (1) All instances of because.

$Query = ">::*[child::Arg1[\@factuality='NonFact'] and child::Arg2[not(\@factuality='NonFact')]]";


## (2) Modified Connectives.

# $Query = ">::*[\@connHead='if' and contains(\@rawText,'even')]";



## (3) Sentence Initial Connectives.


# $Query = ">::*[\@connHead='also' and contains(\@rawText,'Also')]"; 


## (4) 'If' with 'not' in Arg2.

# $Query = ">::*[\@connHead='if' and 
#               child::Arg2[regexp(\@rawText,'.*\\W*not\\W*.*')]]";


## (5) 'If' followed anywhere by 'otherwise'.

# $Query = ">::*[(\@connHead='if' and 
#               \$>::*[\@connHead='otherwise']) or 
#              (\@connHead='otherwise' and 
#              <\$::*[\@connHead='if'])]";



## (6) 'If' immediately followed by 'otherwise', 'but', or 'however'

# $Conn1="(\@connHead='if')";

# $Conn2="(\@connHead='otherwise' or \@connHead='but' or \@connHead='however')";

# $Query = ">::*[($Conn1 and 
#                \$>::*[$Conn2 and position()=1]) or 
#               ($Conn1 and 
#                <\$::*[$Conn1 and position()=1])]";


## (7) Implicit relations with Causal and Additional Information classes 

# $Query = ">::ImplicitRelation[attribute::*[string()='Cause'] and 
#                              attribute::*[string()='Add.Info']]";


## (8) Relations with Sups

# $Query = ">::*[child::Sup1 or child::Sup2]";



####################################################
## Queries using the span functionality. See      ##
## htdocs/xpathextensions.html for an explanation.##
## See the cached versions below for how to make  ##
## these more efficient                           ##
####################################################

## (9) Nested Relations

# $Query = ">::*[comp-splist('is-contained-by',
#                            />>::*[is-arg()],
#                            'uc-uns') or
#                 >::*[is-arg() and
#                      comp-splist('contains',
#                                  />>::*[is-rel()],
#                                  'uc-uns')
#                ]]";


## (10) Shared Argument 
## (See (17a) for a softer notion of identity)

# $Query = ">::*[>::*[is-arg() and 
#                      comp-splist('identity',
#                                  />>::*[is-arg()],
#                                  'uc-uns')
#                      ]]";

## (11) Properly Contained Argument 
## (See (18a) for a softer notion of containment)

#  $Query = ">::*[>::*[is-arg() and 
#                      (
#                       comp-splist('contains',
#                                   />>::*[is-arg()],
#                                   'ei') or
#                       comp-splist('is-contained-by',
#                                   />>::*[is-arg()],
#                                   'ei')
#                       )
#                 ]]";




## (12) Pure Crossing

# $Query = ">::*[comp-splist('range-crosses',
#                            >::*[is-rel()],
#                             'uc-uns-eo')
#               ]";


## (13) Partial Overlap

#  $Query = ">::*[>::*[is-arg() and
#                      comp-splist('overlaps',
#                                  />>::*[is-arg()],
#                                  'uc-uns-ero')
#                ]]";


#####################
### Span list size ##
#####################

## (14) Discontinuous connectives

# $Query = ">::*[splist-size() > 1]";

#####################
## Delimited Text ###
#####################

## (15) Same as (14)

# $Query = ">::*[contains(delim-text(),'####')]";


###################################
## Cached versions of positional ##
## queries. Much more efficient  ##
## than the earlier forms.       ##
###################################


## (16) Nested Relations

#  $Query = ">::*[comp-splist('is-contained-by',
#                             cache({
#                                    />>::*[is-arg()]
#                                   }), 
#                             'uc-uns') or 
#                  >::*[is-arg() and 
#                       comp-splist('contains',
#                                   cache({
#                                          />>::*[is-rel()]
#                                        }), 
#                                   'uc-uns')
#                 ]]";


## (17) Shared Argument

# $Query = ">::*[>::*[is-arg() and 
#                      comp-splist('identity',
#                                  cache({
#                                         />>::*[is-arg()]
#                                       }),
#                                  'uc-uns')
#                      ]]";


## (17a) Shared Argument with range-identity

#  $Query = ">::*[>::*[is-arg() and 
#                      comp-splist('range-identity',
#                                  cache({
#                                         />>::*[is-arg()]
#                                       }),
#                                  'uc-uns')
#                       ]]";




## (18) Properly Contained Argument

#  $Query = ">::*[>::*[is-arg() and 
#                      (
#                       comp-splist('contains',
#                                   cache({
#                                          />>::*[is-arg()]
#                                         }),
#                                   'ei') or
#                       comp-splist('is-contained-by',
#                                   cache({
#                                          />>::*[is-arg()]
#                                    }),
#                                   'ei')
#                       )
#                 ]]";


## (18a) Properly Contained Argument with ranges-over

#   $Query = ">::*[>::*[is-arg()  and
#                         (
#                          comp-splist('range-contains',
#                                      cache({
#                                             />>::*[is-arg()]
#                                           }),
#                                      'uc-uns-eri-emp') or
#                          comp-splist('is-range-contained-by',
#                                      cache({
#                                             />>::*[is-arg()]
#                                           }),
#                                       'uc-uns-eri-emp')
#                         )
#                       ]]";




## (19) Pure Crossing

# $Query = ">::*[comp-splist('range-crosses',
#                            cache({
#                                   >::*[is-rel()]
#                                 }),
#                             'uc-uns-eo')
#               ]";


## (20) Partial Overlap

# $Query = ">::*[>::*[is-arg() and 
#                     comp-splist('overlaps',
#                                 cache({
#                                        />>::*[is-arg()]
#                                      }),
#                                  'uc-uns-erc')
#               ]]";


## (21) "If" overlapping "otherwise"

# $Query=">::*[\@connHead='if' and 
#              comp-splist('overlaps',
#                          cache({
#                                 />>::*[\@connHead={otherwise}]
#                               }),
#                          'uc-uns')
#             ]";

############################################################
### Cache with caution. The following are not equivalent. ##
############################################################


## (22) Selects Arg1 with overlapping Arg2 within a relation.
##      Note that when a query selects an argument, the
##      relation is output. If you want just the argument, use
##      the API.

# $Query=">>::Arg1[comp-splist('overlaps',\$>::Arg2)]";


## (23) Selects nothing. It is a query to select Arg1 which overlaps with
##      Arg2 nodes which are following siblings of the RelationList, and this
##      has no siblings.

# $Query=">>::Arg1[comp-splist('overlaps',cache({\$>::Arg2}))]";



############################################
## Filtering explicit connectives by type ##
############################################


## (24) Adverbials which share an argument

#  $Query = ">::*[>::*[is-arg() and 
#                      ..[is-adv()] and
#                      comp-splist('range-identity',
#                                  cache({
#                                         />>::*[is-arg() and
#                                                ..[is-adv()]]
#                                       }),
#                                  'uc-uns')
#                       ]]";



## (25) Subordinating conjunctions which share an argument

#  $Query = ">::*[>::*[is-arg() and 
#                      ..[is-sc()] and
#                      comp-splist('range-identity',
#                                  cache({
#                                         />>::*[is-arg() and 
#                                                ..[is-sc()]]
#                                       }),
#                                  'uc-uns')
#                       ]]";


## (26) Subordinating conjunctions which share an argument
##      without a coordinating conjunction between them.
##      (Approximately)

# $NotNextToCC="(not(\$>::*[position()=1 and is-cc()]) and not(<\$::*[position()=1 and is-cc()]))";

#  $Query = ">::*[>::*[is-arg() and 
#                      ..[is-sc() and $NotNextToCC] and
#                      comp-splist('range-identity',
#                                  cache({
#                                         />>::*[is-arg() and 
#                                                ..[is-sc() and $NotNextToCC]]
#                                       }),
#                                  'uc-uns')
#                       ]]";



## Change to the directory the
## script is in, which should be
## the PDTBUser directory.
$PdtbUserDir = dirname($0);
chdir($PdtbUserDir);

if((-e "pdtb.jar" || -e "pdtbbrowser.jnlp") && (-e "run_query.pl")){
   ## Remove the prior query output.
   system("rm -Rf QueryOut");

   ## Invoke the run_query script.
   system("./run_query.pl QueryOut \"". $Query . "\"");

}
else{
   die "Please place this in the PDTBUser directory";

}

