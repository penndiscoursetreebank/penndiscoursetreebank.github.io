Windows:
Copy these files to your C:\WINDOWS\Fonts directory